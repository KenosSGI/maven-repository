/*
 * XML Type:  TE105105
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TE105105(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TE105105Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105
{
    private static final long serialVersionUID = 1L;
    
    public TE105105Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XDESC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDesc");
    private static final javax.xml.namespace.QName CPFAGTRIB$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPFAgTrib");
    private static final javax.xml.namespace.QName NPROCADM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nProcAdm");
    private static final javax.xml.namespace.QName CMOTIVO$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMotivo");
    private static final javax.xml.namespace.QName XMOTIVO$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xMotivo");
    
    
    /**
     * Gets the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc.Enum getXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc xgetXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc)get_store().find_element_user(XDESC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDesc" element
     */
    public void setXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc.Enum xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESC$0);
            }
            target.setEnumValue(xDesc);
        }
    }
    
    /**
     * Sets (as xml) the "xDesc" element
     */
    public void xsetXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc)get_store().add_element_user(XDESC$0);
            }
            target.set(xDesc);
        }
    }
    
    /**
     * Gets the "CPFAgTrib" element
     */
    public java.lang.String getCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPFAgTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CPFAgTrib" element
     */
    public void setCPFAgTrib(java.lang.String cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFAGTRIB$2);
            }
            target.setStringValue(cpfAgTrib);
        }
    }
    
    /**
     * Sets (as xml) the "CPFAgTrib" element
     */
    public void xsetCPFAgTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPFAGTRIB$2);
            }
            target.set(cpfAgTrib);
        }
    }
    
    /**
     * Gets the "nProcAdm" element
     */
    public java.lang.String getNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nProcAdm" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc xgetNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().find_element_user(NPROCADM$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "nProcAdm" element
     */
    public boolean isSetNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NPROCADM$4) != 0;
        }
    }
    
    /**
     * Sets the "nProcAdm" element
     */
    public void setNProcAdm(java.lang.String nProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NPROCADM$4);
            }
            target.setStringValue(nProcAdm);
        }
    }
    
    /**
     * Sets (as xml) the "nProcAdm" element
     */
    public void xsetNProcAdm(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc nProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().add_element_user(NPROCADM$4);
            }
            target.set(nProcAdm);
        }
    }
    
    /**
     * Unsets the "nProcAdm" element
     */
    public void unsetNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NPROCADM$4, 0);
        }
    }
    
    /**
     * Gets the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef.Enum getCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef xgetCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef)get_store().find_element_user(CMOTIVO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMotivo" element
     */
    public void setCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef.Enum cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMOTIVO$6);
            }
            target.setEnumValue(cMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "cMotivo" element
     */
    public void xsetCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef)get_store().find_element_user(CMOTIVO$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef)get_store().add_element_user(CMOTIVO$6);
            }
            target.set(cMotivo);
        }
    }
    
    /**
     * Gets the "xMotivo" element
     */
    public java.lang.String getXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xMotivo" element
     */
    public void setXMotivo(java.lang.String xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XMOTIVO$8);
            }
            target.setStringValue(xMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    public void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XMOTIVO$8);
            }
            target.set(xMotivo);
        }
    }
    /**
     * An XML xDesc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105$XDesc.
     */
    public static class XDescImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105.XDesc
    {
        private static final long serialVersionUID = 1L;
        
        public XDescImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected XDescImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
}
