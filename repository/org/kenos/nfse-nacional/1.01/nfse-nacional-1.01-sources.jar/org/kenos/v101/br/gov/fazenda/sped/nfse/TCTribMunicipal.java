/*
 * XML Type:  TCTribMunicipal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCTribMunicipal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCTribMunicipal extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCTribMunicipal.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tctribmunicipal8e9atype");
    
    /**
     * Gets the "tribISSQN" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN.Enum getTribISSQN();
    
    /**
     * Gets (as xml) the "tribISSQN" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN xgetTribISSQN();
    
    /**
     * Sets the "tribISSQN" element
     */
    void setTribISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN.Enum tribISSQN);
    
    /**
     * Sets (as xml) the "tribISSQN" element
     */
    void xsetTribISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN tribISSQN);
    
    /**
     * Gets the "cPaisResult" element
     */
    java.lang.String getCPaisResult();
    
    /**
     * Gets (as xml) the "cPaisResult" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO xgetCPaisResult();
    
    /**
     * True if has "cPaisResult" element
     */
    boolean isSetCPaisResult();
    
    /**
     * Sets the "cPaisResult" element
     */
    void setCPaisResult(java.lang.String cPaisResult);
    
    /**
     * Sets (as xml) the "cPaisResult" element
     */
    void xsetCPaisResult(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO cPaisResult);
    
    /**
     * Unsets the "cPaisResult" element
     */
    void unsetCPaisResult();
    
    /**
     * Gets the "tpImunidade" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN.Enum getTpImunidade();
    
    /**
     * Gets (as xml) the "tpImunidade" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN xgetTpImunidade();
    
    /**
     * True if has "tpImunidade" element
     */
    boolean isSetTpImunidade();
    
    /**
     * Sets the "tpImunidade" element
     */
    void setTpImunidade(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN.Enum tpImunidade);
    
    /**
     * Sets (as xml) the "tpImunidade" element
     */
    void xsetTpImunidade(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN tpImunidade);
    
    /**
     * Unsets the "tpImunidade" element
     */
    void unsetTpImunidade();
    
    /**
     * Gets the "exigSusp" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa getExigSusp();
    
    /**
     * True if has "exigSusp" element
     */
    boolean isSetExigSusp();
    
    /**
     * Sets the "exigSusp" element
     */
    void setExigSusp(org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa exigSusp);
    
    /**
     * Appends and returns a new empty "exigSusp" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa addNewExigSusp();
    
    /**
     * Unsets the "exigSusp" element
     */
    void unsetExigSusp();
    
    /**
     * Gets the "BM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal getBM();
    
    /**
     * True if has "BM" element
     */
    boolean isSetBM();
    
    /**
     * Sets the "BM" element
     */
    void setBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal bm);
    
    /**
     * Appends and returns a new empty "BM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal addNewBM();
    
    /**
     * Unsets the "BM" element
     */
    void unsetBM();
    
    /**
     * Gets the "tpRetISSQN" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN.Enum getTpRetISSQN();
    
    /**
     * Gets (as xml) the "tpRetISSQN" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN xgetTpRetISSQN();
    
    /**
     * Sets the "tpRetISSQN" element
     */
    void setTpRetISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN.Enum tpRetISSQN);
    
    /**
     * Sets (as xml) the "tpRetISSQN" element
     */
    void xsetTpRetISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN tpRetISSQN);
    
    /**
     * Gets the "pAliq" element
     */
    java.lang.String getPAliq();
    
    /**
     * Gets (as xml) the "pAliq" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 xgetPAliq();
    
    /**
     * True if has "pAliq" element
     */
    boolean isSetPAliq();
    
    /**
     * Sets the "pAliq" element
     */
    void setPAliq(java.lang.String pAliq);
    
    /**
     * Sets (as xml) the "pAliq" element
     */
    void xsetPAliq(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 pAliq);
    
    /**
     * Unsets the "pAliq" element
     */
    void unsetPAliq();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
