/*
 * XML Type:  TCRTCInfoDest
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoDest(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoDestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoDestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPF");
    private static final javax.xml.namespace.QName NIF$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "NIF");
    private static final javax.xml.namespace.QName CNAONIF$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cNaoNIF");
    private static final javax.xml.namespace.QName XNOME$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xNome");
    private static final javax.xml.namespace.QName END$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "end");
    private static final javax.xml.namespace.QName FONE$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fone");
    private static final javax.xml.namespace.QName EMAIL$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "email");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "NIF" element
     */
    public java.lang.String getNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF xgetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().find_element_user(NIF$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "NIF" element
     */
    public boolean isSetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NIF$4) != 0;
        }
    }
    
    /**
     * Sets the "NIF" element
     */
    public void setNIF(java.lang.String nif)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NIF$4);
            }
            target.setStringValue(nif);
        }
    }
    
    /**
     * Sets (as xml) the "NIF" element
     */
    public void xsetNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF nif)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().add_element_user(NIF$4);
            }
            target.set(nif);
        }
    }
    
    /**
     * Unsets the "NIF" element
     */
    public void unsetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NIF$4, 0);
        }
    }
    
    /**
     * Gets the "cNaoNIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum getCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cNaoNIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF xgetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().find_element_user(CNAONIF$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "cNaoNIF" element
     */
    public boolean isSetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNAONIF$6) != 0;
        }
    }
    
    /**
     * Sets the "cNaoNIF" element
     */
    public void setCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum cNaoNIF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNAONIF$6);
            }
            target.setEnumValue(cNaoNIF);
        }
    }
    
    /**
     * Sets (as xml) the "cNaoNIF" element
     */
    public void xsetCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF cNaoNIF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().add_element_user(CNAONIF$6);
            }
            target.set(cNaoNIF);
        }
    }
    
    /**
     * Unsets the "cNaoNIF" element
     */
    public void unsetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNAONIF$6, 0);
        }
    }
    
    /**
     * Gets the "xNome" element
     */
    public java.lang.String getXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xNome" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XNOME$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xNome" element
     */
    public void setXNome(java.lang.String xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XNOME$8);
            }
            target.setStringValue(xNome);
        }
    }
    
    /**
     * Sets (as xml) the "xNome" element
     */
    public void xsetXNome(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XNOME$8);
            }
            target.set(xNome);
        }
    }
    
    /**
     * Gets the "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco getEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco)get_store().find_element_user(END$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "end" element
     */
    public boolean isSetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(END$10) != 0;
        }
    }
    
    /**
     * Sets the "end" element
     */
    public void setEnd(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco end)
    {
        generatedSetterHelperImpl(end, END$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco addNewEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco)get_store().add_element_user(END$10);
            return target;
        }
    }
    
    /**
     * Unsets the "end" element
     */
    public void unsetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(END$10, 0);
        }
    }
    
    /**
     * Gets the "fone" element
     */
    public java.lang.String getFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fone" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone xgetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "fone" element
     */
    public boolean isSetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FONE$12) != 0;
        }
    }
    
    /**
     * Sets the "fone" element
     */
    public void setFone(java.lang.String fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FONE$12);
            }
            target.setStringValue(fone);
        }
    }
    
    /**
     * Sets (as xml) the "fone" element
     */
    public void xsetFone(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().add_element_user(FONE$12);
            }
            target.set(fone);
        }
    }
    
    /**
     * Unsets the "fone" element
     */
    public void unsetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FONE$12, 0);
        }
    }
    
    /**
     * Gets the "email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "email" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$14) != 0;
        }
    }
    
    /**
     * Sets the "email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$14);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "email" element
     */
    public void xsetEmail(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().add_element_user(EMAIL$14);
            }
            target.set(email);
        }
    }
    
    /**
     * Unsets the "email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$14, 0);
        }
    }
}
