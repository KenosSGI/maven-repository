/*
 * XML Type:  TCInfoDedRed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoDedRed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoDedRedImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoDedRedImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PDR$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pDR");
    private static final javax.xml.namespace.QName VDR$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDR");
    private static final javax.xml.namespace.QName DOCUMENTOS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "documentos");
    
    
    /**
     * Gets the "pDR" element
     */
    public java.lang.String getPDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pDR" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDR$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "pDR" element
     */
    public boolean isSetPDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PDR$0) != 0;
        }
    }
    
    /**
     * Sets the "pDR" element
     */
    public void setPDR(java.lang.String pdr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PDR$0);
            }
            target.setStringValue(pdr);
        }
    }
    
    /**
     * Sets (as xml) the "pDR" element
     */
    public void xsetPDR(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pdr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDR$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PDR$0);
            }
            target.set(pdr);
        }
    }
    
    /**
     * Unsets the "pDR" element
     */
    public void unsetPDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PDR$0, 0);
        }
    }
    
    /**
     * Gets the "vDR" element
     */
    public java.lang.String getVDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDR" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDR$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDR" element
     */
    public boolean isSetVDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDR$2) != 0;
        }
    }
    
    /**
     * Sets the "vDR" element
     */
    public void setVDR(java.lang.String vdr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDR$2);
            }
            target.setStringValue(vdr);
        }
    }
    
    /**
     * Sets (as xml) the "vDR" element
     */
    public void xsetVDR(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vdr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDR$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDR$2);
            }
            target.set(vdr);
        }
    }
    
    /**
     * Unsets the "vDR" element
     */
    public void unsetVDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDR$2, 0);
        }
    }
    
    /**
     * Gets the "documentos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed getDocumentos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed)get_store().find_element_user(DOCUMENTOS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "documentos" element
     */
    public boolean isSetDocumentos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENTOS$4) != 0;
        }
    }
    
    /**
     * Sets the "documentos" element
     */
    public void setDocumentos(org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed documentos)
    {
        generatedSetterHelperImpl(documentos, DOCUMENTOS$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "documentos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed addNewDocumentos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed)get_store().add_element_user(DOCUMENTOS$4);
            return target;
        }
    }
    
    /**
     * Unsets the "documentos" element
     */
    public void unsetDocumentos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENTOS$4, 0);
        }
    }
}
