/*
 * XML Type:  TCRTCListaDocFornec
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCListaDocFornec(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCListaDocFornecImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCListaDocFornecImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPF");
    private static final javax.xml.namespace.QName NIF$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "NIF");
    private static final javax.xml.namespace.QName CNAONIF$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cNaoNIF");
    private static final javax.xml.namespace.QName XNOME$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xNome");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "NIF" element
     */
    public java.lang.String getNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF xgetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().find_element_user(NIF$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "NIF" element
     */
    public boolean isSetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NIF$4) != 0;
        }
    }
    
    /**
     * Sets the "NIF" element
     */
    public void setNIF(java.lang.String nif)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NIF$4);
            }
            target.setStringValue(nif);
        }
    }
    
    /**
     * Sets (as xml) the "NIF" element
     */
    public void xsetNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF nif)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().find_element_user(NIF$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF)get_store().add_element_user(NIF$4);
            }
            target.set(nif);
        }
    }
    
    /**
     * Unsets the "NIF" element
     */
    public void unsetNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NIF$4, 0);
        }
    }
    
    /**
     * Gets the "cNaoNIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum getCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cNaoNIF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF xgetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().find_element_user(CNAONIF$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "cNaoNIF" element
     */
    public boolean isSetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNAONIF$6) != 0;
        }
    }
    
    /**
     * Sets the "cNaoNIF" element
     */
    public void setCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum cNaoNIF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNAONIF$6);
            }
            target.setEnumValue(cNaoNIF);
        }
    }
    
    /**
     * Sets (as xml) the "cNaoNIF" element
     */
    public void xsetCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF cNaoNIF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().find_element_user(CNAONIF$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF)get_store().add_element_user(CNAONIF$6);
            }
            target.set(cNaoNIF);
        }
    }
    
    /**
     * Unsets the "cNaoNIF" element
     */
    public void unsetCNaoNIF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNAONIF$6, 0);
        }
    }
    
    /**
     * Gets the "xNome" element
     */
    public java.lang.String getXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xNome" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XNOME$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xNome" element
     */
    public void setXNome(java.lang.String xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XNOME$8);
            }
            target.setStringValue(xNome);
        }
    }
    
    /**
     * Sets (as xml) the "xNome" element
     */
    public void xsetXNome(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XNOME$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XNOME$8);
            }
            target.set(xNome);
        }
    }
}
