/*
 * XML Type:  TCBeneficioMunicipal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCBeneficioMunicipal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCBeneficioMunicipal extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCBeneficioMunicipal.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcbeneficiomunicipalcd15type");
    
    /**
     * Gets the "nBM" element
     */
    java.lang.String getNBM();
    
    /**
     * Gets (as xml) the "nBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal xgetNBM();
    
    /**
     * Sets the "nBM" element
     */
    void setNBM(java.lang.String nbm);
    
    /**
     * Sets (as xml) the "nBM" element
     */
    void xsetNBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal nbm);
    
    /**
     * Gets the "vRedBCBM" element
     */
    java.lang.String getVRedBCBM();
    
    /**
     * Gets (as xml) the "vRedBCBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVRedBCBM();
    
    /**
     * True if has "vRedBCBM" element
     */
    boolean isSetVRedBCBM();
    
    /**
     * Sets the "vRedBCBM" element
     */
    void setVRedBCBM(java.lang.String vRedBCBM);
    
    /**
     * Sets (as xml) the "vRedBCBM" element
     */
    void xsetVRedBCBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vRedBCBM);
    
    /**
     * Unsets the "vRedBCBM" element
     */
    void unsetVRedBCBM();
    
    /**
     * Gets the "pRedBCBM" element
     */
    java.lang.String getPRedBCBM();
    
    /**
     * Gets (as xml) the "pRedBCBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedBCBM();
    
    /**
     * True if has "pRedBCBM" element
     */
    boolean isSetPRedBCBM();
    
    /**
     * Sets the "pRedBCBM" element
     */
    void setPRedBCBM(java.lang.String pRedBCBM);
    
    /**
     * Sets (as xml) the "pRedBCBM" element
     */
    void xsetPRedBCBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedBCBM);
    
    /**
     * Unsets the "pRedBCBM" element
     */
    void unsetPRedBCBM();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
