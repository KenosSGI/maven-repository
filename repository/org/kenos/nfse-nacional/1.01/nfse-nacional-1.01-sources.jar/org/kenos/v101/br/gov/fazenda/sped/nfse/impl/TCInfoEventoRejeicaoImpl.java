/*
 * XML Type:  TCInfoEventoRejeicao
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoRejeicao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoEventoRejeicao(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoEventoRejeicaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoRejeicao
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoEventoRejeicaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CMOTIVO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMotivo");
    private static final javax.xml.namespace.QName XMOTIVO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xMotivo");
    
    
    /**
     * Gets the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao.Enum getCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao xgetCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao)get_store().find_element_user(CMOTIVO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMotivo" element
     */
    public void setCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao.Enum cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMOTIVO$0);
            }
            target.setEnumValue(cMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "cMotivo" element
     */
    public void xsetCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao)get_store().find_element_user(CMOTIVO$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMotivoRejeicao)get_store().add_element_user(CMOTIVO$0);
            }
            target.set(cMotivo);
        }
    }
    
    /**
     * Gets the "xMotivo" element
     */
    public java.lang.String getXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "xMotivo" element
     */
    public boolean isSetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XMOTIVO$2) != 0;
        }
    }
    
    /**
     * Sets the "xMotivo" element
     */
    public void setXMotivo(java.lang.String xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XMOTIVO$2);
            }
            target.setStringValue(xMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    public void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XMOTIVO$2);
            }
            target.set(xMotivo);
        }
    }
    
    /**
     * Unsets the "xMotivo" element
     */
    public void unsetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XMOTIVO$2, 0);
        }
    }
}
