/*
 * XML Type:  TSNum14Dig
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum14Dig
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSNum14Dig(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum14Dig.
 */
public class TSNum14DigImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum14Dig
{
    private static final long serialVersionUID = 1L;
    
    public TSNum14DigImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSNum14DigImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
