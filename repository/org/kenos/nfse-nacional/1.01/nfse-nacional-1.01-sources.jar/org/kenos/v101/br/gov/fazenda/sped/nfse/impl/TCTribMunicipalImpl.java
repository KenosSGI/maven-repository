/*
 * XML Type:  TCTribMunicipal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribMunicipal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribMunicipalImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal
{
    private static final long serialVersionUID = 1L;
    
    public TCTribMunicipalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRIBISSQN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tribISSQN");
    private static final javax.xml.namespace.QName CPAISRESULT$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cPaisResult");
    private static final javax.xml.namespace.QName TPIMUNIDADE$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpImunidade");
    private static final javax.xml.namespace.QName EXIGSUSP$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "exigSusp");
    private static final javax.xml.namespace.QName BM$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "BM");
    private static final javax.xml.namespace.QName TPRETISSQN$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpRetISSQN");
    private static final javax.xml.namespace.QName PALIQ$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliq");
    
    
    /**
     * Gets the "tribISSQN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN.Enum getTribISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIBISSQN$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tribISSQN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN xgetTribISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN)get_store().find_element_user(TRIBISSQN$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tribISSQN" element
     */
    public void setTribISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN.Enum tribISSQN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIBISSQN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRIBISSQN$0);
            }
            target.setEnumValue(tribISSQN);
        }
    }
    
    /**
     * Sets (as xml) the "tribISSQN" element
     */
    public void xsetTribISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN tribISSQN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN)get_store().find_element_user(TRIBISSQN$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTribISSQN)get_store().add_element_user(TRIBISSQN$0);
            }
            target.set(tribISSQN);
        }
    }
    
    /**
     * Gets the "cPaisResult" element
     */
    public java.lang.String getCPaisResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPAISRESULT$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cPaisResult" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO xgetCPaisResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().find_element_user(CPAISRESULT$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "cPaisResult" element
     */
    public boolean isSetCPaisResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPAISRESULT$2) != 0;
        }
    }
    
    /**
     * Sets the "cPaisResult" element
     */
    public void setCPaisResult(java.lang.String cPaisResult)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPAISRESULT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPAISRESULT$2);
            }
            target.setStringValue(cPaisResult);
        }
    }
    
    /**
     * Sets (as xml) the "cPaisResult" element
     */
    public void xsetCPaisResult(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO cPaisResult)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().find_element_user(CPAISRESULT$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().add_element_user(CPAISRESULT$2);
            }
            target.set(cPaisResult);
        }
    }
    
    /**
     * Unsets the "cPaisResult" element
     */
    public void unsetCPaisResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPAISRESULT$2, 0);
        }
    }
    
    /**
     * Gets the "tpImunidade" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN.Enum getTpImunidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPIMUNIDADE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpImunidade" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN xgetTpImunidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN)get_store().find_element_user(TPIMUNIDADE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "tpImunidade" element
     */
    public boolean isSetTpImunidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPIMUNIDADE$4) != 0;
        }
    }
    
    /**
     * Sets the "tpImunidade" element
     */
    public void setTpImunidade(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN.Enum tpImunidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPIMUNIDADE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPIMUNIDADE$4);
            }
            target.setEnumValue(tpImunidade);
        }
    }
    
    /**
     * Sets (as xml) the "tpImunidade" element
     */
    public void xsetTpImunidade(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN tpImunidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN)get_store().find_element_user(TPIMUNIDADE$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoImunidadeISSQN)get_store().add_element_user(TPIMUNIDADE$4);
            }
            target.set(tpImunidade);
        }
    }
    
    /**
     * Unsets the "tpImunidade" element
     */
    public void unsetTpImunidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPIMUNIDADE$4, 0);
        }
    }
    
    /**
     * Gets the "exigSusp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa getExigSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa)get_store().find_element_user(EXIGSUSP$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "exigSusp" element
     */
    public boolean isSetExigSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXIGSUSP$6) != 0;
        }
    }
    
    /**
     * Sets the "exigSusp" element
     */
    public void setExigSusp(org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa exigSusp)
    {
        generatedSetterHelperImpl(exigSusp, EXIGSUSP$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "exigSusp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa addNewExigSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa)get_store().add_element_user(EXIGSUSP$6);
            return target;
        }
    }
    
    /**
     * Unsets the "exigSusp" element
     */
    public void unsetExigSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXIGSUSP$6, 0);
        }
    }
    
    /**
     * Gets the "BM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal getBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal)get_store().find_element_user(BM$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "BM" element
     */
    public boolean isSetBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BM$8) != 0;
        }
    }
    
    /**
     * Sets the "BM" element
     */
    public void setBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal bm)
    {
        generatedSetterHelperImpl(bm, BM$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "BM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal addNewBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal)get_store().add_element_user(BM$8);
            return target;
        }
    }
    
    /**
     * Unsets the "BM" element
     */
    public void unsetBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BM$8, 0);
        }
    }
    
    /**
     * Gets the "tpRetISSQN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN.Enum getTpRetISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPRETISSQN$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpRetISSQN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN xgetTpRetISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN)get_store().find_element_user(TPRETISSQN$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpRetISSQN" element
     */
    public void setTpRetISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN.Enum tpRetISSQN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPRETISSQN$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPRETISSQN$10);
            }
            target.setEnumValue(tpRetISSQN);
        }
    }
    
    /**
     * Sets (as xml) the "tpRetISSQN" element
     */
    public void xsetTpRetISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN tpRetISSQN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN)get_store().find_element_user(TPRETISSQN$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetISSQN)get_store().add_element_user(TPRETISSQN$10);
            }
            target.set(tpRetISSQN);
        }
    }
    
    /**
     * Gets the "pAliq" element
     */
    public java.lang.String getPAliq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQ$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliq" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 xgetPAliq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().find_element_user(PALIQ$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "pAliq" element
     */
    public boolean isSetPAliq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PALIQ$12) != 0;
        }
    }
    
    /**
     * Sets the "pAliq" element
     */
    public void setPAliq(java.lang.String pAliq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQ$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQ$12);
            }
            target.setStringValue(pAliq);
        }
    }
    
    /**
     * Sets (as xml) the "pAliq" element
     */
    public void xsetPAliq(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 pAliq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().find_element_user(PALIQ$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().add_element_user(PALIQ$12);
            }
            target.set(pAliq);
        }
    }
    
    /**
     * Unsets the "pAliq" element
     */
    public void unsetPAliq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PALIQ$12, 0);
        }
    }
}
