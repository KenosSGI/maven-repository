/*
 * XML Type:  TCRTCInfoIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCInfoIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCInfoIBSCBS extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCInfoIBSCBS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcrtcinfoibscbs3da8type");
    
    /**
     * Gets the "finNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.Enum getFinNFSe();
    
    /**
     * Gets (as xml) the "finNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe xgetFinNFSe();
    
    /**
     * Sets the "finNFSe" element
     */
    void setFinNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.Enum finNFSe);
    
    /**
     * Sets (as xml) the "finNFSe" element
     */
    void xsetFinNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe finNFSe);
    
    /**
     * Gets the "indFinal" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.Enum getIndFinal();
    
    /**
     * Gets (as xml) the "indFinal" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal xgetIndFinal();
    
    /**
     * True if has "indFinal" element
     */
    boolean isSetIndFinal();
    
    /**
     * Sets the "indFinal" element
     */
    void setIndFinal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.Enum indFinal);
    
    /**
     * Sets (as xml) the "indFinal" element
     */
    void xsetIndFinal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal indFinal);
    
    /**
     * Unsets the "indFinal" element
     */
    void unsetIndFinal();
    
    /**
     * Gets the "cIndOp" element
     */
    java.lang.String getCIndOp();
    
    /**
     * Gets (as xml) the "cIndOp" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp xgetCIndOp();
    
    /**
     * Sets the "cIndOp" element
     */
    void setCIndOp(java.lang.String cIndOp);
    
    /**
     * Sets (as xml) the "cIndOp" element
     */
    void xsetCIndOp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp cIndOp);
    
    /**
     * Gets the "tpOper" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper.Enum getTpOper();
    
    /**
     * Gets (as xml) the "tpOper" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper xgetTpOper();
    
    /**
     * True if has "tpOper" element
     */
    boolean isSetTpOper();
    
    /**
     * Sets the "tpOper" element
     */
    void setTpOper(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper.Enum tpOper);
    
    /**
     * Sets (as xml) the "tpOper" element
     */
    void xsetTpOper(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper tpOper);
    
    /**
     * Unsets the "tpOper" element
     */
    void unsetTpOper();
    
    /**
     * Gets the "gRefNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe getGRefNFSe();
    
    /**
     * True if has "gRefNFSe" element
     */
    boolean isSetGRefNFSe();
    
    /**
     * Sets the "gRefNFSe" element
     */
    void setGRefNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe gRefNFSe);
    
    /**
     * Appends and returns a new empty "gRefNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe addNewGRefNFSe();
    
    /**
     * Unsets the "gRefNFSe" element
     */
    void unsetGRefNFSe();
    
    /**
     * Gets the "tpEnteGov" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov.Enum getTpEnteGov();
    
    /**
     * Gets (as xml) the "tpEnteGov" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov xgetTpEnteGov();
    
    /**
     * True if has "tpEnteGov" element
     */
    boolean isSetTpEnteGov();
    
    /**
     * Sets the "tpEnteGov" element
     */
    void setTpEnteGov(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov.Enum tpEnteGov);
    
    /**
     * Sets (as xml) the "tpEnteGov" element
     */
    void xsetTpEnteGov(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov tpEnteGov);
    
    /**
     * Unsets the "tpEnteGov" element
     */
    void unsetTpEnteGov();
    
    /**
     * Gets the "indDest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest.Enum getIndDest();
    
    /**
     * Gets (as xml) the "indDest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest xgetIndDest();
    
    /**
     * Sets the "indDest" element
     */
    void setIndDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest.Enum indDest);
    
    /**
     * Sets (as xml) the "indDest" element
     */
    void xsetIndDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest indDest);
    
    /**
     * Gets the "dest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest getDest();
    
    /**
     * True if has "dest" element
     */
    boolean isSetDest();
    
    /**
     * Sets the "dest" element
     */
    void setDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest dest);
    
    /**
     * Appends and returns a new empty "dest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest addNewDest();
    
    /**
     * Unsets the "dest" element
     */
    void unsetDest();
    
    /**
     * Gets the "imovel" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel getImovel();
    
    /**
     * True if has "imovel" element
     */
    boolean isSetImovel();
    
    /**
     * Sets the "imovel" element
     */
    void setImovel(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel imovel);
    
    /**
     * Appends and returns a new empty "imovel" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel addNewImovel();
    
    /**
     * Unsets the "imovel" element
     */
    void unsetImovel();
    
    /**
     * Gets the "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS getValores();
    
    /**
     * Sets the "valores" element
     */
    void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS valores);
    
    /**
     * Appends and returns a new empty "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS addNewValores();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
