/*
 * XML Type:  TCServ
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCServ(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCServ extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCServ.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcserv1705type");
    
    /**
     * Gets the "locPrest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest getLocPrest();
    
    /**
     * Sets the "locPrest" element
     */
    void setLocPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest locPrest);
    
    /**
     * Appends and returns a new empty "locPrest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest addNewLocPrest();
    
    /**
     * Gets the "cServ" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ getCServ();
    
    /**
     * Sets the "cServ" element
     */
    void setCServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ cServ);
    
    /**
     * Appends and returns a new empty "cServ" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ addNewCServ();
    
    /**
     * Gets the "comExt" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior getComExt();
    
    /**
     * True if has "comExt" element
     */
    boolean isSetComExt();
    
    /**
     * Sets the "comExt" element
     */
    void setComExt(org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior comExt);
    
    /**
     * Appends and returns a new empty "comExt" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior addNewComExt();
    
    /**
     * Unsets the "comExt" element
     */
    void unsetComExt();
    
    /**
     * Gets the "obra" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra getObra();
    
    /**
     * True if has "obra" element
     */
    boolean isSetObra();
    
    /**
     * Sets the "obra" element
     */
    void setObra(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra obra);
    
    /**
     * Appends and returns a new empty "obra" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra addNewObra();
    
    /**
     * Unsets the "obra" element
     */
    void unsetObra();
    
    /**
     * Gets the "atvEvento" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento getAtvEvento();
    
    /**
     * True if has "atvEvento" element
     */
    boolean isSetAtvEvento();
    
    /**
     * Sets the "atvEvento" element
     */
    void setAtvEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento atvEvento);
    
    /**
     * Appends and returns a new empty "atvEvento" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento addNewAtvEvento();
    
    /**
     * Unsets the "atvEvento" element
     */
    void unsetAtvEvento();
    
    /**
     * Gets the "explRod" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria getExplRod();
    
    /**
     * True if has "explRod" element
     */
    boolean isSetExplRod();
    
    /**
     * Sets the "explRod" element
     */
    void setExplRod(org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria explRod);
    
    /**
     * Appends and returns a new empty "explRod" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria addNewExplRod();
    
    /**
     * Unsets the "explRod" element
     */
    void unsetExplRod();
    
    /**
     * Gets the "infoCompl" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl getInfoCompl();
    
    /**
     * True if has "infoCompl" element
     */
    boolean isSetInfoCompl();
    
    /**
     * Sets the "infoCompl" element
     */
    void setInfoCompl(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl infoCompl);
    
    /**
     * Appends and returns a new empty "infoCompl" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl addNewInfoCompl();
    
    /**
     * Unsets the "infoCompl" element
     */
    void unsetInfoCompl();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
