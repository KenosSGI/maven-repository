/*
 * XML Type:  TE305101
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TE305101(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TE305101Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101
{
    private static final long serialVersionUID = 1L;
    
    public TE305101Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XDESC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDesc");
    private static final javax.xml.namespace.QName CPFAGTRIB$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPFAgTrib");
    private static final javax.xml.namespace.QName NPROCADM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nProcAdm");
    private static final javax.xml.namespace.QName XPROCADM$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xProcAdm");
    
    
    /**
     * Gets the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc.Enum getXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc xgetXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc)get_store().find_element_user(XDESC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDesc" element
     */
    public void setXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc.Enum xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESC$0);
            }
            target.setEnumValue(xDesc);
        }
    }
    
    /**
     * Sets (as xml) the "xDesc" element
     */
    public void xsetXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc)get_store().add_element_user(XDESC$0);
            }
            target.set(xDesc);
        }
    }
    
    /**
     * Gets the "CPFAgTrib" element
     */
    public java.lang.String getCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPFAgTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CPFAgTrib" element
     */
    public void setCPFAgTrib(java.lang.String cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFAGTRIB$2);
            }
            target.setStringValue(cpfAgTrib);
        }
    }
    
    /**
     * Sets (as xml) the "CPFAgTrib" element
     */
    public void xsetCPFAgTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPFAGTRIB$2);
            }
            target.set(cpfAgTrib);
        }
    }
    
    /**
     * Gets the "nProcAdm" element
     */
    public java.lang.String getNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nProcAdm" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc xgetNProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().find_element_user(NPROCADM$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nProcAdm" element
     */
    public void setNProcAdm(java.lang.String nProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NPROCADM$4);
            }
            target.setStringValue(nProcAdm);
        }
    }
    
    /**
     * Sets (as xml) the "nProcAdm" element
     */
    public void xsetNProcAdm(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc nProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().find_element_user(NPROCADM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc)get_store().add_element_user(NPROCADM$4);
            }
            target.set(nProcAdm);
        }
    }
    
    /**
     * Gets the "xProcAdm" element
     */
    public java.lang.String getXProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XPROCADM$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xProcAdm" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXProcAdm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XPROCADM$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xProcAdm" element
     */
    public void setXProcAdm(java.lang.String xProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XPROCADM$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XPROCADM$6);
            }
            target.setStringValue(xProcAdm);
        }
    }
    
    /**
     * Sets (as xml) the "xProcAdm" element
     */
    public void xsetXProcAdm(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xProcAdm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XPROCADM$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XPROCADM$6);
            }
            target.set(xProcAdm);
        }
    }
    /**
     * An XML xDesc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101$XDesc.
     */
    public static class XDescImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101.XDesc
    {
        private static final long serialVersionUID = 1L;
        
        public XDescImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected XDescImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
}
