/*
 * XML Type:  TCEvento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEvento(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEventoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento
{
    private static final long serialVersionUID = 1L;
    
    public TCEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INFEVENTO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "infEvento");
    private static final javax.xml.namespace.QName SIGNATURE$2 = 
        new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
    private static final javax.xml.namespace.QName VERSAO$4 = 
        new javax.xml.namespace.QName("", "versao");
    
    
    /**
     * Gets the "infEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento getInfEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento)get_store().find_element_user(INFEVENTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "infEvento" element
     */
    public void setInfEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento infEvento)
    {
        generatedSetterHelperImpl(infEvento, INFEVENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "infEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento addNewInfEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento)get_store().add_element_user(INFEVENTO$0);
            return target;
        }
    }
    
    /**
     * Gets the "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Signature" element
     */
    public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
    {
        generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
            return target;
        }
    }
    
    /**
     * Gets the "versao" attribute
     */
    public java.lang.String getVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe xgetVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe)get_store().find_attribute_user(VERSAO$4);
            return target;
        }
    }
    
    /**
     * Sets the "versao" attribute
     */
    public void setVersao(java.lang.String versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$4);
            }
            target.setStringValue(versao);
        }
    }
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    public void xsetVersao(org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerNFSe)get_store().add_attribute_user(VERSAO$4);
            }
            target.set(versao);
        }
    }
}
