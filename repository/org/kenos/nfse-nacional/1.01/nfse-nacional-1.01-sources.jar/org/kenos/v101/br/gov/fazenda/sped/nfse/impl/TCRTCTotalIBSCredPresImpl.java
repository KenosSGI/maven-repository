/*
 * XML Type:  TCRTCTotalIBSCredPres
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalIBSCredPres(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalIBSCredPresImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalIBSCredPresImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PCREDPRESIBS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pCredPresIBS");
    private static final javax.xml.namespace.QName VCREDPRESIBS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCredPresIBS");
    
    
    /**
     * Gets the "pCredPresIBS" element
     */
    public java.lang.String getPCredPresIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCREDPRESIBS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pCredPresIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPCredPresIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCREDPRESIBS$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pCredPresIBS" element
     */
    public void setPCredPresIBS(java.lang.String pCredPresIBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCREDPRESIBS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PCREDPRESIBS$0);
            }
            target.setStringValue(pCredPresIBS);
        }
    }
    
    /**
     * Sets (as xml) the "pCredPresIBS" element
     */
    public void xsetPCredPresIBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pCredPresIBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCREDPRESIBS$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PCREDPRESIBS$0);
            }
            target.set(pCredPresIBS);
        }
    }
    
    /**
     * Gets the "vCredPresIBS" element
     */
    public java.lang.String getVCredPresIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCREDPRESIBS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCredPresIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCredPresIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCREDPRESIBS$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vCredPresIBS" element
     */
    public void setVCredPresIBS(java.lang.String vCredPresIBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCREDPRESIBS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCREDPRESIBS$2);
            }
            target.setStringValue(vCredPresIBS);
        }
    }
    
    /**
     * Sets (as xml) the "vCredPresIBS" element
     */
    public void xsetVCredPresIBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCredPresIBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCREDPRESIBS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCREDPRESIBS$2);
            }
            target.set(vCredPresIBS);
        }
    }
}
