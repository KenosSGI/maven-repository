/*
 * XML Type:  TCRTCInfoValoresIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoValoresIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoValoresIBSCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoValoresIBSCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GREEREPRES$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gReeRepRes");
    private static final javax.xml.namespace.QName TRIB$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "trib");
    
    
    /**
     * Gets the "gReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes getGReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes)get_store().find_element_user(GREEREPRES$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gReeRepRes" element
     */
    public boolean isSetGReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GREEREPRES$0) != 0;
        }
    }
    
    /**
     * Sets the "gReeRepRes" element
     */
    public void setGReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes gReeRepRes)
    {
        generatedSetterHelperImpl(gReeRepRes, GREEREPRES$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes addNewGReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes)get_store().add_element_user(GREEREPRES$0);
            return target;
        }
    }
    
    /**
     * Unsets the "gReeRepRes" element
     */
    public void unsetGReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GREEREPRES$0, 0);
        }
    }
    
    /**
     * Gets the "trib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS getTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS)get_store().find_element_user(TRIB$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "trib" element
     */
    public void setTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS trib)
    {
        generatedSetterHelperImpl(trib, TRIB$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "trib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS addNewTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS)get_store().add_element_user(TRIB$2);
            return target;
        }
    }
}
