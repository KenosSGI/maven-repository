/*
 * XML Type:  TCInfCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfCNCImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC
{
    private static final long serialVersionUID = 1L;
    
    public TCInfCNCImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPAMB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpAmb");
    private static final javax.xml.namespace.QName DHGERACAOARQUIVO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dhGeracaoArquivo");
    private static final javax.xml.namespace.QName VERAPLIC$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "verAplic");
    private static final javax.xml.namespace.QName CONTRIBUINTESCNC$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "contribuintesCnc");
    
    
    /**
     * Gets the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpAmb" element
     */
    public void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPAMB$0);
            }
            target.setEnumValue(tpAmb);
        }
    }
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    public void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().add_element_user(TPAMB$0);
            }
            target.set(tpAmb);
        }
    }
    
    /**
     * Gets the "dhGeracaoArquivo" element
     */
    public java.lang.String getDhGeracaoArquivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHGERACAOARQUIVO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dhGeracaoArquivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhGeracaoArquivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHGERACAOARQUIVO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dhGeracaoArquivo" element
     */
    public void setDhGeracaoArquivo(java.lang.String dhGeracaoArquivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHGERACAOARQUIVO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DHGERACAOARQUIVO$2);
            }
            target.setStringValue(dhGeracaoArquivo);
        }
    }
    
    /**
     * Sets (as xml) the "dhGeracaoArquivo" element
     */
    public void xsetDhGeracaoArquivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhGeracaoArquivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHGERACAOARQUIVO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().add_element_user(DHGERACAOARQUIVO$2);
            }
            target.set(dhGeracaoArquivo);
        }
    }
    
    /**
     * Gets the "verAplic" element
     */
    public java.lang.String getVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "verAplic" element
     */
    public void setVerAplic(java.lang.String verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERAPLIC$4);
            }
            target.setStringValue(verAplic);
        }
    }
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    public void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().add_element_user(VERAPLIC$4);
            }
            target.set(verAplic);
        }
    }
    
    /**
     * Gets the "contribuintesCnc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc getContribuintesCnc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc)get_store().find_element_user(CONTRIBUINTESCNC$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "contribuintesCnc" element
     */
    public void setContribuintesCnc(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc contribuintesCnc)
    {
        generatedSetterHelperImpl(contribuintesCnc, CONTRIBUINTESCNC$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "contribuintesCnc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc addNewContribuintesCnc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc)get_store().add_element_user(CONTRIBUINTESCNC$6);
            return target;
        }
    }
    /**
     * An XML contribuintesCnc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is a complex type.
     */
    public static class ContribuintesCncImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc
    {
        private static final long serialVersionUID = 1L;
        
        public ContribuintesCncImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONTRIBUINTECNC$0 = 
            new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "contribuinteCnc");
        
        
        /**
         * Gets array of all "contribuinteCnc" elements
         */
        public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[] getContribuinteCncArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CONTRIBUINTECNC$0, targetList);
                org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "contribuinteCnc" element
         */
        public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC getContribuinteCncArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC target = null;
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC)get_store().find_element_user(CONTRIBUINTECNC$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "contribuinteCnc" element
         */
        public int sizeOfContribuinteCncArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONTRIBUINTECNC$0);
            }
        }
        
        /**
         * Sets array of all "contribuinteCnc" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setContribuinteCncArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[] contribuinteCncArray)
        {
            check_orphaned();
            arraySetterHelper(contribuinteCncArray, CONTRIBUINTECNC$0);
        }
        
        /**
         * Sets ith "contribuinteCnc" element
         */
        public void setContribuinteCncArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC contribuinteCnc)
        {
            generatedSetterHelperImpl(contribuinteCnc, CONTRIBUINTECNC$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "contribuinteCnc" element
         */
        public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC insertNewContribuinteCnc(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC target = null;
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC)get_store().insert_element_user(CONTRIBUINTECNC$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "contribuinteCnc" element
         */
        public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC addNewContribuinteCnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC target = null;
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC)get_store().add_element_user(CONTRIBUINTECNC$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "contribuinteCnc" element
         */
        public void removeContribuinteCnc(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONTRIBUINTECNC$0, i);
            }
        }
    }
}
