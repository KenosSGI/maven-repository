/*
 * XML Type:  TSSentido
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSSentido(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido.
 */
public class TSSentidoImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido
{
    private static final long serialVersionUID = 1L;
    
    public TSSentidoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSSentidoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
