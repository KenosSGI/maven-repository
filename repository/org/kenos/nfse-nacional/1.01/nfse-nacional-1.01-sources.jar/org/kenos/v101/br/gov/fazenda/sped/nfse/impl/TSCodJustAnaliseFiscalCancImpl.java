/*
 * XML Type:  TSCodJustAnaliseFiscalCanc
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCanc
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSCodJustAnaliseFiscalCanc(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCanc.
 */
public class TSCodJustAnaliseFiscalCancImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCanc
{
    private static final long serialVersionUID = 1L;
    
    public TSCodJustAnaliseFiscalCancImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSCodJustAnaliseFiscalCancImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
