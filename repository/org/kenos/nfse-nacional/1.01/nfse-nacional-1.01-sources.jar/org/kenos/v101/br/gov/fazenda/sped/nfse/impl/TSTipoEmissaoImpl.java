/*
 * XML Type:  TSTipoEmissao
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSTipoEmissao(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.
 */
public class TSTipoEmissaoImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao
{
    private static final long serialVersionUID = 1L;
    
    public TSTipoEmissaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSTipoEmissaoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
