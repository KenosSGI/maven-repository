/*
 * XML Type:  TCRTCIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCIBSCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCIBSCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLOCALIDADEINCID$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cLocalidadeIncid");
    private static final javax.xml.namespace.QName XLOCALIDADEINCID$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLocalidadeIncid");
    private static final javax.xml.namespace.QName PREDUTOR$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pRedutor");
    private static final javax.xml.namespace.QName VALORES$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "valores");
    private static final javax.xml.namespace.QName TOTCIBS$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "totCIBS");
    
    
    /**
     * Gets the "cLocalidadeIncid" element
     */
    public java.lang.String getCLocalidadeIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCALIDADEINCID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cLocalidadeIncid" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocalidadeIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCALIDADEINCID$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cLocalidadeIncid" element
     */
    public void setCLocalidadeIncid(java.lang.String cLocalidadeIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCALIDADEINCID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLOCALIDADEINCID$0);
            }
            target.setStringValue(cLocalidadeIncid);
        }
    }
    
    /**
     * Sets (as xml) the "cLocalidadeIncid" element
     */
    public void xsetCLocalidadeIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocalidadeIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCALIDADEINCID$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CLOCALIDADEINCID$0);
            }
            target.set(cLocalidadeIncid);
        }
    }
    
    /**
     * Gets the "xLocalidadeIncid" element
     */
    public java.lang.String getXLocalidadeIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCALIDADEINCID$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLocalidadeIncid" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXLocalidadeIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XLOCALIDADEINCID$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xLocalidadeIncid" element
     */
    public void setXLocalidadeIncid(java.lang.String xLocalidadeIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCALIDADEINCID$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLOCALIDADEINCID$2);
            }
            target.setStringValue(xLocalidadeIncid);
        }
    }
    
    /**
     * Sets (as xml) the "xLocalidadeIncid" element
     */
    public void xsetXLocalidadeIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xLocalidadeIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XLOCALIDADEINCID$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().add_element_user(XLOCALIDADEINCID$2);
            }
            target.set(xLocalidadeIncid);
        }
    }
    
    /**
     * Gets the "pRedutor" element
     */
    public java.lang.String getPRedutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDUTOR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pRedutor" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPRedutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PREDUTOR$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "pRedutor" element
     */
    public boolean isSetPRedutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDUTOR$4) != 0;
        }
    }
    
    /**
     * Sets the "pRedutor" element
     */
    public void setPRedutor(java.lang.String pRedutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDUTOR$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDUTOR$4);
            }
            target.setStringValue(pRedutor);
        }
    }
    
    /**
     * Sets (as xml) the "pRedutor" element
     */
    public void xsetPRedutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pRedutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PREDUTOR$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PREDUTOR$4);
            }
            target.set(pRedutor);
        }
    }
    
    /**
     * Unsets the "pRedutor" element
     */
    public void unsetPRedutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDUTOR$4, 0);
        }
    }
    
    /**
     * Gets the "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS getValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS)get_store().find_element_user(VALORES$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "valores" element
     */
    public void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS valores)
    {
        generatedSetterHelperImpl(valores, VALORES$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS addNewValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS)get_store().add_element_user(VALORES$6);
            return target;
        }
    }
    
    /**
     * Gets the "totCIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS getTotCIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS)get_store().find_element_user(TOTCIBS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "totCIBS" element
     */
    public void setTotCIBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS totCIBS)
    {
        generatedSetterHelperImpl(totCIBS, TOTCIBS$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "totCIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS addNewTotCIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS)get_store().add_element_user(TOTCIBS$8);
            return target;
        }
    }
}
