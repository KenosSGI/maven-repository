/*
 * XML Type:  TCEnderNac
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderNac
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEnderNac(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEnderNacImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderNac
{
    private static final long serialVersionUID = 1L;
    
    public TCEnderNacImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CMUN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMun");
    private static final javax.xml.namespace.QName CEP$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CEP");
    
    
    /**
     * Gets the "cMun" element
     */
    public java.lang.String getCMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUN$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMun" element
     */
    public void setCMun(java.lang.String cMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMUN$0);
            }
            target.setStringValue(cMun);
        }
    }
    
    /**
     * Sets (as xml) the "cMun" element
     */
    public void xsetCMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUN$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CMUN$0);
            }
            target.set(cMun);
        }
    }
    
    /**
     * Gets the "CEP" element
     */
    public java.lang.String getCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CEP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP xgetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CEP" element
     */
    public void setCEP(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$2);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "CEP" element
     */
    public void xsetCEP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().add_element_user(CEP$2);
            }
            target.set(cep);
        }
    }
}
