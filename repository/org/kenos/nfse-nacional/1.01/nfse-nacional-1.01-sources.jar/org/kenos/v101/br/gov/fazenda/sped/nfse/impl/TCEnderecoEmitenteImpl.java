/*
 * XML Type:  TCEnderecoEmitente
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEnderecoEmitente(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEnderecoEmitenteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente
{
    private static final long serialVersionUID = 1L;
    
    public TCEnderecoEmitenteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XLGR$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLgr");
    private static final javax.xml.namespace.QName NRO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nro");
    private static final javax.xml.namespace.QName XCPL$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xCpl");
    private static final javax.xml.namespace.QName XBAIRRO$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xBairro");
    private static final javax.xml.namespace.QName CMUN$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMun");
    private static final javax.xml.namespace.QName UF$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "UF");
    private static final javax.xml.namespace.QName CEP$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CEP");
    
    
    /**
     * Gets the "xLgr" element
     */
    public java.lang.String getXLgr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLGR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLgr" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro xgetXLgr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().find_element_user(XLGR$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xLgr" element
     */
    public void setXLgr(java.lang.String xLgr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLGR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLGR$0);
            }
            target.setStringValue(xLgr);
        }
    }
    
    /**
     * Sets (as xml) the "xLgr" element
     */
    public void xsetXLgr(org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro xLgr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().find_element_user(XLGR$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().add_element_user(XLGR$0);
            }
            target.set(xLgr);
        }
    }
    
    /**
     * Gets the "nro" element
     */
    public java.lang.String getNro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetNro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(NRO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nro" element
     */
    public void setNro(java.lang.String nro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NRO$2);
            }
            target.setStringValue(nro);
        }
    }
    
    /**
     * Sets (as xml) the "nro" element
     */
    public void xsetNro(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco nro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(NRO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().add_element_user(NRO$2);
            }
            target.set(nro);
        }
    }
    
    /**
     * Gets the "xCpl" element
     */
    public java.lang.String getXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCPL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xCpl" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xgetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().find_element_user(XCPL$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "xCpl" element
     */
    public boolean isSetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XCPL$4) != 0;
        }
    }
    
    /**
     * Sets the "xCpl" element
     */
    public void setXCpl(java.lang.String xCpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCPL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XCPL$4);
            }
            target.setStringValue(xCpl);
        }
    }
    
    /**
     * Sets (as xml) the "xCpl" element
     */
    public void xsetXCpl(org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xCpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().find_element_user(XCPL$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().add_element_user(XCPL$4);
            }
            target.set(xCpl);
        }
    }
    
    /**
     * Unsets the "xCpl" element
     */
    public void unsetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XCPL$4, 0);
        }
    }
    
    /**
     * Gets the "xBairro" element
     */
    public java.lang.String getXBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XBAIRRO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xBairro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro xgetXBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().find_element_user(XBAIRRO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xBairro" element
     */
    public void setXBairro(java.lang.String xBairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XBAIRRO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XBAIRRO$6);
            }
            target.setStringValue(xBairro);
        }
    }
    
    /**
     * Sets (as xml) the "xBairro" element
     */
    public void xsetXBairro(org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro xBairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().find_element_user(XBAIRRO$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().add_element_user(XBAIRRO$6);
            }
            target.set(xBairro);
        }
    }
    
    /**
     * Gets the "cMun" element
     */
    public java.lang.String getCMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUN$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUN$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMun" element
     */
    public void setCMun(java.lang.String cMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUN$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMUN$8);
            }
            target.setStringValue(cMun);
        }
    }
    
    /**
     * Sets (as xml) the "cMun" element
     */
    public void xsetCMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUN$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CMUN$8);
            }
            target.set(cMun);
        }
    }
    
    /**
     * Gets the "UF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF.Enum getUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "UF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF xgetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF)get_store().find_element_user(UF$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "UF" element
     */
    public void setUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF.Enum uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$10);
            }
            target.setEnumValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "UF" element
     */
    public void xsetUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSUF)get_store().add_element_user(UF$10);
            }
            target.set(uf);
        }
    }
    
    /**
     * Gets the "CEP" element
     */
    public java.lang.String getCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CEP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP xgetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CEP" element
     */
    public void setCEP(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$12);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "CEP" element
     */
    public void xsetCEP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().add_element_user(CEP$12);
            }
            target.set(cep);
        }
    }
}
