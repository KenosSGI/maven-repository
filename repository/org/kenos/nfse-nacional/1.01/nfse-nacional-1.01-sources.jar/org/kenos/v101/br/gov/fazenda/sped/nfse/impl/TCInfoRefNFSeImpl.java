/*
 * XML Type:  TCInfoRefNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoRefNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoRefNFSeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoRefNFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REFNFSE$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "refNFSe");
    
    
    /**
     * Gets array of all "refNFSe" elements
     */
    public java.lang.String[] getRefNFSeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(REFNFSE$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "refNFSe" element
     */
    public java.lang.String getRefNFSeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REFNFSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) array of all "refNFSe" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe[] xgetRefNFSeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(REFNFSE$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "refNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetRefNFSeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(REFNFSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "refNFSe" element
     */
    public int sizeOfRefNFSeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REFNFSE$0);
        }
    }
    
    /**
     * Sets array of all "refNFSe" element
     */
    public void setRefNFSeArray(java.lang.String[] refNFSeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(refNFSeArray, REFNFSE$0);
        }
    }
    
    /**
     * Sets ith "refNFSe" element
     */
    public void setRefNFSeArray(int i, java.lang.String refNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REFNFSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(refNFSe);
        }
    }
    
    /**
     * Sets (as xml) array of all "refNFSe" element
     */
    public void xsetRefNFSeArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe[]refNFSeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(refNFSeArray, REFNFSE$0);
        }
    }
    
    /**
     * Sets (as xml) ith "refNFSe" element
     */
    public void xsetRefNFSeArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe refNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(REFNFSE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(refNFSe);
        }
    }
    
    /**
     * Inserts the value as the ith "refNFSe" element
     */
    public void insertRefNFSe(int i, java.lang.String refNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(REFNFSE$0, i);
            target.setStringValue(refNFSe);
        }
    }
    
    /**
     * Appends the value as the last "refNFSe" element
     */
    public void addRefNFSe(java.lang.String refNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REFNFSE$0);
            target.setStringValue(refNFSe);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "refNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe insertNewRefNFSe(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().insert_element_user(REFNFSE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "refNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe addNewRefNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(REFNFSE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "refNFSe" element
     */
    public void removeRefNFSe(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REFNFSE$0, i);
        }
    }
}
