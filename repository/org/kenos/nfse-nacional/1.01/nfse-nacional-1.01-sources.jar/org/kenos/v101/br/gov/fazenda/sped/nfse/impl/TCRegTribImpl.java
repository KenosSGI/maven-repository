/*
 * XML Type:  TCRegTrib
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRegTrib
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRegTrib(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRegTribImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRegTrib
{
    private static final long serialVersionUID = 1L;
    
    public TCRegTribImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OPSIMPNAC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "opSimpNac");
    private static final javax.xml.namespace.QName REGAPTRIBSN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "regApTribSN");
    private static final javax.xml.namespace.QName REGESPTRIB$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "regEspTrib");
    
    
    /**
     * Gets the "opSimpNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac.Enum getOpSimpNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPSIMPNAC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "opSimpNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac xgetOpSimpNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac)get_store().find_element_user(OPSIMPNAC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "opSimpNac" element
     */
    public void setOpSimpNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac.Enum opSimpNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPSIMPNAC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPSIMPNAC$0);
            }
            target.setEnumValue(opSimpNac);
        }
    }
    
    /**
     * Sets (as xml) the "opSimpNac" element
     */
    public void xsetOpSimpNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac opSimpNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac)get_store().find_element_user(OPSIMPNAC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpSimpNac)get_store().add_element_user(OPSIMPNAC$0);
            }
            target.set(opSimpNac);
        }
    }
    
    /**
     * Gets the "regApTribSN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac.Enum getRegApTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGAPTRIBSN$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "regApTribSN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac xgetRegApTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac)get_store().find_element_user(REGAPTRIBSN$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "regApTribSN" element
     */
    public boolean isSetRegApTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REGAPTRIBSN$2) != 0;
        }
    }
    
    /**
     * Sets the "regApTribSN" element
     */
    public void setRegApTribSN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac.Enum regApTribSN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGAPTRIBSN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REGAPTRIBSN$2);
            }
            target.setEnumValue(regApTribSN);
        }
    }
    
    /**
     * Sets (as xml) the "regApTribSN" element
     */
    public void xsetRegApTribSN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac regApTribSN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac)get_store().find_element_user(REGAPTRIBSN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegimeApuracaoSimpNac)get_store().add_element_user(REGAPTRIBSN$2);
            }
            target.set(regApTribSN);
        }
    }
    
    /**
     * Unsets the "regApTribSN" element
     */
    public void unsetRegApTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REGAPTRIBSN$2, 0);
        }
    }
    
    /**
     * Gets the "regEspTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum getRegEspTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGESPTRIB$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "regEspTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib xgetRegEspTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().find_element_user(REGESPTRIB$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "regEspTrib" element
     */
    public void setRegEspTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum regEspTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGESPTRIB$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REGESPTRIB$4);
            }
            target.setEnumValue(regEspTrib);
        }
    }
    
    /**
     * Sets (as xml) the "regEspTrib" element
     */
    public void xsetRegEspTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib regEspTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().find_element_user(REGESPTRIB$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().add_element_user(REGESPTRIB$4);
            }
            target.set(regEspTrib);
        }
    }
}
