/*
 * XML Type:  TCValoresNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCValoresNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCValoresNFSe extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCValoresNFSe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcvaloresnfsee11btype");
    
    /**
     * Gets the "vCalcDR" element
     */
    java.lang.String getVCalcDR();
    
    /**
     * Gets (as xml) the "vCalcDR" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCalcDR();
    
    /**
     * True if has "vCalcDR" element
     */
    boolean isSetVCalcDR();
    
    /**
     * Sets the "vCalcDR" element
     */
    void setVCalcDR(java.lang.String vCalcDR);
    
    /**
     * Sets (as xml) the "vCalcDR" element
     */
    void xsetVCalcDR(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCalcDR);
    
    /**
     * Unsets the "vCalcDR" element
     */
    void unsetVCalcDR();
    
    /**
     * Gets the "tpBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN.Enum getTpBM();
    
    /**
     * Gets (as xml) the "tpBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN xgetTpBM();
    
    /**
     * True if has "tpBM" element
     */
    boolean isSetTpBM();
    
    /**
     * Sets the "tpBM" element
     */
    void setTpBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN.Enum tpBM);
    
    /**
     * Sets (as xml) the "tpBM" element
     */
    void xsetTpBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN tpBM);
    
    /**
     * Unsets the "tpBM" element
     */
    void unsetTpBM();
    
    /**
     * Gets the "vCalcBM" element
     */
    java.lang.String getVCalcBM();
    
    /**
     * Gets (as xml) the "vCalcBM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCalcBM();
    
    /**
     * True if has "vCalcBM" element
     */
    boolean isSetVCalcBM();
    
    /**
     * Sets the "vCalcBM" element
     */
    void setVCalcBM(java.lang.String vCalcBM);
    
    /**
     * Sets (as xml) the "vCalcBM" element
     */
    void xsetVCalcBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCalcBM);
    
    /**
     * Unsets the "vCalcBM" element
     */
    void unsetVCalcBM();
    
    /**
     * Gets the "vBC" element
     */
    java.lang.String getVBC();
    
    /**
     * Gets (as xml) the "vBC" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVBC();
    
    /**
     * True if has "vBC" element
     */
    boolean isSetVBC();
    
    /**
     * Sets the "vBC" element
     */
    void setVBC(java.lang.String vbc);
    
    /**
     * Sets (as xml) the "vBC" element
     */
    void xsetVBC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vbc);
    
    /**
     * Unsets the "vBC" element
     */
    void unsetVBC();
    
    /**
     * Gets the "pAliqAplic" element
     */
    java.lang.String getPAliqAplic();
    
    /**
     * Gets (as xml) the "pAliqAplic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 xgetPAliqAplic();
    
    /**
     * True if has "pAliqAplic" element
     */
    boolean isSetPAliqAplic();
    
    /**
     * Sets the "pAliqAplic" element
     */
    void setPAliqAplic(java.lang.String pAliqAplic);
    
    /**
     * Sets (as xml) the "pAliqAplic" element
     */
    void xsetPAliqAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 pAliqAplic);
    
    /**
     * Unsets the "pAliqAplic" element
     */
    void unsetPAliqAplic();
    
    /**
     * Gets the "vISSQN" element
     */
    java.lang.String getVISSQN();
    
    /**
     * Gets (as xml) the "vISSQN" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVISSQN();
    
    /**
     * True if has "vISSQN" element
     */
    boolean isSetVISSQN();
    
    /**
     * Sets the "vISSQN" element
     */
    void setVISSQN(java.lang.String vissqn);
    
    /**
     * Sets (as xml) the "vISSQN" element
     */
    void xsetVISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vissqn);
    
    /**
     * Unsets the "vISSQN" element
     */
    void unsetVISSQN();
    
    /**
     * Gets the "vTotalRet" element
     */
    java.lang.String getVTotalRet();
    
    /**
     * Gets (as xml) the "vTotalRet" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotalRet();
    
    /**
     * True if has "vTotalRet" element
     */
    boolean isSetVTotalRet();
    
    /**
     * Sets the "vTotalRet" element
     */
    void setVTotalRet(java.lang.String vTotalRet);
    
    /**
     * Sets (as xml) the "vTotalRet" element
     */
    void xsetVTotalRet(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotalRet);
    
    /**
     * Unsets the "vTotalRet" element
     */
    void unsetVTotalRet();
    
    /**
     * Gets the "vLiq" element
     */
    java.lang.String getVLiq();
    
    /**
     * Gets (as xml) the "vLiq" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVLiq();
    
    /**
     * Sets the "vLiq" element
     */
    void setVLiq(java.lang.String vLiq);
    
    /**
     * Sets (as xml) the "vLiq" element
     */
    void xsetVLiq(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vLiq);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
