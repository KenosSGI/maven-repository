/*
 * XML Type:  TCRTCInfoReeRepRes
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoReeRepRes(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoReeRepResImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoReeRepRes
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoReeRepResImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCUMENTOS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "documentos");
    
    
    /**
     * Gets array of all "documentos" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc[] getDocumentosArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DOCUMENTOS$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "documentos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc getDocumentosArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc)get_store().find_element_user(DOCUMENTOS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "documentos" element
     */
    public int sizeOfDocumentosArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCUMENTOS$0);
        }
    }
    
    /**
     * Sets array of all "documentos" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setDocumentosArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc[] documentosArray)
    {
        check_orphaned();
        arraySetterHelper(documentosArray, DOCUMENTOS$0);
    }
    
    /**
     * Sets ith "documentos" element
     */
    public void setDocumentosArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc documentos)
    {
        generatedSetterHelperImpl(documentos, DOCUMENTOS$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "documentos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc insertNewDocumentos(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc)get_store().insert_element_user(DOCUMENTOS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "documentos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc addNewDocumentos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc)get_store().add_element_user(DOCUMENTOS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "documentos" element
     */
    public void removeDocumentos(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCUMENTOS$0, i);
        }
    }
}
