/*
 * XML Type:  TCCServ
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCCServ(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCCServImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ
{
    private static final long serialVersionUID = 1L;
    
    public TCCServImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CTRIBNAC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cTribNac");
    private static final javax.xml.namespace.QName CTRIBMUN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cTribMun");
    private static final javax.xml.namespace.QName XDESCSERV$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDescServ");
    private static final javax.xml.namespace.QName CNBS$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cNBS");
    private static final javax.xml.namespace.QName CINTCONTRIB$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cIntContrib");
    
    
    /**
     * Gets the "cTribNac" element
     */
    public java.lang.String getCTribNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTRIBNAC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cTribNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac xgetCTribNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac)get_store().find_element_user(CTRIBNAC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cTribNac" element
     */
    public void setCTribNac(java.lang.String cTribNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTRIBNAC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CTRIBNAC$0);
            }
            target.setStringValue(cTribNac);
        }
    }
    
    /**
     * Sets (as xml) the "cTribNac" element
     */
    public void xsetCTribNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac cTribNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac)get_store().find_element_user(CTRIBNAC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodTribNac)get_store().add_element_user(CTRIBNAC$0);
            }
            target.set(cTribNac);
        }
    }
    
    /**
     * Gets the "cTribMun" element
     */
    public java.lang.String getCTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTRIBMUN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cTribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun xgetCTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun)get_store().find_element_user(CTRIBMUN$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "cTribMun" element
     */
    public boolean isSetCTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTRIBMUN$2) != 0;
        }
    }
    
    /**
     * Sets the "cTribMun" element
     */
    public void setCTribMun(java.lang.String cTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTRIBMUN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CTRIBMUN$2);
            }
            target.setStringValue(cTribMun);
        }
    }
    
    /**
     * Sets (as xml) the "cTribMun" element
     */
    public void xsetCTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun cTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun)get_store().find_element_user(CTRIBMUN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCCodTribMun)get_store().add_element_user(CTRIBMUN$2);
            }
            target.set(cTribMun);
        }
    }
    
    /**
     * Unsets the "cTribMun" element
     */
    public void unsetCTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTRIBMUN$2, 0);
        }
    }
    
    /**
     * Gets the "xDescServ" element
     */
    public java.lang.String getXDescServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESCSERV$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDescServ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xgetXDescServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().find_element_user(XDESCSERV$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDescServ" element
     */
    public void setXDescServ(java.lang.String xDescServ)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESCSERV$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESCSERV$4);
            }
            target.setStringValue(xDescServ);
        }
    }
    
    /**
     * Sets (as xml) the "xDescServ" element
     */
    public void xsetXDescServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xDescServ)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().find_element_user(XDESCSERV$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().add_element_user(XDESCSERV$4);
            }
            target.set(xDescServ);
        }
    }
    
    /**
     * Gets the "cNBS" element
     */
    public java.lang.String getCNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNBS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cNBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS xgetCNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS)get_store().find_element_user(CNBS$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cNBS" element
     */
    public void setCNBS(java.lang.String cnbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNBS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNBS$6);
            }
            target.setStringValue(cnbs);
        }
    }
    
    /**
     * Sets (as xml) the "cNBS" element
     */
    public void xsetCNBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS cnbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS)get_store().find_element_user(CNBS$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNBS)get_store().add_element_user(CNBS$6);
            }
            target.set(cnbs);
        }
    }
    
    /**
     * Gets the "cIntContrib" element
     */
    public java.lang.String getCIntContrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CINTCONTRIB$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cIntContrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte xgetCIntContrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte)get_store().find_element_user(CINTCONTRIB$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "cIntContrib" element
     */
    public boolean isSetCIntContrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CINTCONTRIB$8) != 0;
        }
    }
    
    /**
     * Sets the "cIntContrib" element
     */
    public void setCIntContrib(java.lang.String cIntContrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CINTCONTRIB$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CINTCONTRIB$8);
            }
            target.setStringValue(cIntContrib);
        }
    }
    
    /**
     * Sets (as xml) the "cIntContrib" element
     */
    public void xsetCIntContrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte cIntContrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte)get_store().find_element_user(CINTCONTRIB$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoInternoContribuinte)get_store().add_element_user(CINTCONTRIB$8);
            }
            target.set(cIntContrib);
        }
    }
    
    /**
     * Unsets the "cIntContrib" element
     */
    public void unsetCIntContrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CINTCONTRIB$8, 0);
        }
    }
}
