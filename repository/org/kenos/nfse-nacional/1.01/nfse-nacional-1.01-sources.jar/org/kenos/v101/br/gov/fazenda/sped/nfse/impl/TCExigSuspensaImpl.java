/*
 * XML Type:  TCExigSuspensa
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCExigSuspensa(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCExigSuspensaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCExigSuspensa
{
    private static final long serialVersionUID = 1L;
    
    public TCExigSuspensaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPSUSP$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpSusp");
    private static final javax.xml.namespace.QName NPROCESSO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nProcesso");
    
    
    /**
     * Gets the "tpSusp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa.Enum getTpSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPSUSP$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpSusp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa xgetTpSusp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa)get_store().find_element_user(TPSUSP$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpSusp" element
     */
    public void setTpSusp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa.Enum tpSusp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPSUSP$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPSUSP$0);
            }
            target.setEnumValue(tpSusp);
        }
    }
    
    /**
     * Sets (as xml) the "tpSusp" element
     */
    public void xsetTpSusp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa tpSusp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa)get_store().find_element_user(TPSUSP$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSOpExigSuspensa)get_store().add_element_user(TPSUSP$0);
            }
            target.set(tpSusp);
        }
    }
    
    /**
     * Gets the "nProcesso" element
     */
    public java.lang.String getNProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCESSO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nProcesso" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa xgetNProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa)get_store().find_element_user(NPROCESSO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nProcesso" element
     */
    public void setNProcesso(java.lang.String nProcesso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPROCESSO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NPROCESSO$2);
            }
            target.setStringValue(nProcesso);
        }
    }
    
    /**
     * Sets (as xml) the "nProcesso" element
     */
    public void xsetNProcesso(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa nProcesso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa)get_store().find_element_user(NPROCESSO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcExigSuspensa)get_store().add_element_user(NPROCESSO$2);
            }
            target.set(nProcesso);
        }
    }
}
