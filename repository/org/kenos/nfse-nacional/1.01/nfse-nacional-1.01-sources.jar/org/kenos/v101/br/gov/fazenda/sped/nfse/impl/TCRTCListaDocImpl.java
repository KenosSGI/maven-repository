/*
 * XML Type:  TCRTCListaDoc
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCListaDoc(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCListaDocImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCListaDocImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DFENACIONAL$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dFeNacional");
    private static final javax.xml.namespace.QName DOCFISCALOUTRO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "docFiscalOutro");
    private static final javax.xml.namespace.QName DOCOUTRO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "docOutro");
    private static final javax.xml.namespace.QName FORNEC$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fornec");
    private static final javax.xml.namespace.QName DTEMIDOC$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dtEmiDoc");
    private static final javax.xml.namespace.QName DTCOMPDOC$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dtCompDoc");
    private static final javax.xml.namespace.QName TPREEREPRES$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpReeRepRes");
    private static final javax.xml.namespace.QName XTPREEREPRES$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xTpReeRepRes");
    private static final javax.xml.namespace.QName VLRREEREPRES$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vlrReeRepRes");
    
    
    /**
     * Gets the "dFeNacional" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe getDFeNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe)get_store().find_element_user(DFENACIONAL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "dFeNacional" element
     */
    public boolean isSetDFeNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DFENACIONAL$0) != 0;
        }
    }
    
    /**
     * Sets the "dFeNacional" element
     */
    public void setDFeNacional(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe dFeNacional)
    {
        generatedSetterHelperImpl(dFeNacional, DFENACIONAL$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "dFeNacional" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe addNewDFeNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe)get_store().add_element_user(DFENACIONAL$0);
            return target;
        }
    }
    
    /**
     * Unsets the "dFeNacional" element
     */
    public void unsetDFeNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DFENACIONAL$0, 0);
        }
    }
    
    /**
     * Gets the "docFiscalOutro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro getDocFiscalOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro)get_store().find_element_user(DOCFISCALOUTRO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "docFiscalOutro" element
     */
    public boolean isSetDocFiscalOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCFISCALOUTRO$2) != 0;
        }
    }
    
    /**
     * Sets the "docFiscalOutro" element
     */
    public void setDocFiscalOutro(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro docFiscalOutro)
    {
        generatedSetterHelperImpl(docFiscalOutro, DOCFISCALOUTRO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "docFiscalOutro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro addNewDocFiscalOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro)get_store().add_element_user(DOCFISCALOUTRO$2);
            return target;
        }
    }
    
    /**
     * Unsets the "docFiscalOutro" element
     */
    public void unsetDocFiscalOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCFISCALOUTRO$2, 0);
        }
    }
    
    /**
     * Gets the "docOutro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro getDocOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro)get_store().find_element_user(DOCOUTRO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "docOutro" element
     */
    public boolean isSetDocOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCOUTRO$4) != 0;
        }
    }
    
    /**
     * Sets the "docOutro" element
     */
    public void setDocOutro(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro docOutro)
    {
        generatedSetterHelperImpl(docOutro, DOCOUTRO$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "docOutro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro addNewDocOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro)get_store().add_element_user(DOCOUTRO$4);
            return target;
        }
    }
    
    /**
     * Unsets the "docOutro" element
     */
    public void unsetDocOutro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCOUTRO$4, 0);
        }
    }
    
    /**
     * Gets the "fornec" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec getFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec)get_store().find_element_user(FORNEC$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fornec" element
     */
    public boolean isSetFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FORNEC$6) != 0;
        }
    }
    
    /**
     * Sets the "fornec" element
     */
    public void setFornec(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec fornec)
    {
        generatedSetterHelperImpl(fornec, FORNEC$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "fornec" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec addNewFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec)get_store().add_element_user(FORNEC$6);
            return target;
        }
    }
    
    /**
     * Unsets the "fornec" element
     */
    public void unsetFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FORNEC$6, 0);
        }
    }
    
    /**
     * Gets the "dtEmiDoc" element
     */
    public java.lang.String getDtEmiDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTEMIDOC$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dtEmiDoc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtEmiDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTEMIDOC$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dtEmiDoc" element
     */
    public void setDtEmiDoc(java.lang.String dtEmiDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTEMIDOC$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTEMIDOC$8);
            }
            target.setStringValue(dtEmiDoc);
        }
    }
    
    /**
     * Sets (as xml) the "dtEmiDoc" element
     */
    public void xsetDtEmiDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtEmiDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTEMIDOC$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DTEMIDOC$8);
            }
            target.set(dtEmiDoc);
        }
    }
    
    /**
     * Gets the "dtCompDoc" element
     */
    public java.lang.String getDtCompDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTCOMPDOC$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dtCompDoc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtCompDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTCOMPDOC$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dtCompDoc" element
     */
    public void setDtCompDoc(java.lang.String dtCompDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTCOMPDOC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTCOMPDOC$10);
            }
            target.setStringValue(dtCompDoc);
        }
    }
    
    /**
     * Sets (as xml) the "dtCompDoc" element
     */
    public void xsetDtCompDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtCompDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTCOMPDOC$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DTCOMPDOC$10);
            }
            target.set(dtCompDoc);
        }
    }
    
    /**
     * Gets the "tpReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes.Enum getTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPREEREPRES$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes xgetTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes)get_store().find_element_user(TPREEREPRES$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpReeRepRes" element
     */
    public void setTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes.Enum tpReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPREEREPRES$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPREEREPRES$12);
            }
            target.setEnumValue(tpReeRepRes);
        }
    }
    
    /**
     * Sets (as xml) the "tpReeRepRes" element
     */
    public void xsetTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes tpReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes)get_store().find_element_user(TPREEREPRES$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes)get_store().add_element_user(TPREEREPRES$12);
            }
            target.set(tpReeRepRes);
        }
    }
    
    /**
     * Gets the "xTpReeRepRes" element
     */
    public java.lang.String getXTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTPREEREPRES$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xTpReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XTPREEREPRES$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "xTpReeRepRes" element
     */
    public boolean isSetXTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XTPREEREPRES$14) != 0;
        }
    }
    
    /**
     * Sets the "xTpReeRepRes" element
     */
    public void setXTpReeRepRes(java.lang.String xTpReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTPREEREPRES$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XTPREEREPRES$14);
            }
            target.setStringValue(xTpReeRepRes);
        }
    }
    
    /**
     * Sets (as xml) the "xTpReeRepRes" element
     */
    public void xsetXTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xTpReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XTPREEREPRES$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XTPREEREPRES$14);
            }
            target.set(xTpReeRepRes);
        }
    }
    
    /**
     * Unsets the "xTpReeRepRes" element
     */
    public void unsetXTpReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XTPREEREPRES$14, 0);
        }
    }
    
    /**
     * Gets the "vlrReeRepRes" element
     */
    public java.lang.String getVlrReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VLRREEREPRES$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vlrReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVlrReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VLRREEREPRES$16, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vlrReeRepRes" element
     */
    public void setVlrReeRepRes(java.lang.String vlrReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VLRREEREPRES$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VLRREEREPRES$16);
            }
            target.setStringValue(vlrReeRepRes);
        }
    }
    
    /**
     * Sets (as xml) the "vlrReeRepRes" element
     */
    public void xsetVlrReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vlrReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VLRREEREPRES$16, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VLRREEREPRES$16);
            }
            target.set(vlrReeRepRes);
        }
    }
}
