/*
 * XML Type:  TSRTCIndFinal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSRTCIndFinal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.
 */
public class TSRTCIndFinalImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal
{
    private static final long serialVersionUID = 1L;
    
    public TSRTCIndFinalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSRTCIndFinalImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
