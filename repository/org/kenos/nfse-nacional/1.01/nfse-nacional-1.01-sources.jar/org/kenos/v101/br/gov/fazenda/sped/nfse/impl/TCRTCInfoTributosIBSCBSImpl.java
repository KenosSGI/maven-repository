/*
 * XML Type:  TCRTCInfoTributosIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoTributosIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoTributosIBSCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosIBSCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoTributosIBSCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GIBSCBS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gIBSCBS");
    
    
    /**
     * Gets the "gIBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas getGIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas)get_store().find_element_user(GIBSCBS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gIBSCBS" element
     */
    public void setGIBSCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas gibscbs)
    {
        generatedSetterHelperImpl(gibscbs, GIBSCBS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gIBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas addNewGIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas)get_store().add_element_user(GIBSCBS$0);
            return target;
        }
    }
}
