/*
 * XML Type:  TCVServPrest
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCVServPrest(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCVServPrestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest
{
    private static final long serialVersionUID = 1L;
    
    public TCVServPrestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VRECEB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vReceb");
    private static final javax.xml.namespace.QName VSERV$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vServ");
    
    
    /**
     * Gets the "vReceb" element
     */
    public java.lang.String getVReceb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRECEB$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vReceb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVReceb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRECEB$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "vReceb" element
     */
    public boolean isSetVReceb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VRECEB$0) != 0;
        }
    }
    
    /**
     * Sets the "vReceb" element
     */
    public void setVReceb(java.lang.String vReceb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRECEB$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VRECEB$0);
            }
            target.setStringValue(vReceb);
        }
    }
    
    /**
     * Sets (as xml) the "vReceb" element
     */
    public void xsetVReceb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vReceb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRECEB$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VRECEB$0);
            }
            target.set(vReceb);
        }
    }
    
    /**
     * Unsets the "vReceb" element
     */
    public void unsetVReceb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VRECEB$0, 0);
        }
    }
    
    /**
     * Gets the "vServ" element
     */
    public java.lang.String getVServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VSERV$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vServ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VSERV$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vServ" element
     */
    public void setVServ(java.lang.String vServ)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VSERV$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VSERV$2);
            }
            target.setStringValue(vServ);
        }
    }
    
    /**
     * Sets (as xml) the "vServ" element
     */
    public void xsetVServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vServ)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VSERV$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VSERV$2);
            }
            target.set(vServ);
        }
    }
}
