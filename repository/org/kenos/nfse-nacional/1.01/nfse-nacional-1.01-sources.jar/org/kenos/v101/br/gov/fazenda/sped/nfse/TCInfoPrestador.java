/*
 * XML Type:  TCInfoPrestador
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfoPrestador(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfoPrestador extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfoPrestador.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcinfoprestadora3fbtype");
    
    /**
     * Gets the "CNPJ" element
     */
    java.lang.String getCNPJ();
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ();
    
    /**
     * True if has "CNPJ" element
     */
    boolean isSetCNPJ();
    
    /**
     * Sets the "CNPJ" element
     */
    void setCNPJ(java.lang.String cnpj);
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj);
    
    /**
     * Unsets the "CNPJ" element
     */
    void unsetCNPJ();
    
    /**
     * Gets the "CPF" element
     */
    java.lang.String getCPF();
    
    /**
     * Gets (as xml) the "CPF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF();
    
    /**
     * True if has "CPF" element
     */
    boolean isSetCPF();
    
    /**
     * Sets the "CPF" element
     */
    void setCPF(java.lang.String cpf);
    
    /**
     * Sets (as xml) the "CPF" element
     */
    void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf);
    
    /**
     * Unsets the "CPF" element
     */
    void unsetCPF();
    
    /**
     * Gets the "NIF" element
     */
    java.lang.String getNIF();
    
    /**
     * Gets (as xml) the "NIF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF xgetNIF();
    
    /**
     * True if has "NIF" element
     */
    boolean isSetNIF();
    
    /**
     * Sets the "NIF" element
     */
    void setNIF(java.lang.String nif);
    
    /**
     * Sets (as xml) the "NIF" element
     */
    void xsetNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNIF nif);
    
    /**
     * Unsets the "NIF" element
     */
    void unsetNIF();
    
    /**
     * Gets the "cNaoNIF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum getCNaoNIF();
    
    /**
     * Gets (as xml) the "cNaoNIF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF xgetCNaoNIF();
    
    /**
     * True if has "cNaoNIF" element
     */
    boolean isSetCNaoNIF();
    
    /**
     * Sets the "cNaoNIF" element
     */
    void setCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF.Enum cNaoNIF);
    
    /**
     * Sets (as xml) the "cNaoNIF" element
     */
    void xsetCNaoNIF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodNaoNIF cNaoNIF);
    
    /**
     * Unsets the "cNaoNIF" element
     */
    void unsetCNaoNIF();
    
    /**
     * Gets the "CAEPF" element
     */
    java.lang.String getCAEPF();
    
    /**
     * Gets (as xml) the "CAEPF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCAEPF xgetCAEPF();
    
    /**
     * True if has "CAEPF" element
     */
    boolean isSetCAEPF();
    
    /**
     * Sets the "CAEPF" element
     */
    void setCAEPF(java.lang.String caepf);
    
    /**
     * Sets (as xml) the "CAEPF" element
     */
    void xsetCAEPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCAEPF caepf);
    
    /**
     * Unsets the "CAEPF" element
     */
    void unsetCAEPF();
    
    /**
     * Gets the "IM" element
     */
    java.lang.String getIM();
    
    /**
     * Gets (as xml) the "IM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun xgetIM();
    
    /**
     * True if has "IM" element
     */
    boolean isSetIM();
    
    /**
     * Sets the "IM" element
     */
    void setIM(java.lang.String im);
    
    /**
     * Sets (as xml) the "IM" element
     */
    void xsetIM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun im);
    
    /**
     * Unsets the "IM" element
     */
    void unsetIM();
    
    /**
     * Gets the "xNome" element
     */
    java.lang.String getXNome();
    
    /**
     * Gets (as xml) the "xNome" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial xgetXNome();
    
    /**
     * True if has "xNome" element
     */
    boolean isSetXNome();
    
    /**
     * Sets the "xNome" element
     */
    void setXNome(java.lang.String xNome);
    
    /**
     * Sets (as xml) the "xNome" element
     */
    void xsetXNome(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial xNome);
    
    /**
     * Unsets the "xNome" element
     */
    void unsetXNome();
    
    /**
     * Gets the "end" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco getEnd();
    
    /**
     * True if has "end" element
     */
    boolean isSetEnd();
    
    /**
     * Sets the "end" element
     */
    void setEnd(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco end);
    
    /**
     * Appends and returns a new empty "end" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEndereco addNewEnd();
    
    /**
     * Unsets the "end" element
     */
    void unsetEnd();
    
    /**
     * Gets the "fone" element
     */
    java.lang.String getFone();
    
    /**
     * Gets (as xml) the "fone" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone xgetFone();
    
    /**
     * True if has "fone" element
     */
    boolean isSetFone();
    
    /**
     * Sets the "fone" element
     */
    void setFone(java.lang.String fone);
    
    /**
     * Sets (as xml) the "fone" element
     */
    void xsetFone(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone fone);
    
    /**
     * Unsets the "fone" element
     */
    void unsetFone();
    
    /**
     * Gets the "email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "email" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail xgetEmail();
    
    /**
     * True if has "email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "email" element
     */
    void xsetEmail(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail email);
    
    /**
     * Unsets the "email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "regTrib" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRegTrib getRegTrib();
    
    /**
     * Sets the "regTrib" element
     */
    void setRegTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRegTrib regTrib);
    
    /**
     * Appends and returns a new empty "regTrib" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRegTrib addNewRegTrib();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
