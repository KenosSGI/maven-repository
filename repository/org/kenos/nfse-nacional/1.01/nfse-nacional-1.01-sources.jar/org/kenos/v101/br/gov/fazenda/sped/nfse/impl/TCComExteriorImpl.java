/*
 * XML Type:  TCComExterior
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCComExterior(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCComExteriorImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior
{
    private static final long serialVersionUID = 1L;
    
    public TCComExteriorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MDPRESTACAO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "mdPrestacao");
    private static final javax.xml.namespace.QName VINCPREST$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vincPrest");
    private static final javax.xml.namespace.QName TPMOEDA$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpMoeda");
    private static final javax.xml.namespace.QName VSERVMOEDA$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vServMoeda");
    private static final javax.xml.namespace.QName MECAFCOMEXP$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "mecAFComexP");
    private static final javax.xml.namespace.QName MECAFCOMEXT$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "mecAFComexT");
    private static final javax.xml.namespace.QName MOVTEMPBENS$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "movTempBens");
    private static final javax.xml.namespace.QName NDI$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDI");
    private static final javax.xml.namespace.QName NRE$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nRE");
    private static final javax.xml.namespace.QName MDIC$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "mdic");
    
    
    /**
     * Gets the "mdPrestacao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao.Enum getMdPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDPRESTACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "mdPrestacao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao xgetMdPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao)get_store().find_element_user(MDPRESTACAO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "mdPrestacao" element
     */
    public void setMdPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao.Enum mdPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDPRESTACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MDPRESTACAO$0);
            }
            target.setEnumValue(mdPrestacao);
        }
    }
    
    /**
     * Sets (as xml) the "mdPrestacao" element
     */
    public void xsetMdPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao mdPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao)get_store().find_element_user(MDPRESTACAO$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao)get_store().add_element_user(MDPRESTACAO$0);
            }
            target.set(mdPrestacao);
        }
    }
    
    /**
     * Gets the "vincPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest.Enum getVincPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VINCPREST$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "vincPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest xgetVincPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest)get_store().find_element_user(VINCPREST$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vincPrest" element
     */
    public void setVincPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest.Enum vincPrest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VINCPREST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VINCPREST$2);
            }
            target.setEnumValue(vincPrest);
        }
    }
    
    /**
     * Sets (as xml) the "vincPrest" element
     */
    public void xsetVincPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest vincPrest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest)get_store().find_element_user(VINCPREST$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest)get_store().add_element_user(VINCPREST$2);
            }
            target.set(vincPrest);
        }
    }
    
    /**
     * Gets the "tpMoeda" element
     */
    public java.lang.String getTpMoeda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMOEDA$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpMoeda" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda xgetTpMoeda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda)get_store().find_element_user(TPMOEDA$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpMoeda" element
     */
    public void setTpMoeda(java.lang.String tpMoeda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMOEDA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPMOEDA$4);
            }
            target.setStringValue(tpMoeda);
        }
    }
    
    /**
     * Sets (as xml) the "tpMoeda" element
     */
    public void xsetTpMoeda(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda tpMoeda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda)get_store().find_element_user(TPMOEDA$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda)get_store().add_element_user(TPMOEDA$4);
            }
            target.set(tpMoeda);
        }
    }
    
    /**
     * Gets the "vServMoeda" element
     */
    public java.lang.String getVServMoeda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VSERVMOEDA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vServMoeda" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVServMoeda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VSERVMOEDA$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vServMoeda" element
     */
    public void setVServMoeda(java.lang.String vServMoeda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VSERVMOEDA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VSERVMOEDA$6);
            }
            target.setStringValue(vServMoeda);
        }
    }
    
    /**
     * Sets (as xml) the "vServMoeda" element
     */
    public void xsetVServMoeda(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vServMoeda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VSERVMOEDA$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VSERVMOEDA$6);
            }
            target.set(vServMoeda);
        }
    }
    
    /**
     * Gets the "mecAFComexP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest.Enum getMecAFComexP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MECAFCOMEXP$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "mecAFComexP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest xgetMecAFComexP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest)get_store().find_element_user(MECAFCOMEXP$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "mecAFComexP" element
     */
    public void setMecAFComexP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest.Enum mecAFComexP)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MECAFCOMEXP$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MECAFCOMEXP$8);
            }
            target.setEnumValue(mecAFComexP);
        }
    }
    
    /**
     * Sets (as xml) the "mecAFComexP" element
     */
    public void xsetMecAFComexP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest mecAFComexP)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest)get_store().find_element_user(MECAFCOMEXP$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest)get_store().add_element_user(MECAFCOMEXP$8);
            }
            target.set(mecAFComexP);
        }
    }
    
    /**
     * Gets the "mecAFComexT" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.Enum getMecAFComexT()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MECAFCOMEXT$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "mecAFComexT" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma xgetMecAFComexT()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma)get_store().find_element_user(MECAFCOMEXT$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "mecAFComexT" element
     */
    public void setMecAFComexT(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.Enum mecAFComexT)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MECAFCOMEXT$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MECAFCOMEXT$10);
            }
            target.setEnumValue(mecAFComexT);
        }
    }
    
    /**
     * Sets (as xml) the "mecAFComexT" element
     */
    public void xsetMecAFComexT(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma mecAFComexT)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma)get_store().find_element_user(MECAFCOMEXT$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma)get_store().add_element_user(MECAFCOMEXT$10);
            }
            target.set(mecAFComexT);
        }
    }
    
    /**
     * Gets the "movTempBens" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens.Enum getMovTempBens()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOVTEMPBENS$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "movTempBens" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens xgetMovTempBens()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens)get_store().find_element_user(MOVTEMPBENS$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "movTempBens" element
     */
    public void setMovTempBens(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens.Enum movTempBens)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOVTEMPBENS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MOVTEMPBENS$12);
            }
            target.setEnumValue(movTempBens);
        }
    }
    
    /**
     * Sets (as xml) the "movTempBens" element
     */
    public void xsetMovTempBens(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens movTempBens)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens)get_store().find_element_user(MOVTEMPBENS$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens)get_store().add_element_user(MOVTEMPBENS$12);
            }
            target.set(movTempBens);
        }
    }
    
    /**
     * Gets the "nDI" element
     */
    public java.lang.String getNDI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDI$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDI" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport xgetNDI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport)get_store().find_element_user(NDI$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "nDI" element
     */
    public boolean isSetNDI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NDI$14) != 0;
        }
    }
    
    /**
     * Sets the "nDI" element
     */
    public void setNDI(java.lang.String ndi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDI$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDI$14);
            }
            target.setStringValue(ndi);
        }
    }
    
    /**
     * Sets (as xml) the "nDI" element
     */
    public void xsetNDI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport ndi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport)get_store().find_element_user(NDI$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport)get_store().add_element_user(NDI$14);
            }
            target.set(ndi);
        }
    }
    
    /**
     * Unsets the "nDI" element
     */
    public void unsetNDI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NDI$14, 0);
        }
    }
    
    /**
     * Gets the "nRE" element
     */
    public java.lang.String getNRE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRE$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nRE" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport xgetNRE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport)get_store().find_element_user(NRE$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "nRE" element
     */
    public boolean isSetNRE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NRE$16) != 0;
        }
    }
    
    /**
     * Sets the "nRE" element
     */
    public void setNRE(java.lang.String nre)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NRE$16);
            }
            target.setStringValue(nre);
        }
    }
    
    /**
     * Sets (as xml) the "nRE" element
     */
    public void xsetNRE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport nre)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport)get_store().find_element_user(NRE$16, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport)get_store().add_element_user(NRE$16);
            }
            target.set(nre);
        }
    }
    
    /**
     * Unsets the "nRE" element
     */
    public void unsetNRE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NRE$16, 0);
        }
    }
    
    /**
     * Gets the "mdic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC.Enum getMdic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDIC$18, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "mdic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC xgetMdic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC)get_store().find_element_user(MDIC$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "mdic" element
     */
    public void setMdic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC.Enum mdic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDIC$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MDIC$18);
            }
            target.setEnumValue(mdic);
        }
    }
    
    /**
     * Sets (as xml) the "mdic" element
     */
    public void xsetMdic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC mdic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC)get_store().find_element_user(MDIC$18, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC)get_store().add_element_user(MDIC$18);
            }
            target.set(mdic);
        }
    }
}
