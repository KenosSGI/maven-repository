/*
 * An XML document type.
 * Localname: pedRegEvento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.PedRegEventoDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * A document containing one pedRegEvento(@http://www.sped.fazenda.gov.br/nfse) element.
 *
 * This is a complex type.
 */
public class PedRegEventoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.PedRegEventoDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedRegEventoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDREGEVENTO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pedRegEvento");
    
    
    /**
     * Gets the "pedRegEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt getPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt)get_store().find_element_user(PEDREGEVENTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pedRegEvento" element
     */
    public void setPedRegEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt pedRegEvento)
    {
        generatedSetterHelperImpl(pedRegEvento, PEDREGEVENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "pedRegEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt addNewPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt)get_store().add_element_user(PEDREGEVENTO$0);
            return target;
        }
    }
}
