/*
 * XML Type:  TCListaDocDedRed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCListaDocDedRed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCListaDocDedRedImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaDocDedRed
{
    private static final long serialVersionUID = 1L;
    
    public TCListaDocDedRedImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOCDEDRED$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "docDedRed");
    
    
    /**
     * Gets array of all "docDedRed" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed[] getDocDedRedArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(DOCDEDRED$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "docDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed getDocDedRedArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed)get_store().find_element_user(DOCDEDRED$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "docDedRed" element
     */
    public int sizeOfDocDedRedArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCDEDRED$0);
        }
    }
    
    /**
     * Sets array of all "docDedRed" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setDocDedRedArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed[] docDedRedArray)
    {
        check_orphaned();
        arraySetterHelper(docDedRedArray, DOCDEDRED$0);
    }
    
    /**
     * Sets ith "docDedRed" element
     */
    public void setDocDedRedArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed docDedRed)
    {
        generatedSetterHelperImpl(docDedRed, DOCDEDRED$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "docDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed insertNewDocDedRed(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed)get_store().insert_element_user(DOCDEDRED$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "docDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed addNewDocDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed)get_store().add_element_user(DOCDEDRED$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "docDedRed" element
     */
    public void removeDocDedRed(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCDEDRED$0, i);
        }
    }
}
