/*
 * XML Type:  TCServ
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCServ(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCServImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ
{
    private static final long serialVersionUID = 1L;
    
    public TCServImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LOCPREST$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "locPrest");
    private static final javax.xml.namespace.QName CSERV$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cServ");
    private static final javax.xml.namespace.QName COMEXT$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "comExt");
    private static final javax.xml.namespace.QName OBRA$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "obra");
    private static final javax.xml.namespace.QName ATVEVENTO$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "atvEvento");
    private static final javax.xml.namespace.QName EXPLROD$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "explRod");
    private static final javax.xml.namespace.QName INFOCOMPL$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "infoCompl");
    
    
    /**
     * Gets the "locPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest getLocPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest)get_store().find_element_user(LOCPREST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "locPrest" element
     */
    public void setLocPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest locPrest)
    {
        generatedSetterHelperImpl(locPrest, LOCPREST$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "locPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest addNewLocPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest)get_store().add_element_user(LOCPREST$0);
            return target;
        }
    }
    
    /**
     * Gets the "cServ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ getCServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ)get_store().find_element_user(CSERV$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cServ" element
     */
    public void setCServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ cServ)
    {
        generatedSetterHelperImpl(cServ, CSERV$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "cServ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ addNewCServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCCServ)get_store().add_element_user(CSERV$2);
            return target;
        }
    }
    
    /**
     * Gets the "comExt" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior getComExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior)get_store().find_element_user(COMEXT$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "comExt" element
     */
    public boolean isSetComExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMEXT$4) != 0;
        }
    }
    
    /**
     * Sets the "comExt" element
     */
    public void setComExt(org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior comExt)
    {
        generatedSetterHelperImpl(comExt, COMEXT$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "comExt" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior addNewComExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior)get_store().add_element_user(COMEXT$4);
            return target;
        }
    }
    
    /**
     * Unsets the "comExt" element
     */
    public void unsetComExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMEXT$4, 0);
        }
    }
    
    /**
     * Gets the "obra" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra getObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra)get_store().find_element_user(OBRA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "obra" element
     */
    public boolean isSetObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBRA$6) != 0;
        }
    }
    
    /**
     * Sets the "obra" element
     */
    public void setObra(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra obra)
    {
        generatedSetterHelperImpl(obra, OBRA$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "obra" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra addNewObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra)get_store().add_element_user(OBRA$6);
            return target;
        }
    }
    
    /**
     * Unsets the "obra" element
     */
    public void unsetObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBRA$6, 0);
        }
    }
    
    /**
     * Gets the "atvEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento getAtvEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento)get_store().find_element_user(ATVEVENTO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "atvEvento" element
     */
    public boolean isSetAtvEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ATVEVENTO$8) != 0;
        }
    }
    
    /**
     * Sets the "atvEvento" element
     */
    public void setAtvEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento atvEvento)
    {
        generatedSetterHelperImpl(atvEvento, ATVEVENTO$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "atvEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento addNewAtvEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento)get_store().add_element_user(ATVEVENTO$8);
            return target;
        }
    }
    
    /**
     * Unsets the "atvEvento" element
     */
    public void unsetAtvEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ATVEVENTO$8, 0);
        }
    }
    
    /**
     * Gets the "explRod" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria getExplRod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria)get_store().find_element_user(EXPLROD$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "explRod" element
     */
    public boolean isSetExplRod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXPLROD$10) != 0;
        }
    }
    
    /**
     * Sets the "explRod" element
     */
    public void setExplRod(org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria explRod)
    {
        generatedSetterHelperImpl(explRod, EXPLROD$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "explRod" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria addNewExplRod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria)get_store().add_element_user(EXPLROD$10);
            return target;
        }
    }
    
    /**
     * Unsets the "explRod" element
     */
    public void unsetExplRod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXPLROD$10, 0);
        }
    }
    
    /**
     * Gets the "infoCompl" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl getInfoCompl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl)get_store().find_element_user(INFOCOMPL$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "infoCompl" element
     */
    public boolean isSetInfoCompl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INFOCOMPL$12) != 0;
        }
    }
    
    /**
     * Sets the "infoCompl" element
     */
    public void setInfoCompl(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl infoCompl)
    {
        generatedSetterHelperImpl(infoCompl, INFOCOMPL$12, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "infoCompl" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl addNewInfoCompl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl)get_store().add_element_user(INFOCOMPL$12);
            return target;
        }
    }
    
    /**
     * Unsets the "infoCompl" element
     */
    public void unsetInfoCompl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INFOCOMPL$12, 0);
        }
    }
}
