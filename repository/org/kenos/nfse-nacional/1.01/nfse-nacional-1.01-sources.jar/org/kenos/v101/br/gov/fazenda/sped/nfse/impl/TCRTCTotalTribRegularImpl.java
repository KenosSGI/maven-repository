/*
 * XML Type:  TCRTCTotalTribRegular
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalTribRegular(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalTribRegularImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalTribRegularImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PALIQEFEREGIBSUF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfeRegIBSUF");
    private static final javax.xml.namespace.QName VTRIBREGIBSUF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTribRegIBSUF");
    private static final javax.xml.namespace.QName PALIQEFEREGIBSMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfeRegIBSMun");
    private static final javax.xml.namespace.QName VTRIBREGIBSMUN$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTribRegIBSMun");
    private static final javax.xml.namespace.QName PALIQEFEREGCBS$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfeRegCBS");
    private static final javax.xml.namespace.QName VTRIBREGCBS$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTribRegCBS");
    
    
    /**
     * Gets the "pAliqEfeRegIBSUF" element
     */
    public java.lang.String getPAliqEfeRegIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGIBSUF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfeRegIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGIBSUF$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfeRegIBSUF" element
     */
    public void setPAliqEfeRegIBSUF(java.lang.String pAliqEfeRegIBSUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGIBSUF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFEREGIBSUF$0);
            }
            target.setStringValue(pAliqEfeRegIBSUF);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfeRegIBSUF" element
     */
    public void xsetPAliqEfeRegIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegIBSUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGIBSUF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFEREGIBSUF$0);
            }
            target.set(pAliqEfeRegIBSUF);
        }
    }
    
    /**
     * Gets the "vTribRegIBSUF" element
     */
    public java.lang.String getVTribRegIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGIBSUF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTribRegIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGIBSUF$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTribRegIBSUF" element
     */
    public void setVTribRegIBSUF(java.lang.String vTribRegIBSUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGIBSUF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTRIBREGIBSUF$2);
            }
            target.setStringValue(vTribRegIBSUF);
        }
    }
    
    /**
     * Sets (as xml) the "vTribRegIBSUF" element
     */
    public void xsetVTribRegIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegIBSUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGIBSUF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTRIBREGIBSUF$2);
            }
            target.set(vTribRegIBSUF);
        }
    }
    
    /**
     * Gets the "pAliqEfeRegIBSMun" element
     */
    public java.lang.String getPAliqEfeRegIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGIBSMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfeRegIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGIBSMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfeRegIBSMun" element
     */
    public void setPAliqEfeRegIBSMun(java.lang.String pAliqEfeRegIBSMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGIBSMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFEREGIBSMUN$4);
            }
            target.setStringValue(pAliqEfeRegIBSMun);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfeRegIBSMun" element
     */
    public void xsetPAliqEfeRegIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegIBSMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGIBSMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFEREGIBSMUN$4);
            }
            target.set(pAliqEfeRegIBSMun);
        }
    }
    
    /**
     * Gets the "vTribRegIBSMun" element
     */
    public java.lang.String getVTribRegIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGIBSMUN$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTribRegIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGIBSMUN$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTribRegIBSMun" element
     */
    public void setVTribRegIBSMun(java.lang.String vTribRegIBSMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGIBSMUN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTRIBREGIBSMUN$6);
            }
            target.setStringValue(vTribRegIBSMun);
        }
    }
    
    /**
     * Sets (as xml) the "vTribRegIBSMun" element
     */
    public void xsetVTribRegIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegIBSMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGIBSMUN$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTRIBREGIBSMUN$6);
            }
            target.set(vTribRegIBSMun);
        }
    }
    
    /**
     * Gets the "pAliqEfeRegCBS" element
     */
    public java.lang.String getPAliqEfeRegCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGCBS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfeRegCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGCBS$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfeRegCBS" element
     */
    public void setPAliqEfeRegCBS(java.lang.String pAliqEfeRegCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFEREGCBS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFEREGCBS$8);
            }
            target.setStringValue(pAliqEfeRegCBS);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfeRegCBS" element
     */
    public void xsetPAliqEfeRegCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFEREGCBS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFEREGCBS$8);
            }
            target.set(pAliqEfeRegCBS);
        }
    }
    
    /**
     * Gets the "vTribRegCBS" element
     */
    public java.lang.String getVTribRegCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGCBS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTribRegCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGCBS$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTribRegCBS" element
     */
    public void setVTribRegCBS(java.lang.String vTribRegCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTRIBREGCBS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTRIBREGCBS$10);
            }
            target.setStringValue(vTribRegCBS);
        }
    }
    
    /**
     * Sets (as xml) the "vTribRegCBS" element
     */
    public void xsetVTribRegCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTRIBREGCBS$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTRIBREGCBS$10);
            }
            target.set(vTribRegCBS);
        }
    }
}
