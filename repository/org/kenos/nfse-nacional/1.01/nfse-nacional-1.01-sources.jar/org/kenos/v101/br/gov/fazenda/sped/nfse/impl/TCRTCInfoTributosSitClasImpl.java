/*
 * XML Type:  TCRTCInfoTributosSitClas
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoTributosSitClas(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoTributosSitClasImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosSitClas
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoTributosSitClasImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CST$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CST");
    private static final javax.xml.namespace.QName CCLASSTRIB$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cClassTrib");
    private static final javax.xml.namespace.QName CCREDPRES$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cCredPres");
    private static final javax.xml.namespace.QName GTRIBREGULAR$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gTribRegular");
    private static final javax.xml.namespace.QName GDIF$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gDif");
    
    
    /**
     * Gets the "CST" element
     */
    public java.lang.String getCST()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CST" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib xgetCST()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().find_element_user(CST$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CST" element
     */
    public void setCST(java.lang.String cst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CST$0);
            }
            target.setStringValue(cst);
        }
    }
    
    /**
     * Sets (as xml) the "CST" element
     */
    public void xsetCST(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib cst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().add_element_user(CST$0);
            }
            target.set(cst);
        }
    }
    
    /**
     * Gets the "cClassTrib" element
     */
    public java.lang.String getCClassTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCLASSTRIB$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cClassTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib xgetCClassTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().find_element_user(CCLASSTRIB$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cClassTrib" element
     */
    public void setCClassTrib(java.lang.String cClassTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCLASSTRIB$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CCLASSTRIB$2);
            }
            target.setStringValue(cClassTrib);
        }
    }
    
    /**
     * Sets (as xml) the "cClassTrib" element
     */
    public void xsetCClassTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib cClassTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().find_element_user(CCLASSTRIB$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().add_element_user(CCLASSTRIB$2);
            }
            target.set(cClassTrib);
        }
    }
    
    /**
     * Gets the "cCredPres" element
     */
    public java.lang.String getCCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCREDPRES$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cCredPres" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres xgetCCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres)get_store().find_element_user(CCREDPRES$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "cCredPres" element
     */
    public boolean isSetCCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCREDPRES$4) != 0;
        }
    }
    
    /**
     * Sets the "cCredPres" element
     */
    public void setCCredPres(java.lang.String cCredPres)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCREDPRES$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CCREDPRES$4);
            }
            target.setStringValue(cCredPres);
        }
    }
    
    /**
     * Sets (as xml) the "cCredPres" element
     */
    public void xsetCCredPres(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres cCredPres)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres)get_store().find_element_user(CCREDPRES$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodCredPres)get_store().add_element_user(CCREDPRES$4);
            }
            target.set(cCredPres);
        }
    }
    
    /**
     * Unsets the "cCredPres" element
     */
    public void unsetCCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCREDPRES$4, 0);
        }
    }
    
    /**
     * Gets the "gTribRegular" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular getGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular)get_store().find_element_user(GTRIBREGULAR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gTribRegular" element
     */
    public boolean isSetGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTRIBREGULAR$6) != 0;
        }
    }
    
    /**
     * Sets the "gTribRegular" element
     */
    public void setGTribRegular(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular gTribRegular)
    {
        generatedSetterHelperImpl(gTribRegular, GTRIBREGULAR$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gTribRegular" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular addNewGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular)get_store().add_element_user(GTRIBREGULAR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "gTribRegular" element
     */
    public void unsetGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTRIBREGULAR$6, 0);
        }
    }
    
    /**
     * Gets the "gDif" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif getGDif()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif)get_store().find_element_user(GDIF$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gDif" element
     */
    public boolean isSetGDif()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GDIF$8) != 0;
        }
    }
    
    /**
     * Sets the "gDif" element
     */
    public void setGDif(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif gDif)
    {
        generatedSetterHelperImpl(gDif, GDIF$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gDif" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif addNewGDif()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif)get_store().add_element_user(GDIF$8);
            return target;
        }
    }
    
    /**
     * Unsets the "gDif" element
     */
    public void unsetGDif()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GDIF$8, 0);
        }
    }
}
