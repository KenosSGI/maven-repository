/*
 * XML Type:  TCRTCValoresIBSCBSFed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCValoresIBSCBSFed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCValoresIBSCBSFed extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCValoresIBSCBSFed.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcrtcvaloresibscbsfeda2b9type");
    
    /**
     * Gets the "pCBS" element
     */
    java.lang.String getPCBS();
    
    /**
     * Gets (as xml) the "pCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPCBS();
    
    /**
     * Sets the "pCBS" element
     */
    void setPCBS(java.lang.String pcbs);
    
    /**
     * Sets (as xml) the "pCBS" element
     */
    void xsetPCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pcbs);
    
    /**
     * Gets the "pRedAliqCBS" element
     */
    java.lang.String getPRedAliqCBS();
    
    /**
     * Gets (as xml) the "pRedAliqCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedAliqCBS();
    
    /**
     * True if has "pRedAliqCBS" element
     */
    boolean isSetPRedAliqCBS();
    
    /**
     * Sets the "pRedAliqCBS" element
     */
    void setPRedAliqCBS(java.lang.String pRedAliqCBS);
    
    /**
     * Sets (as xml) the "pRedAliqCBS" element
     */
    void xsetPRedAliqCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedAliqCBS);
    
    /**
     * Unsets the "pRedAliqCBS" element
     */
    void unsetPRedAliqCBS();
    
    /**
     * Gets the "pAliqEfetCBS" element
     */
    java.lang.String getPAliqEfetCBS();
    
    /**
     * Gets (as xml) the "pAliqEfetCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfetCBS();
    
    /**
     * Sets the "pAliqEfetCBS" element
     */
    void setPAliqEfetCBS(java.lang.String pAliqEfetCBS);
    
    /**
     * Sets (as xml) the "pAliqEfetCBS" element
     */
    void xsetPAliqEfetCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfetCBS);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
