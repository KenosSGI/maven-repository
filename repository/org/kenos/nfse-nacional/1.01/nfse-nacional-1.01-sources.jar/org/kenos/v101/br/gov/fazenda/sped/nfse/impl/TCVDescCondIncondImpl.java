/*
 * XML Type:  TCVDescCondIncond
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCVDescCondIncond(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCVDescCondIncondImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond
{
    private static final long serialVersionUID = 1L;
    
    public TCVDescCondIncondImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VDESCINCOND$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDescIncond");
    private static final javax.xml.namespace.QName VDESCCOND$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDescCond");
    
    
    /**
     * Gets the "vDescIncond" element
     */
    public java.lang.String getVDescIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDESCINCOND$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDescIncond" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDescIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDESCINCOND$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDescIncond" element
     */
    public boolean isSetVDescIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDESCINCOND$0) != 0;
        }
    }
    
    /**
     * Sets the "vDescIncond" element
     */
    public void setVDescIncond(java.lang.String vDescIncond)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDESCINCOND$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDESCINCOND$0);
            }
            target.setStringValue(vDescIncond);
        }
    }
    
    /**
     * Sets (as xml) the "vDescIncond" element
     */
    public void xsetVDescIncond(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDescIncond)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDESCINCOND$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDESCINCOND$0);
            }
            target.set(vDescIncond);
        }
    }
    
    /**
     * Unsets the "vDescIncond" element
     */
    public void unsetVDescIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDESCINCOND$0, 0);
        }
    }
    
    /**
     * Gets the "vDescCond" element
     */
    public java.lang.String getVDescCond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDESCCOND$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDescCond" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDescCond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDESCCOND$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDescCond" element
     */
    public boolean isSetVDescCond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDESCCOND$2) != 0;
        }
    }
    
    /**
     * Sets the "vDescCond" element
     */
    public void setVDescCond(java.lang.String vDescCond)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDESCCOND$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDESCCOND$2);
            }
            target.setStringValue(vDescCond);
        }
    }
    
    /**
     * Sets (as xml) the "vDescCond" element
     */
    public void xsetVDescCond(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDescCond)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDESCCOND$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDESCCOND$2);
            }
            target.set(vDescCond);
        }
    }
    
    /**
     * Unsets the "vDescCond" element
     */
    public void unsetVDescCond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDESCCOND$2, 0);
        }
    }
}
