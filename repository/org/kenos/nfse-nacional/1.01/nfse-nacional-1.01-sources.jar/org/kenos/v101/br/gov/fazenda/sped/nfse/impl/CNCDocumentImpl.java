/*
 * An XML document type.
 * Localname: CNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.CNCDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * A document containing one CNC(@http://www.sped.fazenda.gov.br/nfse) element.
 *
 * This is a complex type.
 */
public class CNCDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.CNCDocument
{
    private static final long serialVersionUID = 1L;
    
    public CNCDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNC");
    
    
    /**
     * Gets the "CNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC getCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC)get_store().find_element_user(CNC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CNC" element
     */
    public void setCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC cnc)
    {
        generatedSetterHelperImpl(cnc, CNC$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC addNewCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC)get_store().add_element_user(CNC$0);
            return target;
        }
    }
}
