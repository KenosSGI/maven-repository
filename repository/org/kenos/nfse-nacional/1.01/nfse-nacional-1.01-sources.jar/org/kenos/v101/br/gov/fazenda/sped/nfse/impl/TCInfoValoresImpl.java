/*
 * XML Type:  TCInfoValores
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoValores(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoValoresImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoValoresImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VSERVPREST$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vServPrest");
    private static final javax.xml.namespace.QName VDESCCONDINCOND$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDescCondIncond");
    private static final javax.xml.namespace.QName VDEDRED$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDedRed");
    private static final javax.xml.namespace.QName TRIB$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "trib");
    
    
    /**
     * Gets the "vServPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest getVServPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest)get_store().find_element_user(VSERVPREST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "vServPrest" element
     */
    public void setVServPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest vServPrest)
    {
        generatedSetterHelperImpl(vServPrest, VSERVPREST$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "vServPrest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest addNewVServPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCVServPrest)get_store().add_element_user(VSERVPREST$0);
            return target;
        }
    }
    
    /**
     * Gets the "vDescCondIncond" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond getVDescCondIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond)get_store().find_element_user(VDESCCONDINCOND$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vDescCondIncond" element
     */
    public boolean isSetVDescCondIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDESCCONDINCOND$2) != 0;
        }
    }
    
    /**
     * Sets the "vDescCondIncond" element
     */
    public void setVDescCondIncond(org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond vDescCondIncond)
    {
        generatedSetterHelperImpl(vDescCondIncond, VDESCCONDINCOND$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "vDescCondIncond" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond addNewVDescCondIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCVDescCondIncond)get_store().add_element_user(VDESCCONDINCOND$2);
            return target;
        }
    }
    
    /**
     * Unsets the "vDescCondIncond" element
     */
    public void unsetVDescCondIncond()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDESCCONDINCOND$2, 0);
        }
    }
    
    /**
     * Gets the "vDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed getVDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed)get_store().find_element_user(VDEDRED$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vDedRed" element
     */
    public boolean isSetVDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDEDRED$4) != 0;
        }
    }
    
    /**
     * Sets the "vDedRed" element
     */
    public void setVDedRed(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed vDedRed)
    {
        generatedSetterHelperImpl(vDedRed, VDEDRED$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "vDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed addNewVDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoDedRed)get_store().add_element_user(VDEDRED$4);
            return target;
        }
    }
    
    /**
     * Unsets the "vDedRed" element
     */
    public void unsetVDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDEDRED$4, 0);
        }
    }
    
    /**
     * Gets the "trib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao getTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao)get_store().find_element_user(TRIB$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "trib" element
     */
    public void setTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao trib)
    {
        generatedSetterHelperImpl(trib, TRIB$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "trib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao addNewTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao)get_store().add_element_user(TRIB$6);
            return target;
        }
    }
}
