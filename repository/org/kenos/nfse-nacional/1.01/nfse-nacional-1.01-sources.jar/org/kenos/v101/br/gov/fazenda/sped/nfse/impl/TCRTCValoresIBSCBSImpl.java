/*
 * XML Type:  TCRTCValoresIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCValoresIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCValoresIBSCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCValoresIBSCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VBC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vBC");
    private static final javax.xml.namespace.QName VCALCREEREPRES$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCalcReeRepRes");
    private static final javax.xml.namespace.QName UF$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "uf");
    private static final javax.xml.namespace.QName MUN$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "mun");
    private static final javax.xml.namespace.QName FED$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fed");
    
    
    /**
     * Gets the "vBC" element
     */
    public java.lang.String getVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vBC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vBC" element
     */
    public void setVBC(java.lang.String vbc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VBC$0);
            }
            target.setStringValue(vbc);
        }
    }
    
    /**
     * Sets (as xml) the "vBC" element
     */
    public void xsetVBC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vbc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VBC$0);
            }
            target.set(vbc);
        }
    }
    
    /**
     * Gets the "vCalcReeRepRes" element
     */
    public java.lang.String getVCalcReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCREEREPRES$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCalcReeRepRes" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCalcReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCREEREPRES$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vCalcReeRepRes" element
     */
    public boolean isSetVCalcReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VCALCREEREPRES$2) != 0;
        }
    }
    
    /**
     * Sets the "vCalcReeRepRes" element
     */
    public void setVCalcReeRepRes(java.lang.String vCalcReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCREEREPRES$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCALCREEREPRES$2);
            }
            target.setStringValue(vCalcReeRepRes);
        }
    }
    
    /**
     * Sets (as xml) the "vCalcReeRepRes" element
     */
    public void xsetVCalcReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCalcReeRepRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCREEREPRES$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCALCREEREPRES$2);
            }
            target.set(vCalcReeRepRes);
        }
    }
    
    /**
     * Unsets the "vCalcReeRepRes" element
     */
    public void unsetVCalcReeRepRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VCALCREEREPRES$2, 0);
        }
    }
    
    /**
     * Gets the "uf" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF getUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF)get_store().find_element_user(UF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "uf" element
     */
    public void setUf(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF uf)
    {
        generatedSetterHelperImpl(uf, UF$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "uf" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF addNewUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF)get_store().add_element_user(UF$4);
            return target;
        }
    }
    
    /**
     * Gets the "mun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun getMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun)get_store().find_element_user(MUN$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "mun" element
     */
    public void setMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun mun)
    {
        generatedSetterHelperImpl(mun, MUN$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "mun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun addNewMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun)get_store().add_element_user(MUN$6);
            return target;
        }
    }
    
    /**
     * Gets the "fed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed getFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed)get_store().find_element_user(FED$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "fed" element
     */
    public void setFed(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed fed)
    {
        generatedSetterHelperImpl(fed, FED$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "fed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed addNewFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed)get_store().add_element_user(FED$8);
            return target;
        }
    }
}
