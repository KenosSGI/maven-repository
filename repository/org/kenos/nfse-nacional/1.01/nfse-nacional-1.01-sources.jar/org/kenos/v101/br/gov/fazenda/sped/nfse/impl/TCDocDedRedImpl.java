/*
 * XML Type:  TCDocDedRed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCDocDedRed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCDocDedRedImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed
{
    private static final long serialVersionUID = 1L;
    
    public TCDocDedRedImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHNFSE$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chNFSe");
    private static final javax.xml.namespace.QName CHNFE$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chNFe");
    private static final javax.xml.namespace.QName NFSEMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "NFSeMun");
    private static final javax.xml.namespace.QName NFNFS$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "NFNFS");
    private static final javax.xml.namespace.QName NDOCFISC$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDocFisc");
    private static final javax.xml.namespace.QName NDOC$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDoc");
    private static final javax.xml.namespace.QName TPDEDRED$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpDedRed");
    private static final javax.xml.namespace.QName XDESCOUTDED$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDescOutDed");
    private static final javax.xml.namespace.QName DTEMIDOC$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dtEmiDoc");
    private static final javax.xml.namespace.QName VDEDUTIVELREDUTIVEL$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDedutivelRedutivel");
    private static final javax.xml.namespace.QName VDEDUCAOREDUCAO$20 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDeducaoReducao");
    private static final javax.xml.namespace.QName FORNEC$22 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fornec");
    
    
    /**
     * Gets the "chNFSe" element
     */
    public java.lang.String getChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "chNFSe" element
     */
    public boolean isSetChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CHNFSE$0) != 0;
        }
    }
    
    /**
     * Sets the "chNFSe" element
     */
    public void setChNFSe(java.lang.String chNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHNFSE$0);
            }
            target.setStringValue(chNFSe);
        }
    }
    
    /**
     * Sets (as xml) the "chNFSe" element
     */
    public void xsetChNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSE$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(CHNFSE$0);
            }
            target.set(chNFSe);
        }
    }
    
    /**
     * Unsets the "chNFSe" element
     */
    public void unsetChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CHNFSE$0, 0);
        }
    }
    
    /**
     * Gets the "chNFe" element
     */
    public java.lang.String getChNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chNFe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe xgetChNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe)get_store().find_element_user(CHNFE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "chNFe" element
     */
    public boolean isSetChNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CHNFE$2) != 0;
        }
    }
    
    /**
     * Sets the "chNFe" element
     */
    public void setChNFe(java.lang.String chNFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHNFE$2);
            }
            target.setStringValue(chNFe);
        }
    }
    
    /**
     * Sets (as xml) the "chNFe" element
     */
    public void xsetChNFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe chNFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe)get_store().find_element_user(CHNFE$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe)get_store().add_element_user(CHNFE$2);
            }
            target.set(chNFe);
        }
    }
    
    /**
     * Unsets the "chNFe" element
     */
    public void unsetChNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CHNFE$2, 0);
        }
    }
    
    /**
     * Gets the "NFSeMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe getNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe)get_store().find_element_user(NFSEMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "NFSeMun" element
     */
    public boolean isSetNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NFSEMUN$4) != 0;
        }
    }
    
    /**
     * Sets the "NFSeMun" element
     */
    public void setNFSeMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe nfSeMun)
    {
        generatedSetterHelperImpl(nfSeMun, NFSEMUN$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NFSeMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe addNewNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe)get_store().add_element_user(NFSEMUN$4);
            return target;
        }
    }
    
    /**
     * Unsets the "NFSeMun" element
     */
    public void unsetNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NFSEMUN$4, 0);
        }
    }
    
    /**
     * Gets the "NFNFS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS getNFNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS)get_store().find_element_user(NFNFS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "NFNFS" element
     */
    public boolean isSetNFNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NFNFS$6) != 0;
        }
    }
    
    /**
     * Sets the "NFNFS" element
     */
    public void setNFNFS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS nfnfs)
    {
        generatedSetterHelperImpl(nfnfs, NFNFS$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NFNFS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS addNewNFNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS)get_store().add_element_user(NFNFS$6);
            return target;
        }
    }
    
    /**
     * Unsets the "NFNFS" element
     */
    public void unsetNFNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NFNFS$6, 0);
        }
    }
    
    /**
     * Gets the "nDocFisc" element
     */
    public java.lang.String getNDocFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOCFISC$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDocFisc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDocFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOCFISC$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "nDocFisc" element
     */
    public boolean isSetNDocFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NDOCFISC$8) != 0;
        }
    }
    
    /**
     * Sets the "nDocFisc" element
     */
    public void setNDocFisc(java.lang.String nDocFisc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOCFISC$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDOCFISC$8);
            }
            target.setStringValue(nDocFisc);
        }
    }
    
    /**
     * Sets (as xml) the "nDocFisc" element
     */
    public void xsetNDocFisc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDocFisc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOCFISC$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(NDOCFISC$8);
            }
            target.set(nDocFisc);
        }
    }
    
    /**
     * Unsets the "nDocFisc" element
     */
    public void unsetNDocFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NDOCFISC$8, 0);
        }
    }
    
    /**
     * Gets the "nDoc" element
     */
    public java.lang.String getNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOC$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDoc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOC$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "nDoc" element
     */
    public boolean isSetNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NDOC$10) != 0;
        }
    }
    
    /**
     * Sets the "nDoc" element
     */
    public void setNDoc(java.lang.String nDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDOC$10);
            }
            target.setStringValue(nDoc);
        }
    }
    
    /**
     * Sets (as xml) the "nDoc" element
     */
    public void xsetNDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOC$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(NDOC$10);
            }
            target.set(nDoc);
        }
    }
    
    /**
     * Unsets the "nDoc" element
     */
    public void unsetNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NDOC$10, 0);
        }
    }
    
    /**
     * Gets the "tpDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed.Enum getTpDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPDEDRED$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpDedRed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed xgetTpDedRed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed)get_store().find_element_user(TPDEDRED$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpDedRed" element
     */
    public void setTpDedRed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed.Enum tpDedRed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPDEDRED$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPDEDRED$12);
            }
            target.setEnumValue(tpDedRed);
        }
    }
    
    /**
     * Sets (as xml) the "tpDedRed" element
     */
    public void xsetTpDedRed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed tpDedRed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed)get_store().find_element_user(TPDEDRED$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed)get_store().add_element_user(TPDEDRED$12);
            }
            target.set(tpDedRed);
        }
    }
    
    /**
     * Gets the "xDescOutDed" element
     */
    public java.lang.String getXDescOutDed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESCOUTDED$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDescOutDed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed xgetXDescOutDed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed)get_store().find_element_user(XDESCOUTDED$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "xDescOutDed" element
     */
    public boolean isSetXDescOutDed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XDESCOUTDED$14) != 0;
        }
    }
    
    /**
     * Sets the "xDescOutDed" element
     */
    public void setXDescOutDed(java.lang.String xDescOutDed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESCOUTDED$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESCOUTDED$14);
            }
            target.setStringValue(xDescOutDed);
        }
    }
    
    /**
     * Sets (as xml) the "xDescOutDed" element
     */
    public void xsetXDescOutDed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed xDescOutDed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed)get_store().find_element_user(XDESCOUTDED$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed)get_store().add_element_user(XDESCOUTDED$14);
            }
            target.set(xDescOutDed);
        }
    }
    
    /**
     * Unsets the "xDescOutDed" element
     */
    public void unsetXDescOutDed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XDESCOUTDED$14, 0);
        }
    }
    
    /**
     * Gets the "dtEmiDoc" element
     */
    public java.util.Calendar getDtEmiDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTEMIDOC$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "dtEmiDoc" element
     */
    public org.apache.xmlbeans.XmlDate xgetDtEmiDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTEMIDOC$16, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dtEmiDoc" element
     */
    public void setDtEmiDoc(java.util.Calendar dtEmiDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTEMIDOC$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTEMIDOC$16);
            }
            target.setCalendarValue(dtEmiDoc);
        }
    }
    
    /**
     * Sets (as xml) the "dtEmiDoc" element
     */
    public void xsetDtEmiDoc(org.apache.xmlbeans.XmlDate dtEmiDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTEMIDOC$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DTEMIDOC$16);
            }
            target.set(dtEmiDoc);
        }
    }
    
    /**
     * Gets the "vDedutivelRedutivel" element
     */
    public java.lang.String getVDedutivelRedutivel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDEDUTIVELREDUTIVEL$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDedutivelRedutivel" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDedutivelRedutivel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDEDUTIVELREDUTIVEL$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vDedutivelRedutivel" element
     */
    public void setVDedutivelRedutivel(java.lang.String vDedutivelRedutivel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDEDUTIVELREDUTIVEL$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDEDUTIVELREDUTIVEL$18);
            }
            target.setStringValue(vDedutivelRedutivel);
        }
    }
    
    /**
     * Sets (as xml) the "vDedutivelRedutivel" element
     */
    public void xsetVDedutivelRedutivel(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDedutivelRedutivel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDEDUTIVELREDUTIVEL$18, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDEDUTIVELREDUTIVEL$18);
            }
            target.set(vDedutivelRedutivel);
        }
    }
    
    /**
     * Gets the "vDeducaoReducao" element
     */
    public java.lang.String getVDeducaoReducao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDEDUCAOREDUCAO$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDeducaoReducao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDeducaoReducao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDEDUCAOREDUCAO$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vDeducaoReducao" element
     */
    public void setVDeducaoReducao(java.lang.String vDeducaoReducao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDEDUCAOREDUCAO$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDEDUCAOREDUCAO$20);
            }
            target.setStringValue(vDeducaoReducao);
        }
    }
    
    /**
     * Sets (as xml) the "vDeducaoReducao" element
     */
    public void xsetVDeducaoReducao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDeducaoReducao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDEDUCAOREDUCAO$20, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDEDUCAOREDUCAO$20);
            }
            target.set(vDeducaoReducao);
        }
    }
    
    /**
     * Gets the "fornec" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().find_element_user(FORNEC$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fornec" element
     */
    public boolean isSetFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FORNEC$22) != 0;
        }
    }
    
    /**
     * Sets the "fornec" element
     */
    public void setFornec(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa fornec)
    {
        generatedSetterHelperImpl(fornec, FORNEC$22, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "fornec" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().add_element_user(FORNEC$22);
            return target;
        }
    }
    
    /**
     * Unsets the "fornec" element
     */
    public void unsetFornec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FORNEC$22, 0);
        }
    }
}
