/*
 * XML Type:  TCRTCListaDocDFe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCListaDocDFe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCListaDocDFeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCListaDocDFeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TIPOCHAVEDFE$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tipoChaveDFe");
    private static final javax.xml.namespace.QName XTIPOCHAVEDFE$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xTipoChaveDFe");
    private static final javax.xml.namespace.QName CHAVEDFE$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chaveDFe");
    
    
    /**
     * Gets the "tipoChaveDFe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe.Enum getTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOCHAVEDFE$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tipoChaveDFe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe xgetTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe)get_store().find_element_user(TIPOCHAVEDFE$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tipoChaveDFe" element
     */
    public void setTipoChaveDFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe.Enum tipoChaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOCHAVEDFE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPOCHAVEDFE$0);
            }
            target.setEnumValue(tipoChaveDFe);
        }
    }
    
    /**
     * Sets (as xml) the "tipoChaveDFe" element
     */
    public void xsetTipoChaveDFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe tipoChaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe)get_store().find_element_user(TIPOCHAVEDFE$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTipoChaveDFe)get_store().add_element_user(TIPOCHAVEDFE$0);
            }
            target.set(tipoChaveDFe);
        }
    }
    
    /**
     * Gets the "xTipoChaveDFe" element
     */
    public java.lang.String getXTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTIPOCHAVEDFE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xTipoChaveDFe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetXTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XTIPOCHAVEDFE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "xTipoChaveDFe" element
     */
    public boolean isSetXTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XTIPOCHAVEDFE$2) != 0;
        }
    }
    
    /**
     * Sets the "xTipoChaveDFe" element
     */
    public void setXTipoChaveDFe(java.lang.String xTipoChaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTIPOCHAVEDFE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XTIPOCHAVEDFE$2);
            }
            target.setStringValue(xTipoChaveDFe);
        }
    }
    
    /**
     * Sets (as xml) the "xTipoChaveDFe" element
     */
    public void xsetXTipoChaveDFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xTipoChaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XTIPOCHAVEDFE$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(XTIPOCHAVEDFE$2);
            }
            target.set(xTipoChaveDFe);
        }
    }
    
    /**
     * Unsets the "xTipoChaveDFe" element
     */
    public void unsetXTipoChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XTIPOCHAVEDFE$2, 0);
        }
    }
    
    /**
     * Gets the "chaveDFe" element
     */
    public java.lang.String getChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHAVEDFE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chaveDFe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe xgetChaveDFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe)get_store().find_element_user(CHAVEDFE$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "chaveDFe" element
     */
    public void setChaveDFe(java.lang.String chaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHAVEDFE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHAVEDFE$4);
            }
            target.setStringValue(chaveDFe);
        }
    }
    
    /**
     * Sets (as xml) the "chaveDFe" element
     */
    public void xsetChaveDFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe chaveDFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe)get_store().find_element_user(CHAVEDFE$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCChaveDFe)get_store().add_element_user(CHAVEDFE$4);
            }
            target.set(chaveDFe);
        }
    }
}
