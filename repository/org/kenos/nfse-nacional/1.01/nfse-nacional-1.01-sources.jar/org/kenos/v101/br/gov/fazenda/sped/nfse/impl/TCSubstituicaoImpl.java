/*
 * XML Type:  TCSubstituicao
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCSubstituicao(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCSubstituicaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao
{
    private static final long serialVersionUID = 1L;
    
    public TCSubstituicaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHSUBSTDA$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chSubstda");
    private static final javax.xml.namespace.QName CMOTIVO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMotivo");
    private static final javax.xml.namespace.QName XMOTIVO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xMotivo");
    
    
    /**
     * Gets the "chSubstda" element
     */
    public java.lang.String getChSubstda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHSUBSTDA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chSubstda" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChSubstda()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHSUBSTDA$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "chSubstda" element
     */
    public void setChSubstda(java.lang.String chSubstda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHSUBSTDA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHSUBSTDA$0);
            }
            target.setStringValue(chSubstda);
        }
    }
    
    /**
     * Sets (as xml) the "chSubstda" element
     */
    public void xsetChSubstda(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chSubstda)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHSUBSTDA$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(CHSUBSTDA$0);
            }
            target.set(chSubstda);
        }
    }
    
    /**
     * Gets the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum getCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst xgetCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().find_element_user(CMOTIVO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMotivo" element
     */
    public void setCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMOTIVO$2);
            }
            target.setEnumValue(cMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "cMotivo" element
     */
    public void xsetCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().add_element_user(CMOTIVO$2);
            }
            target.set(cMotivo);
        }
    }
    
    /**
     * Gets the "xMotivo" element
     */
    public java.lang.String getXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "xMotivo" element
     */
    public boolean isSetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XMOTIVO$4) != 0;
        }
    }
    
    /**
     * Sets the "xMotivo" element
     */
    public void setXMotivo(java.lang.String xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XMOTIVO$4);
            }
            target.setStringValue(xMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    public void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XMOTIVO$4);
            }
            target.set(xMotivo);
        }
    }
    
    /**
     * Unsets the "xMotivo" element
     */
    public void unsetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XMOTIVO$4, 0);
        }
    }
}
