/*
 * XML Type:  TCRTCTotalCBSCredPres
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalCBSCredPres(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalCBSCredPresImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalCBSCredPresImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PCREDPRESCBS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pCredPresCBS");
    private static final javax.xml.namespace.QName VCREDPRESCBS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCredPresCBS");
    
    
    /**
     * Gets the "pCredPresCBS" element
     */
    public java.lang.String getPCredPresCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCREDPRESCBS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pCredPresCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPCredPresCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCREDPRESCBS$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pCredPresCBS" element
     */
    public void setPCredPresCBS(java.lang.String pCredPresCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCREDPRESCBS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PCREDPRESCBS$0);
            }
            target.setStringValue(pCredPresCBS);
        }
    }
    
    /**
     * Sets (as xml) the "pCredPresCBS" element
     */
    public void xsetPCredPresCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pCredPresCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCREDPRESCBS$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PCREDPRESCBS$0);
            }
            target.set(pCredPresCBS);
        }
    }
    
    /**
     * Gets the "vCredPresCBS" element
     */
    public java.lang.String getVCredPresCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCREDPRESCBS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCredPresCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCredPresCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCREDPRESCBS$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vCredPresCBS" element
     */
    public void setVCredPresCBS(java.lang.String vCredPresCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCREDPRESCBS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCREDPRESCBS$2);
            }
            target.setStringValue(vCredPresCBS);
        }
    }
    
    /**
     * Sets (as xml) the "vCredPresCBS" element
     */
    public void xsetVCredPresCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCredPresCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCREDPRESCBS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCREDPRESCBS$2);
            }
            target.set(vCredPresCBS);
        }
    }
}
