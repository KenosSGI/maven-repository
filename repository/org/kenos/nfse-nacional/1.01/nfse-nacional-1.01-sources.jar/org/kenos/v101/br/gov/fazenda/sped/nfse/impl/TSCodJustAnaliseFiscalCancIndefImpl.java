/*
 * XML Type:  TSCodJustAnaliseFiscalCancIndef
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSCodJustAnaliseFiscalCancIndef(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef.
 */
public class TSCodJustAnaliseFiscalCancIndefImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancIndef
{
    private static final long serialVersionUID = 1L;
    
    public TSCodJustAnaliseFiscalCancIndefImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSCodJustAnaliseFiscalCancIndefImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
