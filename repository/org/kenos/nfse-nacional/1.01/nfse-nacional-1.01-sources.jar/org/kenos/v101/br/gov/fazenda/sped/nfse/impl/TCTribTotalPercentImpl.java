/*
 * XML Type:  TCTribTotalPercent
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribTotalPercent(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribTotalPercentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent
{
    private static final long serialVersionUID = 1L;
    
    public TCTribTotalPercentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PTOTTRIBFED$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pTotTribFed");
    private static final javax.xml.namespace.QName PTOTTRIBEST$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pTotTribEst");
    private static final javax.xml.namespace.QName PTOTTRIBMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pTotTribMun");
    
    
    /**
     * Gets the "pTotTribFed" element
     */
    public java.lang.String getPTotTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBFED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pTotTribFed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPTotTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBFED$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pTotTribFed" element
     */
    public void setPTotTribFed(java.lang.String pTotTribFed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBFED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PTOTTRIBFED$0);
            }
            target.setStringValue(pTotTribFed);
        }
    }
    
    /**
     * Sets (as xml) the "pTotTribFed" element
     */
    public void xsetPTotTribFed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pTotTribFed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBFED$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PTOTTRIBFED$0);
            }
            target.set(pTotTribFed);
        }
    }
    
    /**
     * Gets the "pTotTribEst" element
     */
    public java.lang.String getPTotTribEst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBEST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pTotTribEst" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPTotTribEst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBEST$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pTotTribEst" element
     */
    public void setPTotTribEst(java.lang.String pTotTribEst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBEST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PTOTTRIBEST$2);
            }
            target.setStringValue(pTotTribEst);
        }
    }
    
    /**
     * Sets (as xml) the "pTotTribEst" element
     */
    public void xsetPTotTribEst(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pTotTribEst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBEST$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PTOTTRIBEST$2);
            }
            target.set(pTotTribEst);
        }
    }
    
    /**
     * Gets the "pTotTribMun" element
     */
    public java.lang.String getPTotTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pTotTribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPTotTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pTotTribMun" element
     */
    public void setPTotTribMun(java.lang.String pTotTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PTOTTRIBMUN$4);
            }
            target.setStringValue(pTotTribMun);
        }
    }
    
    /**
     * Sets (as xml) the "pTotTribMun" element
     */
    public void xsetPTotTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pTotTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PTOTTRIBMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PTOTTRIBMUN$4);
            }
            target.set(pTotTribMun);
        }
    }
}
