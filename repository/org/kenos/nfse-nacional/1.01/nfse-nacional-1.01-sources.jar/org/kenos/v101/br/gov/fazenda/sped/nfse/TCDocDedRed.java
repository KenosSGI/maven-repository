/*
 * XML Type:  TCDocDedRed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCDocDedRed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCDocDedRed extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCDocDedRed.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcdocdedred3d65type");
    
    /**
     * Gets the "chNFSe" element
     */
    java.lang.String getChNFSe();
    
    /**
     * Gets (as xml) the "chNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSe();
    
    /**
     * True if has "chNFSe" element
     */
    boolean isSetChNFSe();
    
    /**
     * Sets the "chNFSe" element
     */
    void setChNFSe(java.lang.String chNFSe);
    
    /**
     * Sets (as xml) the "chNFSe" element
     */
    void xsetChNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSe);
    
    /**
     * Unsets the "chNFSe" element
     */
    void unsetChNFSe();
    
    /**
     * Gets the "chNFe" element
     */
    java.lang.String getChNFe();
    
    /**
     * Gets (as xml) the "chNFe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe xgetChNFe();
    
    /**
     * True if has "chNFe" element
     */
    boolean isSetChNFe();
    
    /**
     * Sets the "chNFe" element
     */
    void setChNFe(java.lang.String chNFe);
    
    /**
     * Sets (as xml) the "chNFe" element
     */
    void xsetChNFe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFe chNFe);
    
    /**
     * Unsets the "chNFe" element
     */
    void unsetChNFe();
    
    /**
     * Gets the "NFSeMun" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe getNFSeMun();
    
    /**
     * True if has "NFSeMun" element
     */
    boolean isSetNFSeMun();
    
    /**
     * Sets the "NFSeMun" element
     */
    void setNFSeMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe nfSeMun);
    
    /**
     * Appends and returns a new empty "NFSeMun" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe addNewNFSeMun();
    
    /**
     * Unsets the "NFSeMun" element
     */
    void unsetNFSeMun();
    
    /**
     * Gets the "NFNFS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS getNFNFS();
    
    /**
     * True if has "NFNFS" element
     */
    boolean isSetNFNFS();
    
    /**
     * Sets the "NFNFS" element
     */
    void setNFNFS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS nfnfs);
    
    /**
     * Appends and returns a new empty "NFNFS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS addNewNFNFS();
    
    /**
     * Unsets the "NFNFS" element
     */
    void unsetNFNFS();
    
    /**
     * Gets the "nDocFisc" element
     */
    java.lang.String getNDocFisc();
    
    /**
     * Gets (as xml) the "nDocFisc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDocFisc();
    
    /**
     * True if has "nDocFisc" element
     */
    boolean isSetNDocFisc();
    
    /**
     * Sets the "nDocFisc" element
     */
    void setNDocFisc(java.lang.String nDocFisc);
    
    /**
     * Sets (as xml) the "nDocFisc" element
     */
    void xsetNDocFisc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDocFisc);
    
    /**
     * Unsets the "nDocFisc" element
     */
    void unsetNDocFisc();
    
    /**
     * Gets the "nDoc" element
     */
    java.lang.String getNDoc();
    
    /**
     * Gets (as xml) the "nDoc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDoc();
    
    /**
     * True if has "nDoc" element
     */
    boolean isSetNDoc();
    
    /**
     * Sets the "nDoc" element
     */
    void setNDoc(java.lang.String nDoc);
    
    /**
     * Sets (as xml) the "nDoc" element
     */
    void xsetNDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDoc);
    
    /**
     * Unsets the "nDoc" element
     */
    void unsetNDoc();
    
    /**
     * Gets the "tpDedRed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed.Enum getTpDedRed();
    
    /**
     * Gets (as xml) the "tpDedRed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed xgetTpDedRed();
    
    /**
     * Sets the "tpDedRed" element
     */
    void setTpDedRed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed.Enum tpDedRed);
    
    /**
     * Sets (as xml) the "tpDedRed" element
     */
    void xsetTpDedRed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeDedRed tpDedRed);
    
    /**
     * Gets the "xDescOutDed" element
     */
    java.lang.String getXDescOutDed();
    
    /**
     * Gets (as xml) the "xDescOutDed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed xgetXDescOutDed();
    
    /**
     * True if has "xDescOutDed" element
     */
    boolean isSetXDescOutDed();
    
    /**
     * Sets the "xDescOutDed" element
     */
    void setXDescOutDed(java.lang.String xDescOutDed);
    
    /**
     * Sets (as xml) the "xDescOutDed" element
     */
    void xsetXDescOutDed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescOutDedRed xDescOutDed);
    
    /**
     * Unsets the "xDescOutDed" element
     */
    void unsetXDescOutDed();
    
    /**
     * Gets the "dtEmiDoc" element
     */
    java.util.Calendar getDtEmiDoc();
    
    /**
     * Gets (as xml) the "dtEmiDoc" element
     */
    org.apache.xmlbeans.XmlDate xgetDtEmiDoc();
    
    /**
     * Sets the "dtEmiDoc" element
     */
    void setDtEmiDoc(java.util.Calendar dtEmiDoc);
    
    /**
     * Sets (as xml) the "dtEmiDoc" element
     */
    void xsetDtEmiDoc(org.apache.xmlbeans.XmlDate dtEmiDoc);
    
    /**
     * Gets the "vDedutivelRedutivel" element
     */
    java.lang.String getVDedutivelRedutivel();
    
    /**
     * Gets (as xml) the "vDedutivelRedutivel" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDedutivelRedutivel();
    
    /**
     * Sets the "vDedutivelRedutivel" element
     */
    void setVDedutivelRedutivel(java.lang.String vDedutivelRedutivel);
    
    /**
     * Sets (as xml) the "vDedutivelRedutivel" element
     */
    void xsetVDedutivelRedutivel(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDedutivelRedutivel);
    
    /**
     * Gets the "vDeducaoReducao" element
     */
    java.lang.String getVDeducaoReducao();
    
    /**
     * Gets (as xml) the "vDeducaoReducao" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDeducaoReducao();
    
    /**
     * Sets the "vDeducaoReducao" element
     */
    void setVDeducaoReducao(java.lang.String vDeducaoReducao);
    
    /**
     * Sets (as xml) the "vDeducaoReducao" element
     */
    void xsetVDeducaoReducao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDeducaoReducao);
    
    /**
     * Gets the "fornec" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getFornec();
    
    /**
     * True if has "fornec" element
     */
    boolean isSetFornec();
    
    /**
     * Sets the "fornec" element
     */
    void setFornec(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa fornec);
    
    /**
     * Appends and returns a new empty "fornec" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewFornec();
    
    /**
     * Unsets the "fornec" element
     */
    void unsetFornec();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocDedRed) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
