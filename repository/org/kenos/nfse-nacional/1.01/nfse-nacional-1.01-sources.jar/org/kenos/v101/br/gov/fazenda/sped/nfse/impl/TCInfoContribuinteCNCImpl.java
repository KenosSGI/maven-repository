/*
 * XML Type:  TCInfoContribuinteCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoContribuinteCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoContribuinteCNCImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoContribuinteCNCImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPF");
    private static final javax.xml.namespace.QName IM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "IM");
    private static final javax.xml.namespace.QName DINSCRICAOMUNICIPAL$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dInscricaoMunicipal");
    private static final javax.xml.namespace.QName ENDERCONTRIBUINTECNC$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "enderContribuinteCNC");
    private static final javax.xml.namespace.QName FONE$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fone");
    private static final javax.xml.namespace.QName EMAIL$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "email");
    private static final javax.xml.namespace.QName REGESPTRIBCONTRIBUINTECNC$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "regEspTribContribuinteCNC");
    private static final javax.xml.namespace.QName SITUACAOCADASTROCONTRIBUINTE$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "situacaoCadastroContribuinte");
    private static final javax.xml.namespace.QName MOTIVOSITUACAOCADASTROCONTRIBUINTE$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "motivoSituacaoCadastroContribuinte");
    private static final javax.xml.namespace.QName SITUACAOEMISSAONFSE$20 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "situacaoEmissaoNFSE");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "IM" element
     */
    public java.lang.String getIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun xgetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().find_element_user(IM$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "IM" element
     */
    public boolean isSetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IM$4) != 0;
        }
    }
    
    /**
     * Sets the "IM" element
     */
    public void setIM(java.lang.String im)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IM$4);
            }
            target.setStringValue(im);
        }
    }
    
    /**
     * Sets (as xml) the "IM" element
     */
    public void xsetIM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun im)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().add_element_user(IM$4);
            }
            target.set(im);
        }
    }
    
    /**
     * Unsets the "IM" element
     */
    public void unsetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IM$4, 0);
        }
    }
    
    /**
     * Gets the "dInscricaoMunicipal" element
     */
    public java.lang.String getDInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DINSCRICAOMUNICIPAL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dInscricaoMunicipal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DINSCRICAOMUNICIPAL$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dInscricaoMunicipal" element
     */
    public void setDInscricaoMunicipal(java.lang.String dInscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DINSCRICAOMUNICIPAL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DINSCRICAOMUNICIPAL$6);
            }
            target.setStringValue(dInscricaoMunicipal);
        }
    }
    
    /**
     * Sets (as xml) the "dInscricaoMunicipal" element
     */
    public void xsetDInscricaoMunicipal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dInscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DINSCRICAOMUNICIPAL$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DINSCRICAOMUNICIPAL$6);
            }
            target.set(dInscricaoMunicipal);
        }
    }
    
    /**
     * Gets the "enderContribuinteCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC getEnderContribuinteCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC)get_store().find_element_user(ENDERCONTRIBUINTECNC$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enderContribuinteCNC" element
     */
    public void setEnderContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC enderContribuinteCNC)
    {
        generatedSetterHelperImpl(enderContribuinteCNC, ENDERCONTRIBUINTECNC$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "enderContribuinteCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC addNewEnderContribuinteCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC)get_store().add_element_user(ENDERCONTRIBUINTECNC$8);
            return target;
        }
    }
    
    /**
     * Gets the "fone" element
     */
    public java.lang.String getFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fone" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone xgetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "fone" element
     */
    public boolean isSetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FONE$10) != 0;
        }
    }
    
    /**
     * Sets the "fone" element
     */
    public void setFone(java.lang.String fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FONE$10);
            }
            target.setStringValue(fone);
        }
    }
    
    /**
     * Sets (as xml) the "fone" element
     */
    public void xsetFone(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().add_element_user(FONE$10);
            }
            target.set(fone);
        }
    }
    
    /**
     * Unsets the "fone" element
     */
    public void unsetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FONE$10, 0);
        }
    }
    
    /**
     * Gets the "email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "email" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$12) != 0;
        }
    }
    
    /**
     * Sets the "email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$12);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "email" element
     */
    public void xsetEmail(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().add_element_user(EMAIL$12);
            }
            target.set(email);
        }
    }
    
    /**
     * Unsets the "email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$12, 0);
        }
    }
    
    /**
     * Gets the "regEspTribContribuinteCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum getRegEspTribContribuinteCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGESPTRIBCONTRIBUINTECNC$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "regEspTribContribuinteCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib xgetRegEspTribContribuinteCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().find_element_user(REGESPTRIBCONTRIBUINTECNC$14, 0);
            return target;
        }
    }
    
    /**
     * Sets the "regEspTribContribuinteCNC" element
     */
    public void setRegEspTribContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum regEspTribContribuinteCNC)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGESPTRIBCONTRIBUINTECNC$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REGESPTRIBCONTRIBUINTECNC$14);
            }
            target.setEnumValue(regEspTribContribuinteCNC);
        }
    }
    
    /**
     * Sets (as xml) the "regEspTribContribuinteCNC" element
     */
    public void xsetRegEspTribContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib regEspTribContribuinteCNC)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().find_element_user(REGESPTRIBCONTRIBUINTECNC$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib)get_store().add_element_user(REGESPTRIBCONTRIBUINTECNC$14);
            }
            target.set(regEspTribContribuinteCNC);
        }
    }
    
    /**
     * Gets the "situacaoCadastroContribuinte" element
     */
    public java.lang.String getSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAOCADASTROCONTRIBUINTE$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "situacaoCadastroContribuinte" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte xgetSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte)get_store().find_element_user(SITUACAOCADASTROCONTRIBUINTE$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "situacaoCadastroContribuinte" element
     */
    public boolean isSetSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SITUACAOCADASTROCONTRIBUINTE$16) != 0;
        }
    }
    
    /**
     * Sets the "situacaoCadastroContribuinte" element
     */
    public void setSituacaoCadastroContribuinte(java.lang.String situacaoCadastroContribuinte)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAOCADASTROCONTRIBUINTE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SITUACAOCADASTROCONTRIBUINTE$16);
            }
            target.setStringValue(situacaoCadastroContribuinte);
        }
    }
    
    /**
     * Sets (as xml) the "situacaoCadastroContribuinte" element
     */
    public void xsetSituacaoCadastroContribuinte(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte situacaoCadastroContribuinte)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte)get_store().find_element_user(SITUACAOCADASTROCONTRIBUINTE$16, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte)get_store().add_element_user(SITUACAOCADASTROCONTRIBUINTE$16);
            }
            target.set(situacaoCadastroContribuinte);
        }
    }
    
    /**
     * Unsets the "situacaoCadastroContribuinte" element
     */
    public void unsetSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SITUACAOCADASTROCONTRIBUINTE$16, 0);
        }
    }
    
    /**
     * Gets the "motivoSituacaoCadastroContribuinte" element
     */
    public java.lang.String getMotivoSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "motivoSituacaoCadastroContribuinte" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte xgetMotivoSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte)get_store().find_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "motivoSituacaoCadastroContribuinte" element
     */
    public boolean isSetMotivoSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18) != 0;
        }
    }
    
    /**
     * Sets the "motivoSituacaoCadastroContribuinte" element
     */
    public void setMotivoSituacaoCadastroContribuinte(java.lang.String motivoSituacaoCadastroContribuinte)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18);
            }
            target.setStringValue(motivoSituacaoCadastroContribuinte);
        }
    }
    
    /**
     * Sets (as xml) the "motivoSituacaoCadastroContribuinte" element
     */
    public void xsetMotivoSituacaoCadastroContribuinte(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte motivoSituacaoCadastroContribuinte)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte)get_store().find_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte)get_store().add_element_user(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18);
            }
            target.set(motivoSituacaoCadastroContribuinte);
        }
    }
    
    /**
     * Unsets the "motivoSituacaoCadastroContribuinte" element
     */
    public void unsetMotivoSituacaoCadastroContribuinte()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MOTIVOSITUACAOCADASTROCONTRIBUINTE$18, 0);
        }
    }
    
    /**
     * Gets the "situacaoEmissaoNFSE" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.Enum getSituacaoEmissaoNFSE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAOEMISSAONFSE$20, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "situacaoEmissaoNFSE" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE xgetSituacaoEmissaoNFSE()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE)get_store().find_element_user(SITUACAOEMISSAONFSE$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "situacaoEmissaoNFSE" element
     */
    public void setSituacaoEmissaoNFSE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.Enum situacaoEmissaoNFSE)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAOEMISSAONFSE$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SITUACAOEMISSAONFSE$20);
            }
            target.setEnumValue(situacaoEmissaoNFSE);
        }
    }
    
    /**
     * Sets (as xml) the "situacaoEmissaoNFSE" element
     */
    public void xsetSituacaoEmissaoNFSE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE situacaoEmissaoNFSE)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE)get_store().find_element_user(SITUACAOEMISSAONFSE$20, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE)get_store().add_element_user(SITUACAOEMISSAONFSE$20);
            }
            target.set(situacaoEmissaoNFSE);
        }
    }
}
