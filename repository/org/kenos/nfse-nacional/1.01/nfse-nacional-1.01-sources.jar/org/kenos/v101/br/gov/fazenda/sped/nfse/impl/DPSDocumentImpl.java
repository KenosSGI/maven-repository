/*
 * An XML document type.
 * Localname: DPS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.DPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * A document containing one DPS(@http://www.sped.fazenda.gov.br/nfse) element.
 *
 * This is a complex type.
 */
public class DPSDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.DPSDocument
{
    private static final long serialVersionUID = 1L;
    
    public DPSDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DPS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "DPS");
    
    
    /**
     * Gets the "DPS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS getDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS)get_store().find_element_user(DPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "DPS" element
     */
    public void setDPS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS dps)
    {
        generatedSetterHelperImpl(dps, DPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DPS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS addNewDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS)get_store().add_element_user(DPS$0);
            return target;
        }
    }
}
