/*
 * XML Type:  TCRTCValoresIBSCBSUF
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCValoresIBSCBSUF(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCValoresIBSCBSUFImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSUF
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCValoresIBSCBSUFImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PIBSUF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pIBSUF");
    private static final javax.xml.namespace.QName PREDALIQUF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pRedAliqUF");
    private static final javax.xml.namespace.QName PALIQEFETUF$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfetUF");
    
    
    /**
     * Gets the "pIBSUF" element
     */
    public java.lang.String getPIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSUF$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pIBSUF" element
     */
    public void setPIBSUF(java.lang.String pibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PIBSUF$0);
            }
            target.setStringValue(pibsuf);
        }
    }
    
    /**
     * Sets (as xml) the "pIBSUF" element
     */
    public void xsetPIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PIBSUF$0);
            }
            target.set(pibsuf);
        }
    }
    
    /**
     * Gets the "pRedAliqUF" element
     */
    public java.lang.String getPRedAliqUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQUF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pRedAliqUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedAliqUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQUF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "pRedAliqUF" element
     */
    public boolean isSetPRedAliqUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDALIQUF$2) != 0;
        }
    }
    
    /**
     * Sets the "pRedAliqUF" element
     */
    public void setPRedAliqUF(java.lang.String pRedAliqUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQUF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDALIQUF$2);
            }
            target.setStringValue(pRedAliqUF);
        }
    }
    
    /**
     * Sets (as xml) the "pRedAliqUF" element
     */
    public void xsetPRedAliqUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedAliqUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQUF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PREDALIQUF$2);
            }
            target.set(pRedAliqUF);
        }
    }
    
    /**
     * Unsets the "pRedAliqUF" element
     */
    public void unsetPRedAliqUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDALIQUF$2, 0);
        }
    }
    
    /**
     * Gets the "pAliqEfetUF" element
     */
    public java.lang.String getPAliqEfetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETUF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfetUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETUF$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfetUF" element
     */
    public void setPAliqEfetUF(java.lang.String pAliqEfetUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETUF$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFETUF$4);
            }
            target.setStringValue(pAliqEfetUF);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfetUF" element
     */
    public void xsetPAliqEfetUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfetUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETUF$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFETUF$4);
            }
            target.set(pAliqEfetUF);
        }
    }
}
