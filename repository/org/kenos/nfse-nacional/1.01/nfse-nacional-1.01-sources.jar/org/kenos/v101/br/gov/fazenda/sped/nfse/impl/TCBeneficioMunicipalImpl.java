/*
 * XML Type:  TCBeneficioMunicipal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCBeneficioMunicipal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCBeneficioMunicipalImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCBeneficioMunicipal
{
    private static final long serialVersionUID = 1L;
    
    public TCBeneficioMunicipalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NBM$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nBM");
    private static final javax.xml.namespace.QName VREDBCBM$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vRedBCBM");
    private static final javax.xml.namespace.QName PREDBCBM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pRedBCBM");
    
    
    /**
     * Gets the "nBM" element
     */
    public java.lang.String getNBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NBM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal xgetNBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal)get_store().find_element_user(NBM$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nBM" element
     */
    public void setNBM(java.lang.String nbm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NBM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NBM$0);
            }
            target.setStringValue(nbm);
        }
    }
    
    /**
     * Sets (as xml) the "nBM" element
     */
    public void xsetNBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal nbm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal)get_store().find_element_user(NBM$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumBeneficioMunicipal)get_store().add_element_user(NBM$0);
            }
            target.set(nbm);
        }
    }
    
    /**
     * Gets the "vRedBCBM" element
     */
    public java.lang.String getVRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VREDBCBM$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vRedBCBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VREDBCBM$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vRedBCBM" element
     */
    public boolean isSetVRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VREDBCBM$2) != 0;
        }
    }
    
    /**
     * Sets the "vRedBCBM" element
     */
    public void setVRedBCBM(java.lang.String vRedBCBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VREDBCBM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VREDBCBM$2);
            }
            target.setStringValue(vRedBCBM);
        }
    }
    
    /**
     * Sets (as xml) the "vRedBCBM" element
     */
    public void xsetVRedBCBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vRedBCBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VREDBCBM$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VREDBCBM$2);
            }
            target.set(vRedBCBM);
        }
    }
    
    /**
     * Unsets the "vRedBCBM" element
     */
    public void unsetVRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VREDBCBM$2, 0);
        }
    }
    
    /**
     * Gets the "pRedBCBM" element
     */
    public java.lang.String getPRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDBCBM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pRedBCBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDBCBM$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "pRedBCBM" element
     */
    public boolean isSetPRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDBCBM$4) != 0;
        }
    }
    
    /**
     * Sets the "pRedBCBM" element
     */
    public void setPRedBCBM(java.lang.String pRedBCBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDBCBM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDBCBM$4);
            }
            target.setStringValue(pRedBCBM);
        }
    }
    
    /**
     * Sets (as xml) the "pRedBCBM" element
     */
    public void xsetPRedBCBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedBCBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDBCBM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PREDBCBM$4);
            }
            target.set(pRedBCBM);
        }
    }
    
    /**
     * Unsets the "pRedBCBM" element
     */
    public void unsetPRedBCBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDBCBM$4, 0);
        }
    }
}
