/*
 * An XML document type.
 * Localname: evento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.EventoDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * A document containing one evento(@http://www.sped.fazenda.gov.br/nfse) element.
 *
 * This is a complex type.
 */
public class EventoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.EventoDocument
{
    private static final long serialVersionUID = 1L;
    
    public EventoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EVENTO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "evento");
    
    
    /**
     * Gets the "evento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento getEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento)get_store().find_element_user(EVENTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "evento" element
     */
    public void setEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento evento)
    {
        generatedSetterHelperImpl(evento, EVENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "evento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento addNewEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEvento)get_store().add_element_user(EVENTO$0);
            return target;
        }
    }
}
