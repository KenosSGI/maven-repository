/*
 * XML Type:  TCRTCInfoIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoIBSCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoIBSCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FINNFSE$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "finNFSe");
    private static final javax.xml.namespace.QName INDFINAL$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "indFinal");
    private static final javax.xml.namespace.QName CINDOP$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cIndOp");
    private static final javax.xml.namespace.QName TPOPER$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpOper");
    private static final javax.xml.namespace.QName GREFNFSE$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gRefNFSe");
    private static final javax.xml.namespace.QName TPENTEGOV$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpEnteGov");
    private static final javax.xml.namespace.QName INDDEST$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "indDest");
    private static final javax.xml.namespace.QName DEST$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dest");
    private static final javax.xml.namespace.QName IMOVEL$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "imovel");
    private static final javax.xml.namespace.QName VALORES$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "valores");
    
    
    /**
     * Gets the "finNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.Enum getFinNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FINNFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "finNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe xgetFinNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe)get_store().find_element_user(FINNFSE$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "finNFSe" element
     */
    public void setFinNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.Enum finNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FINNFSE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FINNFSE$0);
            }
            target.setEnumValue(finNFSe);
        }
    }
    
    /**
     * Sets (as xml) the "finNFSe" element
     */
    public void xsetFinNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe finNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe)get_store().find_element_user(FINNFSE$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe)get_store().add_element_user(FINNFSE$0);
            }
            target.set(finNFSe);
        }
    }
    
    /**
     * Gets the "indFinal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.Enum getIndFinal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDFINAL$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "indFinal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal xgetIndFinal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal)get_store().find_element_user(INDFINAL$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "indFinal" element
     */
    public boolean isSetIndFinal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INDFINAL$2) != 0;
        }
    }
    
    /**
     * Sets the "indFinal" element
     */
    public void setIndFinal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal.Enum indFinal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDFINAL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INDFINAL$2);
            }
            target.setEnumValue(indFinal);
        }
    }
    
    /**
     * Sets (as xml) the "indFinal" element
     */
    public void xsetIndFinal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal indFinal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal)get_store().find_element_user(INDFINAL$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndFinal)get_store().add_element_user(INDFINAL$2);
            }
            target.set(indFinal);
        }
    }
    
    /**
     * Unsets the "indFinal" element
     */
    public void unsetIndFinal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INDFINAL$2, 0);
        }
    }
    
    /**
     * Gets the "cIndOp" element
     */
    public java.lang.String getCIndOp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CINDOP$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cIndOp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp xgetCIndOp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp)get_store().find_element_user(CINDOP$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cIndOp" element
     */
    public void setCIndOp(java.lang.String cIndOp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CINDOP$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CINDOP$4);
            }
            target.setStringValue(cIndOp);
        }
    }
    
    /**
     * Sets (as xml) the "cIndOp" element
     */
    public void xsetCIndOp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp cIndOp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp)get_store().find_element_user(CINDOP$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodIndOp)get_store().add_element_user(CINDOP$4);
            }
            target.set(cIndOp);
        }
    }
    
    /**
     * Gets the "tpOper" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper.Enum getTpOper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPOPER$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpOper" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper xgetTpOper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper)get_store().find_element_user(TPOPER$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "tpOper" element
     */
    public boolean isSetTpOper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPOPER$6) != 0;
        }
    }
    
    /**
     * Sets the "tpOper" element
     */
    public void setTpOper(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper.Enum tpOper)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPOPER$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPOPER$6);
            }
            target.setEnumValue(tpOper);
        }
    }
    
    /**
     * Sets (as xml) the "tpOper" element
     */
    public void xsetTpOper(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper tpOper)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper)get_store().find_element_user(TPOPER$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpOper)get_store().add_element_user(TPOPER$6);
            }
            target.set(tpOper);
        }
    }
    
    /**
     * Unsets the "tpOper" element
     */
    public void unsetTpOper()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPOPER$6, 0);
        }
    }
    
    /**
     * Gets the "gRefNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe getGRefNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe)get_store().find_element_user(GREFNFSE$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gRefNFSe" element
     */
    public boolean isSetGRefNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GREFNFSE$8) != 0;
        }
    }
    
    /**
     * Sets the "gRefNFSe" element
     */
    public void setGRefNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe gRefNFSe)
    {
        generatedSetterHelperImpl(gRefNFSe, GREFNFSE$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gRefNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe addNewGRefNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoRefNFSe)get_store().add_element_user(GREFNFSE$8);
            return target;
        }
    }
    
    /**
     * Unsets the "gRefNFSe" element
     */
    public void unsetGRefNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GREFNFSE$8, 0);
        }
    }
    
    /**
     * Gets the "tpEnteGov" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov.Enum getTpEnteGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPENTEGOV$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpEnteGov" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov xgetTpEnteGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov)get_store().find_element_user(TPENTEGOV$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "tpEnteGov" element
     */
    public boolean isSetTpEnteGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPENTEGOV$10) != 0;
        }
    }
    
    /**
     * Sets the "tpEnteGov" element
     */
    public void setTpEnteGov(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov.Enum tpEnteGov)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPENTEGOV$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPENTEGOV$10);
            }
            target.setEnumValue(tpEnteGov);
        }
    }
    
    /**
     * Sets (as xml) the "tpEnteGov" element
     */
    public void xsetTpEnteGov(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov tpEnteGov)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov)get_store().find_element_user(TPENTEGOV$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpEnteGov)get_store().add_element_user(TPENTEGOV$10);
            }
            target.set(tpEnteGov);
        }
    }
    
    /**
     * Unsets the "tpEnteGov" element
     */
    public void unsetTpEnteGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPENTEGOV$10, 0);
        }
    }
    
    /**
     * Gets the "indDest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest.Enum getIndDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDDEST$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "indDest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest xgetIndDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest)get_store().find_element_user(INDDEST$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "indDest" element
     */
    public void setIndDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest.Enum indDest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDDEST$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INDDEST$12);
            }
            target.setEnumValue(indDest);
        }
    }
    
    /**
     * Sets (as xml) the "indDest" element
     */
    public void xsetIndDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest indDest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest)get_store().find_element_user(INDDEST$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCIndDest)get_store().add_element_user(INDDEST$12);
            }
            target.set(indDest);
        }
    }
    
    /**
     * Gets the "dest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest getDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest)get_store().find_element_user(DEST$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "dest" element
     */
    public boolean isSetDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DEST$14) != 0;
        }
    }
    
    /**
     * Sets the "dest" element
     */
    public void setDest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest dest)
    {
        generatedSetterHelperImpl(dest, DEST$14, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "dest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest addNewDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoDest)get_store().add_element_user(DEST$14);
            return target;
        }
    }
    
    /**
     * Unsets the "dest" element
     */
    public void unsetDest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DEST$14, 0);
        }
    }
    
    /**
     * Gets the "imovel" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel getImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel)get_store().find_element_user(IMOVEL$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "imovel" element
     */
    public boolean isSetImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IMOVEL$16) != 0;
        }
    }
    
    /**
     * Sets the "imovel" element
     */
    public void setImovel(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel imovel)
    {
        generatedSetterHelperImpl(imovel, IMOVEL$16, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "imovel" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel addNewImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoImovel)get_store().add_element_user(IMOVEL$16);
            return target;
        }
    }
    
    /**
     * Unsets the "imovel" element
     */
    public void unsetImovel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IMOVEL$16, 0);
        }
    }
    
    /**
     * Gets the "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS getValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS)get_store().find_element_user(VALORES$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "valores" element
     */
    public void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS valores)
    {
        generatedSetterHelperImpl(valores, VALORES$18, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS addNewValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoValoresIBSCBS)get_store().add_element_user(VALORES$18);
            return target;
        }
    }
}
