/*
 * XML Type:  TCTribTotalMonet
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribTotalMonet(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribTotalMonetImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet
{
    private static final long serialVersionUID = 1L;
    
    public TCTribTotalMonetImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VTOTTRIBFED$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotTribFed");
    private static final javax.xml.namespace.QName VTOTTRIBEST$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotTribEst");
    private static final javax.xml.namespace.QName VTOTTRIBMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotTribMun");
    
    
    /**
     * Gets the "vTotTribFed" element
     */
    public java.lang.String getVTotTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBFED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTotTribFed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBFED$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTotTribFed" element
     */
    public void setVTotTribFed(java.lang.String vTotTribFed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBFED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTOTTRIBFED$0);
            }
            target.setStringValue(vTotTribFed);
        }
    }
    
    /**
     * Sets (as xml) the "vTotTribFed" element
     */
    public void xsetVTotTribFed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotTribFed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBFED$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTOTTRIBFED$0);
            }
            target.set(vTotTribFed);
        }
    }
    
    /**
     * Gets the "vTotTribEst" element
     */
    public java.lang.String getVTotTribEst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBEST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTotTribEst" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotTribEst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBEST$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTotTribEst" element
     */
    public void setVTotTribEst(java.lang.String vTotTribEst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBEST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTOTTRIBEST$2);
            }
            target.setStringValue(vTotTribEst);
        }
    }
    
    /**
     * Sets (as xml) the "vTotTribEst" element
     */
    public void xsetVTotTribEst(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotTribEst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBEST$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTOTTRIBEST$2);
            }
            target.set(vTotTribEst);
        }
    }
    
    /**
     * Gets the "vTotTribMun" element
     */
    public java.lang.String getVTotTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTotTribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTotTribMun" element
     */
    public void setVTotTribMun(java.lang.String vTotTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTTRIBMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTOTTRIBMUN$4);
            }
            target.setStringValue(vTotTribMun);
        }
    }
    
    /**
     * Sets (as xml) the "vTotTribMun" element
     */
    public void xsetVTotTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTTRIBMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTOTTRIBMUN$4);
            }
            target.set(vTotTribMun);
        }
    }
}
