/*
 * XML Type:  TCListaEventos
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaEventos
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCListaEventos(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCListaEventosImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCListaEventos
{
    private static final long serialVersionUID = 1L;
    
    public TCListaEventosImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODEVENTO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "codEvento");
    
    
    /**
     * Gets array of all "codEvento" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum[] getCodEventoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CODEVENTO$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "codEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum getCodEventoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEVENTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) array of all "codEvento" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe[] xgetCodEventoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CODEVENTO$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "codEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe xgetCodEventoArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe)get_store().find_element_user(CODEVENTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "codEvento" element
     */
    public int sizeOfCodEventoArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODEVENTO$0);
        }
    }
    
    /**
     * Sets array of all "codEvento" element
     */
    public void setCodEventoArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum[] codEventoArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(codEventoArray, CODEVENTO$0);
        }
    }
    
    /**
     * Sets ith "codEvento" element
     */
    public void setCodEventoArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum codEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODEVENTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(codEvento);
        }
    }
    
    /**
     * Sets (as xml) array of all "codEvento" element
     */
    public void xsetCodEventoArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe[]codEventoArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(codEventoArray, CODEVENTO$0);
        }
    }
    
    /**
     * Sets (as xml) ith "codEvento" element
     */
    public void xsetCodEventoArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe codEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe)get_store().find_element_user(CODEVENTO$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(codEvento);
        }
    }
    
    /**
     * Inserts the value as the ith "codEvento" element
     */
    public void insertCodEvento(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum codEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(CODEVENTO$0, i);
            target.setEnumValue(codEvento);
        }
    }
    
    /**
     * Appends the value as the last "codEvento" element
     */
    public void addCodEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe.Enum codEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODEVENTO$0);
            target.setEnumValue(codEvento);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "codEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe insertNewCodEvento(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe)get_store().insert_element_user(CODEVENTO$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "codEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe addNewCodEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEventoNFSe)get_store().add_element_user(CODEVENTO$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "codEvento" element
     */
    public void removeCodEvento(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODEVENTO$0, i);
        }
    }
}
