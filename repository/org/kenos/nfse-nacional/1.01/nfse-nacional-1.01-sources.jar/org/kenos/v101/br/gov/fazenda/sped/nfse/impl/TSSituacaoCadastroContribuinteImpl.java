/*
 * XML Type:  TSSituacaoCadastroContribuinte
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSSituacaoCadastroContribuinte(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte.
 */
public class TSSituacaoCadastroContribuinteImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte
{
    private static final long serialVersionUID = 1L;
    
    public TSSituacaoCadastroContribuinteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSSituacaoCadastroContribuinteImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
