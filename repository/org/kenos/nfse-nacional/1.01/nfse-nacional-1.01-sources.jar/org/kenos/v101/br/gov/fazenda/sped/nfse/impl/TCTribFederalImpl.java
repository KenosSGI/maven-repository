/*
 * XML Type:  TCTribFederal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribFederal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribFederalImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal
{
    private static final long serialVersionUID = 1L;
    
    public TCTribFederalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PISCOFINS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "piscofins");
    private static final javax.xml.namespace.QName VRETCP$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vRetCP");
    private static final javax.xml.namespace.QName VRETIRRF$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vRetIRRF");
    private static final javax.xml.namespace.QName VRETCSLL$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vRetCSLL");
    
    
    /**
     * Gets the "piscofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins getPiscofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins)get_store().find_element_user(PISCOFINS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "piscofins" element
     */
    public boolean isSetPiscofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PISCOFINS$0) != 0;
        }
    }
    
    /**
     * Sets the "piscofins" element
     */
    public void setPiscofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins piscofins)
    {
        generatedSetterHelperImpl(piscofins, PISCOFINS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "piscofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins addNewPiscofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins)get_store().add_element_user(PISCOFINS$0);
            return target;
        }
    }
    
    /**
     * Unsets the "piscofins" element
     */
    public void unsetPiscofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PISCOFINS$0, 0);
        }
    }
    
    /**
     * Gets the "vRetCP" element
     */
    public java.lang.String getVRetCP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETCP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vRetCP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVRetCP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETCP$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vRetCP" element
     */
    public boolean isSetVRetCP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VRETCP$2) != 0;
        }
    }
    
    /**
     * Sets the "vRetCP" element
     */
    public void setVRetCP(java.lang.String vRetCP)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETCP$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VRETCP$2);
            }
            target.setStringValue(vRetCP);
        }
    }
    
    /**
     * Sets (as xml) the "vRetCP" element
     */
    public void xsetVRetCP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vRetCP)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETCP$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VRETCP$2);
            }
            target.set(vRetCP);
        }
    }
    
    /**
     * Unsets the "vRetCP" element
     */
    public void unsetVRetCP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VRETCP$2, 0);
        }
    }
    
    /**
     * Gets the "vRetIRRF" element
     */
    public java.lang.String getVRetIRRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETIRRF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vRetIRRF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVRetIRRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETIRRF$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "vRetIRRF" element
     */
    public boolean isSetVRetIRRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VRETIRRF$4) != 0;
        }
    }
    
    /**
     * Sets the "vRetIRRF" element
     */
    public void setVRetIRRF(java.lang.String vRetIRRF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETIRRF$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VRETIRRF$4);
            }
            target.setStringValue(vRetIRRF);
        }
    }
    
    /**
     * Sets (as xml) the "vRetIRRF" element
     */
    public void xsetVRetIRRF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vRetIRRF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETIRRF$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VRETIRRF$4);
            }
            target.set(vRetIRRF);
        }
    }
    
    /**
     * Unsets the "vRetIRRF" element
     */
    public void unsetVRetIRRF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VRETIRRF$4, 0);
        }
    }
    
    /**
     * Gets the "vRetCSLL" element
     */
    public java.lang.String getVRetCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETCSLL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vRetCSLL" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVRetCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETCSLL$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "vRetCSLL" element
     */
    public boolean isSetVRetCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VRETCSLL$6) != 0;
        }
    }
    
    /**
     * Sets the "vRetCSLL" element
     */
    public void setVRetCSLL(java.lang.String vRetCSLL)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VRETCSLL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VRETCSLL$6);
            }
            target.setStringValue(vRetCSLL);
        }
    }
    
    /**
     * Sets (as xml) the "vRetCSLL" element
     */
    public void xsetVRetCSLL(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vRetCSLL)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VRETCSLL$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VRETCSLL$6);
            }
            target.set(vRetCSLL);
        }
    }
    
    /**
     * Unsets the "vRetCSLL" element
     */
    public void unsetVRetCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VRETCSLL$6, 0);
        }
    }
}
