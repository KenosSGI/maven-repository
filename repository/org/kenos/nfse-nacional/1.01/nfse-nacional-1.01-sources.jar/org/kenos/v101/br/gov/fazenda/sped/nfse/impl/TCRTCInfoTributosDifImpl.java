/*
 * XML Type:  TCRTCInfoTributosDif
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoTributosDif(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoTributosDifImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosDif
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoTributosDifImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PDIFUF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pDifUF");
    private static final javax.xml.namespace.QName PDIFMUN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pDifMun");
    private static final javax.xml.namespace.QName PDIFCBS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pDifCBS");
    
    
    /**
     * Gets the "pDifUF" element
     */
    public java.lang.String getPDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFUF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pDifUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFUF$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pDifUF" element
     */
    public void setPDifUF(java.lang.String pDifUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFUF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PDIFUF$0);
            }
            target.setStringValue(pDifUF);
        }
    }
    
    /**
     * Sets (as xml) the "pDifUF" element
     */
    public void xsetPDifUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pDifUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFUF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PDIFUF$0);
            }
            target.set(pDifUF);
        }
    }
    
    /**
     * Gets the "pDifMun" element
     */
    public java.lang.String getPDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFMUN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pDifMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFMUN$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pDifMun" element
     */
    public void setPDifMun(java.lang.String pDifMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFMUN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PDIFMUN$2);
            }
            target.setStringValue(pDifMun);
        }
    }
    
    /**
     * Sets (as xml) the "pDifMun" element
     */
    public void xsetPDifMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pDifMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFMUN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PDIFMUN$2);
            }
            target.set(pDifMun);
        }
    }
    
    /**
     * Gets the "pDifCBS" element
     */
    public java.lang.String getPDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFCBS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pDifCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFCBS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pDifCBS" element
     */
    public void setPDifCBS(java.lang.String pDifCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PDIFCBS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PDIFCBS$4);
            }
            target.setStringValue(pDifCBS);
        }
    }
    
    /**
     * Sets (as xml) the "pDifCBS" element
     */
    public void xsetPDifCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pDifCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PDIFCBS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PDIFCBS$4);
            }
            target.set(pDifCBS);
        }
    }
}
