/*
 * XML Type:  TCExploracaoRodoviaria
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCExploracaoRodoviaria(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCExploracaoRodoviariaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria
{
    private static final long serialVersionUID = 1L;
    
    public TCExploracaoRodoviariaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CATEGVEIC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "categVeic");
    private static final javax.xml.namespace.QName NEIXOS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nEixos");
    private static final javax.xml.namespace.QName RODAGEM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "rodagem");
    private static final javax.xml.namespace.QName SENTIDO$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "sentido");
    private static final javax.xml.namespace.QName PLACA$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "placa");
    private static final javax.xml.namespace.QName CODACESSOPED$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "codAcessoPed");
    private static final javax.xml.namespace.QName CODCONTRATO$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "codContrato");
    
    
    /**
     * Gets the "categVeic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic.Enum getCategVeic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CATEGVEIC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "categVeic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic xgetCategVeic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic)get_store().find_element_user(CATEGVEIC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "categVeic" element
     */
    public void setCategVeic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic.Enum categVeic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CATEGVEIC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CATEGVEIC$0);
            }
            target.setEnumValue(categVeic);
        }
    }
    
    /**
     * Sets (as xml) the "categVeic" element
     */
    public void xsetCategVeic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic categVeic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic)get_store().find_element_user(CATEGVEIC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic)get_store().add_element_user(CATEGVEIC$0);
            }
            target.set(categVeic);
        }
    }
    
    /**
     * Gets the "nEixos" element
     */
    public java.lang.String getNEixos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NEIXOS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nEixos" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos xgetNEixos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos)get_store().find_element_user(NEIXOS$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nEixos" element
     */
    public void setNEixos(java.lang.String nEixos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NEIXOS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NEIXOS$2);
            }
            target.setStringValue(nEixos);
        }
    }
    
    /**
     * Sets (as xml) the "nEixos" element
     */
    public void xsetNEixos(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos nEixos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos)get_store().find_element_user(NEIXOS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos)get_store().add_element_user(NEIXOS$2);
            }
            target.set(nEixos);
        }
    }
    
    /**
     * Gets the "rodagem" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem.Enum getRodagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RODAGEM$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "rodagem" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem xgetRodagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem)get_store().find_element_user(RODAGEM$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "rodagem" element
     */
    public void setRodagem(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem.Enum rodagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RODAGEM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RODAGEM$4);
            }
            target.setEnumValue(rodagem);
        }
    }
    
    /**
     * Sets (as xml) the "rodagem" element
     */
    public void xsetRodagem(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem rodagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem)get_store().find_element_user(RODAGEM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem)get_store().add_element_user(RODAGEM$4);
            }
            target.set(rodagem);
        }
    }
    
    /**
     * Gets the "sentido" element
     */
    public java.lang.String getSentido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SENTIDO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "sentido" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido xgetSentido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido)get_store().find_element_user(SENTIDO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "sentido" element
     */
    public void setSentido(java.lang.String sentido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SENTIDO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SENTIDO$6);
            }
            target.setStringValue(sentido);
        }
    }
    
    /**
     * Sets (as xml) the "sentido" element
     */
    public void xsetSentido(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido sentido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido)get_store().find_element_user(SENTIDO$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido)get_store().add_element_user(SENTIDO$6);
            }
            target.set(sentido);
        }
    }
    
    /**
     * Gets the "placa" element
     */
    public java.lang.String getPlaca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PLACA$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "placa" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca xgetPlaca()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca)get_store().find_element_user(PLACA$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "placa" element
     */
    public void setPlaca(java.lang.String placa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PLACA$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PLACA$8);
            }
            target.setStringValue(placa);
        }
    }
    
    /**
     * Sets (as xml) the "placa" element
     */
    public void xsetPlaca(org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca placa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca)get_store().find_element_user(PLACA$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca)get_store().add_element_user(PLACA$8);
            }
            target.set(placa);
        }
    }
    
    /**
     * Gets the "codAcessoPed" element
     */
    public java.lang.String getCodAcessoPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODACESSOPED$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "codAcessoPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed xgetCodAcessoPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed)get_store().find_element_user(CODACESSOPED$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "codAcessoPed" element
     */
    public void setCodAcessoPed(java.lang.String codAcessoPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODACESSOPED$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODACESSOPED$10);
            }
            target.setStringValue(codAcessoPed);
        }
    }
    
    /**
     * Sets (as xml) the "codAcessoPed" element
     */
    public void xsetCodAcessoPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed codAcessoPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed)get_store().find_element_user(CODACESSOPED$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed)get_store().add_element_user(CODACESSOPED$10);
            }
            target.set(codAcessoPed);
        }
    }
    
    /**
     * Gets the "codContrato" element
     */
    public java.lang.String getCodContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODCONTRATO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "codContrato" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato xgetCodContrato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato)get_store().find_element_user(CODCONTRATO$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "codContrato" element
     */
    public void setCodContrato(java.lang.String codContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODCONTRATO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODCONTRATO$12);
            }
            target.setStringValue(codContrato);
        }
    }
    
    /**
     * Sets (as xml) the "codContrato" element
     */
    public void xsetCodContrato(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato codContrato)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato)get_store().find_element_user(CODCONTRATO$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato)get_store().add_element_user(CODCONTRATO$12);
            }
            target.set(codContrato);
        }
    }
}
