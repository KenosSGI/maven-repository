/*
 * XML Type:  TSNDFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSNDFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe.
 */
public class TSNDFSeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe
{
    private static final long serialVersionUID = 1L;
    
    public TSNDFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSNDFSeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
