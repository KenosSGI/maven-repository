/*
 * XML Type:  TCInfoObra
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoObra(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoObraImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoObra
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoObraImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INSCIMOBFISC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "inscImobFisc");
    private static final javax.xml.namespace.QName COBRA$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cObra");
    private static final javax.xml.namespace.QName CCIB$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cCIB");
    private static final javax.xml.namespace.QName END$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "end");
    
    
    /**
     * Gets the "inscImobFisc" element
     */
    public java.lang.String getInscImobFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCIMOBFISC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "inscImobFisc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc xgetInscImobFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc)get_store().find_element_user(INSCIMOBFISC$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "inscImobFisc" element
     */
    public boolean isSetInscImobFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCIMOBFISC$0) != 0;
        }
    }
    
    /**
     * Sets the "inscImobFisc" element
     */
    public void setInscImobFisc(java.lang.String inscImobFisc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCIMOBFISC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCIMOBFISC$0);
            }
            target.setStringValue(inscImobFisc);
        }
    }
    
    /**
     * Sets (as xml) the "inscImobFisc" element
     */
    public void xsetInscImobFisc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc inscImobFisc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc)get_store().find_element_user(INSCIMOBFISC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscImobFisc)get_store().add_element_user(INSCIMOBFISC$0);
            }
            target.set(inscImobFisc);
        }
    }
    
    /**
     * Unsets the "inscImobFisc" element
     */
    public void unsetInscImobFisc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCIMOBFISC$0, 0);
        }
    }
    
    /**
     * Gets the "cObra" element
     */
    public java.lang.String getCObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COBRA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cObra" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra xgetCObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra)get_store().find_element_user(COBRA$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "cObra" element
     */
    public boolean isSetCObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COBRA$2) != 0;
        }
    }
    
    /**
     * Sets the "cObra" element
     */
    public void setCObra(java.lang.String cObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COBRA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COBRA$2);
            }
            target.setStringValue(cObra);
        }
    }
    
    /**
     * Sets (as xml) the "cObra" element
     */
    public void xsetCObra(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra cObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra)get_store().find_element_user(COBRA$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodObra)get_store().add_element_user(COBRA$2);
            }
            target.set(cObra);
        }
    }
    
    /**
     * Unsets the "cObra" element
     */
    public void unsetCObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COBRA$2, 0);
        }
    }
    
    /**
     * Gets the "cCIB" element
     */
    public java.lang.String getCCIB()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCIB$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cCIB" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB xgetCCIB()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB)get_store().find_element_user(CCIB$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "cCIB" element
     */
    public boolean isSetCCIB()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCIB$4) != 0;
        }
    }
    
    /**
     * Sets the "cCIB" element
     */
    public void setCCIB(java.lang.String ccib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCIB$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CCIB$4);
            }
            target.setStringValue(ccib);
        }
    }
    
    /**
     * Sets (as xml) the "cCIB" element
     */
    public void xsetCCIB(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB ccib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB)get_store().find_element_user(CCIB$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodCIB)get_store().add_element_user(CCIB$4);
            }
            target.set(ccib);
        }
    }
    
    /**
     * Unsets the "cCIB" element
     */
    public void unsetCCIB()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCIB$4, 0);
        }
    }
    
    /**
     * Gets the "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento getEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento)get_store().find_element_user(END$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "end" element
     */
    public boolean isSetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(END$6) != 0;
        }
    }
    
    /**
     * Sets the "end" element
     */
    public void setEnd(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento end)
    {
        generatedSetterHelperImpl(end, END$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento addNewEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento)get_store().add_element_user(END$6);
            return target;
        }
    }
    
    /**
     * Unsets the "end" element
     */
    public void unsetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(END$6, 0);
        }
    }
}
