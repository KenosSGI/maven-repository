/*
 * XML Type:  TSNum7Dig
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSNum7Dig(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig.
 */
public class TSNum7DigImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig
{
    private static final long serialVersionUID = 1L;
    
    public TSNum7DigImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSNum7DigImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
