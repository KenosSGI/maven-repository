/*
 * XML Type:  TCTribOutrosPisCofins
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribOutrosPisCofins(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribOutrosPisCofinsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribOutrosPisCofins
{
    private static final long serialVersionUID = 1L;
    
    public TCTribOutrosPisCofinsImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CST$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CST");
    private static final javax.xml.namespace.QName VBCPISCOFINS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vBCPisCofins");
    private static final javax.xml.namespace.QName PALIQPIS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqPis");
    private static final javax.xml.namespace.QName PALIQCOFINS$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqCofins");
    private static final javax.xml.namespace.QName VPIS$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vPis");
    private static final javax.xml.namespace.QName VCOFINS$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCofins");
    private static final javax.xml.namespace.QName TPRETPISCOFINS$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpRetPisCofins");
    
    
    /**
     * Gets the "CST" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST.Enum getCST()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "CST" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST xgetCST()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST)get_store().find_element_user(CST$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CST" element
     */
    public void setCST(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST.Enum cst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CST$0);
            }
            target.setEnumValue(cst);
        }
    }
    
    /**
     * Sets (as xml) the "CST" element
     */
    public void xsetCST(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST cst)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST)get_store().find_element_user(CST$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST)get_store().add_element_user(CST$0);
            }
            target.set(cst);
        }
    }
    
    /**
     * Gets the "vBCPisCofins" element
     */
    public java.lang.String getVBCPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBCPISCOFINS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vBCPisCofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVBCPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBCPISCOFINS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vBCPisCofins" element
     */
    public boolean isSetVBCPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VBCPISCOFINS$2) != 0;
        }
    }
    
    /**
     * Sets the "vBCPisCofins" element
     */
    public void setVBCPisCofins(java.lang.String vbcPisCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBCPISCOFINS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VBCPISCOFINS$2);
            }
            target.setStringValue(vbcPisCofins);
        }
    }
    
    /**
     * Sets (as xml) the "vBCPisCofins" element
     */
    public void xsetVBCPisCofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vbcPisCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBCPISCOFINS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VBCPISCOFINS$2);
            }
            target.set(vbcPisCofins);
        }
    }
    
    /**
     * Unsets the "vBCPisCofins" element
     */
    public void unsetVBCPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VBCPISCOFINS$2, 0);
        }
    }
    
    /**
     * Gets the "pAliqPis" element
     */
    public java.lang.String getPAliqPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQPIS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqPis" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQPIS$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "pAliqPis" element
     */
    public boolean isSetPAliqPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PALIQPIS$4) != 0;
        }
    }
    
    /**
     * Sets the "pAliqPis" element
     */
    public void setPAliqPis(java.lang.String pAliqPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQPIS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQPIS$4);
            }
            target.setStringValue(pAliqPis);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqPis" element
     */
    public void xsetPAliqPis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQPIS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQPIS$4);
            }
            target.set(pAliqPis);
        }
    }
    
    /**
     * Unsets the "pAliqPis" element
     */
    public void unsetPAliqPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PALIQPIS$4, 0);
        }
    }
    
    /**
     * Gets the "pAliqCofins" element
     */
    public java.lang.String getPAliqCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQCOFINS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqCofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQCOFINS$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "pAliqCofins" element
     */
    public boolean isSetPAliqCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PALIQCOFINS$6) != 0;
        }
    }
    
    /**
     * Sets the "pAliqCofins" element
     */
    public void setPAliqCofins(java.lang.String pAliqCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQCOFINS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQCOFINS$6);
            }
            target.setStringValue(pAliqCofins);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqCofins" element
     */
    public void xsetPAliqCofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQCOFINS$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQCOFINS$6);
            }
            target.set(pAliqCofins);
        }
    }
    
    /**
     * Unsets the "pAliqCofins" element
     */
    public void unsetPAliqCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PALIQCOFINS$6, 0);
        }
    }
    
    /**
     * Gets the "vPis" element
     */
    public java.lang.String getVPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VPIS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vPis" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VPIS$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "vPis" element
     */
    public boolean isSetVPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VPIS$8) != 0;
        }
    }
    
    /**
     * Sets the "vPis" element
     */
    public void setVPis(java.lang.String vPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VPIS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VPIS$8);
            }
            target.setStringValue(vPis);
        }
    }
    
    /**
     * Sets (as xml) the "vPis" element
     */
    public void xsetVPis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VPIS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VPIS$8);
            }
            target.set(vPis);
        }
    }
    
    /**
     * Unsets the "vPis" element
     */
    public void unsetVPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VPIS$8, 0);
        }
    }
    
    /**
     * Gets the "vCofins" element
     */
    public java.lang.String getVCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCOFINS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCOFINS$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "vCofins" element
     */
    public boolean isSetVCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VCOFINS$10) != 0;
        }
    }
    
    /**
     * Sets the "vCofins" element
     */
    public void setVCofins(java.lang.String vCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCOFINS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCOFINS$10);
            }
            target.setStringValue(vCofins);
        }
    }
    
    /**
     * Sets (as xml) the "vCofins" element
     */
    public void xsetVCofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCOFINS$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCOFINS$10);
            }
            target.set(vCofins);
        }
    }
    
    /**
     * Unsets the "vCofins" element
     */
    public void unsetVCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VCOFINS$10, 0);
        }
    }
    
    /**
     * Gets the "tpRetPisCofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins.Enum getTpRetPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPRETPISCOFINS$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpRetPisCofins" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins xgetTpRetPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins)get_store().find_element_user(TPRETPISCOFINS$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "tpRetPisCofins" element
     */
    public boolean isSetTpRetPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPRETPISCOFINS$12) != 0;
        }
    }
    
    /**
     * Sets the "tpRetPisCofins" element
     */
    public void setTpRetPisCofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins.Enum tpRetPisCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPRETPISCOFINS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPRETPISCOFINS$12);
            }
            target.setEnumValue(tpRetPisCofins);
        }
    }
    
    /**
     * Sets (as xml) the "tpRetPisCofins" element
     */
    public void xsetTpRetPisCofins(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins tpRetPisCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins)get_store().find_element_user(TPRETPISCOFINS$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoRetPISCofins)get_store().add_element_user(TPRETPISCOFINS$12);
            }
            target.set(tpRetPisCofins);
        }
    }
    
    /**
     * Unsets the "tpRetPisCofins" element
     */
    public void unsetTpRetPisCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPRETPISCOFINS$12, 0);
        }
    }
}
