/*
 * XML Type:  TCExploracaoRodoviaria
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCExploracaoRodoviaria(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCExploracaoRodoviaria extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCExploracaoRodoviaria.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcexploracaorodoviariaf735type");
    
    /**
     * Gets the "categVeic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic.Enum getCategVeic();
    
    /**
     * Gets (as xml) the "categVeic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic xgetCategVeic();
    
    /**
     * Sets the "categVeic" element
     */
    void setCategVeic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic.Enum categVeic);
    
    /**
     * Sets (as xml) the "categVeic" element
     */
    void xsetCategVeic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCategVeic categVeic);
    
    /**
     * Gets the "nEixos" element
     */
    java.lang.String getNEixos();
    
    /**
     * Gets (as xml) the "nEixos" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos xgetNEixos();
    
    /**
     * Sets the "nEixos" element
     */
    void setNEixos(java.lang.String nEixos);
    
    /**
     * Sets (as xml) the "nEixos" element
     */
    void xsetNEixos(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumEixos nEixos);
    
    /**
     * Gets the "rodagem" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem.Enum getRodagem();
    
    /**
     * Gets (as xml) the "rodagem" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem xgetRodagem();
    
    /**
     * Sets the "rodagem" element
     */
    void setRodagem(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem.Enum rodagem);
    
    /**
     * Sets (as xml) the "rodagem" element
     */
    void xsetRodagem(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRodagem rodagem);
    
    /**
     * Gets the "sentido" element
     */
    java.lang.String getSentido();
    
    /**
     * Gets (as xml) the "sentido" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido xgetSentido();
    
    /**
     * Sets the "sentido" element
     */
    void setSentido(java.lang.String sentido);
    
    /**
     * Sets (as xml) the "sentido" element
     */
    void xsetSentido(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSentido sentido);
    
    /**
     * Gets the "placa" element
     */
    java.lang.String getPlaca();
    
    /**
     * Gets (as xml) the "placa" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca xgetPlaca();
    
    /**
     * Sets the "placa" element
     */
    void setPlaca(java.lang.String placa);
    
    /**
     * Sets (as xml) the "placa" element
     */
    void xsetPlaca(org.kenos.v101.br.gov.fazenda.sped.nfse.TSPlaca placa);
    
    /**
     * Gets the "codAcessoPed" element
     */
    java.lang.String getCodAcessoPed();
    
    /**
     * Gets (as xml) the "codAcessoPed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed xgetCodAcessoPed();
    
    /**
     * Sets the "codAcessoPed" element
     */
    void setCodAcessoPed(java.lang.String codAcessoPed);
    
    /**
     * Sets (as xml) the "codAcessoPed" element
     */
    void xsetCodAcessoPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodAcessoPed codAcessoPed);
    
    /**
     * Gets the "codContrato" element
     */
    java.lang.String getCodContrato();
    
    /**
     * Gets (as xml) the "codContrato" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato xgetCodContrato();
    
    /**
     * Sets the "codContrato" element
     */
    void setCodContrato(java.lang.String codContrato);
    
    /**
     * Sets (as xml) the "codContrato" element
     */
    void xsetCodContrato(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodContrato codContrato);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCExploracaoRodoviaria) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
