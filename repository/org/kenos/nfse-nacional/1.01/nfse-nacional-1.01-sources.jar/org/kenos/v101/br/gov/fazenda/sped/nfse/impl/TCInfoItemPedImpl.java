/*
 * XML Type:  TCInfoItemPed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoItemPed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoItemPedImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoItemPedImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XITEMPED$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xItemPed");
    
    
    /**
     * Gets array of all "xItemPed" elements
     */
    public java.lang.String[] getXItemPedArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(XITEMPED$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "xItemPed" element
     */
    public java.lang.String getXItemPedArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XITEMPED$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) array of all "xItemPed" elements
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco[] xgetXItemPedArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(XITEMPED$0, targetList);
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco[] result = new org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "xItemPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetXItemPedArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(XITEMPED$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "xItemPed" element
     */
    public int sizeOfXItemPedArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XITEMPED$0);
        }
    }
    
    /**
     * Sets array of all "xItemPed" element
     */
    public void setXItemPedArray(java.lang.String[] xItemPedArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(xItemPedArray, XITEMPED$0);
        }
    }
    
    /**
     * Sets ith "xItemPed" element
     */
    public void setXItemPedArray(int i, java.lang.String xItemPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XITEMPED$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(xItemPed);
        }
    }
    
    /**
     * Sets (as xml) array of all "xItemPed" element
     */
    public void xsetXItemPedArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco[]xItemPedArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(xItemPedArray, XITEMPED$0);
        }
    }
    
    /**
     * Sets (as xml) ith "xItemPed" element
     */
    public void xsetXItemPedArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xItemPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(XITEMPED$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(xItemPed);
        }
    }
    
    /**
     * Inserts the value as the ith "xItemPed" element
     */
    public void insertXItemPed(int i, java.lang.String xItemPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(XITEMPED$0, i);
            target.setStringValue(xItemPed);
        }
    }
    
    /**
     * Appends the value as the last "xItemPed" element
     */
    public void addXItemPed(java.lang.String xItemPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XITEMPED$0);
            target.setStringValue(xItemPed);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "xItemPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco insertNewXItemPed(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().insert_element_user(XITEMPED$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "xItemPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco addNewXItemPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().add_element_user(XITEMPED$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "xItemPed" element
     */
    public void removeXItemPed(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XITEMPED$0, i);
        }
    }
}
