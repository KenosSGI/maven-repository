/*
 * XML Type:  TCDocNFNFS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCDocNFNFS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCDocNFNFSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocNFNFS
{
    private static final long serialVersionUID = 1L;
    
    public TCDocNFNFSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NNFS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nNFS");
    private static final javax.xml.namespace.QName MODNFS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "modNFS");
    private static final javax.xml.namespace.QName SERIENFS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "serieNFS");
    
    
    /**
     * Gets the "nNFS" element
     */
    public java.lang.String getNNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nNFS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig xgetNNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().find_element_user(NNFS$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nNFS" element
     */
    public void setNNFS(java.lang.String nnfs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NNFS$0);
            }
            target.setStringValue(nnfs);
        }
    }
    
    /**
     * Sets (as xml) the "nNFS" element
     */
    public void xsetNNFS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig nnfs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().find_element_user(NNFS$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().add_element_user(NNFS$0);
            }
            target.set(nnfs);
        }
    }
    
    /**
     * Gets the "modNFS" element
     */
    public java.lang.String getModNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODNFS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "modNFS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig xgetModNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().find_element_user(MODNFS$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "modNFS" element
     */
    public void setModNFS(java.lang.String modNFS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODNFS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MODNFS$2);
            }
            target.setStringValue(modNFS);
        }
    }
    
    /**
     * Sets (as xml) the "modNFS" element
     */
    public void xsetModNFS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig modNFS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().find_element_user(MODNFS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().add_element_user(MODNFS$2);
            }
            target.set(modNFS);
        }
    }
    
    /**
     * Gets the "serieNFS" element
     */
    public java.lang.String getSerieNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIENFS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serieNFS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS xgetSerieNFS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS)get_store().find_element_user(SERIENFS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serieNFS" element
     */
    public void setSerieNFS(java.lang.String serieNFS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIENFS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERIENFS$4);
            }
            target.setStringValue(serieNFS);
        }
    }
    
    /**
     * Sets (as xml) the "serieNFS" element
     */
    public void xsetSerieNFS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS serieNFS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS)get_store().find_element_user(SERIENFS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieNFNFS)get_store().add_element_user(SERIENFS$4);
            }
            target.set(serieNFS);
        }
    }
}
