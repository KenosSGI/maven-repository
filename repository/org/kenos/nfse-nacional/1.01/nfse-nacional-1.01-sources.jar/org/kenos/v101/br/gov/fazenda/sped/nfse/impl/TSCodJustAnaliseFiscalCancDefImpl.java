/*
 * XML Type:  TSCodJustAnaliseFiscalCancDef
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSCodJustAnaliseFiscalCancDef(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef.
 */
public class TSCodJustAnaliseFiscalCancDefImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef
{
    private static final long serialVersionUID = 1L;
    
    public TSCodJustAnaliseFiscalCancDefImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSCodJustAnaliseFiscalCancDefImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
