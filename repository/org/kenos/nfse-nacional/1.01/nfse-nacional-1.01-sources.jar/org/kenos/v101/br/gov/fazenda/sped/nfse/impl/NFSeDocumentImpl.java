/*
 * An XML document type.
 * Localname: NFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.NFSeDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * A document containing one NFSe(@http://www.sped.fazenda.gov.br/nfse) element.
 *
 * This is a complex type.
 */
public class NFSeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.NFSeDocument
{
    private static final long serialVersionUID = 1L;
    
    public NFSeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NFSE$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "NFSe");
    
    
    /**
     * Gets the "NFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe getNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe)get_store().find_element_user(NFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "NFSe" element
     */
    public void setNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe nfSe)
    {
        generatedSetterHelperImpl(nfSe, NFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe addNewNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCNFSe)get_store().add_element_user(NFSE$0);
            return target;
        }
    }
}
