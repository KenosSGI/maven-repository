/*
 * XML Type:  TCInfPedReg
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfPedReg(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfPedReg extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfPedReg.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcinfpedrege4c5type");
    
    /**
     * Gets the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb();
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb();
    
    /**
     * Sets the "tpAmb" element
     */
    void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb);
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb);
    
    /**
     * Gets the "verAplic" element
     */
    java.lang.String getVerAplic();
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic();
    
    /**
     * Sets the "verAplic" element
     */
    void setVerAplic(java.lang.String verAplic);
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic);
    
    /**
     * Gets the "dhEvento" element
     */
    java.lang.String getDhEvento();
    
    /**
     * Gets (as xml) the "dhEvento" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhEvento();
    
    /**
     * Sets the "dhEvento" element
     */
    void setDhEvento(java.lang.String dhEvento);
    
    /**
     * Sets (as xml) the "dhEvento" element
     */
    void xsetDhEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhEvento);
    
    /**
     * Gets the "CNPJAutor" element
     */
    java.lang.String getCNPJAutor();
    
    /**
     * Gets (as xml) the "CNPJAutor" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJAutor();
    
    /**
     * True if has "CNPJAutor" element
     */
    boolean isSetCNPJAutor();
    
    /**
     * Sets the "CNPJAutor" element
     */
    void setCNPJAutor(java.lang.String cnpjAutor);
    
    /**
     * Sets (as xml) the "CNPJAutor" element
     */
    void xsetCNPJAutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpjAutor);
    
    /**
     * Unsets the "CNPJAutor" element
     */
    void unsetCNPJAutor();
    
    /**
     * Gets the "CPFAutor" element
     */
    java.lang.String getCPFAutor();
    
    /**
     * Gets (as xml) the "CPFAutor" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAutor();
    
    /**
     * True if has "CPFAutor" element
     */
    boolean isSetCPFAutor();
    
    /**
     * Sets the "CPFAutor" element
     */
    void setCPFAutor(java.lang.String cpfAutor);
    
    /**
     * Sets (as xml) the "CPFAutor" element
     */
    void xsetCPFAutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAutor);
    
    /**
     * Unsets the "CPFAutor" element
     */
    void unsetCPFAutor();
    
    /**
     * Gets the "chNFSe" element
     */
    java.lang.String getChNFSe();
    
    /**
     * Gets (as xml) the "chNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSe();
    
    /**
     * Sets the "chNFSe" element
     */
    void setChNFSe(java.lang.String chNFSe);
    
    /**
     * Sets (as xml) the "chNFSe" element
     */
    void xsetChNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSe);
    
    /**
     * Gets the "nPedRegEvento" element
     */
    java.lang.String getNPedRegEvento();
    
    /**
     * Gets (as xml) the "nPedRegEvento" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig xgetNPedRegEvento();
    
    /**
     * Sets the "nPedRegEvento" element
     */
    void setNPedRegEvento(java.lang.String nPedRegEvento);
    
    /**
     * Sets (as xml) the "nPedRegEvento" element
     */
    void xsetNPedRegEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig nPedRegEvento);
    
    /**
     * Gets the "e101101" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 getE101101();
    
    /**
     * True if has "e101101" element
     */
    boolean isSetE101101();
    
    /**
     * Sets the "e101101" element
     */
    void setE101101(org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 e101101);
    
    /**
     * Appends and returns a new empty "e101101" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 addNewE101101();
    
    /**
     * Unsets the "e101101" element
     */
    void unsetE101101();
    
    /**
     * Gets the "e105102" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 getE105102();
    
    /**
     * True if has "e105102" element
     */
    boolean isSetE105102();
    
    /**
     * Sets the "e105102" element
     */
    void setE105102(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 e105102);
    
    /**
     * Appends and returns a new empty "e105102" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 addNewE105102();
    
    /**
     * Unsets the "e105102" element
     */
    void unsetE105102();
    
    /**
     * Gets the "e101103" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 getE101103();
    
    /**
     * True if has "e101103" element
     */
    boolean isSetE101103();
    
    /**
     * Sets the "e101103" element
     */
    void setE101103(org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 e101103);
    
    /**
     * Appends and returns a new empty "e101103" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 addNewE101103();
    
    /**
     * Unsets the "e101103" element
     */
    void unsetE101103();
    
    /**
     * Gets the "e105104" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 getE105104();
    
    /**
     * True if has "e105104" element
     */
    boolean isSetE105104();
    
    /**
     * Sets the "e105104" element
     */
    void setE105104(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 e105104);
    
    /**
     * Appends and returns a new empty "e105104" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 addNewE105104();
    
    /**
     * Unsets the "e105104" element
     */
    void unsetE105104();
    
    /**
     * Gets the "e105105" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 getE105105();
    
    /**
     * True if has "e105105" element
     */
    boolean isSetE105105();
    
    /**
     * Sets the "e105105" element
     */
    void setE105105(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 e105105);
    
    /**
     * Appends and returns a new empty "e105105" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 addNewE105105();
    
    /**
     * Unsets the "e105105" element
     */
    void unsetE105105();
    
    /**
     * Gets the "e202201" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 getE202201();
    
    /**
     * True if has "e202201" element
     */
    boolean isSetE202201();
    
    /**
     * Sets the "e202201" element
     */
    void setE202201(org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 e202201);
    
    /**
     * Appends and returns a new empty "e202201" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 addNewE202201();
    
    /**
     * Unsets the "e202201" element
     */
    void unsetE202201();
    
    /**
     * Gets the "e203202" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 getE203202();
    
    /**
     * True if has "e203202" element
     */
    boolean isSetE203202();
    
    /**
     * Sets the "e203202" element
     */
    void setE203202(org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 e203202);
    
    /**
     * Appends and returns a new empty "e203202" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 addNewE203202();
    
    /**
     * Unsets the "e203202" element
     */
    void unsetE203202();
    
    /**
     * Gets the "e204203" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 getE204203();
    
    /**
     * True if has "e204203" element
     */
    boolean isSetE204203();
    
    /**
     * Sets the "e204203" element
     */
    void setE204203(org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 e204203);
    
    /**
     * Appends and returns a new empty "e204203" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 addNewE204203();
    
    /**
     * Unsets the "e204203" element
     */
    void unsetE204203();
    
    /**
     * Gets the "e205204" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 getE205204();
    
    /**
     * True if has "e205204" element
     */
    boolean isSetE205204();
    
    /**
     * Sets the "e205204" element
     */
    void setE205204(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 e205204);
    
    /**
     * Appends and returns a new empty "e205204" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 addNewE205204();
    
    /**
     * Unsets the "e205204" element
     */
    void unsetE205204();
    
    /**
     * Gets the "e202205" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 getE202205();
    
    /**
     * True if has "e202205" element
     */
    boolean isSetE202205();
    
    /**
     * Sets the "e202205" element
     */
    void setE202205(org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 e202205);
    
    /**
     * Appends and returns a new empty "e202205" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 addNewE202205();
    
    /**
     * Unsets the "e202205" element
     */
    void unsetE202205();
    
    /**
     * Gets the "e203206" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 getE203206();
    
    /**
     * True if has "e203206" element
     */
    boolean isSetE203206();
    
    /**
     * Sets the "e203206" element
     */
    void setE203206(org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 e203206);
    
    /**
     * Appends and returns a new empty "e203206" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 addNewE203206();
    
    /**
     * Unsets the "e203206" element
     */
    void unsetE203206();
    
    /**
     * Gets the "e204207" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 getE204207();
    
    /**
     * True if has "e204207" element
     */
    boolean isSetE204207();
    
    /**
     * Sets the "e204207" element
     */
    void setE204207(org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 e204207);
    
    /**
     * Appends and returns a new empty "e204207" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 addNewE204207();
    
    /**
     * Unsets the "e204207" element
     */
    void unsetE204207();
    
    /**
     * Gets the "e205208" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 getE205208();
    
    /**
     * True if has "e205208" element
     */
    boolean isSetE205208();
    
    /**
     * Sets the "e205208" element
     */
    void setE205208(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 e205208);
    
    /**
     * Appends and returns a new empty "e205208" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 addNewE205208();
    
    /**
     * Unsets the "e205208" element
     */
    void unsetE205208();
    
    /**
     * Gets the "e305101" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 getE305101();
    
    /**
     * True if has "e305101" element
     */
    boolean isSetE305101();
    
    /**
     * Sets the "e305101" element
     */
    void setE305101(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 e305101);
    
    /**
     * Appends and returns a new empty "e305101" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 addNewE305101();
    
    /**
     * Unsets the "e305101" element
     */
    void unsetE305101();
    
    /**
     * Gets the "e305102" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 getE305102();
    
    /**
     * True if has "e305102" element
     */
    boolean isSetE305102();
    
    /**
     * Sets the "e305102" element
     */
    void setE305102(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 e305102);
    
    /**
     * Appends and returns a new empty "e305102" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 addNewE305102();
    
    /**
     * Unsets the "e305102" element
     */
    void unsetE305102();
    
    /**
     * Gets the "e305103" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 getE305103();
    
    /**
     * True if has "e305103" element
     */
    boolean isSetE305103();
    
    /**
     * Sets the "e305103" element
     */
    void setE305103(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 e305103);
    
    /**
     * Appends and returns a new empty "e305103" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 addNewE305103();
    
    /**
     * Unsets the "e305103" element
     */
    void unsetE305103();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt xgetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt id);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
