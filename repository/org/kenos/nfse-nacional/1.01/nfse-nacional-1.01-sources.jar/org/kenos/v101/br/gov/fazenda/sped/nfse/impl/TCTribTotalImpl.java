/*
 * XML Type:  TCTribTotal
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCTribTotal(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCTribTotalImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal
{
    private static final long serialVersionUID = 1L;
    
    public TCTribTotalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VTOTTRIB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotTrib");
    private static final javax.xml.namespace.QName PTOTTRIB$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pTotTrib");
    private static final javax.xml.namespace.QName INDTOTTRIB$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "indTotTrib");
    private static final javax.xml.namespace.QName PTOTTRIBSN$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pTotTribSN");
    
    
    /**
     * Gets the "vTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet getVTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet)get_store().find_element_user(VTOTTRIB$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vTotTrib" element
     */
    public boolean isSetVTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VTOTTRIB$0) != 0;
        }
    }
    
    /**
     * Sets the "vTotTrib" element
     */
    public void setVTotTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet vTotTrib)
    {
        generatedSetterHelperImpl(vTotTrib, VTOTTRIB$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "vTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet addNewVTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalMonet)get_store().add_element_user(VTOTTRIB$0);
            return target;
        }
    }
    
    /**
     * Unsets the "vTotTrib" element
     */
    public void unsetVTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VTOTTRIB$0, 0);
        }
    }
    
    /**
     * Gets the "pTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent getPTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent)get_store().find_element_user(PTOTTRIB$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "pTotTrib" element
     */
    public boolean isSetPTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTOTTRIB$2) != 0;
        }
    }
    
    /**
     * Sets the "pTotTrib" element
     */
    public void setPTotTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent pTotTrib)
    {
        generatedSetterHelperImpl(pTotTrib, PTOTTRIB$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "pTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent addNewPTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotalPercent)get_store().add_element_user(PTOTTRIB$2);
            return target;
        }
    }
    
    /**
     * Unsets the "pTotTrib" element
     */
    public void unsetPTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTOTTRIB$2, 0);
        }
    }
    
    /**
     * Gets the "indTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib.Enum getIndTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDTOTTRIB$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "indTotTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib xgetIndTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib)get_store().find_element_user(INDTOTTRIB$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "indTotTrib" element
     */
    public boolean isSetIndTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INDTOTTRIB$4) != 0;
        }
    }
    
    /**
     * Sets the "indTotTrib" element
     */
    public void setIndTotTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib.Enum indTotTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INDTOTTRIB$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INDTOTTRIB$4);
            }
            target.setEnumValue(indTotTrib);
        }
    }
    
    /**
     * Sets (as xml) the "indTotTrib" element
     */
    public void xsetIndTotTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib indTotTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib)get_store().find_element_user(INDTOTTRIB$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoIndTotTrib)get_store().add_element_user(INDTOTTRIB$4);
            }
            target.set(indTotTrib);
        }
    }
    
    /**
     * Unsets the "indTotTrib" element
     */
    public void unsetIndTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INDTOTTRIB$4, 0);
        }
    }
    
    /**
     * Gets the "pTotTribSN" element
     */
    public java.lang.String getPTotTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBSN$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pTotTribSN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPTotTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PTOTTRIBSN$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "pTotTribSN" element
     */
    public boolean isSetPTotTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTOTTRIBSN$6) != 0;
        }
    }
    
    /**
     * Sets the "pTotTribSN" element
     */
    public void setPTotTribSN(java.lang.String pTotTribSN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PTOTTRIBSN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PTOTTRIBSN$6);
            }
            target.setStringValue(pTotTribSN);
        }
    }
    
    /**
     * Sets (as xml) the "pTotTribSN" element
     */
    public void xsetPTotTribSN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pTotTribSN)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PTOTTRIBSN$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PTOTTRIBSN$6);
            }
            target.set(pTotTribSN);
        }
    }
    
    /**
     * Unsets the "pTotTribSN" element
     */
    public void unsetPTotTribSN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTOTTRIBSN$6, 0);
        }
    }
}
