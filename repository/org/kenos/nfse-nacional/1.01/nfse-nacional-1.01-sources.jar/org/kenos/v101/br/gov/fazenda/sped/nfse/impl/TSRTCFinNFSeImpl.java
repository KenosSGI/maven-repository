/*
 * XML Type:  TSRTCFinNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSRTCFinNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe.
 */
public class TSRTCFinNFSeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCFinNFSe
{
    private static final long serialVersionUID = 1L;
    
    public TSRTCFinNFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSRTCFinNFSeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
