/*
 * XML Type:  TCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCNCImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCNC
{
    private static final long serialVersionUID = 1L;
    
    public TCNCImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INFCNC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "infCNC");
    private static final javax.xml.namespace.QName VERSAO$2 = 
        new javax.xml.namespace.QName("", "versao");
    
    
    /**
     * Gets the "infCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC getInfCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC)get_store().find_element_user(INFCNC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "infCNC" element
     */
    public void setInfCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC infCNC)
    {
        generatedSetterHelperImpl(infCNC, INFCNC$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "infCNC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC addNewInfCNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC)get_store().add_element_user(INFCNC$0);
            return target;
        }
    }
    
    /**
     * Gets the "versao" attribute
     */
    public java.lang.String getVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC xgetVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC)get_store().find_attribute_user(VERSAO$2);
            return target;
        }
    }
    
    /**
     * Sets the "versao" attribute
     */
    public void setVersao(java.lang.String versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
            }
            target.setStringValue(versao);
        }
    }
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    public void xsetVersao(org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC)get_store().find_attribute_user(VERSAO$2);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TVerCNC)get_store().add_attribute_user(VERSAO$2);
            }
            target.set(versao);
        }
    }
}
