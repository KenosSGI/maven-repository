/*
 * XML Type:  TCRTCTotalCIBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalCIBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalCIBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalCIBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VTOTNF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotNF");
    private static final javax.xml.namespace.QName GIBS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gIBS");
    private static final javax.xml.namespace.QName GCBS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gCBS");
    private static final javax.xml.namespace.QName GTRIBREGULAR$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gTribRegular");
    private static final javax.xml.namespace.QName GTRIBCOMPRAGOV$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gTribCompraGov");
    
    
    /**
     * Gets the "vTotNF" element
     */
    public java.lang.String getVTotNF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTNF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTotNF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotNF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTNF$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vTotNF" element
     */
    public void setVTotNF(java.lang.String vTotNF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTNF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTOTNF$0);
            }
            target.setStringValue(vTotNF);
        }
    }
    
    /**
     * Sets (as xml) the "vTotNF" element
     */
    public void xsetVTotNF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotNF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTNF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTOTNF$0);
            }
            target.set(vTotNF);
        }
    }
    
    /**
     * Gets the "gIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS getGIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS)get_store().find_element_user(GIBS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gIBS" element
     */
    public void setGIBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS gibs)
    {
        generatedSetterHelperImpl(gibs, GIBS$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gIBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS addNewGIBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS)get_store().add_element_user(GIBS$2);
            return target;
        }
    }
    
    /**
     * Gets the "gCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS getGCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS)get_store().find_element_user(GCBS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gCBS" element
     */
    public void setGCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS gcbs)
    {
        generatedSetterHelperImpl(gcbs, GCBS$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS addNewGCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS)get_store().add_element_user(GCBS$4);
            return target;
        }
    }
    
    /**
     * Gets the "gTribRegular" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular getGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular)get_store().find_element_user(GTRIBREGULAR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gTribRegular" element
     */
    public boolean isSetGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTRIBREGULAR$6) != 0;
        }
    }
    
    /**
     * Sets the "gTribRegular" element
     */
    public void setGTribRegular(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular gTribRegular)
    {
        generatedSetterHelperImpl(gTribRegular, GTRIBREGULAR$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gTribRegular" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular addNewGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular)get_store().add_element_user(GTRIBREGULAR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "gTribRegular" element
     */
    public void unsetGTribRegular()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTRIBREGULAR$6, 0);
        }
    }
    
    /**
     * Gets the "gTribCompraGov" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov getGTribCompraGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov)get_store().find_element_user(GTRIBCOMPRAGOV$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gTribCompraGov" element
     */
    public boolean isSetGTribCompraGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTRIBCOMPRAGOV$8) != 0;
        }
    }
    
    /**
     * Sets the "gTribCompraGov" element
     */
    public void setGTribCompraGov(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov gTribCompraGov)
    {
        generatedSetterHelperImpl(gTribCompraGov, GTRIBCOMPRAGOV$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gTribCompraGov" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov addNewGTribCompraGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov)get_store().add_element_user(GTRIBCOMPRAGOV$8);
            return target;
        }
    }
    
    /**
     * Unsets the "gTribCompraGov" element
     */
    public void unsetGTribCompraGov()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTRIBCOMPRAGOV$8, 0);
        }
    }
}
