/*
 * XML Type:  TCDocOutNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCDocOutNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCDocOutNFSeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCDocOutNFSe
{
    private static final long serialVersionUID = 1L;
    
    public TCDocOutNFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CMUNNFSEMUN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMunNFSeMun");
    private static final javax.xml.namespace.QName NNFSEMUN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nNFSeMun");
    private static final javax.xml.namespace.QName CVERIFNFSEMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cVerifNFSeMun");
    
    
    /**
     * Gets the "cMunNFSeMun" element
     */
    public java.lang.String getCMunNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUNNFSEMUN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMunNFSeMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCMunNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUNNFSEMUN$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMunNFSeMun" element
     */
    public void setCMunNFSeMun(java.lang.String cMunNFSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUNNFSEMUN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMUNNFSEMUN$0);
            }
            target.setStringValue(cMunNFSeMun);
        }
    }
    
    /**
     * Sets (as xml) the "cMunNFSeMun" element
     */
    public void xsetCMunNFSeMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cMunNFSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CMUNNFSEMUN$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CMUNNFSEMUN$0);
            }
            target.set(cMunNFSeMun);
        }
    }
    
    /**
     * Gets the "nNFSeMun" element
     */
    public java.lang.String getNNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFSEMUN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nNFSeMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig xgetNNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().find_element_user(NNFSEMUN$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nNFSeMun" element
     */
    public void setNNFSeMun(java.lang.String nnfSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFSEMUN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NNFSEMUN$2);
            }
            target.setStringValue(nnfSeMun);
        }
    }
    
    /**
     * Sets (as xml) the "nNFSeMun" element
     */
    public void xsetNNFSeMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig nnfSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().find_element_user(NNFSEMUN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum15Dig)get_store().add_element_user(NNFSEMUN$2);
            }
            target.set(nnfSeMun);
        }
    }
    
    /**
     * Gets the "cVerifNFSeMun" element
     */
    public java.lang.String getCVerifNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CVERIFNFSEMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cVerifNFSeMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao xgetCVerifNFSeMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao)get_store().find_element_user(CVERIFNFSEMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cVerifNFSeMun" element
     */
    public void setCVerifNFSeMun(java.lang.String cVerifNFSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CVERIFNFSEMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CVERIFNFSEMUN$4);
            }
            target.setStringValue(cVerifNFSeMun);
        }
    }
    
    /**
     * Sets (as xml) the "cVerifNFSeMun" element
     */
    public void xsetCVerifNFSeMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao cVerifNFSeMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao)get_store().find_element_user(CVERIFNFSEMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodVerificacao)get_store().add_element_user(CVERIFNFSEMUN$4);
            }
            target.set(cVerifNFSeMun);
        }
    }
}
