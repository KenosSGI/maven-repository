/*
 * XML Type:  TE105104
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TE105104(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TE105104 extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TE105104.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("te1051048e10type");
    
    /**
     * Gets the "xDesc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc.Enum getXDesc();
    
    /**
     * Gets (as xml) the "xDesc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc xgetXDesc();
    
    /**
     * Sets the "xDesc" element
     */
    void setXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc.Enum xDesc);
    
    /**
     * Sets (as xml) the "xDesc" element
     */
    void xsetXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc xDesc);
    
    /**
     * Gets the "CPFAgTrib" element
     */
    java.lang.String getCPFAgTrib();
    
    /**
     * Gets (as xml) the "CPFAgTrib" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAgTrib();
    
    /**
     * Sets the "CPFAgTrib" element
     */
    void setCPFAgTrib(java.lang.String cpfAgTrib);
    
    /**
     * Sets (as xml) the "CPFAgTrib" element
     */
    void xsetCPFAgTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAgTrib);
    
    /**
     * Gets the "nProcAdm" element
     */
    java.lang.String getNProcAdm();
    
    /**
     * Gets (as xml) the "nProcAdm" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc xgetNProcAdm();
    
    /**
     * True if has "nProcAdm" element
     */
    boolean isSetNProcAdm();
    
    /**
     * Sets the "nProcAdm" element
     */
    void setNProcAdm(java.lang.String nProcAdm);
    
    /**
     * Sets (as xml) the "nProcAdm" element
     */
    void xsetNProcAdm(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumProcAdmAnaliseFiscalCanc nProcAdm);
    
    /**
     * Unsets the "nProcAdm" element
     */
    void unsetNProcAdm();
    
    /**
     * Gets the "cMotivo" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef.Enum getCMotivo();
    
    /**
     * Gets (as xml) the "cMotivo" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef xgetCMotivo();
    
    /**
     * Sets the "cMotivo" element
     */
    void setCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef.Enum cMotivo);
    
    /**
     * Sets (as xml) the "cMotivo" element
     */
    void xsetCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustAnaliseFiscalCancDef cMotivo);
    
    /**
     * Gets the "xMotivo" element
     */
    java.lang.String getXMotivo();
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo();
    
    /**
     * Sets the "xMotivo" element
     */
    void setXMotivo(java.lang.String xMotivo);
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo);
    
    /**
     * An XML xDesc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104$XDesc.
     */
    public interface XDesc extends org.apache.xmlbeans.XmlString
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(XDesc.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("xdesc17dbelemtype");
        
        org.apache.xmlbeans.StringEnumAbstractBase enumValue();
        void set(org.apache.xmlbeans.StringEnumAbstractBase e);
        
        static final Enum CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL = Enum.forString("Cancelamento de NFS-e Deferido por Análise Fiscal");
        
        static final int INT_CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL = Enum.INT_CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL;
        
        /**
         * Enumeration value class for org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104$XDesc.
         * These enum values can be used as follows:
         * <pre>
         * enum.toString(); // returns the string value of the enum
         * enum.intValue(); // returns an int value, useful for switches
         * // e.g., case Enum.INT_CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL
         * Enum.forString(s); // returns the enum value for a string
         * Enum.forInt(i); // returns the enum value for an int
         * </pre>
         * Enumeration objects are immutable singleton objects that
         * can be compared using == object equality. They have no
         * public constructor. See the constants defined within this
         * class for all the valid values.
         */
        static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
        {
            /**
             * Returns the enum value for a string, or null if none.
             */
            public static Enum forString(java.lang.String s)
                { return (Enum)table.forString(s); }
            /**
             * Returns the enum value corresponding to an int, or null if none.
             */
            public static Enum forInt(int i)
                { return (Enum)table.forInt(i); }
            
            private Enum(java.lang.String s, int i)
                { super(s, i); }
            
            static final int INT_CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL = 1;
            
            public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
                new org.apache.xmlbeans.StringEnumAbstractBase.Table
            (
                new Enum[]
                {
                    new Enum("Cancelamento de NFS-e Deferido por Análise Fiscal", INT_CANCELAMENTO_DE_NFS_E_DEFERIDO_POR_ANÁLISE_FISCAL),
                }
            );
            private static final long serialVersionUID = 1L;
            private java.lang.Object readResolve() { return forInt(intValue()); } 
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc newValue(java.lang.Object obj) {
              return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc) type.newValue( obj ); }
            
            public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc newInstance() {
              return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104.XDesc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
