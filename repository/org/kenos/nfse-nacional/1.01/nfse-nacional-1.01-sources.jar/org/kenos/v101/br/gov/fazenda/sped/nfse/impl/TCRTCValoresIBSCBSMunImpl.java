/*
 * XML Type:  TCRTCValoresIBSCBSMun
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCValoresIBSCBSMun(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCValoresIBSCBSMunImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSMun
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCValoresIBSCBSMunImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PIBSMUN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pIBSMun");
    private static final javax.xml.namespace.QName PREDALIQMUN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pRedAliqMun");
    private static final javax.xml.namespace.QName PALIQEFETMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfetMun");
    
    
    /**
     * Gets the "pIBSMun" element
     */
    public java.lang.String getPIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSMUN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSMUN$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pIBSMun" element
     */
    public void setPIBSMun(java.lang.String pibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSMUN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PIBSMUN$0);
            }
            target.setStringValue(pibsMun);
        }
    }
    
    /**
     * Sets (as xml) the "pIBSMun" element
     */
    public void xsetPIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSMUN$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PIBSMUN$0);
            }
            target.set(pibsMun);
        }
    }
    
    /**
     * Gets the "pRedAliqMun" element
     */
    public java.lang.String getPRedAliqMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQMUN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pRedAliqMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedAliqMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQMUN$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "pRedAliqMun" element
     */
    public boolean isSetPRedAliqMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDALIQMUN$2) != 0;
        }
    }
    
    /**
     * Sets the "pRedAliqMun" element
     */
    public void setPRedAliqMun(java.lang.String pRedAliqMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQMUN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDALIQMUN$2);
            }
            target.setStringValue(pRedAliqMun);
        }
    }
    
    /**
     * Sets (as xml) the "pRedAliqMun" element
     */
    public void xsetPRedAliqMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedAliqMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQMUN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PREDALIQMUN$2);
            }
            target.set(pRedAliqMun);
        }
    }
    
    /**
     * Unsets the "pRedAliqMun" element
     */
    public void unsetPRedAliqMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDALIQMUN$2, 0);
        }
    }
    
    /**
     * Gets the "pAliqEfetMun" element
     */
    public java.lang.String getPAliqEfetMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfetMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfetMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfetMun" element
     */
    public void setPAliqEfetMun(java.lang.String pAliqEfetMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFETMUN$4);
            }
            target.setStringValue(pAliqEfetMun);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfetMun" element
     */
    public void xsetPAliqEfetMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfetMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFETMUN$4);
            }
            target.set(pAliqEfetMun);
        }
    }
}
