/*
 * XML Type:  TCRTCInfoTributosTribRegular
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCInfoTributosTribRegular(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCInfoTributosTribRegularImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCInfoTributosTribRegularImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CSTREG$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CSTReg");
    private static final javax.xml.namespace.QName CCLASSTRIBREG$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cClassTribReg");
    
    
    /**
     * Gets the "CSTReg" element
     */
    public java.lang.String getCSTReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CSTREG$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CSTReg" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib xgetCSTReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().find_element_user(CSTREG$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CSTReg" element
     */
    public void setCSTReg(java.lang.String cstReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CSTREG$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CSTREG$0);
            }
            target.setStringValue(cstReg);
        }
    }
    
    /**
     * Sets (as xml) the "CSTReg" element
     */
    public void xsetCSTReg(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib cstReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().find_element_user(CSTREG$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib)get_store().add_element_user(CSTREG$0);
            }
            target.set(cstReg);
        }
    }
    
    /**
     * Gets the "cClassTribReg" element
     */
    public java.lang.String getCClassTribReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCLASSTRIBREG$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cClassTribReg" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib xgetCClassTribReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().find_element_user(CCLASSTRIBREG$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cClassTribReg" element
     */
    public void setCClassTribReg(java.lang.String cClassTribReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCLASSTRIBREG$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CCLASSTRIBREG$2);
            }
            target.setStringValue(cClassTribReg);
        }
    }
    
    /**
     * Sets (as xml) the "cClassTribReg" element
     */
    public void xsetCClassTribReg(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib cClassTribReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().find_element_user(CCLASSTRIBREG$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib)get_store().add_element_user(CCLASSTRIBREG$2);
            }
            target.set(cClassTribReg);
        }
    }
}
