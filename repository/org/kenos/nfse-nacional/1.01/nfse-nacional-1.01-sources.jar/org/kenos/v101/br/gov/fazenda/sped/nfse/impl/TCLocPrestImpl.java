/*
 * XML Type:  TCLocPrest
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCLocPrest(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCLocPrestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCLocPrest
{
    private static final long serialVersionUID = 1L;
    
    public TCLocPrestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLOCPRESTACAO$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cLocPrestacao");
    private static final javax.xml.namespace.QName CPAISPRESTACAO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cPaisPrestacao");
    
    
    /**
     * Gets the "cLocPrestacao" element
     */
    public java.lang.String getCLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCPRESTACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cLocPrestacao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCPRESTACAO$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "cLocPrestacao" element
     */
    public boolean isSetCLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLOCPRESTACAO$0) != 0;
        }
    }
    
    /**
     * Sets the "cLocPrestacao" element
     */
    public void setCLocPrestacao(java.lang.String cLocPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCPRESTACAO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLOCPRESTACAO$0);
            }
            target.setStringValue(cLocPrestacao);
        }
    }
    
    /**
     * Sets (as xml) the "cLocPrestacao" element
     */
    public void xsetCLocPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCPRESTACAO$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CLOCPRESTACAO$0);
            }
            target.set(cLocPrestacao);
        }
    }
    
    /**
     * Unsets the "cLocPrestacao" element
     */
    public void unsetCLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLOCPRESTACAO$0, 0);
        }
    }
    
    /**
     * Gets the "cPaisPrestacao" element
     */
    public java.lang.String getCPaisPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPAISPRESTACAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cPaisPrestacao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO xgetCPaisPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().find_element_user(CPAISPRESTACAO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "cPaisPrestacao" element
     */
    public boolean isSetCPaisPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPAISPRESTACAO$2) != 0;
        }
    }
    
    /**
     * Sets the "cPaisPrestacao" element
     */
    public void setCPaisPrestacao(java.lang.String cPaisPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPAISPRESTACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPAISPRESTACAO$2);
            }
            target.setStringValue(cPaisPrestacao);
        }
    }
    
    /**
     * Sets (as xml) the "cPaisPrestacao" element
     */
    public void xsetCPaisPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO cPaisPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().find_element_user(CPAISPRESTACAO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodPaisISO)get_store().add_element_user(CPAISPRESTACAO$2);
            }
            target.set(cPaisPrestacao);
        }
    }
    
    /**
     * Unsets the "cPaisPrestacao" element
     */
    public void unsetCPaisPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPAISPRESTACAO$2, 0);
        }
    }
}
