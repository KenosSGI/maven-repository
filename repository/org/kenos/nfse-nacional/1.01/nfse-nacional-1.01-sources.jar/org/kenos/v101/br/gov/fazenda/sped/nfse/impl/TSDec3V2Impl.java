/*
 * XML Type:  TSDec3V2
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSDec3V2(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2.
 */
public class TSDec3V2Impl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2
{
    private static final long serialVersionUID = 1L;
    
    public TSDec3V2Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSDec3V2Impl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
