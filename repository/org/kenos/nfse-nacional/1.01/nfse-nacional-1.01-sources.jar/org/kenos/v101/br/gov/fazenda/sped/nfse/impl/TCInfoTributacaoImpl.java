/*
 * XML Type:  TCInfoTributacao
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoTributacao(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoTributacaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoTributacao
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoTributacaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRIBMUN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tribMun");
    private static final javax.xml.namespace.QName TRIBFED$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tribFed");
    private static final javax.xml.namespace.QName TOTTRIB$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "totTrib");
    
    
    /**
     * Gets the "tribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal getTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal)get_store().find_element_user(TRIBMUN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tribMun" element
     */
    public void setTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal tribMun)
    {
        generatedSetterHelperImpl(tribMun, TRIBMUN$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "tribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal addNewTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribMunicipal)get_store().add_element_user(TRIBMUN$0);
            return target;
        }
    }
    
    /**
     * Gets the "tribFed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal getTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal)get_store().find_element_user(TRIBFED$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tribFed" element
     */
    public boolean isSetTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRIBFED$2) != 0;
        }
    }
    
    /**
     * Sets the "tribFed" element
     */
    public void setTribFed(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal tribFed)
    {
        generatedSetterHelperImpl(tribFed, TRIBFED$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "tribFed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal addNewTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribFederal)get_store().add_element_user(TRIBFED$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tribFed" element
     */
    public void unsetTribFed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRIBFED$2, 0);
        }
    }
    
    /**
     * Gets the "totTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal getTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal)get_store().find_element_user(TOTTRIB$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "totTrib" element
     */
    public void setTotTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal totTrib)
    {
        generatedSetterHelperImpl(totTrib, TOTTRIB$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "totTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal addNewTotTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCTribTotal)get_store().add_element_user(TOTTRIB$4);
            return target;
        }
    }
}
