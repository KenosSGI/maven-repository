/*
 * XML Type:  TCRTCTotalIBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalIBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalIBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalIBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VIBSTOT$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vIBSTot");
    private static final javax.xml.namespace.QName GIBSCREDPRES$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gIBSCredPres");
    private static final javax.xml.namespace.QName GIBSUFTOT$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gIBSUFTot");
    private static final javax.xml.namespace.QName GIBSMUNTOT$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gIBSMunTot");
    
    
    /**
     * Gets the "vIBSTot" element
     */
    public java.lang.String getVIBSTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSTOT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vIBSTot" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVIBSTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSTOT$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vIBSTot" element
     */
    public void setVIBSTot(java.lang.String vibsTot)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSTOT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VIBSTOT$0);
            }
            target.setStringValue(vibsTot);
        }
    }
    
    /**
     * Sets (as xml) the "vIBSTot" element
     */
    public void xsetVIBSTot(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vibsTot)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSTOT$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VIBSTOT$0);
            }
            target.set(vibsTot);
        }
    }
    
    /**
     * Gets the "gIBSCredPres" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres getGIBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres)get_store().find_element_user(GIBSCREDPRES$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gIBSCredPres" element
     */
    public boolean isSetGIBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GIBSCREDPRES$2) != 0;
        }
    }
    
    /**
     * Sets the "gIBSCredPres" element
     */
    public void setGIBSCredPres(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres gibsCredPres)
    {
        generatedSetterHelperImpl(gibsCredPres, GIBSCREDPRES$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gIBSCredPres" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres addNewGIBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSCredPres)get_store().add_element_user(GIBSCREDPRES$2);
            return target;
        }
    }
    
    /**
     * Unsets the "gIBSCredPres" element
     */
    public void unsetGIBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GIBSCREDPRES$2, 0);
        }
    }
    
    /**
     * Gets the "gIBSUFTot" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF getGIBSUFTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF)get_store().find_element_user(GIBSUFTOT$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gIBSUFTot" element
     */
    public void setGIBSUFTot(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF gibsufTot)
    {
        generatedSetterHelperImpl(gibsufTot, GIBSUFTOT$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gIBSUFTot" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF addNewGIBSUFTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF)get_store().add_element_user(GIBSUFTOT$4);
            return target;
        }
    }
    
    /**
     * Gets the "gIBSMunTot" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun getGIBSMunTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun)get_store().find_element_user(GIBSMUNTOT$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gIBSMunTot" element
     */
    public void setGIBSMunTot(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun gibsMunTot)
    {
        generatedSetterHelperImpl(gibsMunTot, GIBSMUNTOT$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gIBSMunTot" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun addNewGIBSMunTot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun)get_store().add_element_user(GIBSMUNTOT$6);
            return target;
        }
    }
}
