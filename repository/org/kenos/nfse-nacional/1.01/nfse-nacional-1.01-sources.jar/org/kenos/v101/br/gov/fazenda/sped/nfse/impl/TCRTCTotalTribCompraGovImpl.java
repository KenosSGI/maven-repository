/*
 * XML Type:  TCRTCTotalTribCompraGov
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalTribCompraGov(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalTribCompraGovImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribCompraGov
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalTribCompraGovImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PIBSUF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pIBSUF");
    private static final javax.xml.namespace.QName VIBSUF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vIBSUF");
    private static final javax.xml.namespace.QName PIBSMUN$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pIBSMun");
    private static final javax.xml.namespace.QName VIBSMUN$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vIBSMun");
    private static final javax.xml.namespace.QName PCBS$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pCBS");
    private static final javax.xml.namespace.QName VCBS$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCBS");
    
    
    /**
     * Gets the "pIBSUF" element
     */
    public java.lang.String getPIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSUF$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pIBSUF" element
     */
    public void setPIBSUF(java.lang.String pibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PIBSUF$0);
            }
            target.setStringValue(pibsuf);
        }
    }
    
    /**
     * Sets (as xml) the "pIBSUF" element
     */
    public void xsetPIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSUF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PIBSUF$0);
            }
            target.set(pibsuf);
        }
    }
    
    /**
     * Gets the "vIBSUF" element
     */
    public java.lang.String getVIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSUF$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vIBSUF" element
     */
    public void setVIBSUF(java.lang.String vibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VIBSUF$2);
            }
            target.setStringValue(vibsuf);
        }
    }
    
    /**
     * Sets (as xml) the "vIBSUF" element
     */
    public void xsetVIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VIBSUF$2);
            }
            target.set(vibsuf);
        }
    }
    
    /**
     * Gets the "pIBSMun" element
     */
    public java.lang.String getPIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSMUN$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSMUN$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pIBSMun" element
     */
    public void setPIBSMun(java.lang.String pibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PIBSMUN$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PIBSMUN$4);
            }
            target.setStringValue(pibsMun);
        }
    }
    
    /**
     * Sets (as xml) the "pIBSMun" element
     */
    public void xsetPIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PIBSMUN$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PIBSMUN$4);
            }
            target.set(pibsMun);
        }
    }
    
    /**
     * Gets the "vIBSMun" element
     */
    public java.lang.String getVIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSMUN$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSMUN$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vIBSMun" element
     */
    public void setVIBSMun(java.lang.String vibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSMUN$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VIBSMUN$6);
            }
            target.setStringValue(vibsMun);
        }
    }
    
    /**
     * Sets (as xml) the "vIBSMun" element
     */
    public void xsetVIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSMUN$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VIBSMUN$6);
            }
            target.set(vibsMun);
        }
    }
    
    /**
     * Gets the "pCBS" element
     */
    public java.lang.String getPCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCBS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCBS$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pCBS" element
     */
    public void setPCBS(java.lang.String pcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCBS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PCBS$8);
            }
            target.setStringValue(pcbs);
        }
    }
    
    /**
     * Sets (as xml) the "pCBS" element
     */
    public void xsetPCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCBS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PCBS$8);
            }
            target.set(pcbs);
        }
    }
    
    /**
     * Gets the "vCBS" element
     */
    public java.lang.String getVCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCBS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCBS$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vCBS" element
     */
    public void setVCBS(java.lang.String vcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCBS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCBS$10);
            }
            target.setStringValue(vcbs);
        }
    }
    
    /**
     * Sets (as xml) the "vCBS" element
     */
    public void xsetVCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCBS$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCBS$10);
            }
            target.set(vcbs);
        }
    }
}
