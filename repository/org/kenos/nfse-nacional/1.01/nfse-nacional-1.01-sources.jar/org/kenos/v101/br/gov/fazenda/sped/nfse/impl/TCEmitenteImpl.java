/*
 * XML Type:  TCEmitente
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEmitente(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEmitenteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente
{
    private static final long serialVersionUID = 1L;
    
    public TCEmitenteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CNPJ$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNPJ");
    private static final javax.xml.namespace.QName CPF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPF");
    private static final javax.xml.namespace.QName IM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "IM");
    private static final javax.xml.namespace.QName XNOME$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xNome");
    private static final javax.xml.namespace.QName XFANT$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xFant");
    private static final javax.xml.namespace.QName ENDERNAC$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "enderNac");
    private static final javax.xml.namespace.QName FONE$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "fone");
    private static final javax.xml.namespace.QName EMAIL$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "email");
    
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$0);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJ$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().add_element_user(CNPJ$0);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$2) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$2);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPF$2);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$2, 0);
        }
    }
    
    /**
     * Gets the "IM" element
     */
    public java.lang.String getIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "IM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun xgetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().find_element_user(IM$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "IM" element
     */
    public boolean isSetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IM$4) != 0;
        }
    }
    
    /**
     * Sets the "IM" element
     */
    public void setIM(java.lang.String im)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IM$4);
            }
            target.setStringValue(im);
        }
    }
    
    /**
     * Sets (as xml) the "IM" element
     */
    public void xsetIM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun im)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().find_element_user(IM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun)get_store().add_element_user(IM$4);
            }
            target.set(im);
        }
    }
    
    /**
     * Unsets the "IM" element
     */
    public void unsetIM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IM$4, 0);
        }
    }
    
    /**
     * Gets the "xNome" element
     */
    public java.lang.String getXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xNome" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial xgetXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial)get_store().find_element_user(XNOME$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xNome" element
     */
    public void setXNome(java.lang.String xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XNOME$6);
            }
            target.setStringValue(xNome);
        }
    }
    
    /**
     * Sets (as xml) the "xNome" element
     */
    public void xsetXNome(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial)get_store().find_element_user(XNOME$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeRazaoSocial)get_store().add_element_user(XNOME$6);
            }
            target.set(xNome);
        }
    }
    
    /**
     * Gets the "xFant" element
     */
    public java.lang.String getXFant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XFANT$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xFant" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia xgetXFant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia)get_store().find_element_user(XFANT$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "xFant" element
     */
    public boolean isSetXFant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XFANT$8) != 0;
        }
    }
    
    /**
     * Sets the "xFant" element
     */
    public void setXFant(java.lang.String xFant)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XFANT$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XFANT$8);
            }
            target.setStringValue(xFant);
        }
    }
    
    /**
     * Sets (as xml) the "xFant" element
     */
    public void xsetXFant(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia xFant)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia)get_store().find_element_user(XFANT$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNomeFantasia)get_store().add_element_user(XFANT$8);
            }
            target.set(xFant);
        }
    }
    
    /**
     * Unsets the "xFant" element
     */
    public void unsetXFant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XFANT$8, 0);
        }
    }
    
    /**
     * Gets the "enderNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente getEnderNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente)get_store().find_element_user(ENDERNAC$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enderNac" element
     */
    public void setEnderNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente enderNac)
    {
        generatedSetterHelperImpl(enderNac, ENDERNAC$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "enderNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente addNewEnderNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoEmitente)get_store().add_element_user(ENDERNAC$10);
            return target;
        }
    }
    
    /**
     * Gets the "fone" element
     */
    public java.lang.String getFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fone" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone xgetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "fone" element
     */
    public boolean isSetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FONE$12) != 0;
        }
    }
    
    /**
     * Sets the "fone" element
     */
    public void setFone(java.lang.String fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FONE$12);
            }
            target.setStringValue(fone);
        }
    }
    
    /**
     * Sets (as xml) the "fone" element
     */
    public void xsetFone(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone fone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().find_element_user(FONE$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone)get_store().add_element_user(FONE$12);
            }
            target.set(fone);
        }
    }
    
    /**
     * Unsets the "fone" element
     */
    public void unsetFone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FONE$12, 0);
        }
    }
    
    /**
     * Gets the "email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "email" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$14) != 0;
        }
    }
    
    /**
     * Sets the "email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$14);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "email" element
     */
    public void xsetEmail(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().find_element_user(EMAIL$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail)get_store().add_element_user(EMAIL$14);
            }
            target.set(email);
        }
    }
    
    /**
     * Unsets the "email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$14, 0);
        }
    }
}
