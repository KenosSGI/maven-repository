/*
 * XML Type:  TCAtvEvento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCAtvEvento(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCAtvEventoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCAtvEvento
{
    private static final long serialVersionUID = 1L;
    
    public TCAtvEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XNOME$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xNome");
    private static final javax.xml.namespace.QName DTINI$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dtIni");
    private static final javax.xml.namespace.QName DTFIM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dtFim");
    private static final javax.xml.namespace.QName IDATVEVT$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "idAtvEvt");
    private static final javax.xml.namespace.QName END$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "end");
    
    
    /**
     * Gets the "xNome" element
     */
    public java.lang.String getXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xNome" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetXNome()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XNOME$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xNome" element
     */
    public void setXNome(java.lang.String xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNOME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XNOME$0);
            }
            target.setStringValue(xNome);
        }
    }
    
    /**
     * Sets (as xml) the "xNome" element
     */
    public void xsetXNome(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xNome)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XNOME$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(XNOME$0);
            }
            target.set(xNome);
        }
    }
    
    /**
     * Gets the "dtIni" element
     */
    public java.lang.String getDtIni()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINI$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dtIni" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtIni()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTINI$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dtIni" element
     */
    public void setDtIni(java.lang.String dtIni)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINI$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTINI$2);
            }
            target.setStringValue(dtIni);
        }
    }
    
    /**
     * Sets (as xml) the "dtIni" element
     */
    public void xsetDtIni(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtIni)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTINI$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DTINI$2);
            }
            target.set(dtIni);
        }
    }
    
    /**
     * Gets the "dtFim" element
     */
    public java.lang.String getDtFim()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dtFim" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtFim()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTFIM$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dtFim" element
     */
    public void setDtFim(java.lang.String dtFim)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTFIM$4);
            }
            target.setStringValue(dtFim);
        }
    }
    
    /**
     * Sets (as xml) the "dtFim" element
     */
    public void xsetDtFim(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtFim)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DTFIM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DTFIM$4);
            }
            target.set(dtFim);
        }
    }
    
    /**
     * Gets the "idAtvEvt" element
     */
    public java.lang.String getIdAtvEvt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDATVEVT$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "idAtvEvt" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento xgetIdAtvEvt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento)get_store().find_element_user(IDATVEVT$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "idAtvEvt" element
     */
    public boolean isSetIdAtvEvt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDATVEVT$6) != 0;
        }
    }
    
    /**
     * Sets the "idAtvEvt" element
     */
    public void setIdAtvEvt(java.lang.String idAtvEvt)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDATVEVT$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDATVEVT$6);
            }
            target.setStringValue(idAtvEvt);
        }
    }
    
    /**
     * Sets (as xml) the "idAtvEvt" element
     */
    public void xsetIdAtvEvt(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento idAtvEvt)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento)get_store().find_element_user(IDATVEVT$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdeEvento)get_store().add_element_user(IDATVEVT$6);
            }
            target.set(idAtvEvt);
        }
    }
    
    /**
     * Unsets the "idAtvEvt" element
     */
    public void unsetIdAtvEvt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDATVEVT$6, 0);
        }
    }
    
    /**
     * Gets the "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples getEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples)get_store().find_element_user(END$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "end" element
     */
    public boolean isSetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(END$8) != 0;
        }
    }
    
    /**
     * Sets the "end" element
     */
    public void setEnd(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples end)
    {
        generatedSetterHelperImpl(end, END$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "end" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples addNewEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderecoSimples)get_store().add_element_user(END$8);
            return target;
        }
    }
    
    /**
     * Unsets the "end" element
     */
    public void unsetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(END$8, 0);
        }
    }
}
