/*
 * XML Type:  TCEnderExtSimples
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEnderExtSimples(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEnderExtSimplesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples
{
    private static final long serialVersionUID = 1L;
    
    public TCEnderExtSimplesImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CENDPOST$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cEndPost");
    private static final javax.xml.namespace.QName XCIDADE$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xCidade");
    private static final javax.xml.namespace.QName XESTPROVREG$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xEstProvReg");
    
    
    /**
     * Gets the "cEndPost" element
     */
    public java.lang.String getCEndPost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CENDPOST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cEndPost" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal xgetCEndPost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal)get_store().find_element_user(CENDPOST$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cEndPost" element
     */
    public void setCEndPost(java.lang.String cEndPost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CENDPOST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CENDPOST$0);
            }
            target.setStringValue(cEndPost);
        }
    }
    
    /**
     * Sets (as xml) the "cEndPost" element
     */
    public void xsetCEndPost(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal cEndPost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal)get_store().find_element_user(CENDPOST$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodigoEndPostal)get_store().add_element_user(CENDPOST$0);
            }
            target.set(cEndPost);
        }
    }
    
    /**
     * Gets the "xCidade" element
     */
    public java.lang.String getXCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCIDADE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xCidade" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade xgetXCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade)get_store().find_element_user(XCIDADE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xCidade" element
     */
    public void setXCidade(java.lang.String xCidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCIDADE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XCIDADE$2);
            }
            target.setStringValue(xCidade);
        }
    }
    
    /**
     * Sets (as xml) the "xCidade" element
     */
    public void xsetXCidade(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade xCidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade)get_store().find_element_user(XCIDADE$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCidade)get_store().add_element_user(XCIDADE$2);
            }
            target.set(xCidade);
        }
    }
    
    /**
     * Gets the "xEstProvReg" element
     */
    public java.lang.String getXEstProvReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XESTPROVREG$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xEstProvReg" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao xgetXEstProvReg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao)get_store().find_element_user(XESTPROVREG$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xEstProvReg" element
     */
    public void setXEstProvReg(java.lang.String xEstProvReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XESTPROVREG$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XESTPROVREG$4);
            }
            target.setStringValue(xEstProvReg);
        }
    }
    
    /**
     * Sets (as xml) the "xEstProvReg" element
     */
    public void xsetXEstProvReg(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao xEstProvReg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao)get_store().find_element_user(XESTPROVREG$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEstadoProvRegiao)get_store().add_element_user(XESTPROVREG$4);
            }
            target.set(xEstProvReg);
        }
    }
}
