/*
 * XML Type:  TCInfPedReg
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfPedReg(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfPedRegImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfPedReg
{
    private static final long serialVersionUID = 1L;
    
    public TCInfPedRegImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPAMB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpAmb");
    private static final javax.xml.namespace.QName VERAPLIC$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "verAplic");
    private static final javax.xml.namespace.QName DHEVENTO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dhEvento");
    private static final javax.xml.namespace.QName CNPJAUTOR$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CNPJAutor");
    private static final javax.xml.namespace.QName CPFAUTOR$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPFAutor");
    private static final javax.xml.namespace.QName CHNFSE$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chNFSe");
    private static final javax.xml.namespace.QName NPEDREGEVENTO$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nPedRegEvento");
    private static final javax.xml.namespace.QName E101101$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e101101");
    private static final javax.xml.namespace.QName E105102$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e105102");
    private static final javax.xml.namespace.QName E101103$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e101103");
    private static final javax.xml.namespace.QName E105104$20 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e105104");
    private static final javax.xml.namespace.QName E105105$22 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e105105");
    private static final javax.xml.namespace.QName E202201$24 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e202201");
    private static final javax.xml.namespace.QName E203202$26 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e203202");
    private static final javax.xml.namespace.QName E204203$28 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e204203");
    private static final javax.xml.namespace.QName E205204$30 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e205204");
    private static final javax.xml.namespace.QName E202205$32 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e202205");
    private static final javax.xml.namespace.QName E203206$34 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e203206");
    private static final javax.xml.namespace.QName E204207$36 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e204207");
    private static final javax.xml.namespace.QName E205208$38 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e205208");
    private static final javax.xml.namespace.QName E305101$40 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e305101");
    private static final javax.xml.namespace.QName E305102$42 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e305102");
    private static final javax.xml.namespace.QName E305103$44 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "e305103");
    private static final javax.xml.namespace.QName ID$46 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpAmb" element
     */
    public void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPAMB$0);
            }
            target.setEnumValue(tpAmb);
        }
    }
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    public void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().add_element_user(TPAMB$0);
            }
            target.set(tpAmb);
        }
    }
    
    /**
     * Gets the "verAplic" element
     */
    public java.lang.String getVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "verAplic" element
     */
    public void setVerAplic(java.lang.String verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERAPLIC$2);
            }
            target.setStringValue(verAplic);
        }
    }
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    public void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().add_element_user(VERAPLIC$2);
            }
            target.set(verAplic);
        }
    }
    
    /**
     * Gets the "dhEvento" element
     */
    public java.lang.String getDhEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHEVENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dhEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHEVENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dhEvento" element
     */
    public void setDhEvento(java.lang.String dhEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHEVENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DHEVENTO$4);
            }
            target.setStringValue(dhEvento);
        }
    }
    
    /**
     * Sets (as xml) the "dhEvento" element
     */
    public void xsetDhEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHEVENTO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().add_element_user(DHEVENTO$4);
            }
            target.set(dhEvento);
        }
    }
    
    /**
     * Gets the "CNPJAutor" element
     */
    public java.lang.String getCNPJAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJAUTOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJAutor" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJAUTOR$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJAutor" element
     */
    public boolean isSetCNPJAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJAUTOR$6) != 0;
        }
    }
    
    /**
     * Sets the "CNPJAutor" element
     */
    public void setCNPJAutor(java.lang.String cnpjAutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJAUTOR$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJAUTOR$6);
            }
            target.setStringValue(cnpjAutor);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJAutor" element
     */
    public void xsetCNPJAutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpjAutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().find_element_user(CNPJAUTOR$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ)get_store().add_element_user(CNPJAUTOR$6);
            }
            target.set(cnpjAutor);
        }
    }
    
    /**
     * Unsets the "CNPJAutor" element
     */
    public void unsetCNPJAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJAUTOR$6, 0);
        }
    }
    
    /**
     * Gets the "CPFAutor" element
     */
    public java.lang.String getCPFAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAUTOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPFAutor" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAUTOR$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPFAutor" element
     */
    public boolean isSetCPFAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFAUTOR$8) != 0;
        }
    }
    
    /**
     * Sets the "CPFAutor" element
     */
    public void setCPFAutor(java.lang.String cpfAutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAUTOR$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFAUTOR$8);
            }
            target.setStringValue(cpfAutor);
        }
    }
    
    /**
     * Sets (as xml) the "CPFAutor" element
     */
    public void xsetCPFAutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAutor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAUTOR$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPFAUTOR$8);
            }
            target.set(cpfAutor);
        }
    }
    
    /**
     * Unsets the "CPFAutor" element
     */
    public void unsetCPFAutor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFAUTOR$8, 0);
        }
    }
    
    /**
     * Gets the "chNFSe" element
     */
    public java.lang.String getChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSE$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSE$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "chNFSe" element
     */
    public void setChNFSe(java.lang.String chNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHNFSE$10);
            }
            target.setStringValue(chNFSe);
        }
    }
    
    /**
     * Sets (as xml) the "chNFSe" element
     */
    public void xsetChNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSE$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(CHNFSE$10);
            }
            target.set(chNFSe);
        }
    }
    
    /**
     * Gets the "nPedRegEvento" element
     */
    public java.lang.String getNPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPEDREGEVENTO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nPedRegEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig xgetNPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().find_element_user(NPEDREGEVENTO$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nPedRegEvento" element
     */
    public void setNPedRegEvento(java.lang.String nPedRegEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NPEDREGEVENTO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NPEDREGEVENTO$12);
            }
            target.setStringValue(nPedRegEvento);
        }
    }
    
    /**
     * Sets (as xml) the "nPedRegEvento" element
     */
    public void xsetNPedRegEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig nPedRegEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().find_element_user(NPEDREGEVENTO$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().add_element_user(NPEDREGEVENTO$12);
            }
            target.set(nPedRegEvento);
        }
    }
    
    /**
     * Gets the "e101101" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 getE101101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101)get_store().find_element_user(E101101$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e101101" element
     */
    public boolean isSetE101101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E101101$14) != 0;
        }
    }
    
    /**
     * Sets the "e101101" element
     */
    public void setE101101(org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 e101101)
    {
        generatedSetterHelperImpl(e101101, E101101$14, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e101101" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 addNewE101101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE101101)get_store().add_element_user(E101101$14);
            return target;
        }
    }
    
    /**
     * Unsets the "e101101" element
     */
    public void unsetE101101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E101101$14, 0);
        }
    }
    
    /**
     * Gets the "e105102" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 getE105102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102)get_store().find_element_user(E105102$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e105102" element
     */
    public boolean isSetE105102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E105102$16) != 0;
        }
    }
    
    /**
     * Sets the "e105102" element
     */
    public void setE105102(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 e105102)
    {
        generatedSetterHelperImpl(e105102, E105102$16, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e105102" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 addNewE105102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102)get_store().add_element_user(E105102$16);
            return target;
        }
    }
    
    /**
     * Unsets the "e105102" element
     */
    public void unsetE105102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E105102$16, 0);
        }
    }
    
    /**
     * Gets the "e101103" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 getE101103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103)get_store().find_element_user(E101103$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e101103" element
     */
    public boolean isSetE101103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E101103$18) != 0;
        }
    }
    
    /**
     * Sets the "e101103" element
     */
    public void setE101103(org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 e101103)
    {
        generatedSetterHelperImpl(e101103, E101103$18, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e101103" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 addNewE101103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE101103)get_store().add_element_user(E101103$18);
            return target;
        }
    }
    
    /**
     * Unsets the "e101103" element
     */
    public void unsetE101103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E101103$18, 0);
        }
    }
    
    /**
     * Gets the "e105104" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 getE105104()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104)get_store().find_element_user(E105104$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e105104" element
     */
    public boolean isSetE105104()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E105104$20) != 0;
        }
    }
    
    /**
     * Sets the "e105104" element
     */
    public void setE105104(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 e105104)
    {
        generatedSetterHelperImpl(e105104, E105104$20, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e105104" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 addNewE105104()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105104)get_store().add_element_user(E105104$20);
            return target;
        }
    }
    
    /**
     * Unsets the "e105104" element
     */
    public void unsetE105104()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E105104$20, 0);
        }
    }
    
    /**
     * Gets the "e105105" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 getE105105()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105)get_store().find_element_user(E105105$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e105105" element
     */
    public boolean isSetE105105()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E105105$22) != 0;
        }
    }
    
    /**
     * Sets the "e105105" element
     */
    public void setE105105(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 e105105)
    {
        generatedSetterHelperImpl(e105105, E105105$22, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e105105" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 addNewE105105()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105105)get_store().add_element_user(E105105$22);
            return target;
        }
    }
    
    /**
     * Unsets the "e105105" element
     */
    public void unsetE105105()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E105105$22, 0);
        }
    }
    
    /**
     * Gets the "e202201" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 getE202201()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201)get_store().find_element_user(E202201$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e202201" element
     */
    public boolean isSetE202201()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E202201$24) != 0;
        }
    }
    
    /**
     * Sets the "e202201" element
     */
    public void setE202201(org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 e202201)
    {
        generatedSetterHelperImpl(e202201, E202201$24, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e202201" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 addNewE202201()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE202201)get_store().add_element_user(E202201$24);
            return target;
        }
    }
    
    /**
     * Unsets the "e202201" element
     */
    public void unsetE202201()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E202201$24, 0);
        }
    }
    
    /**
     * Gets the "e203202" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 getE203202()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202)get_store().find_element_user(E203202$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e203202" element
     */
    public boolean isSetE203202()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E203202$26) != 0;
        }
    }
    
    /**
     * Sets the "e203202" element
     */
    public void setE203202(org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 e203202)
    {
        generatedSetterHelperImpl(e203202, E203202$26, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e203202" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 addNewE203202()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE203202)get_store().add_element_user(E203202$26);
            return target;
        }
    }
    
    /**
     * Unsets the "e203202" element
     */
    public void unsetE203202()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E203202$26, 0);
        }
    }
    
    /**
     * Gets the "e204203" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 getE204203()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203)get_store().find_element_user(E204203$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e204203" element
     */
    public boolean isSetE204203()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E204203$28) != 0;
        }
    }
    
    /**
     * Sets the "e204203" element
     */
    public void setE204203(org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 e204203)
    {
        generatedSetterHelperImpl(e204203, E204203$28, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e204203" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 addNewE204203()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE204203)get_store().add_element_user(E204203$28);
            return target;
        }
    }
    
    /**
     * Unsets the "e204203" element
     */
    public void unsetE204203()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E204203$28, 0);
        }
    }
    
    /**
     * Gets the "e205204" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 getE205204()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204)get_store().find_element_user(E205204$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e205204" element
     */
    public boolean isSetE205204()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E205204$30) != 0;
        }
    }
    
    /**
     * Sets the "e205204" element
     */
    public void setE205204(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 e205204)
    {
        generatedSetterHelperImpl(e205204, E205204$30, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e205204" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 addNewE205204()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205204)get_store().add_element_user(E205204$30);
            return target;
        }
    }
    
    /**
     * Unsets the "e205204" element
     */
    public void unsetE205204()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E205204$30, 0);
        }
    }
    
    /**
     * Gets the "e202205" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 getE202205()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205)get_store().find_element_user(E202205$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e202205" element
     */
    public boolean isSetE202205()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E202205$32) != 0;
        }
    }
    
    /**
     * Sets the "e202205" element
     */
    public void setE202205(org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 e202205)
    {
        generatedSetterHelperImpl(e202205, E202205$32, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e202205" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 addNewE202205()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE202205)get_store().add_element_user(E202205$32);
            return target;
        }
    }
    
    /**
     * Unsets the "e202205" element
     */
    public void unsetE202205()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E202205$32, 0);
        }
    }
    
    /**
     * Gets the "e203206" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 getE203206()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206)get_store().find_element_user(E203206$34, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e203206" element
     */
    public boolean isSetE203206()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E203206$34) != 0;
        }
    }
    
    /**
     * Sets the "e203206" element
     */
    public void setE203206(org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 e203206)
    {
        generatedSetterHelperImpl(e203206, E203206$34, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e203206" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 addNewE203206()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE203206)get_store().add_element_user(E203206$34);
            return target;
        }
    }
    
    /**
     * Unsets the "e203206" element
     */
    public void unsetE203206()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E203206$34, 0);
        }
    }
    
    /**
     * Gets the "e204207" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 getE204207()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207)get_store().find_element_user(E204207$36, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e204207" element
     */
    public boolean isSetE204207()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E204207$36) != 0;
        }
    }
    
    /**
     * Sets the "e204207" element
     */
    public void setE204207(org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 e204207)
    {
        generatedSetterHelperImpl(e204207, E204207$36, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e204207" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 addNewE204207()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE204207)get_store().add_element_user(E204207$36);
            return target;
        }
    }
    
    /**
     * Unsets the "e204207" element
     */
    public void unsetE204207()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E204207$36, 0);
        }
    }
    
    /**
     * Gets the "e205208" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 getE205208()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208)get_store().find_element_user(E205208$38, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e205208" element
     */
    public boolean isSetE205208()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E205208$38) != 0;
        }
    }
    
    /**
     * Sets the "e205208" element
     */
    public void setE205208(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 e205208)
    {
        generatedSetterHelperImpl(e205208, E205208$38, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e205208" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 addNewE205208()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208)get_store().add_element_user(E205208$38);
            return target;
        }
    }
    
    /**
     * Unsets the "e205208" element
     */
    public void unsetE205208()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E205208$38, 0);
        }
    }
    
    /**
     * Gets the "e305101" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 getE305101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101)get_store().find_element_user(E305101$40, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e305101" element
     */
    public boolean isSetE305101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E305101$40) != 0;
        }
    }
    
    /**
     * Sets the "e305101" element
     */
    public void setE305101(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 e305101)
    {
        generatedSetterHelperImpl(e305101, E305101$40, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e305101" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 addNewE305101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305101)get_store().add_element_user(E305101$40);
            return target;
        }
    }
    
    /**
     * Unsets the "e305101" element
     */
    public void unsetE305101()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E305101$40, 0);
        }
    }
    
    /**
     * Gets the "e305102" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 getE305102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102)get_store().find_element_user(E305102$42, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e305102" element
     */
    public boolean isSetE305102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E305102$42) != 0;
        }
    }
    
    /**
     * Sets the "e305102" element
     */
    public void setE305102(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 e305102)
    {
        generatedSetterHelperImpl(e305102, E305102$42, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e305102" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 addNewE305102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305102)get_store().add_element_user(E305102$42);
            return target;
        }
    }
    
    /**
     * Unsets the "e305102" element
     */
    public void unsetE305102()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E305102$42, 0);
        }
    }
    
    /**
     * Gets the "e305103" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 getE305103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103)get_store().find_element_user(E305103$44, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "e305103" element
     */
    public boolean isSetE305103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(E305103$44) != 0;
        }
    }
    
    /**
     * Sets the "e305103" element
     */
    public void setE305103(org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 e305103)
    {
        generatedSetterHelperImpl(e305103, E305103$44, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "e305103" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 addNewE305103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE305103)get_store().add_element_user(E305103$44);
            return target;
        }
    }
    
    /**
     * Unsets the "e305103" element
     */
    public void unsetE305103()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(E305103$44, 0);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$46);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt)get_store().find_attribute_user(ID$46);
            return target;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$46);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$46);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt)get_store().find_attribute_user(ID$46);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdPedRefEvt)get_store().add_attribute_user(ID$46);
            }
            target.set(id);
        }
    }
}
