/*
 * XML Type:  TSMecAFComExToma
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSMecAFComExToma(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.
 */
public class TSMecAFComExTomaImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma
{
    private static final long serialVersionUID = 1L;
    
    public TSMecAFComExTomaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSMecAFComExTomaImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
