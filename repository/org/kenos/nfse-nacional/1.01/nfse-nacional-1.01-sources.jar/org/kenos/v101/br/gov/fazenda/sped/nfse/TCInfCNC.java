/*
 * XML Type:  TCInfCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfCNC extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfCNC.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcinfcnc5226type");
    
    /**
     * Gets the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb();
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb();
    
    /**
     * Sets the "tpAmb" element
     */
    void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb);
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb);
    
    /**
     * Gets the "dhGeracaoArquivo" element
     */
    java.lang.String getDhGeracaoArquivo();
    
    /**
     * Gets (as xml) the "dhGeracaoArquivo" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhGeracaoArquivo();
    
    /**
     * Sets the "dhGeracaoArquivo" element
     */
    void setDhGeracaoArquivo(java.lang.String dhGeracaoArquivo);
    
    /**
     * Sets (as xml) the "dhGeracaoArquivo" element
     */
    void xsetDhGeracaoArquivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhGeracaoArquivo);
    
    /**
     * Gets the "verAplic" element
     */
    java.lang.String getVerAplic();
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic();
    
    /**
     * Sets the "verAplic" element
     */
    void setVerAplic(java.lang.String verAplic);
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic);
    
    /**
     * Gets the "contribuintesCnc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc getContribuintesCnc();
    
    /**
     * Sets the "contribuintesCnc" element
     */
    void setContribuintesCnc(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc contribuintesCnc);
    
    /**
     * Appends and returns a new empty "contribuintesCnc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc addNewContribuintesCnc();
    
    /**
     * An XML contribuintesCnc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is a complex type.
     */
    public interface ContribuintesCnc extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ContribuintesCnc.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("contribuintescnc16f3elemtype");
        
        /**
         * Gets array of all "contribuinteCnc" elements
         */
        org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[] getContribuinteCncArray();
        
        /**
         * Gets ith "contribuinteCnc" element
         */
        org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC getContribuinteCncArray(int i);
        
        /**
         * Returns number of "contribuinteCnc" element
         */
        int sizeOfContribuinteCncArray();
        
        /**
         * Sets array of all "contribuinteCnc" element
         */
        void setContribuinteCncArray(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC[] contribuinteCncArray);
        
        /**
         * Sets ith "contribuinteCnc" element
         */
        void setContribuinteCncArray(int i, org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC contribuinteCnc);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "contribuinteCnc" element
         */
        org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC insertNewContribuinteCnc(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "contribuinteCnc" element
         */
        org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC addNewContribuinteCnc();
        
        /**
         * Removes the ith "contribuinteCnc" element
         */
        void removeContribuinteCnc(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc newInstance() {
              return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC.ContribuintesCnc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
