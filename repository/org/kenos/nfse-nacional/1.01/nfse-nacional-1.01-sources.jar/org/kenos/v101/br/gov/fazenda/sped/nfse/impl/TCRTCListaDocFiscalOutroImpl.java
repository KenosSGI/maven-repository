/*
 * XML Type:  TCRTCListaDocFiscalOutro
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCListaDocFiscalOutro(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCListaDocFiscalOutroImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCListaDocFiscalOutroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CMUNDOCFISCAL$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMunDocFiscal");
    private static final javax.xml.namespace.QName NDOCFISCAL$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDocFiscal");
    private static final javax.xml.namespace.QName XDOCFISCAL$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDocFiscal");
    
    
    /**
     * Gets the "cMunDocFiscal" element
     */
    public java.lang.String getCMunDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUNDOCFISCAL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMunDocFiscal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig xgetCMunDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().find_element_user(CMUNDOCFISCAL$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMunDocFiscal" element
     */
    public void setCMunDocFiscal(java.lang.String cMunDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMUNDOCFISCAL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMUNDOCFISCAL$0);
            }
            target.setStringValue(cMunDocFiscal);
        }
    }
    
    /**
     * Sets (as xml) the "cMunDocFiscal" element
     */
    public void xsetCMunDocFiscal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig cMunDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().find_element_user(CMUNDOCFISCAL$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum7Dig)get_store().add_element_user(CMUNDOCFISCAL$0);
            }
            target.set(cMunDocFiscal);
        }
    }
    
    /**
     * Gets the "nDocFiscal" element
     */
    public java.lang.String getNDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOCFISCAL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDocFiscal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOCFISCAL$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nDocFiscal" element
     */
    public void setNDocFiscal(java.lang.String nDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOCFISCAL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDOCFISCAL$2);
            }
            target.setStringValue(nDocFiscal);
        }
    }
    
    /**
     * Sets (as xml) the "nDocFiscal" element
     */
    public void xsetNDocFiscal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOCFISCAL$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(NDOCFISCAL$2);
            }
            target.set(nDocFiscal);
        }
    }
    
    /**
     * Gets the "xDocFiscal" element
     */
    public java.lang.String getXDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDOCFISCAL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDocFiscal" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetXDocFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XDOCFISCAL$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDocFiscal" element
     */
    public void setXDocFiscal(java.lang.String xDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDOCFISCAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDOCFISCAL$4);
            }
            target.setStringValue(xDocFiscal);
        }
    }
    
    /**
     * Sets (as xml) the "xDocFiscal" element
     */
    public void xsetXDocFiscal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xDocFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XDOCFISCAL$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(XDOCFISCAL$4);
            }
            target.set(xDocFiscal);
        }
    }
}
