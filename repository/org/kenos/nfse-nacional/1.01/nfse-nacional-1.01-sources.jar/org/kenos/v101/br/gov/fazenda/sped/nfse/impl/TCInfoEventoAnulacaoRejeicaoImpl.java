/*
 * XML Type:  TCInfoEventoAnulacaoRejeicao
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoEventoAnulacaoRejeicao(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoEventoAnulacaoRejeicaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoEventoAnulacaoRejeicaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CPFAGTRIB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CPFAgTrib");
    private static final javax.xml.namespace.QName IDEVMANIFREJ$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "idEvManifRej");
    private static final javax.xml.namespace.QName XMOTIVO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xMotivo");
    
    
    /**
     * Gets the "CPFAgTrib" element
     */
    public java.lang.String getCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPFAgTrib" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPFAgTrib()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CPFAgTrib" element
     */
    public void setCPFAgTrib(java.lang.String cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPFAGTRIB$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPFAGTRIB$0);
            }
            target.setStringValue(cpfAgTrib);
        }
    }
    
    /**
     * Sets (as xml) the "CPFAgTrib" element
     */
    public void xsetCPFAgTrib(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpfAgTrib)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().find_element_user(CPFAGTRIB$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF)get_store().add_element_user(CPFAGTRIB$0);
            }
            target.set(cpfAgTrib);
        }
    }
    
    /**
     * Gets the "idEvManifRej" element
     */
    public java.lang.String getIdEvManifRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDEVMANIFREJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "idEvManifRej" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento xgetIdEvManifRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento)get_store().find_element_user(IDEVMANIFREJ$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "idEvManifRej" element
     */
    public void setIdEvManifRej(java.lang.String idEvManifRej)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDEVMANIFREJ$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDEVMANIFREJ$2);
            }
            target.setStringValue(idEvManifRej);
        }
    }
    
    /**
     * Sets (as xml) the "idEvManifRej" element
     */
    public void xsetIdEvManifRej(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento idEvManifRej)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento)get_store().find_element_user(IDEVMANIFREJ$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNumEvento)get_store().add_element_user(IDEVMANIFREJ$2);
            }
            target.set(idEvManifRej);
        }
    }
    
    /**
     * Gets the "xMotivo" element
     */
    public java.lang.String getXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xMotivo" element
     */
    public void setXMotivo(java.lang.String xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XMOTIVO$4);
            }
            target.setStringValue(xMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    public void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XMOTIVO$4);
            }
            target.set(xMotivo);
        }
    }
}
