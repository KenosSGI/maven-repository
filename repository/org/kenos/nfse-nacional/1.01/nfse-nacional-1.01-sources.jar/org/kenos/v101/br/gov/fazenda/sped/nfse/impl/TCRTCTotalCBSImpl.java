/*
 * XML Type:  TCRTCTotalCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalCBSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBS
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalCBSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GCBSCREDPRES$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gCBSCredPres");
    private static final javax.xml.namespace.QName VDIFCBS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDifCBS");
    private static final javax.xml.namespace.QName VCBS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCBS");
    
    
    /**
     * Gets the "gCBSCredPres" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres getGCBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres)get_store().find_element_user(GCBSCREDPRES$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gCBSCredPres" element
     */
    public boolean isSetGCBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GCBSCREDPRES$0) != 0;
        }
    }
    
    /**
     * Sets the "gCBSCredPres" element
     */
    public void setGCBSCredPres(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres gcbsCredPres)
    {
        generatedSetterHelperImpl(gcbsCredPres, GCBSCREDPRES$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gCBSCredPres" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres addNewGCBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCBSCredPres)get_store().add_element_user(GCBSCREDPRES$0);
            return target;
        }
    }
    
    /**
     * Unsets the "gCBSCredPres" element
     */
    public void unsetGCBSCredPres()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GCBSCREDPRES$0, 0);
        }
    }
    
    /**
     * Gets the "vDifCBS" element
     */
    public java.lang.String getVDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFCBS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDifCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFCBS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDifCBS" element
     */
    public boolean isSetVDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDIFCBS$2) != 0;
        }
    }
    
    /**
     * Sets the "vDifCBS" element
     */
    public void setVDifCBS(java.lang.String vDifCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFCBS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDIFCBS$2);
            }
            target.setStringValue(vDifCBS);
        }
    }
    
    /**
     * Sets (as xml) the "vDifCBS" element
     */
    public void xsetVDifCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDifCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFCBS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDIFCBS$2);
            }
            target.set(vDifCBS);
        }
    }
    
    /**
     * Unsets the "vDifCBS" element
     */
    public void unsetVDifCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDIFCBS$2, 0);
        }
    }
    
    /**
     * Gets the "vCBS" element
     */
    public java.lang.String getVCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCBS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCBS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vCBS" element
     */
    public void setVCBS(java.lang.String vcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCBS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCBS$4);
            }
            target.setStringValue(vcbs);
        }
    }
    
    /**
     * Sets (as xml) the "vCBS" element
     */
    public void xsetVCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCBS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCBS$4);
            }
            target.set(vcbs);
        }
    }
}
