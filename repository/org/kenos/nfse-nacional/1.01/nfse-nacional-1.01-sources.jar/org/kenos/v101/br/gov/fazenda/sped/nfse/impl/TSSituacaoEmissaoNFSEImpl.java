/*
 * XML Type:  TSSituacaoEmissaoNFSE
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSSituacaoEmissaoNFSE(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.
 */
public class TSSituacaoEmissaoNFSEImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE
{
    private static final long serialVersionUID = 1L;
    
    public TSSituacaoEmissaoNFSEImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSSituacaoEmissaoNFSEImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
