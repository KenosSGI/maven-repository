/*
 * XML Type:  TCInfoCompl
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfoCompl(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfoComplImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl
{
    private static final long serialVersionUID = 1L;
    
    public TCInfoComplImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDDOCTEC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "idDocTec");
    private static final javax.xml.namespace.QName DOCREF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "docRef");
    private static final javax.xml.namespace.QName XPED$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xPed");
    private static final javax.xml.namespace.QName GITEMPED$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "gItemPed");
    private static final javax.xml.namespace.QName XINFCOMP$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xInfComp");
    
    
    /**
     * Gets the "idDocTec" element
     */
    public java.lang.String getIdDocTec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCTEC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "idDocTec" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT xgetIdDocTec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT)get_store().find_element_user(IDDOCTEC$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "idDocTec" element
     */
    public boolean isSetIdDocTec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDDOCTEC$0) != 0;
        }
    }
    
    /**
     * Sets the "idDocTec" element
     */
    public void setIdDocTec(java.lang.String idDocTec)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(IDDOCTEC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(IDDOCTEC$0);
            }
            target.setStringValue(idDocTec);
        }
    }
    
    /**
     * Sets (as xml) the "idDocTec" element
     */
    public void xsetIdDocTec(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT idDocTec)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT)get_store().find_element_user(IDDOCTEC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT)get_store().add_element_user(IDDOCTEC$0);
            }
            target.set(idDocTec);
        }
    }
    
    /**
     * Unsets the "idDocTec" element
     */
    public void unsetIdDocTec()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDDOCTEC$0, 0);
        }
    }
    
    /**
     * Gets the "docRef" element
     */
    public java.lang.String getDocRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCREF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "docRef" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetDocRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(DOCREF$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "docRef" element
     */
    public boolean isSetDocRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DOCREF$2) != 0;
        }
    }
    
    /**
     * Sets the "docRef" element
     */
    public void setDocRef(java.lang.String docRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DOCREF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DOCREF$2);
            }
            target.setStringValue(docRef);
        }
    }
    
    /**
     * Sets (as xml) the "docRef" element
     */
    public void xsetDocRef(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 docRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(DOCREF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(DOCREF$2);
            }
            target.set(docRef);
        }
    }
    
    /**
     * Unsets the "docRef" element
     */
    public void unsetDocRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DOCREF$2, 0);
        }
    }
    
    /**
     * Gets the "xPed" element
     */
    public java.lang.String getXPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XPED$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetXPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(XPED$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "xPed" element
     */
    public boolean isSetXPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XPED$4) != 0;
        }
    }
    
    /**
     * Sets the "xPed" element
     */
    public void setXPed(java.lang.String xPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XPED$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XPED$4);
            }
            target.setStringValue(xPed);
        }
    }
    
    /**
     * Sets (as xml) the "xPed" element
     */
    public void xsetXPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xPed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(XPED$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().add_element_user(XPED$4);
            }
            target.set(xPed);
        }
    }
    
    /**
     * Unsets the "xPed" element
     */
    public void unsetXPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XPED$4, 0);
        }
    }
    
    /**
     * Gets the "gItemPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed getGItemPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed)get_store().find_element_user(GITEMPED$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gItemPed" element
     */
    public boolean isSetGItemPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GITEMPED$6) != 0;
        }
    }
    
    /**
     * Sets the "gItemPed" element
     */
    public void setGItemPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed gItemPed)
    {
        generatedSetterHelperImpl(gItemPed, GITEMPED$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "gItemPed" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed addNewGItemPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed)get_store().add_element_user(GITEMPED$6);
            return target;
        }
    }
    
    /**
     * Unsets the "gItemPed" element
     */
    public void unsetGItemPed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GITEMPED$6, 0);
        }
    }
    
    /**
     * Gets the "xInfComp" element
     */
    public java.lang.String getXInfComp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XINFCOMP$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xInfComp" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl xgetXInfComp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl)get_store().find_element_user(XINFCOMP$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "xInfComp" element
     */
    public boolean isSetXInfComp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XINFCOMP$8) != 0;
        }
    }
    
    /**
     * Sets the "xInfComp" element
     */
    public void setXInfComp(java.lang.String xInfComp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XINFCOMP$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XINFCOMP$8);
            }
            target.setStringValue(xInfComp);
        }
    }
    
    /**
     * Sets (as xml) the "xInfComp" element
     */
    public void xsetXInfComp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl xInfComp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl)get_store().find_element_user(XINFCOMP$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl)get_store().add_element_user(XINFCOMP$8);
            }
            target.set(xInfComp);
        }
    }
    
    /**
     * Unsets the "xInfComp" element
     */
    public void unsetXInfComp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XINFCOMP$8, 0);
        }
    }
}
