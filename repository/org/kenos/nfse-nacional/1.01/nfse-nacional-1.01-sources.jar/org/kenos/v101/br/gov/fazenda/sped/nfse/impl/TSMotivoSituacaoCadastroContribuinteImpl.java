/*
 * XML Type:  TSMotivoSituacaoCadastroContribuinte
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TSMotivoSituacaoCadastroContribuinte(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte.
 */
public class TSMotivoSituacaoCadastroContribuinteImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte
{
    private static final long serialVersionUID = 1L;
    
    public TSMotivoSituacaoCadastroContribuinteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TSMotivoSituacaoCadastroContribuinteImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
