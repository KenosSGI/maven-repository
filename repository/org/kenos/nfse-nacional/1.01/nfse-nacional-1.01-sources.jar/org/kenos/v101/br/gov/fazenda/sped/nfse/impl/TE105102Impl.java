/*
 * XML Type:  TE105102
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TE105102(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TE105102Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102
{
    private static final long serialVersionUID = 1L;
    
    public TE105102Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XDESC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDesc");
    private static final javax.xml.namespace.QName CMOTIVO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMotivo");
    private static final javax.xml.namespace.QName XMOTIVO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xMotivo");
    private static final javax.xml.namespace.QName CHSUBSTITUTA$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chSubstituta");
    
    
    /**
     * Gets the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc.Enum getXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc xgetXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc)get_store().find_element_user(XDESC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDesc" element
     */
    public void setXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc.Enum xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESC$0);
            }
            target.setEnumValue(xDesc);
        }
    }
    
    /**
     * Sets (as xml) the "xDesc" element
     */
    public void xsetXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc)get_store().add_element_user(XDESC$0);
            }
            target.set(xDesc);
        }
    }
    
    /**
     * Gets the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum getCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst xgetCMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().find_element_user(CMOTIVO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cMotivo" element
     */
    public void setCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst.Enum cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMOTIVO$2);
            }
            target.setEnumValue(cMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "cMotivo" element
     */
    public void xsetCMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst cMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().find_element_user(CMOTIVO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodJustSubst)get_store().add_element_user(CMOTIVO$2);
            }
            target.set(cMotivo);
        }
    }
    
    /**
     * Gets the "xMotivo" element
     */
    public java.lang.String getXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xMotivo" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xgetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "xMotivo" element
     */
    public boolean isSetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XMOTIVO$4) != 0;
        }
    }
    
    /**
     * Sets the "xMotivo" element
     */
    public void setXMotivo(java.lang.String xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XMOTIVO$4);
            }
            target.setStringValue(xMotivo);
        }
    }
    
    /**
     * Sets (as xml) the "xMotivo" element
     */
    public void xsetXMotivo(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo xMotivo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().find_element_user(XMOTIVO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivo)get_store().add_element_user(XMOTIVO$4);
            }
            target.set(xMotivo);
        }
    }
    
    /**
     * Unsets the "xMotivo" element
     */
    public void unsetXMotivo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XMOTIVO$4, 0);
        }
    }
    
    /**
     * Gets the "chSubstituta" element
     */
    public java.lang.String getChSubstituta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHSUBSTITUTA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chSubstituta" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChSubstituta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHSUBSTITUTA$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "chSubstituta" element
     */
    public void setChSubstituta(java.lang.String chSubstituta)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHSUBSTITUTA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHSUBSTITUTA$6);
            }
            target.setStringValue(chSubstituta);
        }
    }
    
    /**
     * Sets (as xml) the "chSubstituta" element
     */
    public void xsetChSubstituta(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chSubstituta)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHSUBSTITUTA$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(CHSUBSTITUTA$6);
            }
            target.set(chSubstituta);
        }
    }
    /**
     * An XML xDesc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102$XDesc.
     */
    public static class XDescImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE105102.XDesc
    {
        private static final long serialVersionUID = 1L;
        
        public XDescImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected XDescImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
}
