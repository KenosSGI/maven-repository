/*
 * XML Type:  TCEnderObraEvento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCEnderObraEvento(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCEnderObraEventoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderObraEvento
{
    private static final long serialVersionUID = 1L;
    
    public TCEnderObraEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CEP$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "CEP");
    private static final javax.xml.namespace.QName ENDEXT$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "endExt");
    private static final javax.xml.namespace.QName XLGR$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLgr");
    private static final javax.xml.namespace.QName NRO$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nro");
    private static final javax.xml.namespace.QName XCPL$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xCpl");
    private static final javax.xml.namespace.QName XBAIRRO$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xBairro");
    
    
    /**
     * Gets the "CEP" element
     */
    public java.lang.String getCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CEP" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP xgetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CEP" element
     */
    public boolean isSetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$0) != 0;
        }
    }
    
    /**
     * Sets the "CEP" element
     */
    public void setCEP(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$0);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "CEP" element
     */
    public void xsetCEP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().find_element_user(CEP$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP)get_store().add_element_user(CEP$0);
            }
            target.set(cep);
        }
    }
    
    /**
     * Unsets the "CEP" element
     */
    public void unsetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$0, 0);
        }
    }
    
    /**
     * Gets the "endExt" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples getEndExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples)get_store().find_element_user(ENDEXT$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "endExt" element
     */
    public boolean isSetEndExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENDEXT$2) != 0;
        }
    }
    
    /**
     * Sets the "endExt" element
     */
    public void setEndExt(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples endExt)
    {
        generatedSetterHelperImpl(endExt, ENDEXT$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "endExt" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples addNewEndExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderExtSimples)get_store().add_element_user(ENDEXT$2);
            return target;
        }
    }
    
    /**
     * Unsets the "endExt" element
     */
    public void unsetEndExt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENDEXT$2, 0);
        }
    }
    
    /**
     * Gets the "xLgr" element
     */
    public java.lang.String getXLgr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLGR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLgr" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro xgetXLgr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().find_element_user(XLGR$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xLgr" element
     */
    public void setXLgr(java.lang.String xLgr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLGR$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLGR$4);
            }
            target.setStringValue(xLgr);
        }
    }
    
    /**
     * Sets (as xml) the "xLgr" element
     */
    public void xsetXLgr(org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro xLgr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().find_element_user(XLGR$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSLogradouro)get_store().add_element_user(XLGR$4);
            }
            target.set(xLgr);
        }
    }
    
    /**
     * Gets the "nro" element
     */
    public java.lang.String getNro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetNro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(NRO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nro" element
     */
    public void setNro(java.lang.String nro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NRO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NRO$6);
            }
            target.setStringValue(nro);
        }
    }
    
    /**
     * Sets (as xml) the "nro" element
     */
    public void xsetNro(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco nro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().find_element_user(NRO$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco)get_store().add_element_user(NRO$6);
            }
            target.set(nro);
        }
    }
    
    /**
     * Gets the "xCpl" element
     */
    public java.lang.String getXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCPL$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xCpl" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xgetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().find_element_user(XCPL$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "xCpl" element
     */
    public boolean isSetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XCPL$8) != 0;
        }
    }
    
    /**
     * Sets the "xCpl" element
     */
    public void setXCpl(java.lang.String xCpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XCPL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XCPL$8);
            }
            target.setStringValue(xCpl);
        }
    }
    
    /**
     * Sets (as xml) the "xCpl" element
     */
    public void xsetXCpl(org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xCpl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().find_element_user(XCPL$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco)get_store().add_element_user(XCPL$8);
            }
            target.set(xCpl);
        }
    }
    
    /**
     * Unsets the "xCpl" element
     */
    public void unsetXCpl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XCPL$8, 0);
        }
    }
    
    /**
     * Gets the "xBairro" element
     */
    public java.lang.String getXBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XBAIRRO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xBairro" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro xgetXBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().find_element_user(XBAIRRO$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xBairro" element
     */
    public void setXBairro(java.lang.String xBairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XBAIRRO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XBAIRRO$10);
            }
            target.setStringValue(xBairro);
        }
    }
    
    /**
     * Sets (as xml) the "xBairro" element
     */
    public void xsetXBairro(org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro xBairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().find_element_user(XBAIRRO$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSBairro)get_store().add_element_user(XBAIRRO$10);
            }
            target.set(xBairro);
        }
    }
}
