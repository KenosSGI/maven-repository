/*
 * XML Type:  TCRTCTotalIBSMun
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalIBSMun(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalIBSMunImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSMun
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalIBSMunImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VDIFMUN$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDifMun");
    private static final javax.xml.namespace.QName VIBSMUN$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vIBSMun");
    
    
    /**
     * Gets the "vDifMun" element
     */
    public java.lang.String getVDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFMUN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDifMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFMUN$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDifMun" element
     */
    public boolean isSetVDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDIFMUN$0) != 0;
        }
    }
    
    /**
     * Sets the "vDifMun" element
     */
    public void setVDifMun(java.lang.String vDifMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFMUN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDIFMUN$0);
            }
            target.setStringValue(vDifMun);
        }
    }
    
    /**
     * Sets (as xml) the "vDifMun" element
     */
    public void xsetVDifMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDifMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFMUN$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDIFMUN$0);
            }
            target.set(vDifMun);
        }
    }
    
    /**
     * Unsets the "vDifMun" element
     */
    public void unsetVDifMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDIFMUN$0, 0);
        }
    }
    
    /**
     * Gets the "vIBSMun" element
     */
    public java.lang.String getVIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSMUN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vIBSMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVIBSMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSMUN$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vIBSMun" element
     */
    public void setVIBSMun(java.lang.String vibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSMUN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VIBSMUN$2);
            }
            target.setStringValue(vibsMun);
        }
    }
    
    /**
     * Sets (as xml) the "vIBSMun" element
     */
    public void xsetVIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vibsMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSMUN$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VIBSMUN$2);
            }
            target.set(vibsMun);
        }
    }
}
