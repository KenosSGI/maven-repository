/*
 * XML Type:  TCRTCTotalIBSUF
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCTotalIBSUF(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCTotalIBSUFImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalIBSUF
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCTotalIBSUFImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VDIFUF$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vDifUF");
    private static final javax.xml.namespace.QName VIBSUF$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vIBSUF");
    
    
    /**
     * Gets the "vDifUF" element
     */
    public java.lang.String getVDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFUF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vDifUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFUF$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "vDifUF" element
     */
    public boolean isSetVDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VDIFUF$0) != 0;
        }
    }
    
    /**
     * Sets the "vDifUF" element
     */
    public void setVDifUF(java.lang.String vDifUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VDIFUF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VDIFUF$0);
            }
            target.setStringValue(vDifUF);
        }
    }
    
    /**
     * Sets (as xml) the "vDifUF" element
     */
    public void xsetVDifUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vDifUF)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VDIFUF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VDIFUF$0);
            }
            target.set(vDifUF);
        }
    }
    
    /**
     * Unsets the "vDifUF" element
     */
    public void unsetVDifUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VDIFUF$0, 0);
        }
    }
    
    /**
     * Gets the "vIBSUF" element
     */
    public java.lang.String getVIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vIBSUF" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVIBSUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSUF$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vIBSUF" element
     */
    public void setVIBSUF(java.lang.String vibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VIBSUF$2);
            }
            target.setStringValue(vibsuf);
        }
    }
    
    /**
     * Sets (as xml) the "vIBSUF" element
     */
    public void xsetVIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vibsuf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VIBSUF$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VIBSUF$2);
            }
            target.set(vibsuf);
        }
    }
}
