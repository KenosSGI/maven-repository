/*
 * XML Type:  TCInfDPS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfDPS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfDPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS
{
    private static final long serialVersionUID = 1L;
    
    public TCInfDPSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPAMB$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpAmb");
    private static final javax.xml.namespace.QName DHEMI$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dhEmi");
    private static final javax.xml.namespace.QName VERAPLIC$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "verAplic");
    private static final javax.xml.namespace.QName SERIE$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "serie");
    private static final javax.xml.namespace.QName NDPS$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDPS");
    private static final javax.xml.namespace.QName DCOMPET$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dCompet");
    private static final javax.xml.namespace.QName TPEMIT$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpEmit");
    private static final javax.xml.namespace.QName CMOTIVOEMISTI$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cMotivoEmisTI");
    private static final javax.xml.namespace.QName CHNFSEREJ$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "chNFSeRej");
    private static final javax.xml.namespace.QName CLOCEMI$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cLocEmi");
    private static final javax.xml.namespace.QName SUBST$20 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "subst");
    private static final javax.xml.namespace.QName PREST$22 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "prest");
    private static final javax.xml.namespace.QName TOMA$24 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "toma");
    private static final javax.xml.namespace.QName INTERM$26 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "interm");
    private static final javax.xml.namespace.QName SERV$28 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "serv");
    private static final javax.xml.namespace.QName VALORES$30 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "valores");
    private static final javax.xml.namespace.QName IBSCBS$32 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "IBSCBS");
    private static final javax.xml.namespace.QName ID$34 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpAmb" element
     */
    public void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPAMB$0);
            }
            target.setEnumValue(tpAmb);
        }
    }
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    public void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().find_element_user(TPAMB$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente)get_store().add_element_user(TPAMB$0);
            }
            target.set(tpAmb);
        }
    }
    
    /**
     * Gets the "dhEmi" element
     */
    public java.lang.String getDhEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHEMI$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dhEmi" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHEMI$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dhEmi" element
     */
    public void setDhEmi(java.lang.String dhEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHEMI$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DHEMI$2);
            }
            target.setStringValue(dhEmi);
        }
    }
    
    /**
     * Sets (as xml) the "dhEmi" element
     */
    public void xsetDhEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHEMI$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().add_element_user(DHEMI$2);
            }
            target.set(dhEmi);
        }
    }
    
    /**
     * Gets the "verAplic" element
     */
    public java.lang.String getVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "verAplic" element
     */
    public void setVerAplic(java.lang.String verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERAPLIC$4);
            }
            target.setStringValue(verAplic);
        }
    }
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    public void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().add_element_user(VERAPLIC$4);
            }
            target.set(verAplic);
        }
    }
    
    /**
     * Gets the "serie" element
     */
    public java.lang.String getSerie()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serie" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS xgetSerie()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS)get_store().find_element_user(SERIE$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serie" element
     */
    public void setSerie(java.lang.String serie)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERIE$6);
            }
            target.setStringValue(serie);
        }
    }
    
    /**
     * Sets (as xml) the "serie" element
     */
    public void xsetSerie(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS serie)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS)get_store().find_element_user(SERIE$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS)get_store().add_element_user(SERIE$6);
            }
            target.set(serie);
        }
    }
    
    /**
     * Gets the "nDPS" element
     */
    public java.lang.String getNDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDPS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDPS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS xgetNDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS)get_store().find_element_user(NDPS$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nDPS" element
     */
    public void setNDPS(java.lang.String ndps)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDPS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDPS$8);
            }
            target.setStringValue(ndps);
        }
    }
    
    /**
     * Sets (as xml) the "nDPS" element
     */
    public void xsetNDPS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS ndps)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS)get_store().find_element_user(NDPS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS)get_store().add_element_user(NDPS$8);
            }
            target.set(ndps);
        }
    }
    
    /**
     * Gets the "dCompet" element
     */
    public java.lang.String getDCompet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DCOMPET$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dCompet" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDCompet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DCOMPET$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dCompet" element
     */
    public void setDCompet(java.lang.String dCompet)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DCOMPET$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DCOMPET$10);
            }
            target.setStringValue(dCompet);
        }
    }
    
    /**
     * Sets (as xml) the "dCompet" element
     */
    public void xsetDCompet(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dCompet)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSData target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().find_element_user(DCOMPET$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSData)get_store().add_element_user(DCOMPET$10);
            }
            target.set(dCompet);
        }
    }
    
    /**
     * Gets the "tpEmit" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS.Enum getTpEmit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPEMIT$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpEmit" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS xgetTpEmit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS)get_store().find_element_user(TPEMIT$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpEmit" element
     */
    public void setTpEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS.Enum tpEmit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPEMIT$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPEMIT$12);
            }
            target.setEnumValue(tpEmit);
        }
    }
    
    /**
     * Sets (as xml) the "tpEmit" element
     */
    public void xsetTpEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS tpEmit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS)get_store().find_element_user(TPEMIT$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS)get_store().add_element_user(TPEMIT$12);
            }
            target.set(tpEmit);
        }
    }
    
    /**
     * Gets the "cMotivoEmisTI" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI.Enum getCMotivoEmisTI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVOEMISTI$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cMotivoEmisTI" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI xgetCMotivoEmisTI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI)get_store().find_element_user(CMOTIVOEMISTI$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "cMotivoEmisTI" element
     */
    public boolean isSetCMotivoEmisTI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CMOTIVOEMISTI$14) != 0;
        }
    }
    
    /**
     * Sets the "cMotivoEmisTI" element
     */
    public void setCMotivoEmisTI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI.Enum cMotivoEmisTI)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CMOTIVOEMISTI$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CMOTIVOEMISTI$14);
            }
            target.setEnumValue(cMotivoEmisTI);
        }
    }
    
    /**
     * Sets (as xml) the "cMotivoEmisTI" element
     */
    public void xsetCMotivoEmisTI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI cMotivoEmisTI)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI)get_store().find_element_user(CMOTIVOEMISTI$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI)get_store().add_element_user(CMOTIVOEMISTI$14);
            }
            target.set(cMotivoEmisTI);
        }
    }
    
    /**
     * Unsets the "cMotivoEmisTI" element
     */
    public void unsetCMotivoEmisTI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CMOTIVOEMISTI$14, 0);
        }
    }
    
    /**
     * Gets the "chNFSeRej" element
     */
    public java.lang.String getChNFSeRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSEREJ$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "chNFSeRej" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSeRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSEREJ$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "chNFSeRej" element
     */
    public boolean isSetChNFSeRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CHNFSEREJ$16) != 0;
        }
    }
    
    /**
     * Sets the "chNFSeRej" element
     */
    public void setChNFSeRej(java.lang.String chNFSeRej)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CHNFSEREJ$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CHNFSEREJ$16);
            }
            target.setStringValue(chNFSeRej);
        }
    }
    
    /**
     * Sets (as xml) the "chNFSeRej" element
     */
    public void xsetChNFSeRej(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSeRej)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().find_element_user(CHNFSEREJ$16, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe)get_store().add_element_user(CHNFSEREJ$16);
            }
            target.set(chNFSeRej);
        }
    }
    
    /**
     * Unsets the "chNFSeRej" element
     */
    public void unsetChNFSeRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CHNFSEREJ$16, 0);
        }
    }
    
    /**
     * Gets the "cLocEmi" element
     */
    public java.lang.String getCLocEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCEMI$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cLocEmi" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCEMI$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cLocEmi" element
     */
    public void setCLocEmi(java.lang.String cLocEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCEMI$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLOCEMI$18);
            }
            target.setStringValue(cLocEmi);
        }
    }
    
    /**
     * Sets (as xml) the "cLocEmi" element
     */
    public void xsetCLocEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCEMI$18, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CLOCEMI$18);
            }
            target.set(cLocEmi);
        }
    }
    
    /**
     * Gets the "subst" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao getSubst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao)get_store().find_element_user(SUBST$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "subst" element
     */
    public boolean isSetSubst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBST$20) != 0;
        }
    }
    
    /**
     * Sets the "subst" element
     */
    public void setSubst(org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao subst)
    {
        generatedSetterHelperImpl(subst, SUBST$20, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "subst" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao addNewSubst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao)get_store().add_element_user(SUBST$20);
            return target;
        }
    }
    
    /**
     * Unsets the "subst" element
     */
    public void unsetSubst()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBST$20, 0);
        }
    }
    
    /**
     * Gets the "prest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador getPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador)get_store().find_element_user(PREST$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "prest" element
     */
    public void setPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador prest)
    {
        generatedSetterHelperImpl(prest, PREST$22, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "prest" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador addNewPrest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador)get_store().add_element_user(PREST$22);
            return target;
        }
    }
    
    /**
     * Gets the "toma" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getToma()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().find_element_user(TOMA$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "toma" element
     */
    public boolean isSetToma()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TOMA$24) != 0;
        }
    }
    
    /**
     * Sets the "toma" element
     */
    public void setToma(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa toma)
    {
        generatedSetterHelperImpl(toma, TOMA$24, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "toma" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewToma()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().add_element_user(TOMA$24);
            return target;
        }
    }
    
    /**
     * Unsets the "toma" element
     */
    public void unsetToma()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TOMA$24, 0);
        }
    }
    
    /**
     * Gets the "interm" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getInterm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().find_element_user(INTERM$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "interm" element
     */
    public boolean isSetInterm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERM$26) != 0;
        }
    }
    
    /**
     * Sets the "interm" element
     */
    public void setInterm(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa interm)
    {
        generatedSetterHelperImpl(interm, INTERM$26, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "interm" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewInterm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa)get_store().add_element_user(INTERM$26);
            return target;
        }
    }
    
    /**
     * Unsets the "interm" element
     */
    public void unsetInterm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERM$26, 0);
        }
    }
    
    /**
     * Gets the "serv" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ getServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ)get_store().find_element_user(SERV$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serv" element
     */
    public void setServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ serv)
    {
        generatedSetterHelperImpl(serv, SERV$28, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "serv" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ addNewServ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ)get_store().add_element_user(SERV$28);
            return target;
        }
    }
    
    /**
     * Gets the "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores getValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores)get_store().find_element_user(VALORES$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "valores" element
     */
    public void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores valores)
    {
        generatedSetterHelperImpl(valores, VALORES$30, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores addNewValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores)get_store().add_element_user(VALORES$30);
            return target;
        }
    }
    
    /**
     * Gets the "IBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS getIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS)get_store().find_element_user(IBSCBS$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "IBSCBS" element
     */
    public boolean isSetIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IBSCBS$32) != 0;
        }
    }
    
    /**
     * Sets the "IBSCBS" element
     */
    public void setIBSCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS ibscbs)
    {
        generatedSetterHelperImpl(ibscbs, IBSCBS$32, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS addNewIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS)get_store().add_element_user(IBSCBS$32);
            return target;
        }
    }
    
    /**
     * Unsets the "IBSCBS" element
     */
    public void unsetIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IBSCBS$32, 0);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$34);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS)get_store().find_attribute_user(ID$34);
            return target;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$34);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$34);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS)get_store().find_attribute_user(ID$34);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS)get_store().add_attribute_user(ID$34);
            }
            target.set(id);
        }
    }
}
