/*
 * XML Type:  TCRTCValoresIBSCBSFed
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCValoresIBSCBSFed(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCValoresIBSCBSFedImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBSFed
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCValoresIBSCBSFedImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PCBS$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pCBS");
    private static final javax.xml.namespace.QName PREDALIQCBS$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pRedAliqCBS");
    private static final javax.xml.namespace.QName PALIQEFETCBS$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqEfetCBS");
    
    
    /**
     * Gets the "pCBS" element
     */
    public java.lang.String getPCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCBS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCBS$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pCBS" element
     */
    public void setPCBS(java.lang.String pcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PCBS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PCBS$0);
            }
            target.setStringValue(pcbs);
        }
    }
    
    /**
     * Sets (as xml) the "pCBS" element
     */
    public void xsetPCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pcbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PCBS$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PCBS$0);
            }
            target.set(pcbs);
        }
    }
    
    /**
     * Gets the "pRedAliqCBS" element
     */
    public java.lang.String getPRedAliqCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQCBS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pRedAliqCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 xgetPRedAliqCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQCBS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "pRedAliqCBS" element
     */
    public boolean isSetPRedAliqCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PREDALIQCBS$2) != 0;
        }
    }
    
    /**
     * Sets the "pRedAliqCBS" element
     */
    public void setPRedAliqCBS(java.lang.String pRedAliqCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PREDALIQCBS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PREDALIQCBS$2);
            }
            target.setStringValue(pRedAliqCBS);
        }
    }
    
    /**
     * Sets (as xml) the "pRedAliqCBS" element
     */
    public void xsetPRedAliqCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 pRedAliqCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().find_element_user(PREDALIQCBS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec3V2)get_store().add_element_user(PREDALIQCBS$2);
            }
            target.set(pRedAliqCBS);
        }
    }
    
    /**
     * Unsets the "pRedAliqCBS" element
     */
    public void unsetPRedAliqCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PREDALIQCBS$2, 0);
        }
    }
    
    /**
     * Gets the "pAliqEfetCBS" element
     */
    public java.lang.String getPAliqEfetCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETCBS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqEfetCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfetCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETCBS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pAliqEfetCBS" element
     */
    public void setPAliqEfetCBS(java.lang.String pAliqEfetCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQEFETCBS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQEFETCBS$4);
            }
            target.setStringValue(pAliqEfetCBS);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqEfetCBS" element
     */
    public void xsetPAliqEfetCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfetCBS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().find_element_user(PALIQEFETCBS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2)get_store().add_element_user(PALIQEFETCBS$4);
            }
            target.set(pAliqEfetCBS);
        }
    }
}
