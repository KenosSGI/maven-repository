/*
 * XML Type:  TCRTCInfoTributosTribRegular
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCInfoTributosTribRegular(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCInfoTributosTribRegular extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCInfoTributosTribRegular.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcrtcinfotributostribregular348btype");
    
    /**
     * Gets the "CSTReg" element
     */
    java.lang.String getCSTReg();
    
    /**
     * Gets (as xml) the "CSTReg" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib xgetCSTReg();
    
    /**
     * Sets the "CSTReg" element
     */
    void setCSTReg(java.lang.String cstReg);
    
    /**
     * Sets (as xml) the "CSTReg" element
     */
    void xsetCSTReg(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodSitTrib cstReg);
    
    /**
     * Gets the "cClassTribReg" element
     */
    java.lang.String getCClassTribReg();
    
    /**
     * Gets (as xml) the "cClassTribReg" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib xgetCClassTribReg();
    
    /**
     * Sets the "cClassTribReg" element
     */
    void setCClassTribReg(java.lang.String cClassTribReg);
    
    /**
     * Sets (as xml) the "cClassTribReg" element
     */
    void xsetCClassTribReg(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCCodClassTrib cClassTribReg);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoTributosTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
