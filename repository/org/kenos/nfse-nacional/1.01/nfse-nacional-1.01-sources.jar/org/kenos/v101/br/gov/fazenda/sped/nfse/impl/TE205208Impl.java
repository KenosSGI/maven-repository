/*
 * XML Type:  TE205208
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TE205208(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TE205208Impl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208
{
    private static final long serialVersionUID = 1L;
    
    public TE205208Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XDESC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDesc");
    private static final javax.xml.namespace.QName INFANREJ$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "infAnRej");
    
    
    /**
     * Gets the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc.Enum getXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDesc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc xgetXDesc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc)get_store().find_element_user(XDESC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDesc" element
     */
    public void setXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc.Enum xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDESC$0);
            }
            target.setEnumValue(xDesc);
        }
    }
    
    /**
     * Sets (as xml) the "xDesc" element
     */
    public void xsetXDesc(org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc xDesc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc)get_store().find_element_user(XDESC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc)get_store().add_element_user(XDESC$0);
            }
            target.set(xDesc);
        }
    }
    
    /**
     * Gets the "infAnRej" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao getInfAnRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao)get_store().find_element_user(INFANREJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "infAnRej" element
     */
    public void setInfAnRej(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao infAnRej)
    {
        generatedSetterHelperImpl(infAnRej, INFANREJ$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "infAnRej" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao addNewInfAnRej()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoEventoAnulacaoRejeicao)get_store().add_element_user(INFANREJ$2);
            return target;
        }
    }
    /**
     * An XML xDesc(@http://www.sped.fazenda.gov.br/nfse).
     *
     * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208$XDesc.
     */
    public static class XDescImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v101.br.gov.fazenda.sped.nfse.TE205208.XDesc
    {
        private static final long serialVersionUID = 1L;
        
        public XDescImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected XDescImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
}
