/*
 * XML Type:  TCInfoContribuinteCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfoContribuinteCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfoContribuinteCNC extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfoContribuinteCNC.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcinfocontribuintecnce797type");
    
    /**
     * Gets the "CNPJ" element
     */
    java.lang.String getCNPJ();
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ xgetCNPJ();
    
    /**
     * True if has "CNPJ" element
     */
    boolean isSetCNPJ();
    
    /**
     * Sets the "CNPJ" element
     */
    void setCNPJ(java.lang.String cnpj);
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    void xsetCNPJ(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCNPJ cnpj);
    
    /**
     * Unsets the "CNPJ" element
     */
    void unsetCNPJ();
    
    /**
     * Gets the "CPF" element
     */
    java.lang.String getCPF();
    
    /**
     * Gets (as xml) the "CPF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF xgetCPF();
    
    /**
     * True if has "CPF" element
     */
    boolean isSetCPF();
    
    /**
     * Sets the "CPF" element
     */
    void setCPF(java.lang.String cpf);
    
    /**
     * Sets (as xml) the "CPF" element
     */
    void xsetCPF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCPF cpf);
    
    /**
     * Unsets the "CPF" element
     */
    void unsetCPF();
    
    /**
     * Gets the "IM" element
     */
    java.lang.String getIM();
    
    /**
     * Gets (as xml) the "IM" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun xgetIM();
    
    /**
     * True if has "IM" element
     */
    boolean isSetIM();
    
    /**
     * Sets the "IM" element
     */
    void setIM(java.lang.String im);
    
    /**
     * Sets (as xml) the "IM" element
     */
    void xsetIM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSInscMun im);
    
    /**
     * Unsets the "IM" element
     */
    void unsetIM();
    
    /**
     * Gets the "dInscricaoMunicipal" element
     */
    java.lang.String getDInscricaoMunicipal();
    
    /**
     * Gets (as xml) the "dInscricaoMunicipal" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDInscricaoMunicipal();
    
    /**
     * Sets the "dInscricaoMunicipal" element
     */
    void setDInscricaoMunicipal(java.lang.String dInscricaoMunicipal);
    
    /**
     * Sets (as xml) the "dInscricaoMunicipal" element
     */
    void xsetDInscricaoMunicipal(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dInscricaoMunicipal);
    
    /**
     * Gets the "enderContribuinteCNC" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC getEnderContribuinteCNC();
    
    /**
     * Sets the "enderContribuinteCNC" element
     */
    void setEnderContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC enderContribuinteCNC);
    
    /**
     * Appends and returns a new empty "enderContribuinteCNC" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC addNewEnderContribuinteCNC();
    
    /**
     * Gets the "fone" element
     */
    java.lang.String getFone();
    
    /**
     * Gets (as xml) the "fone" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone xgetFone();
    
    /**
     * True if has "fone" element
     */
    boolean isSetFone();
    
    /**
     * Sets the "fone" element
     */
    void setFone(java.lang.String fone);
    
    /**
     * Sets (as xml) the "fone" element
     */
    void xsetFone(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTelefone fone);
    
    /**
     * Unsets the "fone" element
     */
    void unsetFone();
    
    /**
     * Gets the "email" element
     */
    java.lang.String getEmail();
    
    /**
     * Gets (as xml) the "email" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail xgetEmail();
    
    /**
     * True if has "email" element
     */
    boolean isSetEmail();
    
    /**
     * Sets the "email" element
     */
    void setEmail(java.lang.String email);
    
    /**
     * Sets (as xml) the "email" element
     */
    void xsetEmail(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmail email);
    
    /**
     * Unsets the "email" element
     */
    void unsetEmail();
    
    /**
     * Gets the "regEspTribContribuinteCNC" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum getRegEspTribContribuinteCNC();
    
    /**
     * Gets (as xml) the "regEspTribContribuinteCNC" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib xgetRegEspTribContribuinteCNC();
    
    /**
     * Sets the "regEspTribContribuinteCNC" element
     */
    void setRegEspTribContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib.Enum regEspTribContribuinteCNC);
    
    /**
     * Sets (as xml) the "regEspTribContribuinteCNC" element
     */
    void xsetRegEspTribContribuinteCNC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRegEspTrib regEspTribContribuinteCNC);
    
    /**
     * Gets the "situacaoCadastroContribuinte" element
     */
    java.lang.String getSituacaoCadastroContribuinte();
    
    /**
     * Gets (as xml) the "situacaoCadastroContribuinte" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte xgetSituacaoCadastroContribuinte();
    
    /**
     * True if has "situacaoCadastroContribuinte" element
     */
    boolean isSetSituacaoCadastroContribuinte();
    
    /**
     * Sets the "situacaoCadastroContribuinte" element
     */
    void setSituacaoCadastroContribuinte(java.lang.String situacaoCadastroContribuinte);
    
    /**
     * Sets (as xml) the "situacaoCadastroContribuinte" element
     */
    void xsetSituacaoCadastroContribuinte(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoCadastroContribuinte situacaoCadastroContribuinte);
    
    /**
     * Unsets the "situacaoCadastroContribuinte" element
     */
    void unsetSituacaoCadastroContribuinte();
    
    /**
     * Gets the "motivoSituacaoCadastroContribuinte" element
     */
    java.lang.String getMotivoSituacaoCadastroContribuinte();
    
    /**
     * Gets (as xml) the "motivoSituacaoCadastroContribuinte" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte xgetMotivoSituacaoCadastroContribuinte();
    
    /**
     * True if has "motivoSituacaoCadastroContribuinte" element
     */
    boolean isSetMotivoSituacaoCadastroContribuinte();
    
    /**
     * Sets the "motivoSituacaoCadastroContribuinte" element
     */
    void setMotivoSituacaoCadastroContribuinte(java.lang.String motivoSituacaoCadastroContribuinte);
    
    /**
     * Sets (as xml) the "motivoSituacaoCadastroContribuinte" element
     */
    void xsetMotivoSituacaoCadastroContribuinte(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoSituacaoCadastroContribuinte motivoSituacaoCadastroContribuinte);
    
    /**
     * Unsets the "motivoSituacaoCadastroContribuinte" element
     */
    void unsetMotivoSituacaoCadastroContribuinte();
    
    /**
     * Gets the "situacaoEmissaoNFSE" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.Enum getSituacaoEmissaoNFSE();
    
    /**
     * Gets (as xml) the "situacaoEmissaoNFSE" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE xgetSituacaoEmissaoNFSE();
    
    /**
     * Sets the "situacaoEmissaoNFSE" element
     */
    void setSituacaoEmissaoNFSE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE.Enum situacaoEmissaoNFSE);
    
    /**
     * Sets (as xml) the "situacaoEmissaoNFSE" element
     */
    void xsetSituacaoEmissaoNFSE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSituacaoEmissaoNFSE situacaoEmissaoNFSE);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
