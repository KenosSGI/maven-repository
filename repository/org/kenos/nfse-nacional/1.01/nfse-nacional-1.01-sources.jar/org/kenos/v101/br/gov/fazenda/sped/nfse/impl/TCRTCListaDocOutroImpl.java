/*
 * XML Type:  TCRTCListaDocOutro
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCRTCListaDocOutro(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCRTCListaDocOutroImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro
{
    private static final long serialVersionUID = 1L;
    
    public TCRTCListaDocOutroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NDOC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDoc");
    private static final javax.xml.namespace.QName XDOC$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xDoc");
    
    
    /**
     * Gets the "nDoc" element
     */
    public java.lang.String getNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDoc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetNDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nDoc" element
     */
    public void setNDoc(java.lang.String nDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDOC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDOC$0);
            }
            target.setStringValue(nDoc);
        }
    }
    
    /**
     * Sets (as xml) the "nDoc" element
     */
    public void xsetNDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 nDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(NDOC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(NDOC$0);
            }
            target.set(nDoc);
        }
    }
    
    /**
     * Gets the "xDoc" element
     */
    public java.lang.String getXDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDOC$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xDoc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetXDoc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XDOC$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xDoc" element
     */
    public void setXDoc(java.lang.String xDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XDOC$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XDOC$2);
            }
            target.setStringValue(xDoc);
        }
    }
    
    /**
     * Sets (as xml) the "xDoc" element
     */
    public void xsetXDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xDoc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().find_element_user(XDOC$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255)get_store().add_element_user(XDOC$2);
            }
            target.set(xDoc);
        }
    }
}
