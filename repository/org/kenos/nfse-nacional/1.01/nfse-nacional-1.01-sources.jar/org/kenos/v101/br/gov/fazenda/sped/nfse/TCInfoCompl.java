/*
 * XML Type:  TCInfoCompl
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfoCompl(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfoCompl extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfoCompl.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sEDA65B63842D82858582E9B33CD87F31").resolveHandle("tcinfocomple72etype");
    
    /**
     * Gets the "idDocTec" element
     */
    java.lang.String getIdDocTec();
    
    /**
     * Gets (as xml) the "idDocTec" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT xgetIdDocTec();
    
    /**
     * True if has "idDocTec" element
     */
    boolean isSetIdDocTec();
    
    /**
     * Sets the "idDocTec" element
     */
    void setIdDocTec(java.lang.String idDocTec);
    
    /**
     * Sets (as xml) the "idDocTec" element
     */
    void xsetIdDocTec(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDRT idDocTec);
    
    /**
     * Unsets the "idDocTec" element
     */
    void unsetIdDocTec();
    
    /**
     * Gets the "docRef" element
     */
    java.lang.String getDocRef();
    
    /**
     * Gets (as xml) the "docRef" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 xgetDocRef();
    
    /**
     * True if has "docRef" element
     */
    boolean isSetDocRef();
    
    /**
     * Sets the "docRef" element
     */
    void setDocRef(java.lang.String docRef);
    
    /**
     * Sets (as xml) the "docRef" element
     */
    void xsetDocRef(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc255 docRef);
    
    /**
     * Unsets the "docRef" element
     */
    void unsetDocRef();
    
    /**
     * Gets the "xPed" element
     */
    java.lang.String getXPed();
    
    /**
     * Gets (as xml) the "xPed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetXPed();
    
    /**
     * True if has "xPed" element
     */
    boolean isSetXPed();
    
    /**
     * Sets the "xPed" element
     */
    void setXPed(java.lang.String xPed);
    
    /**
     * Sets (as xml) the "xPed" element
     */
    void xsetXPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xPed);
    
    /**
     * Unsets the "xPed" element
     */
    void unsetXPed();
    
    /**
     * Gets the "gItemPed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed getGItemPed();
    
    /**
     * True if has "gItemPed" element
     */
    boolean isSetGItemPed();
    
    /**
     * Sets the "gItemPed" element
     */
    void setGItemPed(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed gItemPed);
    
    /**
     * Appends and returns a new empty "gItemPed" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoItemPed addNewGItemPed();
    
    /**
     * Unsets the "gItemPed" element
     */
    void unsetGItemPed();
    
    /**
     * Gets the "xInfComp" element
     */
    java.lang.String getXInfComp();
    
    /**
     * Gets (as xml) the "xInfComp" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl xgetXInfComp();
    
    /**
     * True if has "xInfComp" element
     */
    boolean isSetXInfComp();
    
    /**
     * Sets the "xInfComp" element
     */
    void setXInfComp(java.lang.String xInfComp);
    
    /**
     * Sets (as xml) the "xInfComp" element
     */
    void xsetXInfComp(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDescInfCompl xInfComp);
    
    /**
     * Unsets the "xInfComp" element
     */
    void unsetXInfComp();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoCompl) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
