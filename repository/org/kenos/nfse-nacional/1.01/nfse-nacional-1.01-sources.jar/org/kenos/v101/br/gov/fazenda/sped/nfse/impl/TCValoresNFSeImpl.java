/*
 * XML Type:  TCValoresNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCValoresNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCValoresNFSeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe
{
    private static final long serialVersionUID = 1L;
    
    public TCValoresNFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VCALCDR$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCalcDR");
    private static final javax.xml.namespace.QName TPBM$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpBM");
    private static final javax.xml.namespace.QName VCALCBM$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vCalcBM");
    private static final javax.xml.namespace.QName VBC$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vBC");
    private static final javax.xml.namespace.QName PALIQAPLIC$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pAliqAplic");
    private static final javax.xml.namespace.QName VISSQN$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vISSQN");
    private static final javax.xml.namespace.QName VTOTALRET$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vTotalRet");
    private static final javax.xml.namespace.QName VLIQ$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "vLiq");
    
    
    /**
     * Gets the "vCalcDR" element
     */
    public java.lang.String getVCalcDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCDR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCalcDR" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCalcDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCDR$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "vCalcDR" element
     */
    public boolean isSetVCalcDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VCALCDR$0) != 0;
        }
    }
    
    /**
     * Sets the "vCalcDR" element
     */
    public void setVCalcDR(java.lang.String vCalcDR)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCDR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCALCDR$0);
            }
            target.setStringValue(vCalcDR);
        }
    }
    
    /**
     * Sets (as xml) the "vCalcDR" element
     */
    public void xsetVCalcDR(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCalcDR)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCDR$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCALCDR$0);
            }
            target.set(vCalcDR);
        }
    }
    
    /**
     * Unsets the "vCalcDR" element
     */
    public void unsetVCalcDR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VCALCDR$0, 0);
        }
    }
    
    /**
     * Gets the "tpBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN.Enum getTpBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPBM$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN xgetTpBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN)get_store().find_element_user(TPBM$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "tpBM" element
     */
    public boolean isSetTpBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPBM$2) != 0;
        }
    }
    
    /**
     * Sets the "tpBM" element
     */
    public void setTpBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN.Enum tpBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPBM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPBM$2);
            }
            target.setEnumValue(tpBM);
        }
    }
    
    /**
     * Sets (as xml) the "tpBM" element
     */
    public void xsetTpBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN tpBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN)get_store().find_element_user(TPBM$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TBMISSQN)get_store().add_element_user(TPBM$2);
            }
            target.set(tpBM);
        }
    }
    
    /**
     * Unsets the "tpBM" element
     */
    public void unsetTpBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPBM$2, 0);
        }
    }
    
    /**
     * Gets the "vCalcBM" element
     */
    public java.lang.String getVCalcBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCBM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vCalcBM" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVCalcBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCBM$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "vCalcBM" element
     */
    public boolean isSetVCalcBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VCALCBM$4) != 0;
        }
    }
    
    /**
     * Sets the "vCalcBM" element
     */
    public void setVCalcBM(java.lang.String vCalcBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VCALCBM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VCALCBM$4);
            }
            target.setStringValue(vCalcBM);
        }
    }
    
    /**
     * Sets (as xml) the "vCalcBM" element
     */
    public void xsetVCalcBM(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vCalcBM)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VCALCBM$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VCALCBM$4);
            }
            target.set(vCalcBM);
        }
    }
    
    /**
     * Unsets the "vCalcBM" element
     */
    public void unsetVCalcBM()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VCALCBM$4, 0);
        }
    }
    
    /**
     * Gets the "vBC" element
     */
    public java.lang.String getVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBC$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vBC" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBC$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "vBC" element
     */
    public boolean isSetVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VBC$6) != 0;
        }
    }
    
    /**
     * Sets the "vBC" element
     */
    public void setVBC(java.lang.String vbc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VBC$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VBC$6);
            }
            target.setStringValue(vbc);
        }
    }
    
    /**
     * Sets (as xml) the "vBC" element
     */
    public void xsetVBC(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vbc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VBC$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VBC$6);
            }
            target.set(vbc);
        }
    }
    
    /**
     * Unsets the "vBC" element
     */
    public void unsetVBC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VBC$6, 0);
        }
    }
    
    /**
     * Gets the "pAliqAplic" element
     */
    public java.lang.String getPAliqAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQAPLIC$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pAliqAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 xgetPAliqAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().find_element_user(PALIQAPLIC$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "pAliqAplic" element
     */
    public boolean isSetPAliqAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PALIQAPLIC$8) != 0;
        }
    }
    
    /**
     * Sets the "pAliqAplic" element
     */
    public void setPAliqAplic(java.lang.String pAliqAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PALIQAPLIC$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PALIQAPLIC$8);
            }
            target.setStringValue(pAliqAplic);
        }
    }
    
    /**
     * Sets (as xml) the "pAliqAplic" element
     */
    public void xsetPAliqAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 pAliqAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().find_element_user(PALIQAPLIC$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec1V2)get_store().add_element_user(PALIQAPLIC$8);
            }
            target.set(pAliqAplic);
        }
    }
    
    /**
     * Unsets the "pAliqAplic" element
     */
    public void unsetPAliqAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PALIQAPLIC$8, 0);
        }
    }
    
    /**
     * Gets the "vISSQN" element
     */
    public java.lang.String getVISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VISSQN$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vISSQN" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VISSQN$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "vISSQN" element
     */
    public boolean isSetVISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VISSQN$10) != 0;
        }
    }
    
    /**
     * Sets the "vISSQN" element
     */
    public void setVISSQN(java.lang.String vissqn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VISSQN$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VISSQN$10);
            }
            target.setStringValue(vissqn);
        }
    }
    
    /**
     * Sets (as xml) the "vISSQN" element
     */
    public void xsetVISSQN(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vissqn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VISSQN$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VISSQN$10);
            }
            target.set(vissqn);
        }
    }
    
    /**
     * Unsets the "vISSQN" element
     */
    public void unsetVISSQN()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VISSQN$10, 0);
        }
    }
    
    /**
     * Gets the "vTotalRet" element
     */
    public java.lang.String getVTotalRet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTALRET$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vTotalRet" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTotalRet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTALRET$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "vTotalRet" element
     */
    public boolean isSetVTotalRet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VTOTALRET$12) != 0;
        }
    }
    
    /**
     * Sets the "vTotalRet" element
     */
    public void setVTotalRet(java.lang.String vTotalRet)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VTOTALRET$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VTOTALRET$12);
            }
            target.setStringValue(vTotalRet);
        }
    }
    
    /**
     * Sets (as xml) the "vTotalRet" element
     */
    public void xsetVTotalRet(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTotalRet)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VTOTALRET$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VTOTALRET$12);
            }
            target.set(vTotalRet);
        }
    }
    
    /**
     * Unsets the "vTotalRet" element
     */
    public void unsetVTotalRet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VTOTALRET$12, 0);
        }
    }
    
    /**
     * Gets the "vLiq" element
     */
    public java.lang.String getVLiq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VLIQ$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vLiq" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVLiq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VLIQ$14, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vLiq" element
     */
    public void setVLiq(java.lang.String vLiq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VLIQ$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VLIQ$14);
            }
            target.setStringValue(vLiq);
        }
    }
    
    /**
     * Sets (as xml) the "vLiq" element
     */
    public void xsetVLiq(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vLiq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().find_element_user(VLIQ$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2)get_store().add_element_user(VLIQ$14);
            }
            target.set(vLiq);
        }
    }
}
