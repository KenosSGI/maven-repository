/*
 * XML Type:  TCRTCIBSCBS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCIBSCBS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCIBSCBS extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCIBSCBS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcrtcibscbs22datype");
    
    /**
     * Gets the "cLocalidadeIncid" element
     */
    java.lang.String getCLocalidadeIncid();
    
    /**
     * Gets (as xml) the "cLocalidadeIncid" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocalidadeIncid();
    
    /**
     * Sets the "cLocalidadeIncid" element
     */
    void setCLocalidadeIncid(java.lang.String cLocalidadeIncid);
    
    /**
     * Sets (as xml) the "cLocalidadeIncid" element
     */
    void xsetCLocalidadeIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocalidadeIncid);
    
    /**
     * Gets the "xLocalidadeIncid" element
     */
    java.lang.String getXLocalidadeIncid();
    
    /**
     * Gets (as xml) the "xLocalidadeIncid" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXLocalidadeIncid();
    
    /**
     * Sets the "xLocalidadeIncid" element
     */
    void setXLocalidadeIncid(java.lang.String xLocalidadeIncid);
    
    /**
     * Sets (as xml) the "xLocalidadeIncid" element
     */
    void xsetXLocalidadeIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xLocalidadeIncid);
    
    /**
     * Gets the "pRedutor" element
     */
    java.lang.String getPRedutor();
    
    /**
     * Gets (as xml) the "pRedutor" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPRedutor();
    
    /**
     * True if has "pRedutor" element
     */
    boolean isSetPRedutor();
    
    /**
     * Sets the "pRedutor" element
     */
    void setPRedutor(java.lang.String pRedutor);
    
    /**
     * Sets (as xml) the "pRedutor" element
     */
    void xsetPRedutor(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pRedutor);
    
    /**
     * Unsets the "pRedutor" element
     */
    void unsetPRedutor();
    
    /**
     * Gets the "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS getValores();
    
    /**
     * Sets the "valores" element
     */
    void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS valores);
    
    /**
     * Appends and returns a new empty "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCValoresIBSCBS addNewValores();
    
    /**
     * Gets the "totCIBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS getTotCIBS();
    
    /**
     * Sets the "totCIBS" element
     */
    void setTotCIBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS totCIBS);
    
    /**
     * Appends and returns a new empty "totCIBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalCIBS addNewTotCIBS();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
