/*
 * XML Type:  TCEnderContribuinteCNC
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCEnderContribuinteCNC(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCEnderContribuinteCNC extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCEnderContribuinteCNC.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcendercontribuintecncdbadtype");
    
    /**
     * Gets the "CEP" element
     */
    java.lang.String getCEP();
    
    /**
     * Gets (as xml) the "CEP" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP xgetCEP();
    
    /**
     * Sets the "CEP" element
     */
    void setCEP(java.lang.String cep);
    
    /**
     * Sets (as xml) the "CEP" element
     */
    void xsetCEP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCEP cep);
    
    /**
     * Gets the "nro" element
     */
    java.lang.String getNro();
    
    /**
     * Gets (as xml) the "nro" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco xgetNro();
    
    /**
     * Sets the "nro" element
     */
    void setNro(java.lang.String nro);
    
    /**
     * Sets (as xml) the "nro" element
     */
    void xsetNro(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumeroEndereco nro);
    
    /**
     * Gets the "xCpl" element
     */
    java.lang.String getXCpl();
    
    /**
     * Gets (as xml) the "xCpl" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xgetXCpl();
    
    /**
     * True if has "xCpl" element
     */
    boolean isSetXCpl();
    
    /**
     * Sets the "xCpl" element
     */
    void setXCpl(java.lang.String xCpl);
    
    /**
     * Sets (as xml) the "xCpl" element
     */
    void xsetXCpl(org.kenos.v101.br.gov.fazenda.sped.nfse.TSComplementoEndereco xCpl);
    
    /**
     * Unsets the "xCpl" element
     */
    void unsetXCpl();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEnderContribuinteCNC) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
