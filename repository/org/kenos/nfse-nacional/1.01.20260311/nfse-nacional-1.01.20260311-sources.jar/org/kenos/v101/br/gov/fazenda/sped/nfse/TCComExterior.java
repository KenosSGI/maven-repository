/*
 * XML Type:  TCComExterior
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCComExterior(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCComExterior extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCComExterior.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tccomexterior295etype");
    
    /**
     * Gets the "mdPrestacao" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao.Enum getMdPrestacao();
    
    /**
     * Gets (as xml) the "mdPrestacao" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao xgetMdPrestacao();
    
    /**
     * Sets the "mdPrestacao" element
     */
    void setMdPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao.Enum mdPrestacao);
    
    /**
     * Sets (as xml) the "mdPrestacao" element
     */
    void xsetMdPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSModoPrestacao mdPrestacao);
    
    /**
     * Gets the "vincPrest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest.Enum getVincPrest();
    
    /**
     * Gets (as xml) the "vincPrest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest xgetVincPrest();
    
    /**
     * Sets the "vincPrest" element
     */
    void setVincPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest.Enum vincPrest);
    
    /**
     * Sets (as xml) the "vincPrest" element
     */
    void xsetVincPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVincPrest vincPrest);
    
    /**
     * Gets the "tpMoeda" element
     */
    java.lang.String getTpMoeda();
    
    /**
     * Gets (as xml) the "tpMoeda" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda xgetTpMoeda();
    
    /**
     * Sets the "tpMoeda" element
     */
    void setTpMoeda(java.lang.String tpMoeda);
    
    /**
     * Sets (as xml) the "tpMoeda" element
     */
    void xsetTpMoeda(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMoeda tpMoeda);
    
    /**
     * Gets the "vServMoeda" element
     */
    java.lang.String getVServMoeda();
    
    /**
     * Gets (as xml) the "vServMoeda" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVServMoeda();
    
    /**
     * Sets the "vServMoeda" element
     */
    void setVServMoeda(java.lang.String vServMoeda);
    
    /**
     * Sets (as xml) the "vServMoeda" element
     */
    void xsetVServMoeda(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vServMoeda);
    
    /**
     * Gets the "mecAFComexP" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest.Enum getMecAFComexP();
    
    /**
     * Gets (as xml) the "mecAFComexP" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest xgetMecAFComexP();
    
    /**
     * Sets the "mecAFComexP" element
     */
    void setMecAFComexP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest.Enum mecAFComexP);
    
    /**
     * Sets (as xml) the "mecAFComexP" element
     */
    void xsetMecAFComexP(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExPrest mecAFComexP);
    
    /**
     * Gets the "mecAFComexT" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.Enum getMecAFComexT();
    
    /**
     * Gets (as xml) the "mecAFComexT" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma xgetMecAFComexT();
    
    /**
     * Sets the "mecAFComexT" element
     */
    void setMecAFComexT(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma.Enum mecAFComexT);
    
    /**
     * Sets (as xml) the "mecAFComexT" element
     */
    void xsetMecAFComexT(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMecAFComExToma mecAFComexT);
    
    /**
     * Gets the "movTempBens" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens.Enum getMovTempBens();
    
    /**
     * Gets (as xml) the "movTempBens" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens xgetMovTempBens();
    
    /**
     * Sets the "movTempBens" element
     */
    void setMovTempBens(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens.Enum movTempBens);
    
    /**
     * Sets (as xml) the "movTempBens" element
     */
    void xsetMovTempBens(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMovTempBens movTempBens);
    
    /**
     * Gets the "nDI" element
     */
    java.lang.String getNDI();
    
    /**
     * Gets (as xml) the "nDI" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport xgetNDI();
    
    /**
     * True if has "nDI" element
     */
    boolean isSetNDI();
    
    /**
     * Sets the "nDI" element
     */
    void setNDI(java.lang.String ndi);
    
    /**
     * Sets (as xml) the "nDI" element
     */
    void xsetNDI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDocImport ndi);
    
    /**
     * Unsets the "nDI" element
     */
    void unsetNDI();
    
    /**
     * Gets the "nRE" element
     */
    java.lang.String getNRE();
    
    /**
     * Gets (as xml) the "nRE" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport xgetNRE();
    
    /**
     * True if has "nRE" element
     */
    boolean isSetNRE();
    
    /**
     * Sets the "nRE" element
     */
    void setNRE(java.lang.String nre);
    
    /**
     * Sets (as xml) the "nRE" element
     */
    void xsetNRE(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumRegExport nre);
    
    /**
     * Unsets the "nRE" element
     */
    void unsetNRE();
    
    /**
     * Gets the "mdic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC.Enum getMdic();
    
    /**
     * Gets (as xml) the "mdic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC xgetMdic();
    
    /**
     * Sets the "mdic" element
     */
    void setMdic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC.Enum mdic);
    
    /**
     * Sets (as xml) the "mdic" element
     */
    void xsetMdic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEnvMDIC mdic);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCComExterior) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
