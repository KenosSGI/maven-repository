/*
 * XML Type:  TCInfDPS
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfDPS(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfDPS extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfDPS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcinfdpsbab5type");
    
    /**
     * Gets the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum getTpAmb();
    
    /**
     * Gets (as xml) the "tpAmb" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente xgetTpAmb();
    
    /**
     * Sets the "tpAmb" element
     */
    void setTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente.Enum tpAmb);
    
    /**
     * Sets (as xml) the "tpAmb" element
     */
    void xsetTpAmb(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoAmbiente tpAmb);
    
    /**
     * Gets the "dhEmi" element
     */
    java.lang.String getDhEmi();
    
    /**
     * Gets (as xml) the "dhEmi" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhEmi();
    
    /**
     * Sets the "dhEmi" element
     */
    void setDhEmi(java.lang.String dhEmi);
    
    /**
     * Sets (as xml) the "dhEmi" element
     */
    void xsetDhEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhEmi);
    
    /**
     * Gets the "verAplic" element
     */
    java.lang.String getVerAplic();
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic();
    
    /**
     * Sets the "verAplic" element
     */
    void setVerAplic(java.lang.String verAplic);
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic);
    
    /**
     * Gets the "serie" element
     */
    java.lang.String getSerie();
    
    /**
     * Gets (as xml) the "serie" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS xgetSerie();
    
    /**
     * Sets the "serie" element
     */
    void setSerie(java.lang.String serie);
    
    /**
     * Sets (as xml) the "serie" element
     */
    void xsetSerie(org.kenos.v101.br.gov.fazenda.sped.nfse.TSSerieDPS serie);
    
    /**
     * Gets the "nDPS" element
     */
    java.lang.String getNDPS();
    
    /**
     * Gets (as xml) the "nDPS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS xgetNDPS();
    
    /**
     * Sets the "nDPS" element
     */
    void setNDPS(java.lang.String ndps);
    
    /**
     * Sets (as xml) the "nDPS" element
     */
    void xsetNDPS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDPS ndps);
    
    /**
     * Gets the "dCompet" element
     */
    java.lang.String getDCompet();
    
    /**
     * Gets (as xml) the "dCompet" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDCompet();
    
    /**
     * Sets the "dCompet" element
     */
    void setDCompet(java.lang.String dCompet);
    
    /**
     * Sets (as xml) the "dCompet" element
     */
    void xsetDCompet(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dCompet);
    
    /**
     * Gets the "tpEmit" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS.Enum getTpEmit();
    
    /**
     * Gets (as xml) the "tpEmit" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS xgetTpEmit();
    
    /**
     * Sets the "tpEmit" element
     */
    void setTpEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS.Enum tpEmit);
    
    /**
     * Sets (as xml) the "tpEmit" element
     */
    void xsetTpEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TSEmitenteDPS tpEmit);
    
    /**
     * Gets the "cMotivoEmisTI" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI.Enum getCMotivoEmisTI();
    
    /**
     * Gets (as xml) the "cMotivoEmisTI" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI xgetCMotivoEmisTI();
    
    /**
     * True if has "cMotivoEmisTI" element
     */
    boolean isSetCMotivoEmisTI();
    
    /**
     * Sets the "cMotivoEmisTI" element
     */
    void setCMotivoEmisTI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI.Enum cMotivoEmisTI);
    
    /**
     * Sets (as xml) the "cMotivoEmisTI" element
     */
    void xsetCMotivoEmisTI(org.kenos.v101.br.gov.fazenda.sped.nfse.TSMotivoEmisTI cMotivoEmisTI);
    
    /**
     * Unsets the "cMotivoEmisTI" element
     */
    void unsetCMotivoEmisTI();
    
    /**
     * Gets the "chNFSeRej" element
     */
    java.lang.String getChNFSeRej();
    
    /**
     * Gets (as xml) the "chNFSeRej" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe xgetChNFSeRej();
    
    /**
     * True if has "chNFSeRej" element
     */
    boolean isSetChNFSeRej();
    
    /**
     * Sets the "chNFSeRej" element
     */
    void setChNFSeRej(java.lang.String chNFSeRej);
    
    /**
     * Sets (as xml) the "chNFSeRej" element
     */
    void xsetChNFSeRej(org.kenos.v101.br.gov.fazenda.sped.nfse.TSChaveNFSe chNFSeRej);
    
    /**
     * Unsets the "chNFSeRej" element
     */
    void unsetChNFSeRej();
    
    /**
     * Gets the "cLocEmi" element
     */
    java.lang.String getCLocEmi();
    
    /**
     * Gets (as xml) the "cLocEmi" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocEmi();
    
    /**
     * Sets the "cLocEmi" element
     */
    void setCLocEmi(java.lang.String cLocEmi);
    
    /**
     * Sets (as xml) the "cLocEmi" element
     */
    void xsetCLocEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocEmi);
    
    /**
     * Gets the "subst" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao getSubst();
    
    /**
     * True if has "subst" element
     */
    boolean isSetSubst();
    
    /**
     * Sets the "subst" element
     */
    void setSubst(org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao subst);
    
    /**
     * Appends and returns a new empty "subst" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCSubstituicao addNewSubst();
    
    /**
     * Unsets the "subst" element
     */
    void unsetSubst();
    
    /**
     * Gets the "prest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador getPrest();
    
    /**
     * Sets the "prest" element
     */
    void setPrest(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador prest);
    
    /**
     * Appends and returns a new empty "prest" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPrestador addNewPrest();
    
    /**
     * Gets the "toma" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getToma();
    
    /**
     * True if has "toma" element
     */
    boolean isSetToma();
    
    /**
     * Sets the "toma" element
     */
    void setToma(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa toma);
    
    /**
     * Appends and returns a new empty "toma" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewToma();
    
    /**
     * Unsets the "toma" element
     */
    void unsetToma();
    
    /**
     * Gets the "interm" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa getInterm();
    
    /**
     * True if has "interm" element
     */
    boolean isSetInterm();
    
    /**
     * Sets the "interm" element
     */
    void setInterm(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa interm);
    
    /**
     * Appends and returns a new empty "interm" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoPessoa addNewInterm();
    
    /**
     * Unsets the "interm" element
     */
    void unsetInterm();
    
    /**
     * Gets the "serv" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ getServ();
    
    /**
     * Sets the "serv" element
     */
    void setServ(org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ serv);
    
    /**
     * Appends and returns a new empty "serv" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCServ addNewServ();
    
    /**
     * Gets the "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores getValores();
    
    /**
     * Sets the "valores" element
     */
    void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores valores);
    
    /**
     * Appends and returns a new empty "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfoValores addNewValores();
    
    /**
     * Gets the "IBSCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS getIBSCBS();
    
    /**
     * True if has "IBSCBS" element
     */
    boolean isSetIBSCBS();
    
    /**
     * Sets the "IBSCBS" element
     */
    void setIBSCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS ibscbs);
    
    /**
     * Appends and returns a new empty "IBSCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCInfoIBSCBS addNewIBSCBS();
    
    /**
     * Unsets the "IBSCBS" element
     */
    void unsetIBSCBS();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS xgetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdDPS id);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfDPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
