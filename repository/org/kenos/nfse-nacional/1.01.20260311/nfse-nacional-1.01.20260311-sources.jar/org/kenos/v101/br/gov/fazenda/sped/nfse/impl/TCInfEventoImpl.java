/*
 * XML Type:  TCInfEvento
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfEvento(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfEventoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfEvento
{
    private static final long serialVersionUID = 1L;
    
    public TCInfEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VERAPLIC$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "verAplic");
    private static final javax.xml.namespace.QName AMBGER$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "ambGer");
    private static final javax.xml.namespace.QName NSEQEVENTO$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nSeqEvento");
    private static final javax.xml.namespace.QName DHPROC$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dhProc");
    private static final javax.xml.namespace.QName NDFSE$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDFSe");
    private static final javax.xml.namespace.QName PEDREGEVENTO$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "pedRegEvento");
    private static final javax.xml.namespace.QName ID$12 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "verAplic" element
     */
    public java.lang.String getVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "verAplic" element
     */
    public void setVerAplic(java.lang.String verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERAPLIC$0);
            }
            target.setStringValue(verAplic);
        }
    }
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    public void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().add_element_user(VERAPLIC$0);
            }
            target.set(verAplic);
        }
    }
    
    /**
     * Gets the "ambGer" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt.Enum getAmbGer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AMBGER$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ambGer" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt xgetAmbGer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt)get_store().find_element_user(AMBGER$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ambGer" element
     */
    public void setAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt.Enum ambGer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AMBGER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AMBGER$2);
            }
            target.setEnumValue(ambGer);
        }
    }
    
    /**
     * Sets (as xml) the "ambGer" element
     */
    public void xsetAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt ambGer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt)get_store().find_element_user(AMBGER$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorEvt)get_store().add_element_user(AMBGER$2);
            }
            target.set(ambGer);
        }
    }
    
    /**
     * Gets the "nSeqEvento" element
     */
    public java.lang.String getNSeqEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NSEQEVENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nSeqEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig xgetNSeqEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().find_element_user(NSEQEVENTO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nSeqEvento" element
     */
    public void setNSeqEvento(java.lang.String nSeqEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NSEQEVENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NSEQEVENTO$4);
            }
            target.setStringValue(nSeqEvento);
        }
    }
    
    /**
     * Sets (as xml) the "nSeqEvento" element
     */
    public void xsetNSeqEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig nSeqEvento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().find_element_user(NSEQEVENTO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNum3Dig)get_store().add_element_user(NSEQEVENTO$4);
            }
            target.set(nSeqEvento);
        }
    }
    
    /**
     * Gets the "dhProc" element
     */
    public java.lang.String getDhProc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHPROC$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dhProc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhProc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHPROC$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dhProc" element
     */
    public void setDhProc(java.lang.String dhProc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHPROC$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DHPROC$6);
            }
            target.setStringValue(dhProc);
        }
    }
    
    /**
     * Sets (as xml) the "dhProc" element
     */
    public void xsetDhProc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhProc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHPROC$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().add_element_user(DHPROC$6);
            }
            target.set(dhProc);
        }
    }
    
    /**
     * Gets the "nDFSe" element
     */
    public java.lang.String getNDFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDFSE$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe xgetNDFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe)get_store().find_element_user(NDFSE$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nDFSe" element
     */
    public void setNDFSe(java.lang.String ndfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDFSE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDFSE$8);
            }
            target.setStringValue(ndfSe);
        }
    }
    
    /**
     * Sets (as xml) the "nDFSe" element
     */
    public void xsetNDFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe ndfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe)get_store().find_element_user(NDFSE$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNumDFe)get_store().add_element_user(NDFSE$8);
            }
            target.set(ndfSe);
        }
    }
    
    /**
     * Gets the "pedRegEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt getPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt)get_store().find_element_user(PEDREGEVENTO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pedRegEvento" element
     */
    public void setPedRegEvento(org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt pedRegEvento)
    {
        generatedSetterHelperImpl(pedRegEvento, PEDREGEVENTO$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "pedRegEvento" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt addNewPedRegEvento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCPedRegEvt)get_store().add_element_user(PEDREGEVENTO$10);
            return target;
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$12);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento)get_store().find_attribute_user(ID$12);
            return target;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$12);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento)get_store().find_attribute_user(ID$12);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdEvento)get_store().add_attribute_user(ID$12);
            }
            target.set(id);
        }
    }
}
