/*
 * XML Type:  TCRTCTotalTribRegular
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCTotalTribRegular(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCTotalTribRegular extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCTotalTribRegular.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcrtctotaltribregular12a1type");
    
    /**
     * Gets the "pAliqEfeRegIBSUF" element
     */
    java.lang.String getPAliqEfeRegIBSUF();
    
    /**
     * Gets (as xml) the "pAliqEfeRegIBSUF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegIBSUF();
    
    /**
     * Sets the "pAliqEfeRegIBSUF" element
     */
    void setPAliqEfeRegIBSUF(java.lang.String pAliqEfeRegIBSUF);
    
    /**
     * Sets (as xml) the "pAliqEfeRegIBSUF" element
     */
    void xsetPAliqEfeRegIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegIBSUF);
    
    /**
     * Gets the "vTribRegIBSUF" element
     */
    java.lang.String getVTribRegIBSUF();
    
    /**
     * Gets (as xml) the "vTribRegIBSUF" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegIBSUF();
    
    /**
     * Sets the "vTribRegIBSUF" element
     */
    void setVTribRegIBSUF(java.lang.String vTribRegIBSUF);
    
    /**
     * Sets (as xml) the "vTribRegIBSUF" element
     */
    void xsetVTribRegIBSUF(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegIBSUF);
    
    /**
     * Gets the "pAliqEfeRegIBSMun" element
     */
    java.lang.String getPAliqEfeRegIBSMun();
    
    /**
     * Gets (as xml) the "pAliqEfeRegIBSMun" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegIBSMun();
    
    /**
     * Sets the "pAliqEfeRegIBSMun" element
     */
    void setPAliqEfeRegIBSMun(java.lang.String pAliqEfeRegIBSMun);
    
    /**
     * Sets (as xml) the "pAliqEfeRegIBSMun" element
     */
    void xsetPAliqEfeRegIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegIBSMun);
    
    /**
     * Gets the "vTribRegIBSMun" element
     */
    java.lang.String getVTribRegIBSMun();
    
    /**
     * Gets (as xml) the "vTribRegIBSMun" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegIBSMun();
    
    /**
     * Sets the "vTribRegIBSMun" element
     */
    void setVTribRegIBSMun(java.lang.String vTribRegIBSMun);
    
    /**
     * Sets (as xml) the "vTribRegIBSMun" element
     */
    void xsetVTribRegIBSMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegIBSMun);
    
    /**
     * Gets the "pAliqEfeRegCBS" element
     */
    java.lang.String getPAliqEfeRegCBS();
    
    /**
     * Gets (as xml) the "pAliqEfeRegCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 xgetPAliqEfeRegCBS();
    
    /**
     * Sets the "pAliqEfeRegCBS" element
     */
    void setPAliqEfeRegCBS(java.lang.String pAliqEfeRegCBS);
    
    /**
     * Sets (as xml) the "pAliqEfeRegCBS" element
     */
    void xsetPAliqEfeRegCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec2V2 pAliqEfeRegCBS);
    
    /**
     * Gets the "vTribRegCBS" element
     */
    java.lang.String getVTribRegCBS();
    
    /**
     * Gets (as xml) the "vTribRegCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVTribRegCBS();
    
    /**
     * Sets the "vTribRegCBS" element
     */
    void setVTribRegCBS(java.lang.String vTribRegCBS);
    
    /**
     * Sets (as xml) the "vTribRegCBS" element
     */
    void xsetVTribRegCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vTribRegCBS);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCTotalTribRegular) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
