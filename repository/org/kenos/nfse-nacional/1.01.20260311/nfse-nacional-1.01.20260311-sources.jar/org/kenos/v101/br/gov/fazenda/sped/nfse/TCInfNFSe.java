/*
 * XML Type:  TCInfNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCInfNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCInfNFSe extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCInfNFSe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcinfnfse058atype");
    
    /**
     * Gets the "xLocEmi" element
     */
    java.lang.String getXLocEmi();
    
    /**
     * Gets (as xml) the "xLocEmi" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocEmi();
    
    /**
     * Sets the "xLocEmi" element
     */
    void setXLocEmi(java.lang.String xLocEmi);
    
    /**
     * Sets (as xml) the "xLocEmi" element
     */
    void xsetXLocEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocEmi);
    
    /**
     * Gets the "xLocPrestacao" element
     */
    java.lang.String getXLocPrestacao();
    
    /**
     * Gets (as xml) the "xLocPrestacao" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocPrestacao();
    
    /**
     * Sets the "xLocPrestacao" element
     */
    void setXLocPrestacao(java.lang.String xLocPrestacao);
    
    /**
     * Sets (as xml) the "xLocPrestacao" element
     */
    void xsetXLocPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocPrestacao);
    
    /**
     * Gets the "nNFSe" element
     */
    java.lang.String getNNFSe();
    
    /**
     * Gets (as xml) the "nNFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe xgetNNFSe();
    
    /**
     * Sets the "nNFSe" element
     */
    void setNNFSe(java.lang.String nnfSe);
    
    /**
     * Sets (as xml) the "nNFSe" element
     */
    void xsetNNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe nnfSe);
    
    /**
     * Gets the "cLocIncid" element
     */
    java.lang.String getCLocIncid();
    
    /**
     * Gets (as xml) the "cLocIncid" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocIncid();
    
    /**
     * True if has "cLocIncid" element
     */
    boolean isSetCLocIncid();
    
    /**
     * Sets the "cLocIncid" element
     */
    void setCLocIncid(java.lang.String cLocIncid);
    
    /**
     * Sets (as xml) the "cLocIncid" element
     */
    void xsetCLocIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocIncid);
    
    /**
     * Unsets the "cLocIncid" element
     */
    void unsetCLocIncid();
    
    /**
     * Gets the "xLocIncid" element
     */
    java.lang.String getXLocIncid();
    
    /**
     * Gets (as xml) the "xLocIncid" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocIncid();
    
    /**
     * True if has "xLocIncid" element
     */
    boolean isSetXLocIncid();
    
    /**
     * Sets the "xLocIncid" element
     */
    void setXLocIncid(java.lang.String xLocIncid);
    
    /**
     * Sets (as xml) the "xLocIncid" element
     */
    void xsetXLocIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocIncid);
    
    /**
     * Unsets the "xLocIncid" element
     */
    void unsetXLocIncid();
    
    /**
     * Gets the "xTribNac" element
     */
    java.lang.String getXTribNac();
    
    /**
     * Gets (as xml) the "xTribNac" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXTribNac();
    
    /**
     * Sets the "xTribNac" element
     */
    void setXTribNac(java.lang.String xTribNac);
    
    /**
     * Sets (as xml) the "xTribNac" element
     */
    void xsetXTribNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xTribNac);
    
    /**
     * Gets the "xTribMun" element
     */
    java.lang.String getXTribMun();
    
    /**
     * Gets (as xml) the "xTribMun" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXTribMun();
    
    /**
     * True if has "xTribMun" element
     */
    boolean isSetXTribMun();
    
    /**
     * Sets the "xTribMun" element
     */
    void setXTribMun(java.lang.String xTribMun);
    
    /**
     * Sets (as xml) the "xTribMun" element
     */
    void xsetXTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xTribMun);
    
    /**
     * Unsets the "xTribMun" element
     */
    void unsetXTribMun();
    
    /**
     * Gets the "xNBS" element
     */
    java.lang.String getXNBS();
    
    /**
     * Gets (as xml) the "xNBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXNBS();
    
    /**
     * True if has "xNBS" element
     */
    boolean isSetXNBS();
    
    /**
     * Sets the "xNBS" element
     */
    void setXNBS(java.lang.String xnbs);
    
    /**
     * Sets (as xml) the "xNBS" element
     */
    void xsetXNBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xnbs);
    
    /**
     * Unsets the "xNBS" element
     */
    void unsetXNBS();
    
    /**
     * Gets the "verAplic" element
     */
    java.lang.String getVerAplic();
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic();
    
    /**
     * Sets the "verAplic" element
     */
    void setVerAplic(java.lang.String verAplic);
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic);
    
    /**
     * Gets the "ambGer" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe.Enum getAmbGer();
    
    /**
     * Gets (as xml) the "ambGer" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe xgetAmbGer();
    
    /**
     * Sets the "ambGer" element
     */
    void setAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe.Enum ambGer);
    
    /**
     * Sets (as xml) the "ambGer" element
     */
    void xsetAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe ambGer);
    
    /**
     * Gets the "tpEmis" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.Enum getTpEmis();
    
    /**
     * Gets (as xml) the "tpEmis" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao xgetTpEmis();
    
    /**
     * Sets the "tpEmis" element
     */
    void setTpEmis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.Enum tpEmis);
    
    /**
     * Sets (as xml) the "tpEmis" element
     */
    void xsetTpEmis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao tpEmis);
    
    /**
     * Gets the "procEmi" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao.Enum getProcEmi();
    
    /**
     * Gets (as xml) the "procEmi" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao xgetProcEmi();
    
    /**
     * True if has "procEmi" element
     */
    boolean isSetProcEmi();
    
    /**
     * Sets the "procEmi" element
     */
    void setProcEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao.Enum procEmi);
    
    /**
     * Sets (as xml) the "procEmi" element
     */
    void xsetProcEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao procEmi);
    
    /**
     * Unsets the "procEmi" element
     */
    void unsetProcEmi();
    
    /**
     * Gets the "cStat" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TStat.Enum getCStat();
    
    /**
     * Gets (as xml) the "cStat" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TStat xgetCStat();
    
    /**
     * Sets the "cStat" element
     */
    void setCStat(org.kenos.v101.br.gov.fazenda.sped.nfse.TStat.Enum cStat);
    
    /**
     * Sets (as xml) the "cStat" element
     */
    void xsetCStat(org.kenos.v101.br.gov.fazenda.sped.nfse.TStat cStat);
    
    /**
     * Gets the "dhProc" element
     */
    java.lang.String getDhProc();
    
    /**
     * Gets (as xml) the "dhProc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhProc();
    
    /**
     * Sets the "dhProc" element
     */
    void setDhProc(java.lang.String dhProc);
    
    /**
     * Sets (as xml) the "dhProc" element
     */
    void xsetDhProc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhProc);
    
    /**
     * Gets the "nDFSe" element
     */
    java.lang.String getNDFSe();
    
    /**
     * Gets (as xml) the "nDFSe" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe xgetNDFSe();
    
    /**
     * Sets the "nDFSe" element
     */
    void setNDFSe(java.lang.String ndfSe);
    
    /**
     * Sets (as xml) the "nDFSe" element
     */
    void xsetNDFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe ndfSe);
    
    /**
     * Gets the "emit" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente getEmit();
    
    /**
     * Sets the "emit" element
     */
    void setEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente emit);
    
    /**
     * Appends and returns a new empty "emit" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente addNewEmit();
    
    /**
     * Gets the "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe getValores();
    
    /**
     * Sets the "valores" element
     */
    void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe valores);
    
    /**
     * Appends and returns a new empty "valores" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe addNewValores();
    
    /**
     * Gets the "xOutInf" element
     */
    java.lang.String getXOutInf();
    
    /**
     * Gets (as xml) the "xOutInf" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xgetXOutInf();
    
    /**
     * True if has "xOutInf" element
     */
    boolean isSetXOutInf();
    
    /**
     * Sets the "xOutInf" element
     */
    void setXOutInf(java.lang.String xOutInf);
    
    /**
     * Sets (as xml) the "xOutInf" element
     */
    void xsetXOutInf(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xOutInf);
    
    /**
     * Unsets the "xOutInf" element
     */
    void unsetXOutInf();
    
    /**
     * Gets the "IBSCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS getIBSCBS();
    
    /**
     * True if has "IBSCBS" element
     */
    boolean isSetIBSCBS();
    
    /**
     * Sets the "IBSCBS" element
     */
    void setIBSCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS ibscbs);
    
    /**
     * Appends and returns a new empty "IBSCBS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS addNewIBSCBS();
    
    /**
     * Unsets the "IBSCBS" element
     */
    void unsetIBSCBS();
    
    /**
     * Gets the "DPS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS getDPS();
    
    /**
     * Sets the "DPS" element
     */
    void setDPS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS dps);
    
    /**
     * Appends and returns a new empty "DPS" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS addNewDPS();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe xgetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe id);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
