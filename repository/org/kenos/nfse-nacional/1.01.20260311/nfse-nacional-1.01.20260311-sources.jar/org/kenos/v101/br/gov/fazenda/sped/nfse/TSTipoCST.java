/*
 * XML Type:  TSTipoCST
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TSTipoCST(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is an atomic type that is a restriction of org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST.
 */
public interface TSTipoCST extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TSTipoCST.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tstipocst1d9ftype");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum X_00 = Enum.forString("00");
    static final Enum X_01 = Enum.forString("01");
    static final Enum X_02 = Enum.forString("02");
    static final Enum X_03 = Enum.forString("03");
    static final Enum X_04 = Enum.forString("04");
    static final Enum X_05 = Enum.forString("05");
    static final Enum X_06 = Enum.forString("06");
    static final Enum X_07 = Enum.forString("07");
    static final Enum X_08 = Enum.forString("08");
    static final Enum X_09 = Enum.forString("09");
    static final Enum X_49 = Enum.forString("49");
    static final Enum X_50 = Enum.forString("50");
    static final Enum X_51 = Enum.forString("51");
    static final Enum X_52 = Enum.forString("52");
    static final Enum X_53 = Enum.forString("53");
    static final Enum X_54 = Enum.forString("54");
    static final Enum X_55 = Enum.forString("55");
    static final Enum X_56 = Enum.forString("56");
    static final Enum X_60 = Enum.forString("60");
    static final Enum X_61 = Enum.forString("61");
    static final Enum X_62 = Enum.forString("62");
    static final Enum X_63 = Enum.forString("63");
    static final Enum X_64 = Enum.forString("64");
    static final Enum X_65 = Enum.forString("65");
    static final Enum X_66 = Enum.forString("66");
    static final Enum X_67 = Enum.forString("67");
    static final Enum X_70 = Enum.forString("70");
    static final Enum X_71 = Enum.forString("71");
    static final Enum X_72 = Enum.forString("72");
    static final Enum X_73 = Enum.forString("73");
    static final Enum X_74 = Enum.forString("74");
    static final Enum X_75 = Enum.forString("75");
    static final Enum X_98 = Enum.forString("98");
    static final Enum X_99 = Enum.forString("99");
    
    static final int INT_X_00 = Enum.INT_X_00;
    static final int INT_X_01 = Enum.INT_X_01;
    static final int INT_X_02 = Enum.INT_X_02;
    static final int INT_X_03 = Enum.INT_X_03;
    static final int INT_X_04 = Enum.INT_X_04;
    static final int INT_X_05 = Enum.INT_X_05;
    static final int INT_X_06 = Enum.INT_X_06;
    static final int INT_X_07 = Enum.INT_X_07;
    static final int INT_X_08 = Enum.INT_X_08;
    static final int INT_X_09 = Enum.INT_X_09;
    static final int INT_X_49 = Enum.INT_X_49;
    static final int INT_X_50 = Enum.INT_X_50;
    static final int INT_X_51 = Enum.INT_X_51;
    static final int INT_X_52 = Enum.INT_X_52;
    static final int INT_X_53 = Enum.INT_X_53;
    static final int INT_X_54 = Enum.INT_X_54;
    static final int INT_X_55 = Enum.INT_X_55;
    static final int INT_X_56 = Enum.INT_X_56;
    static final int INT_X_60 = Enum.INT_X_60;
    static final int INT_X_61 = Enum.INT_X_61;
    static final int INT_X_62 = Enum.INT_X_62;
    static final int INT_X_63 = Enum.INT_X_63;
    static final int INT_X_64 = Enum.INT_X_64;
    static final int INT_X_65 = Enum.INT_X_65;
    static final int INT_X_66 = Enum.INT_X_66;
    static final int INT_X_67 = Enum.INT_X_67;
    static final int INT_X_70 = Enum.INT_X_70;
    static final int INT_X_71 = Enum.INT_X_71;
    static final int INT_X_72 = Enum.INT_X_72;
    static final int INT_X_73 = Enum.INT_X_73;
    static final int INT_X_74 = Enum.INT_X_74;
    static final int INT_X_75 = Enum.INT_X_75;
    static final int INT_X_98 = Enum.INT_X_98;
    static final int INT_X_99 = Enum.INT_X_99;
    
    /**
     * Enumeration value class for org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_X_00
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_X_00 = 1;
        static final int INT_X_01 = 2;
        static final int INT_X_02 = 3;
        static final int INT_X_03 = 4;
        static final int INT_X_04 = 5;
        static final int INT_X_05 = 6;
        static final int INT_X_06 = 7;
        static final int INT_X_07 = 8;
        static final int INT_X_08 = 9;
        static final int INT_X_09 = 10;
        static final int INT_X_49 = 11;
        static final int INT_X_50 = 12;
        static final int INT_X_51 = 13;
        static final int INT_X_52 = 14;
        static final int INT_X_53 = 15;
        static final int INT_X_54 = 16;
        static final int INT_X_55 = 17;
        static final int INT_X_56 = 18;
        static final int INT_X_60 = 19;
        static final int INT_X_61 = 20;
        static final int INT_X_62 = 21;
        static final int INT_X_63 = 22;
        static final int INT_X_64 = 23;
        static final int INT_X_65 = 24;
        static final int INT_X_66 = 25;
        static final int INT_X_67 = 26;
        static final int INT_X_70 = 27;
        static final int INT_X_71 = 28;
        static final int INT_X_72 = 29;
        static final int INT_X_73 = 30;
        static final int INT_X_74 = 31;
        static final int INT_X_75 = 32;
        static final int INT_X_98 = 33;
        static final int INT_X_99 = 34;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("00", INT_X_00),
                new Enum("01", INT_X_01),
                new Enum("02", INT_X_02),
                new Enum("03", INT_X_03),
                new Enum("04", INT_X_04),
                new Enum("05", INT_X_05),
                new Enum("06", INT_X_06),
                new Enum("07", INT_X_07),
                new Enum("08", INT_X_08),
                new Enum("09", INT_X_09),
                new Enum("49", INT_X_49),
                new Enum("50", INT_X_50),
                new Enum("51", INT_X_51),
                new Enum("52", INT_X_52),
                new Enum("53", INT_X_53),
                new Enum("54", INT_X_54),
                new Enum("55", INT_X_55),
                new Enum("56", INT_X_56),
                new Enum("60", INT_X_60),
                new Enum("61", INT_X_61),
                new Enum("62", INT_X_62),
                new Enum("63", INT_X_63),
                new Enum("64", INT_X_64),
                new Enum("65", INT_X_65),
                new Enum("66", INT_X_66),
                new Enum("67", INT_X_67),
                new Enum("70", INT_X_70),
                new Enum("71", INT_X_71),
                new Enum("72", INT_X_72),
                new Enum("73", INT_X_73),
                new Enum("74", INT_X_74),
                new Enum("75", INT_X_75),
                new Enum("98", INT_X_98),
                new Enum("99", INT_X_99),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST newValue(java.lang.Object obj) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) type.newValue( obj ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoCST) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
