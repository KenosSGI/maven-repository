/*
 * XML Type:  TCInfNFSe
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse.impl;
/**
 * An XML TCInfNFSe(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public class TCInfNFSeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v101.br.gov.fazenda.sped.nfse.TCInfNFSe
{
    private static final long serialVersionUID = 1L;
    
    public TCInfNFSeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName XLOCEMI$0 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLocEmi");
    private static final javax.xml.namespace.QName XLOCPRESTACAO$2 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLocPrestacao");
    private static final javax.xml.namespace.QName NNFSE$4 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nNFSe");
    private static final javax.xml.namespace.QName CLOCINCID$6 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cLocIncid");
    private static final javax.xml.namespace.QName XLOCINCID$8 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xLocIncid");
    private static final javax.xml.namespace.QName XTRIBNAC$10 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xTribNac");
    private static final javax.xml.namespace.QName XTRIBMUN$12 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xTribMun");
    private static final javax.xml.namespace.QName XNBS$14 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xNBS");
    private static final javax.xml.namespace.QName VERAPLIC$16 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "verAplic");
    private static final javax.xml.namespace.QName AMBGER$18 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "ambGer");
    private static final javax.xml.namespace.QName TPEMIS$20 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "tpEmis");
    private static final javax.xml.namespace.QName PROCEMI$22 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "procEmi");
    private static final javax.xml.namespace.QName CSTAT$24 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "cStat");
    private static final javax.xml.namespace.QName DHPROC$26 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "dhProc");
    private static final javax.xml.namespace.QName NDFSE$28 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "nDFSe");
    private static final javax.xml.namespace.QName EMIT$30 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "emit");
    private static final javax.xml.namespace.QName VALORES$32 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "valores");
    private static final javax.xml.namespace.QName XOUTINF$34 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "xOutInf");
    private static final javax.xml.namespace.QName IBSCBS$36 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "IBSCBS");
    private static final javax.xml.namespace.QName DPS$38 = 
        new javax.xml.namespace.QName("http://www.sped.fazenda.gov.br/nfse", "DPS");
    private static final javax.xml.namespace.QName ID$40 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "xLocEmi" element
     */
    public java.lang.String getXLocEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCEMI$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLocEmi" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCEMI$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xLocEmi" element
     */
    public void setXLocEmi(java.lang.String xLocEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCEMI$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLOCEMI$0);
            }
            target.setStringValue(xLocEmi);
        }
    }
    
    /**
     * Sets (as xml) the "xLocEmi" element
     */
    public void xsetXLocEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCEMI$0, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XLOCEMI$0);
            }
            target.set(xLocEmi);
        }
    }
    
    /**
     * Gets the "xLocPrestacao" element
     */
    public java.lang.String getXLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCPRESTACAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLocPrestacao" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCPRESTACAO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xLocPrestacao" element
     */
    public void setXLocPrestacao(java.lang.String xLocPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCPRESTACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLOCPRESTACAO$2);
            }
            target.setStringValue(xLocPrestacao);
        }
    }
    
    /**
     * Sets (as xml) the "xLocPrestacao" element
     */
    public void xsetXLocPrestacao(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCPRESTACAO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XLOCPRESTACAO$2);
            }
            target.set(xLocPrestacao);
        }
    }
    
    /**
     * Gets the "nNFSe" element
     */
    public java.lang.String getNNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFSE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nNFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe xgetNNFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe)get_store().find_element_user(NNFSE$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nNFSe" element
     */
    public void setNNFSe(java.lang.String nnfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NNFSE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NNFSE$4);
            }
            target.setStringValue(nnfSe);
        }
    }
    
    /**
     * Sets (as xml) the "nNFSe" element
     */
    public void xsetNNFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe nnfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe)get_store().find_element_user(NNFSE$4, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNNFSe)get_store().add_element_user(NNFSE$4);
            }
            target.set(nnfSe);
        }
    }
    
    /**
     * Gets the "cLocIncid" element
     */
    public java.lang.String getCLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCINCID$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "cLocIncid" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE xgetCLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCINCID$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "cLocIncid" element
     */
    public boolean isSetCLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLOCINCID$6) != 0;
        }
    }
    
    /**
     * Sets the "cLocIncid" element
     */
    public void setCLocIncid(java.lang.String cLocIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLOCINCID$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLOCINCID$6);
            }
            target.setStringValue(cLocIncid);
        }
    }
    
    /**
     * Sets (as xml) the "cLocIncid" element
     */
    public void xsetCLocIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE cLocIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().find_element_user(CLOCINCID$6, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSCodMunIBGE)get_store().add_element_user(CLOCINCID$6);
            }
            target.set(cLocIncid);
        }
    }
    
    /**
     * Unsets the "cLocIncid" element
     */
    public void unsetCLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLOCINCID$6, 0);
        }
    }
    
    /**
     * Gets the "xLocIncid" element
     */
    public java.lang.String getXLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCINCID$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xLocIncid" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCINCID$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "xLocIncid" element
     */
    public boolean isSetXLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XLOCINCID$8) != 0;
        }
    }
    
    /**
     * Sets the "xLocIncid" element
     */
    public void setXLocIncid(java.lang.String xLocIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XLOCINCID$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XLOCINCID$8);
            }
            target.setStringValue(xLocIncid);
        }
    }
    
    /**
     * Sets (as xml) the "xLocIncid" element
     */
    public void xsetXLocIncid(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xLocIncid)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().find_element_user(XLOCINCID$8, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150)get_store().add_element_user(XLOCINCID$8);
            }
            target.set(xLocIncid);
        }
    }
    
    /**
     * Unsets the "xLocIncid" element
     */
    public void unsetXLocIncid()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XLOCINCID$8, 0);
        }
    }
    
    /**
     * Gets the "xTribNac" element
     */
    public java.lang.String getXTribNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTRIBNAC$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xTribNac" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXTribNac()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XTRIBNAC$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "xTribNac" element
     */
    public void setXTribNac(java.lang.String xTribNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTRIBNAC$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XTRIBNAC$10);
            }
            target.setStringValue(xTribNac);
        }
    }
    
    /**
     * Sets (as xml) the "xTribNac" element
     */
    public void xsetXTribNac(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xTribNac)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XTRIBNAC$10, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().add_element_user(XTRIBNAC$10);
            }
            target.set(xTribNac);
        }
    }
    
    /**
     * Gets the "xTribMun" element
     */
    public java.lang.String getXTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTRIBMUN$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xTribMun" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XTRIBMUN$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "xTribMun" element
     */
    public boolean isSetXTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XTRIBMUN$12) != 0;
        }
    }
    
    /**
     * Sets the "xTribMun" element
     */
    public void setXTribMun(java.lang.String xTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XTRIBMUN$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XTRIBMUN$12);
            }
            target.setStringValue(xTribMun);
        }
    }
    
    /**
     * Sets (as xml) the "xTribMun" element
     */
    public void xsetXTribMun(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xTribMun)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XTRIBMUN$12, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().add_element_user(XTRIBMUN$12);
            }
            target.set(xTribMun);
        }
    }
    
    /**
     * Unsets the "xTribMun" element
     */
    public void unsetXTribMun()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XTRIBMUN$12, 0);
        }
    }
    
    /**
     * Gets the "xNBS" element
     */
    public java.lang.String getXNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNBS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xNBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xgetXNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XNBS$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "xNBS" element
     */
    public boolean isSetXNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XNBS$14) != 0;
        }
    }
    
    /**
     * Sets the "xNBS" element
     */
    public void setXNBS(java.lang.String xnbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XNBS$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XNBS$14);
            }
            target.setStringValue(xnbs);
        }
    }
    
    /**
     * Sets (as xml) the "xNBS" element
     */
    public void xsetXNBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 xnbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().find_element_user(XNBS$14, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc600)get_store().add_element_user(XNBS$14);
            }
            target.set(xnbs);
        }
    }
    
    /**
     * Unsets the "xNBS" element
     */
    public void unsetXNBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XNBS$14, 0);
        }
    }
    
    /**
     * Gets the "verAplic" element
     */
    public java.lang.String getVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "verAplic" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic xgetVerAplic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$16, 0);
            return target;
        }
    }
    
    /**
     * Sets the "verAplic" element
     */
    public void setVerAplic(java.lang.String verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERAPLIC$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERAPLIC$16);
            }
            target.setStringValue(verAplic);
        }
    }
    
    /**
     * Sets (as xml) the "verAplic" element
     */
    public void xsetVerAplic(org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic verAplic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().find_element_user(VERAPLIC$16, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSVerAplic)get_store().add_element_user(VERAPLIC$16);
            }
            target.set(verAplic);
        }
    }
    
    /**
     * Gets the "ambGer" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe.Enum getAmbGer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AMBGER$18, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ambGer" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe xgetAmbGer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe)get_store().find_element_user(AMBGER$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ambGer" element
     */
    public void setAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe.Enum ambGer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AMBGER$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AMBGER$18);
            }
            target.setEnumValue(ambGer);
        }
    }
    
    /**
     * Sets (as xml) the "ambGer" element
     */
    public void xsetAmbGer(org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe ambGer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe)get_store().find_element_user(AMBGER$18, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSAmbGeradorNFSe)get_store().add_element_user(AMBGER$18);
            }
            target.set(ambGer);
        }
    }
    
    /**
     * Gets the "tpEmis" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.Enum getTpEmis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPEMIS$20, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpEmis" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao xgetTpEmis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao)get_store().find_element_user(TPEMIS$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "tpEmis" element
     */
    public void setTpEmis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao.Enum tpEmis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPEMIS$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPEMIS$20);
            }
            target.setEnumValue(tpEmis);
        }
    }
    
    /**
     * Sets (as xml) the "tpEmis" element
     */
    public void xsetTpEmis(org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao tpEmis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao)get_store().find_element_user(TPEMIS$20, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSTipoEmissao)get_store().add_element_user(TPEMIS$20);
            }
            target.set(tpEmis);
        }
    }
    
    /**
     * Gets the "procEmi" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao.Enum getProcEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROCEMI$22, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "procEmi" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao xgetProcEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao)get_store().find_element_user(PROCEMI$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "procEmi" element
     */
    public boolean isSetProcEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROCEMI$22) != 0;
        }
    }
    
    /**
     * Sets the "procEmi" element
     */
    public void setProcEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao.Enum procEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROCEMI$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROCEMI$22);
            }
            target.setEnumValue(procEmi);
        }
    }
    
    /**
     * Sets (as xml) the "procEmi" element
     */
    public void xsetProcEmi(org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao procEmi)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao)get_store().find_element_user(PROCEMI$22, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSProcEmissao)get_store().add_element_user(PROCEMI$22);
            }
            target.set(procEmi);
        }
    }
    
    /**
     * Unsets the "procEmi" element
     */
    public void unsetProcEmi()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROCEMI$22, 0);
        }
    }
    
    /**
     * Gets the "cStat" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TStat.Enum getCStat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CSTAT$24, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v101.br.gov.fazenda.sped.nfse.TStat.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "cStat" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TStat xgetCStat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TStat target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TStat)get_store().find_element_user(CSTAT$24, 0);
            return target;
        }
    }
    
    /**
     * Sets the "cStat" element
     */
    public void setCStat(org.kenos.v101.br.gov.fazenda.sped.nfse.TStat.Enum cStat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CSTAT$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CSTAT$24);
            }
            target.setEnumValue(cStat);
        }
    }
    
    /**
     * Sets (as xml) the "cStat" element
     */
    public void xsetCStat(org.kenos.v101.br.gov.fazenda.sped.nfse.TStat cStat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TStat target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TStat)get_store().find_element_user(CSTAT$24, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TStat)get_store().add_element_user(CSTAT$24);
            }
            target.set(cStat);
        }
    }
    
    /**
     * Gets the "dhProc" element
     */
    public java.lang.String getDhProc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHPROC$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "dhProc" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC xgetDhProc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHPROC$26, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dhProc" element
     */
    public void setDhProc(java.lang.String dhProc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DHPROC$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DHPROC$26);
            }
            target.setStringValue(dhProc);
        }
    }
    
    /**
     * Sets (as xml) the "dhProc" element
     */
    public void xsetDhProc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC dhProc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().find_element_user(DHPROC$26, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDateTimeUTC)get_store().add_element_user(DHPROC$26);
            }
            target.set(dhProc);
        }
    }
    
    /**
     * Gets the "nDFSe" element
     */
    public java.lang.String getNDFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDFSE$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nDFSe" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe xgetNDFSe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe)get_store().find_element_user(NDFSE$28, 0);
            return target;
        }
    }
    
    /**
     * Sets the "nDFSe" element
     */
    public void setNDFSe(java.lang.String ndfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NDFSE$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NDFSE$28);
            }
            target.setStringValue(ndfSe);
        }
    }
    
    /**
     * Sets (as xml) the "nDFSe" element
     */
    public void xsetNDFSe(org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe ndfSe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe)get_store().find_element_user(NDFSE$28, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSNDFSe)get_store().add_element_user(NDFSE$28);
            }
            target.set(ndfSe);
        }
    }
    
    /**
     * Gets the "emit" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente getEmit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente)get_store().find_element_user(EMIT$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "emit" element
     */
    public void setEmit(org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente emit)
    {
        generatedSetterHelperImpl(emit, EMIT$30, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "emit" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente addNewEmit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCEmitente)get_store().add_element_user(EMIT$30);
            return target;
        }
    }
    
    /**
     * Gets the "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe getValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe)get_store().find_element_user(VALORES$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "valores" element
     */
    public void setValores(org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe valores)
    {
        generatedSetterHelperImpl(valores, VALORES$32, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "valores" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe addNewValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCValoresNFSe)get_store().add_element_user(VALORES$32);
            return target;
        }
    }
    
    /**
     * Gets the "xOutInf" element
     */
    public java.lang.String getXOutInf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XOUTINF$34, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "xOutInf" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xgetXOutInf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().find_element_user(XOUTINF$34, 0);
            return target;
        }
    }
    
    /**
     * True if has "xOutInf" element
     */
    public boolean isSetXOutInf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(XOUTINF$34) != 0;
        }
    }
    
    /**
     * Sets the "xOutInf" element
     */
    public void setXOutInf(java.lang.String xOutInf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(XOUTINF$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(XOUTINF$34);
            }
            target.setStringValue(xOutInf);
        }
    }
    
    /**
     * Sets (as xml) the "xOutInf" element
     */
    public void xsetXOutInf(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 xOutInf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000 target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().find_element_user(XOUTINF$34, 0);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc2000)get_store().add_element_user(XOUTINF$34);
            }
            target.set(xOutInf);
        }
    }
    
    /**
     * Unsets the "xOutInf" element
     */
    public void unsetXOutInf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(XOUTINF$34, 0);
        }
    }
    
    /**
     * Gets the "IBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS getIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS)get_store().find_element_user(IBSCBS$36, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "IBSCBS" element
     */
    public boolean isSetIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IBSCBS$36) != 0;
        }
    }
    
    /**
     * Sets the "IBSCBS" element
     */
    public void setIBSCBS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS ibscbs)
    {
        generatedSetterHelperImpl(ibscbs, IBSCBS$36, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IBSCBS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS addNewIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCIBSCBS)get_store().add_element_user(IBSCBS$36);
            return target;
        }
    }
    
    /**
     * Unsets the "IBSCBS" element
     */
    public void unsetIBSCBS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IBSCBS$36, 0);
        }
    }
    
    /**
     * Gets the "DPS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS getDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS)get_store().find_element_user(DPS$38, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "DPS" element
     */
    public void setDPS(org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS dps)
    {
        generatedSetterHelperImpl(dps, DPS$38, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DPS" element
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS addNewDPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TCDPS)get_store().add_element_user(DPS$38);
            return target;
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$40);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe)get_store().find_attribute_user(ID$40);
            return target;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$40);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$40);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe target = null;
            target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe)get_store().find_attribute_user(ID$40);
            if (target == null)
            {
                target = (org.kenos.v101.br.gov.fazenda.sped.nfse.TSIdNFSe)get_store().add_attribute_user(ID$40);
            }
            target.set(id);
        }
    }
}
