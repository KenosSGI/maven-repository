/*
 * XML Type:  TCRTCListaDoc
 * Namespace: http://www.sped.fazenda.gov.br/nfse
 * Java type: org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v101.br.gov.fazenda.sped.nfse;


/**
 * An XML TCRTCListaDoc(@http://www.sped.fazenda.gov.br/nfse).
 *
 * This is a complex type.
 */
public interface TCRTCListaDoc extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TCRTCListaDoc.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2EEB3CE37A1D9B79753CF4F032F75124").resolveHandle("tcrtclistadoc22b5type");
    
    /**
     * Gets the "dFeNacional" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe getDFeNacional();
    
    /**
     * True if has "dFeNacional" element
     */
    boolean isSetDFeNacional();
    
    /**
     * Sets the "dFeNacional" element
     */
    void setDFeNacional(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe dFeNacional);
    
    /**
     * Appends and returns a new empty "dFeNacional" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocDFe addNewDFeNacional();
    
    /**
     * Unsets the "dFeNacional" element
     */
    void unsetDFeNacional();
    
    /**
     * Gets the "docFiscalOutro" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro getDocFiscalOutro();
    
    /**
     * True if has "docFiscalOutro" element
     */
    boolean isSetDocFiscalOutro();
    
    /**
     * Sets the "docFiscalOutro" element
     */
    void setDocFiscalOutro(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro docFiscalOutro);
    
    /**
     * Appends and returns a new empty "docFiscalOutro" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFiscalOutro addNewDocFiscalOutro();
    
    /**
     * Unsets the "docFiscalOutro" element
     */
    void unsetDocFiscalOutro();
    
    /**
     * Gets the "docOutro" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro getDocOutro();
    
    /**
     * True if has "docOutro" element
     */
    boolean isSetDocOutro();
    
    /**
     * Sets the "docOutro" element
     */
    void setDocOutro(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro docOutro);
    
    /**
     * Appends and returns a new empty "docOutro" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocOutro addNewDocOutro();
    
    /**
     * Unsets the "docOutro" element
     */
    void unsetDocOutro();
    
    /**
     * Gets the "fornec" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec getFornec();
    
    /**
     * True if has "fornec" element
     */
    boolean isSetFornec();
    
    /**
     * Sets the "fornec" element
     */
    void setFornec(org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec fornec);
    
    /**
     * Appends and returns a new empty "fornec" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDocFornec addNewFornec();
    
    /**
     * Unsets the "fornec" element
     */
    void unsetFornec();
    
    /**
     * Gets the "dtEmiDoc" element
     */
    java.lang.String getDtEmiDoc();
    
    /**
     * Gets (as xml) the "dtEmiDoc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtEmiDoc();
    
    /**
     * Sets the "dtEmiDoc" element
     */
    void setDtEmiDoc(java.lang.String dtEmiDoc);
    
    /**
     * Sets (as xml) the "dtEmiDoc" element
     */
    void xsetDtEmiDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtEmiDoc);
    
    /**
     * Gets the "dtCompDoc" element
     */
    java.lang.String getDtCompDoc();
    
    /**
     * Gets (as xml) the "dtCompDoc" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSData xgetDtCompDoc();
    
    /**
     * Sets the "dtCompDoc" element
     */
    void setDtCompDoc(java.lang.String dtCompDoc);
    
    /**
     * Sets (as xml) the "dtCompDoc" element
     */
    void xsetDtCompDoc(org.kenos.v101.br.gov.fazenda.sped.nfse.TSData dtCompDoc);
    
    /**
     * Gets the "tpReeRepRes" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes.Enum getTpReeRepRes();
    
    /**
     * Gets (as xml) the "tpReeRepRes" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes xgetTpReeRepRes();
    
    /**
     * Sets the "tpReeRepRes" element
     */
    void setTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes.Enum tpReeRepRes);
    
    /**
     * Sets (as xml) the "tpReeRepRes" element
     */
    void xsetTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSRTCTpReeRepRes tpReeRepRes);
    
    /**
     * Gets the "xTpReeRepRes" element
     */
    java.lang.String getXTpReeRepRes();
    
    /**
     * Gets (as xml) the "xTpReeRepRes" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xgetXTpReeRepRes();
    
    /**
     * True if has "xTpReeRepRes" element
     */
    boolean isSetXTpReeRepRes();
    
    /**
     * Sets the "xTpReeRepRes" element
     */
    void setXTpReeRepRes(java.lang.String xTpReeRepRes);
    
    /**
     * Sets (as xml) the "xTpReeRepRes" element
     */
    void xsetXTpReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDesc150 xTpReeRepRes);
    
    /**
     * Unsets the "xTpReeRepRes" element
     */
    void unsetXTpReeRepRes();
    
    /**
     * Gets the "vlrReeRepRes" element
     */
    java.lang.String getVlrReeRepRes();
    
    /**
     * Gets (as xml) the "vlrReeRepRes" element
     */
    org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 xgetVlrReeRepRes();
    
    /**
     * Sets the "vlrReeRepRes" element
     */
    void setVlrReeRepRes(java.lang.String vlrReeRepRes);
    
    /**
     * Sets (as xml) the "vlrReeRepRes" element
     */
    void xsetVlrReeRepRes(org.kenos.v101.br.gov.fazenda.sped.nfse.TSDec15V2 vlrReeRepRes);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc newInstance() {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v101.br.gov.fazenda.sped.nfse.TCRTCListaDoc) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
