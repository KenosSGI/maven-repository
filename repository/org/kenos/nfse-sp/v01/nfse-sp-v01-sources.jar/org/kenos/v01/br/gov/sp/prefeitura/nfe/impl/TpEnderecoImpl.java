/*
 * XML Type:  tpEndereco
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpEndereco(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpEnderecoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco
{
    private static final long serialVersionUID = 1L;
    
    public TpEnderecoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TIPOLOGRADOURO$0 = 
        new javax.xml.namespace.QName("", "TipoLogradouro");
    private static final javax.xml.namespace.QName LOGRADOURO$2 = 
        new javax.xml.namespace.QName("", "Logradouro");
    private static final javax.xml.namespace.QName NUMEROENDERECO$4 = 
        new javax.xml.namespace.QName("", "NumeroEndereco");
    private static final javax.xml.namespace.QName COMPLEMENTOENDERECO$6 = 
        new javax.xml.namespace.QName("", "ComplementoEndereco");
    private static final javax.xml.namespace.QName BAIRRO$8 = 
        new javax.xml.namespace.QName("", "Bairro");
    private static final javax.xml.namespace.QName CIDADE$10 = 
        new javax.xml.namespace.QName("", "Cidade");
    private static final javax.xml.namespace.QName UF$12 = 
        new javax.xml.namespace.QName("", "UF");
    private static final javax.xml.namespace.QName CEP$14 = 
        new javax.xml.namespace.QName("", "CEP");
    
    
    /**
     * Gets the "TipoLogradouro" element
     */
    public java.lang.String getTipoLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOLOGRADOURO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TipoLogradouro" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro xgetTipoLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro)get_store().find_element_user(TIPOLOGRADOURO$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "TipoLogradouro" element
     */
    public boolean isSetTipoLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIPOLOGRADOURO$0) != 0;
        }
    }
    
    /**
     * Sets the "TipoLogradouro" element
     */
    public void setTipoLogradouro(java.lang.String tipoLogradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPOLOGRADOURO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPOLOGRADOURO$0);
            }
            target.setStringValue(tipoLogradouro);
        }
    }
    
    /**
     * Sets (as xml) the "TipoLogradouro" element
     */
    public void xsetTipoLogradouro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro tipoLogradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro)get_store().find_element_user(TIPOLOGRADOURO$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro)get_store().add_element_user(TIPOLOGRADOURO$0);
            }
            target.set(tipoLogradouro);
        }
    }
    
    /**
     * Unsets the "TipoLogradouro" element
     */
    public void unsetTipoLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIPOLOGRADOURO$0, 0);
        }
    }
    
    /**
     * Gets the "Logradouro" element
     */
    public java.lang.String getLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro xgetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro)get_store().find_element_user(LOGRADOURO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Logradouro" element
     */
    public boolean isSetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LOGRADOURO$2) != 0;
        }
    }
    
    /**
     * Sets the "Logradouro" element
     */
    public void setLogradouro(java.lang.String logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOGRADOURO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LOGRADOURO$2);
            }
            target.setStringValue(logradouro);
        }
    }
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    public void xsetLogradouro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro logradouro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro)get_store().find_element_user(LOGRADOURO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro)get_store().add_element_user(LOGRADOURO$2);
            }
            target.set(logradouro);
        }
    }
    
    /**
     * Unsets the "Logradouro" element
     */
    public void unsetLogradouro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LOGRADOURO$2, 0);
        }
    }
    
    /**
     * Gets the "NumeroEndereco" element
     */
    public java.lang.String getNumeroEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROENDERECO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroEndereco" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco xgetNumeroEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco)get_store().find_element_user(NUMEROENDERECO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "NumeroEndereco" element
     */
    public boolean isSetNumeroEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROENDERECO$4) != 0;
        }
    }
    
    /**
     * Sets the "NumeroEndereco" element
     */
    public void setNumeroEndereco(java.lang.String numeroEndereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROENDERECO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROENDERECO$4);
            }
            target.setStringValue(numeroEndereco);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroEndereco" element
     */
    public void xsetNumeroEndereco(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco numeroEndereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco)get_store().find_element_user(NUMEROENDERECO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco)get_store().add_element_user(NUMEROENDERECO$4);
            }
            target.set(numeroEndereco);
        }
    }
    
    /**
     * Unsets the "NumeroEndereco" element
     */
    public void unsetNumeroEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROENDERECO$4, 0);
        }
    }
    
    /**
     * Gets the "ComplementoEndereco" element
     */
    public java.lang.String getComplementoEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTOENDERECO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ComplementoEndereco" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco xgetComplementoEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco)get_store().find_element_user(COMPLEMENTOENDERECO$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "ComplementoEndereco" element
     */
    public boolean isSetComplementoEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMPLEMENTOENDERECO$6) != 0;
        }
    }
    
    /**
     * Sets the "ComplementoEndereco" element
     */
    public void setComplementoEndereco(java.lang.String complementoEndereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTOENDERECO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMPLEMENTOENDERECO$6);
            }
            target.setStringValue(complementoEndereco);
        }
    }
    
    /**
     * Sets (as xml) the "ComplementoEndereco" element
     */
    public void xsetComplementoEndereco(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco complementoEndereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco)get_store().find_element_user(COMPLEMENTOENDERECO$6, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco)get_store().add_element_user(COMPLEMENTOENDERECO$6);
            }
            target.set(complementoEndereco);
        }
    }
    
    /**
     * Unsets the "ComplementoEndereco" element
     */
    public void unsetComplementoEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMPLEMENTOENDERECO$6, 0);
        }
    }
    
    /**
     * Gets the "Bairro" element
     */
    public java.lang.String getBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro xgetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro)get_store().find_element_user(BAIRRO$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "Bairro" element
     */
    public boolean isSetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BAIRRO$8) != 0;
        }
    }
    
    /**
     * Sets the "Bairro" element
     */
    public void setBairro(java.lang.String bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BAIRRO$8);
            }
            target.setStringValue(bairro);
        }
    }
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    public void xsetBairro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro)get_store().find_element_user(BAIRRO$8, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro)get_store().add_element_user(BAIRRO$8);
            }
            target.set(bairro);
        }
    }
    
    /**
     * Unsets the "Bairro" element
     */
    public void unsetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BAIRRO$8, 0);
        }
    }
    
    /**
     * Gets the "Cidade" element
     */
    public int getCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$10, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade xgetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().find_element_user(CIDADE$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "Cidade" element
     */
    public boolean isSetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CIDADE$10) != 0;
        }
    }
    
    /**
     * Sets the "Cidade" element
     */
    public void setCidade(int cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CIDADE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CIDADE$10);
            }
            target.setIntValue(cidade);
        }
    }
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    public void xsetCidade(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade cidade)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().find_element_user(CIDADE$10, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().add_element_user(CIDADE$10);
            }
            target.set(cidade);
        }
    }
    
    /**
     * Unsets the "Cidade" element
     */
    public void unsetCidade()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CIDADE$10, 0);
        }
    }
    
    /**
     * Gets the "UF" element
     */
    public java.lang.String getUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "UF" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF xgetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF)get_store().find_element_user(UF$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "UF" element
     */
    public boolean isSetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UF$12) != 0;
        }
    }
    
    /**
     * Sets the "UF" element
     */
    public void setUF(java.lang.String uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$12);
            }
            target.setStringValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "UF" element
     */
    public void xsetUF(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF)get_store().find_element_user(UF$12, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF)get_store().add_element_user(UF$12);
            }
            target.set(uf);
        }
    }
    
    /**
     * Unsets the "UF" element
     */
    public void unsetUF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UF$12, 0);
        }
    }
    
    /**
     * Gets the "CEP" element
     */
    public java.lang.String getCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CEP" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP xgetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP)get_store().find_element_user(CEP$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "CEP" element
     */
    public boolean isSetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$14) != 0;
        }
    }
    
    /**
     * Sets the "CEP" element
     */
    public void setCEP(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$14);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "CEP" element
     */
    public void xsetCEP(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP)get_store().add_element_user(CEP$14);
            }
            target.set(cep);
        }
    }
    
    /**
     * Unsets the "CEP" element
     */
    public void unsetCEP()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$14, 0);
        }
    }
}
