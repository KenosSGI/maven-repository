/*
 * An XML document type.
 * Localname: PedidoConsultaNFePeriodo
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one PedidoConsultaNFePeriodo(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class PedidoConsultaNFePeriodoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedidoConsultaNFePeriodoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDOCONSULTANFEPERIODO$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "PedidoConsultaNFePeriodo");
    
    
    /**
     * Gets the "PedidoConsultaNFePeriodo" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo getPedidoConsultaNFePeriodo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo)get_store().find_element_user(PEDIDOCONSULTANFEPERIODO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PedidoConsultaNFePeriodo" element
     */
    public void setPedidoConsultaNFePeriodo(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo pedidoConsultaNFePeriodo)
    {
        generatedSetterHelperImpl(pedidoConsultaNFePeriodo, PEDIDOCONSULTANFEPERIODO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PedidoConsultaNFePeriodo" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo addNewPedidoConsultaNFePeriodo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo)get_store().add_element_user(PEDIDOCONSULTANFEPERIODO$0);
            return target;
        }
    }
    /**
     * An XML PedidoConsultaNFePeriodo(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class PedidoConsultaNFePeriodoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo
    {
        private static final long serialVersionUID = 1L;
        
        public PedidoConsultaNFePeriodoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName SIGNATURE$2 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
                return target;
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CPFCNPJREMETENTE$0 = 
                new javax.xml.namespace.QName("", "CPFCNPJRemetente");
            private static final javax.xml.namespace.QName CPFCNPJ$2 = 
                new javax.xml.namespace.QName("", "CPFCNPJ");
            private static final javax.xml.namespace.QName INSCRICAO$4 = 
                new javax.xml.namespace.QName("", "Inscricao");
            private static final javax.xml.namespace.QName DTINICIO$6 = 
                new javax.xml.namespace.QName("", "dtInicio");
            private static final javax.xml.namespace.QName DTFIM$8 = 
                new javax.xml.namespace.QName("", "dtFim");
            private static final javax.xml.namespace.QName NUMEROPAGINA$10 = 
                new javax.xml.namespace.QName("", "NumeroPagina");
            private static final javax.xml.namespace.QName VERSAO$12 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
            {
                generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "CPFCNPJ" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJ()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJ$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJ" element
             */
            public void setCPFCNPJ(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpj)
            {
                generatedSetterHelperImpl(cpfcnpj, CPFCNPJ$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJ" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJ()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJ$2);
                    return target;
                }
            }
            
            /**
             * Gets the "Inscricao" element
             */
            public long getInscricao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAO$4, 0);
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Inscricao" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAO$4, 0);
                    return target;
                }
            }
            
            /**
             * True if has "Inscricao" element
             */
            public boolean isSetInscricao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(INSCRICAO$4) != 0;
                }
            }
            
            /**
             * Sets the "Inscricao" element
             */
            public void setInscricao(long inscricao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAO$4, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAO$4);
                    }
                    target.setLongValue(inscricao);
                }
            }
            
            /**
             * Sets (as xml) the "Inscricao" element
             */
            public void xsetInscricao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAO$4, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAO$4);
                    }
                    target.set(inscricao);
                }
            }
            
            /**
             * Unsets the "Inscricao" element
             */
            public void unsetInscricao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(INSCRICAO$4, 0);
                }
            }
            
            /**
             * Gets the "dtInicio" element
             */
            public java.util.Calendar getDtInicio()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINICIO$6, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "dtInicio" element
             */
            public org.apache.xmlbeans.XmlDate xgetDtInicio()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTINICIO$6, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "dtInicio" element
             */
            public void setDtInicio(java.util.Calendar dtInicio)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINICIO$6, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTINICIO$6);
                    }
                    target.setCalendarValue(dtInicio);
                }
            }
            
            /**
             * Sets (as xml) the "dtInicio" element
             */
            public void xsetDtInicio(org.apache.xmlbeans.XmlDate dtInicio)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTINICIO$6, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DTINICIO$6);
                    }
                    target.set(dtInicio);
                }
            }
            
            /**
             * Gets the "dtFim" element
             */
            public java.util.Calendar getDtFim()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$8, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "dtFim" element
             */
            public org.apache.xmlbeans.XmlDate xgetDtFim()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTFIM$8, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "dtFim" element
             */
            public void setDtFim(java.util.Calendar dtFim)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$8, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTFIM$8);
                    }
                    target.setCalendarValue(dtFim);
                }
            }
            
            /**
             * Sets (as xml) the "dtFim" element
             */
            public void xsetDtFim(org.apache.xmlbeans.XmlDate dtFim)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTFIM$8, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DTFIM$8);
                    }
                    target.set(dtFim);
                }
            }
            
            /**
             * Gets the "NumeroPagina" element
             */
            public long getNumeroPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPAGINA$10, 0);
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "NumeroPagina" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMEROPAGINA$10, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "NumeroPagina" element
             */
            public void setNumeroPagina(long numeroPagina)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPAGINA$10, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROPAGINA$10);
                    }
                    target.setLongValue(numeroPagina);
                }
            }
            
            /**
             * Sets (as xml) the "NumeroPagina" element
             */
            public void xsetNumeroPagina(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroPagina)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMEROPAGINA$10, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(NUMEROPAGINA$10);
                    }
                    target.set(numeroPagina);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$12);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$12);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$12);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$12);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$12);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$12);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$12);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$12);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
