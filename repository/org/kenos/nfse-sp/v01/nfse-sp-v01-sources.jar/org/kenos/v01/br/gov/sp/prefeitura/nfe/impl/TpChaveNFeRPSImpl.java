/*
 * XML Type:  tpChaveNFeRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpChaveNFeRPS(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpChaveNFeRPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS
{
    private static final long serialVersionUID = 1L;
    
    public TpChaveNFeRPSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHAVENFE$0 = 
        new javax.xml.namespace.QName("", "ChaveNFe");
    private static final javax.xml.namespace.QName CHAVERPS$2 = 
        new javax.xml.namespace.QName("", "ChaveRPS");
    
    
    /**
     * Gets the "ChaveNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().find_element_user(CHAVENFE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ChaveNFe" element
     */
    public void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe)
    {
        generatedSetterHelperImpl(chaveNFe, CHAVENFE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ChaveNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().add_element_user(CHAVENFE$0);
            return target;
        }
    }
    
    /**
     * Gets the "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().find_element_user(CHAVERPS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ChaveRPS" element
     */
    public void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS)
    {
        generatedSetterHelperImpl(chaveRPS, CHAVERPS$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().add_element_user(CHAVERPS$2);
            return target;
        }
    }
}
