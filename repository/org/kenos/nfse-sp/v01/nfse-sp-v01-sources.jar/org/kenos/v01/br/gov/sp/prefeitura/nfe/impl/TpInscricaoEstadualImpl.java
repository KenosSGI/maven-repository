/*
 * XML Type:  tpInscricaoEstadual
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpInscricaoEstadual(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual.
 */
public class TpInscricaoEstadualImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual
{
    private static final long serialVersionUID = 1L;
    
    public TpInscricaoEstadualImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpInscricaoEstadualImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
