/*
 * An XML document type.
 * Localname: RetornoEnvioLoteRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one RetornoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface RetornoEnvioLoteRPSDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetornoEnvioLoteRPSDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("retornoenvioloterps82cbdoctype");
    
    /**
     * Gets the "RetornoEnvioLoteRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS getRetornoEnvioLoteRPS();
    
    /**
     * Sets the "RetornoEnvioLoteRPS" element
     */
    void setRetornoEnvioLoteRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS retornoEnvioLoteRPS);
    
    /**
     * Appends and returns a new empty "RetornoEnvioLoteRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS addNewRetornoEnvioLoteRPS();
    
    /**
     * An XML RetornoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface RetornoEnvioLoteRPS extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetornoEnvioLoteRPS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("retornoenvioloterpsb1caelemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho addNewCabecalho();
        
        /**
         * Gets array of all "Alerta" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getAlertaArray();
        
        /**
         * Gets ith "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getAlertaArray(int i);
        
        /**
         * Returns number of "Alerta" element
         */
        int sizeOfAlertaArray();
        
        /**
         * Sets array of all "Alerta" element
         */
        void setAlertaArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] alertaArray);
        
        /**
         * Sets ith "Alerta" element
         */
        void setAlertaArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento alerta);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewAlerta(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewAlerta();
        
        /**
         * Removes the ith "Alerta" element
         */
        void removeAlerta(int i);
        
        /**
         * Gets array of all "Erro" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getErroArray();
        
        /**
         * Gets ith "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getErroArray(int i);
        
        /**
         * Returns number of "Erro" element
         */
        int sizeOfErroArray();
        
        /**
         * Sets array of all "Erro" element
         */
        void setErroArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] erroArray);
        
        /**
         * Sets ith "Erro" element
         */
        void setErroArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento erro);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewErro(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewErro();
        
        /**
         * Removes the ith "Erro" element
         */
        void removeErro(int i);
        
        /**
         * Gets array of all "ChaveNFeRPS" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS[] getChaveNFeRPSArray();
        
        /**
         * Gets ith "ChaveNFeRPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS getChaveNFeRPSArray(int i);
        
        /**
         * Returns number of "ChaveNFeRPS" element
         */
        int sizeOfChaveNFeRPSArray();
        
        /**
         * Sets array of all "ChaveNFeRPS" element
         */
        void setChaveNFeRPSArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS[] chaveNFeRPSArray);
        
        /**
         * Sets ith "ChaveNFeRPS" element
         */
        void setChaveNFeRPSArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS chaveNFeRPS);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ChaveNFeRPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS insertNewChaveNFeRPS(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ChaveNFeRPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS addNewChaveNFeRPS();
        
        /**
         * Removes the ith "ChaveNFeRPS" element
         */
        void removeChaveNFeRPS(int i);
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalho24faelemtype");
            
            /**
             * Gets the "Sucesso" element
             */
            boolean getSucesso();
            
            /**
             * Gets (as xml) the "Sucesso" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso xgetSucesso();
            
            /**
             * Sets the "Sucesso" element
             */
            void setSucesso(boolean sucesso);
            
            /**
             * Sets (as xml) the "Sucesso" element
             */
            void xsetSucesso(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso sucesso);
            
            /**
             * Gets the "InformacoesLote" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote getInformacoesLote();
            
            /**
             * True if has "InformacoesLote" element
             */
            boolean isSetInformacoesLote();
            
            /**
             * Sets the "InformacoesLote" element
             */
            void setInformacoesLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote informacoesLote);
            
            /**
             * Appends and returns a new empty "InformacoesLote" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote addNewInformacoesLote();
            
            /**
             * Unsets the "InformacoesLote" element
             */
            void unsetInformacoesLote();
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument.RetornoEnvioLoteRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
