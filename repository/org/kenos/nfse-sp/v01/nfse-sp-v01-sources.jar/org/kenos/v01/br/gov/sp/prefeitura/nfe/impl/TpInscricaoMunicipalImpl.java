/*
 * XML Type:  tpInscricaoMunicipal
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpInscricaoMunicipal(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal.
 */
public class TpInscricaoMunicipalImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal
{
    private static final long serialVersionUID = 1L;
    
    public TpInscricaoMunicipalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpInscricaoMunicipalImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
