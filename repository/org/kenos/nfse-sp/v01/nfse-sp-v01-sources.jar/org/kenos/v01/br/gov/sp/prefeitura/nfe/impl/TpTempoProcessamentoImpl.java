/*
 * XML Type:  tpTempoProcessamento
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpTempoProcessamento(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento.
 */
public class TpTempoProcessamentoImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento
{
    private static final long serialVersionUID = 1L;
    
    public TpTempoProcessamentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpTempoProcessamentoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
