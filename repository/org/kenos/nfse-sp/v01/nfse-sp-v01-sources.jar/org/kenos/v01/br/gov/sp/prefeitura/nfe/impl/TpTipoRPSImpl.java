/*
 * XML Type:  tpTipoRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpTipoRPS(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.
 */
public class TpTipoRPSImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS
{
    private static final long serialVersionUID = 1L;
    
    public TpTipoRPSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpTipoRPSImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
