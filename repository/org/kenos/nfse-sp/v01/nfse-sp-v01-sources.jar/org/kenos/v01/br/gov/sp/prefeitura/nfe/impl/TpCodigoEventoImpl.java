/*
 * XML Type:  tpCodigoEvento
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpCodigoEvento(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento.
 */
public class TpCodigoEventoImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento
{
    private static final long serialVersionUID = 1L;
    
    public TpCodigoEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpCodigoEventoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
