/*
 * An XML document type.
 * Localname: PedidoConsultaNFePeriodo
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one PedidoConsultaNFePeriodo(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface PedidoConsultaNFePeriodoDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoConsultaNFePeriodoDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoconsultanfeperiodob965doctype");
    
    /**
     * Gets the "PedidoConsultaNFePeriodo" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo getPedidoConsultaNFePeriodo();
    
    /**
     * Sets the "PedidoConsultaNFePeriodo" element
     */
    void setPedidoConsultaNFePeriodo(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo pedidoConsultaNFePeriodo);
    
    /**
     * Appends and returns a new empty "PedidoConsultaNFePeriodo" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo addNewPedidoConsultaNFePeriodo();
    
    /**
     * An XML PedidoConsultaNFePeriodo(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface PedidoConsultaNFePeriodo extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoConsultaNFePeriodo.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoconsultanfeperiodof18eelemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho addNewCabecalho();
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalho28beelemtype");
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
            
            /**
             * Gets the "CPFCNPJ" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJ();
            
            /**
             * Sets the "CPFCNPJ" element
             */
            void setCPFCNPJ(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpj);
            
            /**
             * Appends and returns a new empty "CPFCNPJ" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJ();
            
            /**
             * Gets the "Inscricao" element
             */
            long getInscricao();
            
            /**
             * Gets (as xml) the "Inscricao" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricao();
            
            /**
             * True if has "Inscricao" element
             */
            boolean isSetInscricao();
            
            /**
             * Sets the "Inscricao" element
             */
            void setInscricao(long inscricao);
            
            /**
             * Sets (as xml) the "Inscricao" element
             */
            void xsetInscricao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricao);
            
            /**
             * Unsets the "Inscricao" element
             */
            void unsetInscricao();
            
            /**
             * Gets the "dtInicio" element
             */
            java.util.Calendar getDtInicio();
            
            /**
             * Gets (as xml) the "dtInicio" element
             */
            org.apache.xmlbeans.XmlDate xgetDtInicio();
            
            /**
             * Sets the "dtInicio" element
             */
            void setDtInicio(java.util.Calendar dtInicio);
            
            /**
             * Sets (as xml) the "dtInicio" element
             */
            void xsetDtInicio(org.apache.xmlbeans.XmlDate dtInicio);
            
            /**
             * Gets the "dtFim" element
             */
            java.util.Calendar getDtFim();
            
            /**
             * Gets (as xml) the "dtFim" element
             */
            org.apache.xmlbeans.XmlDate xgetDtFim();
            
            /**
             * Sets the "dtFim" element
             */
            void setDtFim(java.util.Calendar dtFim);
            
            /**
             * Sets (as xml) the "dtFim" element
             */
            void xsetDtFim(org.apache.xmlbeans.XmlDate dtFim);
            
            /**
             * Gets the "NumeroPagina" element
             */
            long getNumeroPagina();
            
            /**
             * Gets (as xml) the "NumeroPagina" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroPagina();
            
            /**
             * Sets the "NumeroPagina" element
             */
            void setNumeroPagina(long numeroPagina);
            
            /**
             * Sets (as xml) the "NumeroPagina" element
             */
            void xsetNumeroPagina(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroPagina);
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument.PedidoConsultaNFePeriodo) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFePeriodoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
