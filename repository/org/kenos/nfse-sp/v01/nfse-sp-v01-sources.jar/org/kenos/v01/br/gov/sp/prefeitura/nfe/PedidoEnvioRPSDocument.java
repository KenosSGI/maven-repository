/*
 * An XML document type.
 * Localname: PedidoEnvioRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one PedidoEnvioRPS(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface PedidoEnvioRPSDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoEnvioRPSDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoenviorpsfef1doctype");
    
    /**
     * Gets the "PedidoEnvioRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS getPedidoEnvioRPS();
    
    /**
     * Sets the "PedidoEnvioRPS" element
     */
    void setPedidoEnvioRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS pedidoEnvioRPS);
    
    /**
     * Appends and returns a new empty "PedidoEnvioRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS addNewPedidoEnvioRPS();
    
    /**
     * An XML PedidoEnvioRPS(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface PedidoEnvioRPS extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoEnvioRPS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoenviorps578eelemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho addNewCabecalho();
        
        /**
         * Gets the "RPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS getRPS();
        
        /**
         * Sets the "RPS" element
         */
        void setRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS rps);
        
        /**
         * Appends and returns a new empty "RPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS addNewRPS();
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalho06beelemtype");
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument.PedidoEnvioRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
