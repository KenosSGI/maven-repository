/*
 * XML Type:  tpDiscriminacao
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpDiscriminacao(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao.
 */
public class TpDiscriminacaoImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao
{
    private static final long serialVersionUID = 1L;
    
    public TpDiscriminacaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpDiscriminacaoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
