/*
 * An XML document type.
 * Localname: RetornoConsulta
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one RetornoConsulta(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class RetornoConsultaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument
{
    private static final long serialVersionUID = 1L;
    
    public RetornoConsultaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETORNOCONSULTA$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "RetornoConsulta");
    
    
    /**
     * Gets the "RetornoConsulta" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta getRetornoConsulta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta)get_store().find_element_user(RETORNOCONSULTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "RetornoConsulta" element
     */
    public void setRetornoConsulta(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta retornoConsulta)
    {
        generatedSetterHelperImpl(retornoConsulta, RETORNOCONSULTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "RetornoConsulta" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta addNewRetornoConsulta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta)get_store().add_element_user(RETORNOCONSULTA$0);
            return target;
        }
    }
    /**
     * An XML RetornoConsulta(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class RetornoConsultaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta
    {
        private static final long serialVersionUID = 1L;
        
        public RetornoConsultaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName ALERTA$2 = 
            new javax.xml.namespace.QName("", "Alerta");
        private static final javax.xml.namespace.QName ERRO$4 = 
            new javax.xml.namespace.QName("", "Erro");
        private static final javax.xml.namespace.QName NFE$6 = 
            new javax.xml.namespace.QName("", "NFe");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "Alerta" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ALERTA$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getAlertaArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ALERTA$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Alerta" element
         */
        public int sizeOfAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ALERTA$2);
            }
        }
        
        /**
         * Sets array of all "Alerta" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setAlertaArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] alertaArray)
        {
            check_orphaned();
            arraySetterHelper(alertaArray, ALERTA$2);
        }
        
        /**
         * Sets ith "Alerta" element
         */
        public void setAlertaArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento alerta)
        {
            generatedSetterHelperImpl(alerta, ALERTA$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ALERTA$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewAlerta()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ALERTA$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "Alerta" element
         */
        public void removeAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ALERTA$2, i);
            }
        }
        
        /**
         * Gets array of all "Erro" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ERRO$4, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getErroArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ERRO$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Erro" element
         */
        public int sizeOfErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRO$4);
            }
        }
        
        /**
         * Sets array of all "Erro" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setErroArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] erroArray)
        {
            check_orphaned();
            arraySetterHelper(erroArray, ERRO$4);
        }
        
        /**
         * Sets ith "Erro" element
         */
        public void setErroArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento erro)
        {
            generatedSetterHelperImpl(erro, ERRO$4, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ERRO$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewErro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ERRO$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "Erro" element
         */
        public void removeErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRO$4, i);
            }
        }
        
        /**
         * Gets array of all "NFe" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe[] getNFeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(NFE$6, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "NFe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe getNFeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe)get_store().find_element_user(NFE$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "NFe" element
         */
        public int sizeOfNFeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NFE$6);
            }
        }
        
        /**
         * Sets array of all "NFe" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setNFeArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe[] nFeArray)
        {
            check_orphaned();
            arraySetterHelper(nFeArray, NFE$6);
        }
        
        /**
         * Sets ith "NFe" element
         */
        public void setNFeArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe nFe)
        {
            generatedSetterHelperImpl(nFe, NFE$6, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "NFe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe insertNewNFe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe)get_store().insert_element_user(NFE$6, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "NFe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe addNewNFe()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe)get_store().add_element_user(NFE$6);
                return target;
            }
        }
        
        /**
         * Removes the ith "NFe" element
         */
        public void removeNFe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NFE$6, i);
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaDocument.RetornoConsulta.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName SUCESSO$0 = 
                new javax.xml.namespace.QName("", "Sucesso");
            private static final javax.xml.namespace.QName VERSAO$2 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "Sucesso" element
             */
            public boolean getSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      return false;
                    }
                    return target.getBooleanValue();
                }
            }
            
            /**
             * Gets (as xml) the "Sucesso" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso xgetSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "Sucesso" element
             */
            public void setSucesso(boolean sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUCESSO$0);
                    }
                    target.setBooleanValue(sucesso);
                }
            }
            
            /**
             * Sets (as xml) the "Sucesso" element
             */
            public void xsetSucesso(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().add_element_user(SUCESSO$0);
                    }
                    target.set(sucesso);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$2);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$2);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
