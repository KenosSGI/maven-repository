/*
 * XML Type:  tpEvento
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * An XML tpEvento(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public interface TpEvento extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TpEvento.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("tpeventoe95btype");
    
    /**
     * Gets the "Codigo" element
     */
    short getCodigo();
    
    /**
     * Gets (as xml) the "Codigo" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento xgetCodigo();
    
    /**
     * Sets the "Codigo" element
     */
    void setCodigo(short codigo);
    
    /**
     * Sets (as xml) the "Codigo" element
     */
    void xsetCodigo(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento codigo);
    
    /**
     * Gets the "Descricao" element
     */
    java.lang.String getDescricao();
    
    /**
     * Gets (as xml) the "Descricao" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento xgetDescricao();
    
    /**
     * True if has "Descricao" element
     */
    boolean isSetDescricao();
    
    /**
     * Sets the "Descricao" element
     */
    void setDescricao(java.lang.String descricao);
    
    /**
     * Sets (as xml) the "Descricao" element
     */
    void xsetDescricao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento descricao);
    
    /**
     * Unsets the "Descricao" element
     */
    void unsetDescricao();
    
    /**
     * Gets the "ChaveRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS();
    
    /**
     * True if has "ChaveRPS" element
     */
    boolean isSetChaveRPS();
    
    /**
     * Sets the "ChaveRPS" element
     */
    void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS);
    
    /**
     * Appends and returns a new empty "ChaveRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS();
    
    /**
     * Unsets the "ChaveRPS" element
     */
    void unsetChaveRPS();
    
    /**
     * Gets the "ChaveNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe();
    
    /**
     * True if has "ChaveNFe" element
     */
    boolean isSetChaveNFe();
    
    /**
     * Sets the "ChaveNFe" element
     */
    void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe);
    
    /**
     * Appends and returns a new empty "ChaveNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe();
    
    /**
     * Unsets the "ChaveNFe" element
     */
    void unsetChaveNFe();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
