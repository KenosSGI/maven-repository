/*
 * An XML document type.
 * Localname: PedidoInformacoesLote
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one PedidoInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface PedidoInformacoesLoteDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoInformacoesLoteDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoinformacoesloteeb19doctype");
    
    /**
     * Gets the "PedidoInformacoesLote" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote getPedidoInformacoesLote();
    
    /**
     * Sets the "PedidoInformacoesLote" element
     */
    void setPedidoInformacoesLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote pedidoInformacoesLote);
    
    /**
     * Appends and returns a new empty "PedidoInformacoesLote" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote addNewPedidoInformacoesLote();
    
    /**
     * An XML PedidoInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface PedidoInformacoesLote extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoInformacoesLote.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoinformacoesloteb866elemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho addNewCabecalho();
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalho1396elemtype");
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
            
            /**
             * Gets the "NumeroLote" element
             */
            long getNumeroLote();
            
            /**
             * Gets (as xml) the "NumeroLote" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroLote();
            
            /**
             * True if has "NumeroLote" element
             */
            boolean isSetNumeroLote();
            
            /**
             * Sets the "NumeroLote" element
             */
            void setNumeroLote(long numeroLote);
            
            /**
             * Sets (as xml) the "NumeroLote" element
             */
            void xsetNumeroLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroLote);
            
            /**
             * Unsets the "NumeroLote" element
             */
            void unsetNumeroLote();
            
            /**
             * Gets the "InscricaoPrestador" element
             */
            long getInscricaoPrestador();
            
            /**
             * Gets (as xml) the "InscricaoPrestador" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoPrestador();
            
            /**
             * Sets the "InscricaoPrestador" element
             */
            void setInscricaoPrestador(long inscricaoPrestador);
            
            /**
             * Sets (as xml) the "InscricaoPrestador" element
             */
            void xsetInscricaoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoPrestador);
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument.PedidoInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoInformacoesLoteDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
