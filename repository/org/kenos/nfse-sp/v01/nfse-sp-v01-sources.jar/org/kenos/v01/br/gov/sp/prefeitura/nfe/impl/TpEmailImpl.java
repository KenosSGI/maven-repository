/*
 * XML Type:  tpEmail
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpEmail(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail.
 */
public class TpEmailImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail
{
    private static final long serialVersionUID = 1L;
    
    public TpEmailImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpEmailImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
