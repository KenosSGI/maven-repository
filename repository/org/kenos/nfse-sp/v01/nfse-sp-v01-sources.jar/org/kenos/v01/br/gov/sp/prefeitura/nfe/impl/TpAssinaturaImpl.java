/*
 * XML Type:  tpAssinatura
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpAssinatura(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura.
 */
public class TpAssinaturaImpl extends org.apache.xmlbeans.impl.values.JavaBase64HolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura
{
    private static final long serialVersionUID = 1L;
    
    public TpAssinaturaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpAssinaturaImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
