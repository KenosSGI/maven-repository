/*
 * XML Type:  tpInformacoesLote
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpInformacoesLoteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote
{
    private static final long serialVersionUID = 1L;
    
    public TpInformacoesLoteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMEROLOTE$0 = 
        new javax.xml.namespace.QName("", "NumeroLote");
    private static final javax.xml.namespace.QName INSCRICAOPRESTADOR$2 = 
        new javax.xml.namespace.QName("", "InscricaoPrestador");
    private static final javax.xml.namespace.QName CPFCNPJREMETENTE$4 = 
        new javax.xml.namespace.QName("", "CPFCNPJRemetente");
    private static final javax.xml.namespace.QName DATAENVIOLOTE$6 = 
        new javax.xml.namespace.QName("", "DataEnvioLote");
    private static final javax.xml.namespace.QName QTDNOTASPROCESSADAS$8 = 
        new javax.xml.namespace.QName("", "QtdNotasProcessadas");
    private static final javax.xml.namespace.QName TEMPOPROCESSAMENTO$10 = 
        new javax.xml.namespace.QName("", "TempoProcessamento");
    private static final javax.xml.namespace.QName VALORTOTALSERVICOS$12 = 
        new javax.xml.namespace.QName("", "ValorTotalServicos");
    private static final javax.xml.namespace.QName VALORTOTALDEDUCOES$14 = 
        new javax.xml.namespace.QName("", "ValorTotalDeducoes");
    
    
    /**
     * Gets the "NumeroLote" element
     */
    public long getNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroLote" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMEROLOTE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "NumeroLote" element
     */
    public boolean isSetNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROLOTE$0) != 0;
        }
    }
    
    /**
     * Sets the "NumeroLote" element
     */
    public void setNumeroLote(long numeroLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROLOTE$0);
            }
            target.setLongValue(numeroLote);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroLote" element
     */
    public void xsetNumeroLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(NUMEROLOTE$0);
            }
            target.set(numeroLote);
        }
    }
    
    /**
     * Unsets the "NumeroLote" element
     */
    public void unsetNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROLOTE$0, 0);
        }
    }
    
    /**
     * Gets the "InscricaoPrestador" element
     */
    public long getInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$2, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoPrestador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "InscricaoPrestador" element
     */
    public void setInscricaoPrestador(long inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOPRESTADOR$2);
            }
            target.setLongValue(inscricaoPrestador);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoPrestador" element
     */
    public void xsetInscricaoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAOPRESTADOR$2);
            }
            target.set(inscricaoPrestador);
        }
    }
    
    /**
     * Gets the "CPFCNPJRemetente" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CPFCNPJRemetente" element
     */
    public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
    {
        generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CPFCNPJRemetente" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$4);
            return target;
        }
    }
    
    /**
     * Gets the "DataEnvioLote" element
     */
    public java.util.Calendar getDataEnvioLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAENVIOLOTE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataEnvioLote" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataEnvioLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAENVIOLOTE$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "DataEnvioLote" element
     */
    public void setDataEnvioLote(java.util.Calendar dataEnvioLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAENVIOLOTE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAENVIOLOTE$6);
            }
            target.setCalendarValue(dataEnvioLote);
        }
    }
    
    /**
     * Sets (as xml) the "DataEnvioLote" element
     */
    public void xsetDataEnvioLote(org.apache.xmlbeans.XmlDateTime dataEnvioLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAENVIOLOTE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAENVIOLOTE$6);
            }
            target.set(dataEnvioLote);
        }
    }
    
    /**
     * Gets the "QtdNotasProcessadas" element
     */
    public long getQtdNotasProcessadas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDNOTASPROCESSADAS$8, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "QtdNotasProcessadas" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade xgetQtdNotasProcessadas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().find_element_user(QTDNOTASPROCESSADAS$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "QtdNotasProcessadas" element
     */
    public void setQtdNotasProcessadas(long qtdNotasProcessadas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDNOTASPROCESSADAS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(QTDNOTASPROCESSADAS$8);
            }
            target.setLongValue(qtdNotasProcessadas);
        }
    }
    
    /**
     * Sets (as xml) the "QtdNotasProcessadas" element
     */
    public void xsetQtdNotasProcessadas(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade qtdNotasProcessadas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().find_element_user(QTDNOTASPROCESSADAS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().add_element_user(QTDNOTASPROCESSADAS$8);
            }
            target.set(qtdNotasProcessadas);
        }
    }
    
    /**
     * Gets the "TempoProcessamento" element
     */
    public long getTempoProcessamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPOPROCESSAMENTO$10, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "TempoProcessamento" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento xgetTempoProcessamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento)get_store().find_element_user(TEMPOPROCESSAMENTO$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "TempoProcessamento" element
     */
    public void setTempoProcessamento(long tempoProcessamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPOPROCESSAMENTO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TEMPOPROCESSAMENTO$10);
            }
            target.setLongValue(tempoProcessamento);
        }
    }
    
    /**
     * Sets (as xml) the "TempoProcessamento" element
     */
    public void xsetTempoProcessamento(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento tempoProcessamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento)get_store().find_element_user(TEMPOPROCESSAMENTO$10, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento)get_store().add_element_user(TEMPOPROCESSAMENTO$10);
            }
            target.set(tempoProcessamento);
        }
    }
    
    /**
     * Gets the "ValorTotalServicos" element
     */
    public java.math.BigDecimal getValorTotalServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALSERVICOS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorTotalServicos" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALSERVICOS$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ValorTotalServicos" element
     */
    public void setValorTotalServicos(java.math.BigDecimal valorTotalServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALSERVICOS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORTOTALSERVICOS$12);
            }
            target.setBigDecimalValue(valorTotalServicos);
        }
    }
    
    /**
     * Sets (as xml) the "ValorTotalServicos" element
     */
    public void xsetValorTotalServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALSERVICOS$12, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORTOTALSERVICOS$12);
            }
            target.set(valorTotalServicos);
        }
    }
    
    /**
     * Gets the "ValorTotalDeducoes" element
     */
    public java.math.BigDecimal getValorTotalDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALDEDUCOES$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorTotalDeducoes" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALDEDUCOES$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorTotalDeducoes" element
     */
    public boolean isSetValorTotalDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORTOTALDEDUCOES$14) != 0;
        }
    }
    
    /**
     * Sets the "ValorTotalDeducoes" element
     */
    public void setValorTotalDeducoes(java.math.BigDecimal valorTotalDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALDEDUCOES$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORTOTALDEDUCOES$14);
            }
            target.setBigDecimalValue(valorTotalDeducoes);
        }
    }
    
    /**
     * Sets (as xml) the "ValorTotalDeducoes" element
     */
    public void xsetValorTotalDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALDEDUCOES$14, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORTOTALDEDUCOES$14);
            }
            target.set(valorTotalDeducoes);
        }
    }
    
    /**
     * Unsets the "ValorTotalDeducoes" element
     */
    public void unsetValorTotalDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORTOTALDEDUCOES$14, 0);
        }
    }
}
