/*
 * XML Type:  tpLogradouro
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpLogradouro(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro.
 */
public class TpLogradouroImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro
{
    private static final long serialVersionUID = 1L;
    
    public TpLogradouroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpLogradouroImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
