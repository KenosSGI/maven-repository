/*
 * An XML document type.
 * Localname: PedidoCancelamentoNFe
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one PedidoCancelamentoNFe(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class PedidoCancelamentoNFeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedidoCancelamentoNFeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDOCANCELAMENTONFE$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "PedidoCancelamentoNFe");
    
    
    /**
     * Gets the "PedidoCancelamentoNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe getPedidoCancelamentoNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe)get_store().find_element_user(PEDIDOCANCELAMENTONFE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PedidoCancelamentoNFe" element
     */
    public void setPedidoCancelamentoNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe pedidoCancelamentoNFe)
    {
        generatedSetterHelperImpl(pedidoCancelamentoNFe, PEDIDOCANCELAMENTONFE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PedidoCancelamentoNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe addNewPedidoCancelamentoNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe)get_store().add_element_user(PEDIDOCANCELAMENTONFE$0);
            return target;
        }
    }
    /**
     * An XML PedidoCancelamentoNFe(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class PedidoCancelamentoNFeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe
    {
        private static final long serialVersionUID = 1L;
        
        public PedidoCancelamentoNFeImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName DETALHE$2 = 
            new javax.xml.namespace.QName("", "Detalhe");
        private static final javax.xml.namespace.QName SIGNATURE$4 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "Detalhe" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe[] getDetalheArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(DETALHE$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe getDetalheArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe)get_store().find_element_user(DETALHE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Detalhe" element
         */
        public int sizeOfDetalheArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DETALHE$2);
            }
        }
        
        /**
         * Sets array of all "Detalhe" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setDetalheArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe[] detalheArray)
        {
            check_orphaned();
            arraySetterHelper(detalheArray, DETALHE$2);
        }
        
        /**
         * Sets ith "Detalhe" element
         */
        public void setDetalheArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe detalhe)
        {
            generatedSetterHelperImpl(detalhe, DETALHE$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe insertNewDetalhe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe)get_store().insert_element_user(DETALHE$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe addNewDetalhe()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe)get_store().add_element_user(DETALHE$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "Detalhe" element
         */
        public void removeDetalhe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DETALHE$2, i);
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$4);
                return target;
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CPFCNPJREMETENTE$0 = 
                new javax.xml.namespace.QName("", "CPFCNPJRemetente");
            private static final javax.xml.namespace.QName TRANSACAO$2 = 
                new javax.xml.namespace.QName("", "transacao");
            private static final javax.xml.namespace.QName VERSAO$4 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
            {
                generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "transacao" element
             */
            public boolean getTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      return false;
                    }
                    return target.getBooleanValue();
                }
            }
            
            /**
             * Gets (as xml) the "transacao" element
             */
            public org.apache.xmlbeans.XmlBoolean xgetTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlBoolean target = null;
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRANSACAO$2, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "transacao" element
             */
            public void setTransacao(boolean transacao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRANSACAO$2);
                    }
                    target.setBooleanValue(transacao);
                }
            }
            
            /**
             * Sets (as xml) the "transacao" element
             */
            public void xsetTransacao(org.apache.xmlbeans.XmlBoolean transacao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlBoolean target = null;
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(TRANSACAO$2);
                    }
                    target.set(transacao);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$4);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$4);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$4);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$4);
                    }
                    target.set(versao);
                }
            }
        }
        /**
         * An XML Detalhe(@).
         *
         * This is a complex type.
         */
        public static class DetalheImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoCancelamentoNFeDocument.PedidoCancelamentoNFe.Detalhe
        {
            private static final long serialVersionUID = 1L;
            
            public DetalheImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CHAVENFE$0 = 
                new javax.xml.namespace.QName("", "ChaveNFe");
            private static final javax.xml.namespace.QName ASSINATURACANCELAMENTO$2 = 
                new javax.xml.namespace.QName("", "AssinaturaCancelamento");
            
            
            /**
             * Gets the "ChaveNFe" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().find_element_user(CHAVENFE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "ChaveNFe" element
             */
            public void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe)
            {
                generatedSetterHelperImpl(chaveNFe, CHAVENFE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ChaveNFe" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().add_element_user(CHAVENFE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "AssinaturaCancelamento" element
             */
            public byte[] getAssinaturaCancelamento()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASSINATURACANCELAMENTO$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getByteArrayValue();
                }
            }
            
            /**
             * Gets (as xml) the "AssinaturaCancelamento" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento xgetAssinaturaCancelamento()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento)get_store().find_element_user(ASSINATURACANCELAMENTO$2, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "AssinaturaCancelamento" element
             */
            public void setAssinaturaCancelamento(byte[] assinaturaCancelamento)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASSINATURACANCELAMENTO$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASSINATURACANCELAMENTO$2);
                    }
                    target.setByteArrayValue(assinaturaCancelamento);
                }
            }
            
            /**
             * Sets (as xml) the "AssinaturaCancelamento" element
             */
            public void xsetAssinaturaCancelamento(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento assinaturaCancelamento)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento)get_store().find_element_user(ASSINATURACANCELAMENTO$2, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinaturaCancelamento)get_store().add_element_user(ASSINATURACANCELAMENTO$2);
                    }
                    target.set(assinaturaCancelamento);
                }
            }
        }
    }
}
