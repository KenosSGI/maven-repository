/*
 * XML Type:  tpInformacoesLote
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * An XML tpInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public interface TpInformacoesLote extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TpInformacoesLote.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("tpinformacoeslote09a2type");
    
    /**
     * Gets the "NumeroLote" element
     */
    long getNumeroLote();
    
    /**
     * Gets (as xml) the "NumeroLote" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroLote();
    
    /**
     * True if has "NumeroLote" element
     */
    boolean isSetNumeroLote();
    
    /**
     * Sets the "NumeroLote" element
     */
    void setNumeroLote(long numeroLote);
    
    /**
     * Sets (as xml) the "NumeroLote" element
     */
    void xsetNumeroLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroLote);
    
    /**
     * Unsets the "NumeroLote" element
     */
    void unsetNumeroLote();
    
    /**
     * Gets the "InscricaoPrestador" element
     */
    long getInscricaoPrestador();
    
    /**
     * Gets (as xml) the "InscricaoPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoPrestador();
    
    /**
     * Sets the "InscricaoPrestador" element
     */
    void setInscricaoPrestador(long inscricaoPrestador);
    
    /**
     * Sets (as xml) the "InscricaoPrestador" element
     */
    void xsetInscricaoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoPrestador);
    
    /**
     * Gets the "CPFCNPJRemetente" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
    
    /**
     * Sets the "CPFCNPJRemetente" element
     */
    void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
    
    /**
     * Appends and returns a new empty "CPFCNPJRemetente" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
    
    /**
     * Gets the "DataEnvioLote" element
     */
    java.util.Calendar getDataEnvioLote();
    
    /**
     * Gets (as xml) the "DataEnvioLote" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataEnvioLote();
    
    /**
     * Sets the "DataEnvioLote" element
     */
    void setDataEnvioLote(java.util.Calendar dataEnvioLote);
    
    /**
     * Sets (as xml) the "DataEnvioLote" element
     */
    void xsetDataEnvioLote(org.apache.xmlbeans.XmlDateTime dataEnvioLote);
    
    /**
     * Gets the "QtdNotasProcessadas" element
     */
    long getQtdNotasProcessadas();
    
    /**
     * Gets (as xml) the "QtdNotasProcessadas" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade xgetQtdNotasProcessadas();
    
    /**
     * Sets the "QtdNotasProcessadas" element
     */
    void setQtdNotasProcessadas(long qtdNotasProcessadas);
    
    /**
     * Sets (as xml) the "QtdNotasProcessadas" element
     */
    void xsetQtdNotasProcessadas(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade qtdNotasProcessadas);
    
    /**
     * Gets the "TempoProcessamento" element
     */
    long getTempoProcessamento();
    
    /**
     * Gets (as xml) the "TempoProcessamento" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento xgetTempoProcessamento();
    
    /**
     * Sets the "TempoProcessamento" element
     */
    void setTempoProcessamento(long tempoProcessamento);
    
    /**
     * Sets (as xml) the "TempoProcessamento" element
     */
    void xsetTempoProcessamento(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTempoProcessamento tempoProcessamento);
    
    /**
     * Gets the "ValorTotalServicos" element
     */
    java.math.BigDecimal getValorTotalServicos();
    
    /**
     * Gets (as xml) the "ValorTotalServicos" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalServicos();
    
    /**
     * Sets the "ValorTotalServicos" element
     */
    void setValorTotalServicos(java.math.BigDecimal valorTotalServicos);
    
    /**
     * Sets (as xml) the "ValorTotalServicos" element
     */
    void xsetValorTotalServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalServicos);
    
    /**
     * Gets the "ValorTotalDeducoes" element
     */
    java.math.BigDecimal getValorTotalDeducoes();
    
    /**
     * Gets (as xml) the "ValorTotalDeducoes" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalDeducoes();
    
    /**
     * True if has "ValorTotalDeducoes" element
     */
    boolean isSetValorTotalDeducoes();
    
    /**
     * Sets the "ValorTotalDeducoes" element
     */
    void setValorTotalDeducoes(java.math.BigDecimal valorTotalDeducoes);
    
    /**
     * Sets (as xml) the "ValorTotalDeducoes" element
     */
    void xsetValorTotalDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalDeducoes);
    
    /**
     * Unsets the "ValorTotalDeducoes" element
     */
    void unsetValorTotalDeducoes();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
