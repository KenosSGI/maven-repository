/*
 * XML Type:  tpRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpRPS(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpRPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS
{
    private static final long serialVersionUID = 1L;
    
    public TpRPSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASSINATURA$0 = 
        new javax.xml.namespace.QName("", "Assinatura");
    private static final javax.xml.namespace.QName CHAVERPS$2 = 
        new javax.xml.namespace.QName("", "ChaveRPS");
    private static final javax.xml.namespace.QName TIPORPS$4 = 
        new javax.xml.namespace.QName("", "TipoRPS");
    private static final javax.xml.namespace.QName DATAEMISSAO$6 = 
        new javax.xml.namespace.QName("", "DataEmissao");
    private static final javax.xml.namespace.QName STATUSRPS$8 = 
        new javax.xml.namespace.QName("", "StatusRPS");
    private static final javax.xml.namespace.QName TRIBUTACAORPS$10 = 
        new javax.xml.namespace.QName("", "TributacaoRPS");
    private static final javax.xml.namespace.QName VALORSERVICOS$12 = 
        new javax.xml.namespace.QName("", "ValorServicos");
    private static final javax.xml.namespace.QName VALORDEDUCOES$14 = 
        new javax.xml.namespace.QName("", "ValorDeducoes");
    private static final javax.xml.namespace.QName VALORPIS$16 = 
        new javax.xml.namespace.QName("", "ValorPIS");
    private static final javax.xml.namespace.QName VALORCOFINS$18 = 
        new javax.xml.namespace.QName("", "ValorCOFINS");
    private static final javax.xml.namespace.QName VALORINSS$20 = 
        new javax.xml.namespace.QName("", "ValorINSS");
    private static final javax.xml.namespace.QName VALORIR$22 = 
        new javax.xml.namespace.QName("", "ValorIR");
    private static final javax.xml.namespace.QName VALORCSLL$24 = 
        new javax.xml.namespace.QName("", "ValorCSLL");
    private static final javax.xml.namespace.QName CODIGOSERVICO$26 = 
        new javax.xml.namespace.QName("", "CodigoServico");
    private static final javax.xml.namespace.QName ALIQUOTASERVICOS$28 = 
        new javax.xml.namespace.QName("", "AliquotaServicos");
    private static final javax.xml.namespace.QName ISSRETIDO$30 = 
        new javax.xml.namespace.QName("", "ISSRetido");
    private static final javax.xml.namespace.QName CPFCNPJTOMADOR$32 = 
        new javax.xml.namespace.QName("", "CPFCNPJTomador");
    private static final javax.xml.namespace.QName INSCRICAOMUNICIPALTOMADOR$34 = 
        new javax.xml.namespace.QName("", "InscricaoMunicipalTomador");
    private static final javax.xml.namespace.QName INSCRICAOESTADUALTOMADOR$36 = 
        new javax.xml.namespace.QName("", "InscricaoEstadualTomador");
    private static final javax.xml.namespace.QName RAZAOSOCIALTOMADOR$38 = 
        new javax.xml.namespace.QName("", "RazaoSocialTomador");
    private static final javax.xml.namespace.QName ENDERECOTOMADOR$40 = 
        new javax.xml.namespace.QName("", "EnderecoTomador");
    private static final javax.xml.namespace.QName EMAILTOMADOR$42 = 
        new javax.xml.namespace.QName("", "EmailTomador");
    private static final javax.xml.namespace.QName CPFCNPJINTERMEDIARIO$44 = 
        new javax.xml.namespace.QName("", "CPFCNPJIntermediario");
    private static final javax.xml.namespace.QName INSCRICAOMUNICIPALINTERMEDIARIO$46 = 
        new javax.xml.namespace.QName("", "InscricaoMunicipalIntermediario");
    private static final javax.xml.namespace.QName ISSRETIDOINTERMEDIARIO$48 = 
        new javax.xml.namespace.QName("", "ISSRetidoIntermediario");
    private static final javax.xml.namespace.QName EMAILINTERMEDIARIO$50 = 
        new javax.xml.namespace.QName("", "EmailIntermediario");
    private static final javax.xml.namespace.QName DISCRIMINACAO$52 = 
        new javax.xml.namespace.QName("", "Discriminacao");
    private static final javax.xml.namespace.QName VALORCARGATRIBUTARIA$54 = 
        new javax.xml.namespace.QName("", "ValorCargaTributaria");
    private static final javax.xml.namespace.QName PERCENTUALCARGATRIBUTARIA$56 = 
        new javax.xml.namespace.QName("", "PercentualCargaTributaria");
    private static final javax.xml.namespace.QName FONTECARGATRIBUTARIA$58 = 
        new javax.xml.namespace.QName("", "FonteCargaTributaria");
    private static final javax.xml.namespace.QName CODIGOCEI$60 = 
        new javax.xml.namespace.QName("", "CodigoCEI");
    private static final javax.xml.namespace.QName MATRICULAOBRA$62 = 
        new javax.xml.namespace.QName("", "MatriculaObra");
    private static final javax.xml.namespace.QName MUNICIPIOPRESTACAO$64 = 
        new javax.xml.namespace.QName("", "MunicipioPrestacao");
    
    
    /**
     * Gets the "Assinatura" element
     */
    public byte[] getAssinatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASSINATURA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getByteArrayValue();
        }
    }
    
    /**
     * Gets (as xml) the "Assinatura" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura xgetAssinatura()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura)get_store().find_element_user(ASSINATURA$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Assinatura" element
     */
    public void setAssinatura(byte[] assinatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASSINATURA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASSINATURA$0);
            }
            target.setByteArrayValue(assinatura);
        }
    }
    
    /**
     * Sets (as xml) the "Assinatura" element
     */
    public void xsetAssinatura(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura assinatura)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura)get_store().find_element_user(ASSINATURA$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura)get_store().add_element_user(ASSINATURA$0);
            }
            target.set(assinatura);
        }
    }
    
    /**
     * Gets the "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().find_element_user(CHAVERPS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ChaveRPS" element
     */
    public void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS)
    {
        generatedSetterHelperImpl(chaveRPS, CHAVERPS$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().add_element_user(CHAVERPS$2);
            return target;
        }
    }
    
    /**
     * Gets the "TipoRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.Enum getTipoRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPORPS$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "TipoRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS xgetTipoRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS)get_store().find_element_user(TIPORPS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "TipoRPS" element
     */
    public void setTipoRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.Enum tipoRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPORPS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPORPS$4);
            }
            target.setEnumValue(tipoRPS);
        }
    }
    
    /**
     * Sets (as xml) the "TipoRPS" element
     */
    public void xsetTipoRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS tipoRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS)get_store().find_element_user(TIPORPS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS)get_store().add_element_user(TIPORPS$4);
            }
            target.set(tipoRPS);
        }
    }
    
    /**
     * Gets the "DataEmissao" element
     */
    public java.util.Calendar getDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataEmissao" element
     */
    public org.apache.xmlbeans.XmlDate xgetDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAEMISSAO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "DataEmissao" element
     */
    public void setDataEmissao(java.util.Calendar dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAEMISSAO$6);
            }
            target.setCalendarValue(dataEmissao);
        }
    }
    
    /**
     * Sets (as xml) the "DataEmissao" element
     */
    public void xsetDataEmissao(org.apache.xmlbeans.XmlDate dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAEMISSAO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAEMISSAO$6);
            }
            target.set(dataEmissao);
        }
    }
    
    /**
     * Gets the "StatusRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe.Enum getStatusRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUSRPS$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "StatusRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe xgetStatusRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe)get_store().find_element_user(STATUSRPS$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "StatusRPS" element
     */
    public void setStatusRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe.Enum statusRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUSRPS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATUSRPS$8);
            }
            target.setEnumValue(statusRPS);
        }
    }
    
    /**
     * Sets (as xml) the "StatusRPS" element
     */
    public void xsetStatusRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe statusRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe)get_store().find_element_user(STATUSRPS$8, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe)get_store().add_element_user(STATUSRPS$8);
            }
            target.set(statusRPS);
        }
    }
    
    /**
     * Gets the "TributacaoRPS" element
     */
    public java.lang.String getTributacaoRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIBUTACAORPS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "TributacaoRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe xgetTributacaoRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe)get_store().find_element_user(TRIBUTACAORPS$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "TributacaoRPS" element
     */
    public void setTributacaoRPS(java.lang.String tributacaoRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIBUTACAORPS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRIBUTACAORPS$10);
            }
            target.setStringValue(tributacaoRPS);
        }
    }
    
    /**
     * Sets (as xml) the "TributacaoRPS" element
     */
    public void xsetTributacaoRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe tributacaoRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe)get_store().find_element_user(TRIBUTACAORPS$10, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe)get_store().add_element_user(TRIBUTACAORPS$10);
            }
            target.set(tributacaoRPS);
        }
    }
    
    /**
     * Gets the "ValorServicos" element
     */
    public java.math.BigDecimal getValorServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORSERVICOS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorServicos" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORSERVICOS$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ValorServicos" element
     */
    public void setValorServicos(java.math.BigDecimal valorServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORSERVICOS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORSERVICOS$12);
            }
            target.setBigDecimalValue(valorServicos);
        }
    }
    
    /**
     * Sets (as xml) the "ValorServicos" element
     */
    public void xsetValorServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORSERVICOS$12, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORSERVICOS$12);
            }
            target.set(valorServicos);
        }
    }
    
    /**
     * Gets the "ValorDeducoes" element
     */
    public java.math.BigDecimal getValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORDEDUCOES$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorDeducoes" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORDEDUCOES$14, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ValorDeducoes" element
     */
    public void setValorDeducoes(java.math.BigDecimal valorDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORDEDUCOES$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORDEDUCOES$14);
            }
            target.setBigDecimalValue(valorDeducoes);
        }
    }
    
    /**
     * Sets (as xml) the "ValorDeducoes" element
     */
    public void xsetValorDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORDEDUCOES$14, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORDEDUCOES$14);
            }
            target.set(valorDeducoes);
        }
    }
    
    /**
     * Gets the "ValorPIS" element
     */
    public java.math.BigDecimal getValorPIS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORPIS$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorPIS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorPIS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORPIS$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorPIS" element
     */
    public boolean isSetValorPIS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORPIS$16) != 0;
        }
    }
    
    /**
     * Sets the "ValorPIS" element
     */
    public void setValorPIS(java.math.BigDecimal valorPIS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORPIS$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORPIS$16);
            }
            target.setBigDecimalValue(valorPIS);
        }
    }
    
    /**
     * Sets (as xml) the "ValorPIS" element
     */
    public void xsetValorPIS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorPIS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORPIS$16, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORPIS$16);
            }
            target.set(valorPIS);
        }
    }
    
    /**
     * Unsets the "ValorPIS" element
     */
    public void unsetValorPIS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORPIS$16, 0);
        }
    }
    
    /**
     * Gets the "ValorCOFINS" element
     */
    public java.math.BigDecimal getValorCOFINS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCOFINS$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCOFINS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCOFINS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCOFINS$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCOFINS" element
     */
    public boolean isSetValorCOFINS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCOFINS$18) != 0;
        }
    }
    
    /**
     * Sets the "ValorCOFINS" element
     */
    public void setValorCOFINS(java.math.BigDecimal valorCOFINS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCOFINS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCOFINS$18);
            }
            target.setBigDecimalValue(valorCOFINS);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCOFINS" element
     */
    public void xsetValorCOFINS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCOFINS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCOFINS$18, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORCOFINS$18);
            }
            target.set(valorCOFINS);
        }
    }
    
    /**
     * Unsets the "ValorCOFINS" element
     */
    public void unsetValorCOFINS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCOFINS$18, 0);
        }
    }
    
    /**
     * Gets the "ValorINSS" element
     */
    public java.math.BigDecimal getValorINSS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORINSS$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorINSS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorINSS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORINSS$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorINSS" element
     */
    public boolean isSetValorINSS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORINSS$20) != 0;
        }
    }
    
    /**
     * Sets the "ValorINSS" element
     */
    public void setValorINSS(java.math.BigDecimal valorINSS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORINSS$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORINSS$20);
            }
            target.setBigDecimalValue(valorINSS);
        }
    }
    
    /**
     * Sets (as xml) the "ValorINSS" element
     */
    public void xsetValorINSS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorINSS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORINSS$20, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORINSS$20);
            }
            target.set(valorINSS);
        }
    }
    
    /**
     * Unsets the "ValorINSS" element
     */
    public void unsetValorINSS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORINSS$20, 0);
        }
    }
    
    /**
     * Gets the "ValorIR" element
     */
    public java.math.BigDecimal getValorIR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORIR$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorIR" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorIR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORIR$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorIR" element
     */
    public boolean isSetValorIR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORIR$22) != 0;
        }
    }
    
    /**
     * Sets the "ValorIR" element
     */
    public void setValorIR(java.math.BigDecimal valorIR)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORIR$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORIR$22);
            }
            target.setBigDecimalValue(valorIR);
        }
    }
    
    /**
     * Sets (as xml) the "ValorIR" element
     */
    public void xsetValorIR(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorIR)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORIR$22, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORIR$22);
            }
            target.set(valorIR);
        }
    }
    
    /**
     * Unsets the "ValorIR" element
     */
    public void unsetValorIR()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORIR$22, 0);
        }
    }
    
    /**
     * Gets the "ValorCSLL" element
     */
    public java.math.BigDecimal getValorCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCSLL$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCSLL" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCSLL$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCSLL" element
     */
    public boolean isSetValorCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCSLL$24) != 0;
        }
    }
    
    /**
     * Sets the "ValorCSLL" element
     */
    public void setValorCSLL(java.math.BigDecimal valorCSLL)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCSLL$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCSLL$24);
            }
            target.setBigDecimalValue(valorCSLL);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCSLL" element
     */
    public void xsetValorCSLL(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCSLL)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCSLL$24, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORCSLL$24);
            }
            target.set(valorCSLL);
        }
    }
    
    /**
     * Unsets the "ValorCSLL" element
     */
    public void unsetValorCSLL()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCSLL$24, 0);
        }
    }
    
    /**
     * Gets the "CodigoServico" element
     */
    public java.lang.String getCodigoServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOSERVICO$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoServico" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico xgetCodigoServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico)get_store().find_element_user(CODIGOSERVICO$26, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoServico" element
     */
    public void setCodigoServico(java.lang.String codigoServico)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOSERVICO$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOSERVICO$26);
            }
            target.setStringValue(codigoServico);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoServico" element
     */
    public void xsetCodigoServico(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico codigoServico)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico)get_store().find_element_user(CODIGOSERVICO$26, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico)get_store().add_element_user(CODIGOSERVICO$26);
            }
            target.set(codigoServico);
        }
    }
    
    /**
     * Gets the "AliquotaServicos" element
     */
    public java.math.BigDecimal getAliquotaServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTASERVICOS$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "AliquotaServicos" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota xgetAliquotaServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota)get_store().find_element_user(ALIQUOTASERVICOS$28, 0);
            return target;
        }
    }
    
    /**
     * Sets the "AliquotaServicos" element
     */
    public void setAliquotaServicos(java.math.BigDecimal aliquotaServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTASERVICOS$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALIQUOTASERVICOS$28);
            }
            target.setBigDecimalValue(aliquotaServicos);
        }
    }
    
    /**
     * Sets (as xml) the "AliquotaServicos" element
     */
    public void xsetAliquotaServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota aliquotaServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota)get_store().find_element_user(ALIQUOTASERVICOS$28, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota)get_store().add_element_user(ALIQUOTASERVICOS$28);
            }
            target.set(aliquotaServicos);
        }
    }
    
    /**
     * Gets the "ISSRetido" element
     */
    public boolean getISSRetido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDO$30, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "ISSRetido" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetISSRetido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSRETIDO$30, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ISSRetido" element
     */
    public void setISSRetido(boolean issRetido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDO$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSRETIDO$30);
            }
            target.setBooleanValue(issRetido);
        }
    }
    
    /**
     * Sets (as xml) the "ISSRetido" element
     */
    public void xsetISSRetido(org.apache.xmlbeans.XmlBoolean issRetido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSRETIDO$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSRETIDO$30);
            }
            target.set(issRetido);
        }
    }
    
    /**
     * Gets the "CPFCNPJTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJTOMADOR$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "CPFCNPJTomador" element
     */
    public boolean isSetCPFCNPJTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFCNPJTOMADOR$32) != 0;
        }
    }
    
    /**
     * Sets the "CPFCNPJTomador" element
     */
    public void setCPFCNPJTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjTomador)
    {
        generatedSetterHelperImpl(cpfcnpjTomador, CPFCNPJTOMADOR$32, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CPFCNPJTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJTOMADOR$32);
            return target;
        }
    }
    
    /**
     * Unsets the "CPFCNPJTomador" element
     */
    public void unsetCPFCNPJTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFCNPJTOMADOR$32, 0);
        }
    }
    
    /**
     * Gets the "InscricaoMunicipalTomador" element
     */
    public long getInscricaoMunicipalTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPALTOMADOR$34, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoMunicipalTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoMunicipalTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPALTOMADOR$34, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoMunicipalTomador" element
     */
    public boolean isSetInscricaoMunicipalTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOMUNICIPALTOMADOR$34) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoMunicipalTomador" element
     */
    public void setInscricaoMunicipalTomador(long inscricaoMunicipalTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPALTOMADOR$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOMUNICIPALTOMADOR$34);
            }
            target.setLongValue(inscricaoMunicipalTomador);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoMunicipalTomador" element
     */
    public void xsetInscricaoMunicipalTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoMunicipalTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPALTOMADOR$34, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAOMUNICIPALTOMADOR$34);
            }
            target.set(inscricaoMunicipalTomador);
        }
    }
    
    /**
     * Unsets the "InscricaoMunicipalTomador" element
     */
    public void unsetInscricaoMunicipalTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOMUNICIPALTOMADOR$34, 0);
        }
    }
    
    /**
     * Gets the "InscricaoEstadualTomador" element
     */
    public long getInscricaoEstadualTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOESTADUALTOMADOR$36, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoEstadualTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual xgetInscricaoEstadualTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual)get_store().find_element_user(INSCRICAOESTADUALTOMADOR$36, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoEstadualTomador" element
     */
    public boolean isSetInscricaoEstadualTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOESTADUALTOMADOR$36) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoEstadualTomador" element
     */
    public void setInscricaoEstadualTomador(long inscricaoEstadualTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOESTADUALTOMADOR$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOESTADUALTOMADOR$36);
            }
            target.setLongValue(inscricaoEstadualTomador);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoEstadualTomador" element
     */
    public void xsetInscricaoEstadualTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual inscricaoEstadualTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual)get_store().find_element_user(INSCRICAOESTADUALTOMADOR$36, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual)get_store().add_element_user(INSCRICAOESTADUALTOMADOR$36);
            }
            target.set(inscricaoEstadualTomador);
        }
    }
    
    /**
     * Unsets the "InscricaoEstadualTomador" element
     */
    public void unsetInscricaoEstadualTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOESTADUALTOMADOR$36, 0);
        }
    }
    
    /**
     * Gets the "RazaoSocialTomador" element
     */
    public java.lang.String getRazaoSocialTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIALTOMADOR$38, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocialTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial xgetRazaoSocialTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial)get_store().find_element_user(RAZAOSOCIALTOMADOR$38, 0);
            return target;
        }
    }
    
    /**
     * True if has "RazaoSocialTomador" element
     */
    public boolean isSetRazaoSocialTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RAZAOSOCIALTOMADOR$38) != 0;
        }
    }
    
    /**
     * Sets the "RazaoSocialTomador" element
     */
    public void setRazaoSocialTomador(java.lang.String razaoSocialTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIALTOMADOR$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIALTOMADOR$38);
            }
            target.setStringValue(razaoSocialTomador);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocialTomador" element
     */
    public void xsetRazaoSocialTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial razaoSocialTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial)get_store().find_element_user(RAZAOSOCIALTOMADOR$38, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial)get_store().add_element_user(RAZAOSOCIALTOMADOR$38);
            }
            target.set(razaoSocialTomador);
        }
    }
    
    /**
     * Unsets the "RazaoSocialTomador" element
     */
    public void unsetRazaoSocialTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RAZAOSOCIALTOMADOR$38, 0);
        }
    }
    
    /**
     * Gets the "EnderecoTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco getEnderecoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco)get_store().find_element_user(ENDERECOTOMADOR$40, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "EnderecoTomador" element
     */
    public boolean isSetEnderecoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENDERECOTOMADOR$40) != 0;
        }
    }
    
    /**
     * Sets the "EnderecoTomador" element
     */
    public void setEnderecoTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco enderecoTomador)
    {
        generatedSetterHelperImpl(enderecoTomador, ENDERECOTOMADOR$40, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnderecoTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco addNewEnderecoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco)get_store().add_element_user(ENDERECOTOMADOR$40);
            return target;
        }
    }
    
    /**
     * Unsets the "EnderecoTomador" element
     */
    public void unsetEnderecoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENDERECOTOMADOR$40, 0);
        }
    }
    
    /**
     * Gets the "EmailTomador" element
     */
    public java.lang.String getEmailTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAILTOMADOR$42, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "EmailTomador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail xgetEmailTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().find_element_user(EMAILTOMADOR$42, 0);
            return target;
        }
    }
    
    /**
     * True if has "EmailTomador" element
     */
    public boolean isSetEmailTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAILTOMADOR$42) != 0;
        }
    }
    
    /**
     * Sets the "EmailTomador" element
     */
    public void setEmailTomador(java.lang.String emailTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAILTOMADOR$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAILTOMADOR$42);
            }
            target.setStringValue(emailTomador);
        }
    }
    
    /**
     * Sets (as xml) the "EmailTomador" element
     */
    public void xsetEmailTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail emailTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().find_element_user(EMAILTOMADOR$42, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().add_element_user(EMAILTOMADOR$42);
            }
            target.set(emailTomador);
        }
    }
    
    /**
     * Unsets the "EmailTomador" element
     */
    public void unsetEmailTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAILTOMADOR$42, 0);
        }
    }
    
    /**
     * Gets the "CPFCNPJIntermediario" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJINTERMEDIARIO$44, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "CPFCNPJIntermediario" element
     */
    public boolean isSetCPFCNPJIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFCNPJINTERMEDIARIO$44) != 0;
        }
    }
    
    /**
     * Sets the "CPFCNPJIntermediario" element
     */
    public void setCPFCNPJIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjIntermediario)
    {
        generatedSetterHelperImpl(cpfcnpjIntermediario, CPFCNPJINTERMEDIARIO$44, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CPFCNPJIntermediario" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJINTERMEDIARIO$44);
            return target;
        }
    }
    
    /**
     * Unsets the "CPFCNPJIntermediario" element
     */
    public void unsetCPFCNPJIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFCNPJINTERMEDIARIO$44, 0);
        }
    }
    
    /**
     * Gets the "InscricaoMunicipalIntermediario" element
     */
    public long getInscricaoMunicipalIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoMunicipalIntermediario" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoMunicipalIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoMunicipalIntermediario" element
     */
    public boolean isSetInscricaoMunicipalIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOMUNICIPALINTERMEDIARIO$46) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoMunicipalIntermediario" element
     */
    public void setInscricaoMunicipalIntermediario(long inscricaoMunicipalIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46);
            }
            target.setLongValue(inscricaoMunicipalIntermediario);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoMunicipalIntermediario" element
     */
    public void xsetInscricaoMunicipalIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoMunicipalIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAOMUNICIPALINTERMEDIARIO$46);
            }
            target.set(inscricaoMunicipalIntermediario);
        }
    }
    
    /**
     * Unsets the "InscricaoMunicipalIntermediario" element
     */
    public void unsetInscricaoMunicipalIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOMUNICIPALINTERMEDIARIO$46, 0);
        }
    }
    
    /**
     * Gets the "ISSRetidoIntermediario" element
     */
    public java.lang.String getISSRetidoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDOINTERMEDIARIO$48, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ISSRetidoIntermediario" element
     */
    public org.apache.xmlbeans.XmlString xgetISSRetidoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ISSRETIDOINTERMEDIARIO$48, 0);
            return target;
        }
    }
    
    /**
     * True if has "ISSRetidoIntermediario" element
     */
    public boolean isSetISSRetidoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISSRETIDOINTERMEDIARIO$48) != 0;
        }
    }
    
    /**
     * Sets the "ISSRetidoIntermediario" element
     */
    public void setISSRetidoIntermediario(java.lang.String issRetidoIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDOINTERMEDIARIO$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSRETIDOINTERMEDIARIO$48);
            }
            target.setStringValue(issRetidoIntermediario);
        }
    }
    
    /**
     * Sets (as xml) the "ISSRetidoIntermediario" element
     */
    public void xsetISSRetidoIntermediario(org.apache.xmlbeans.XmlString issRetidoIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ISSRETIDOINTERMEDIARIO$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ISSRETIDOINTERMEDIARIO$48);
            }
            target.set(issRetidoIntermediario);
        }
    }
    
    /**
     * Unsets the "ISSRetidoIntermediario" element
     */
    public void unsetISSRetidoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISSRETIDOINTERMEDIARIO$48, 0);
        }
    }
    
    /**
     * Gets the "EmailIntermediario" element
     */
    public java.lang.String getEmailIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAILINTERMEDIARIO$50, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "EmailIntermediario" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail xgetEmailIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().find_element_user(EMAILINTERMEDIARIO$50, 0);
            return target;
        }
    }
    
    /**
     * True if has "EmailIntermediario" element
     */
    public boolean isSetEmailIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAILINTERMEDIARIO$50) != 0;
        }
    }
    
    /**
     * Sets the "EmailIntermediario" element
     */
    public void setEmailIntermediario(java.lang.String emailIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAILINTERMEDIARIO$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAILINTERMEDIARIO$50);
            }
            target.setStringValue(emailIntermediario);
        }
    }
    
    /**
     * Sets (as xml) the "EmailIntermediario" element
     */
    public void xsetEmailIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail emailIntermediario)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().find_element_user(EMAILINTERMEDIARIO$50, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail)get_store().add_element_user(EMAILINTERMEDIARIO$50);
            }
            target.set(emailIntermediario);
        }
    }
    
    /**
     * Unsets the "EmailIntermediario" element
     */
    public void unsetEmailIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAILINTERMEDIARIO$50, 0);
        }
    }
    
    /**
     * Gets the "Discriminacao" element
     */
    public java.lang.String getDiscriminacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCRIMINACAO$52, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Discriminacao" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao xgetDiscriminacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao)get_store().find_element_user(DISCRIMINACAO$52, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Discriminacao" element
     */
    public void setDiscriminacao(java.lang.String discriminacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCRIMINACAO$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISCRIMINACAO$52);
            }
            target.setStringValue(discriminacao);
        }
    }
    
    /**
     * Sets (as xml) the "Discriminacao" element
     */
    public void xsetDiscriminacao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao discriminacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao)get_store().find_element_user(DISCRIMINACAO$52, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao)get_store().add_element_user(DISCRIMINACAO$52);
            }
            target.set(discriminacao);
        }
    }
    
    /**
     * Gets the "ValorCargaTributaria" element
     */
    public java.math.BigDecimal getValorCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCARGATRIBUTARIA$54, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCargaTributaria" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCARGATRIBUTARIA$54, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCargaTributaria" element
     */
    public boolean isSetValorCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCARGATRIBUTARIA$54) != 0;
        }
    }
    
    /**
     * Sets the "ValorCargaTributaria" element
     */
    public void setValorCargaTributaria(java.math.BigDecimal valorCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCARGATRIBUTARIA$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCARGATRIBUTARIA$54);
            }
            target.setBigDecimalValue(valorCargaTributaria);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCargaTributaria" element
     */
    public void xsetValorCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORCARGATRIBUTARIA$54, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORCARGATRIBUTARIA$54);
            }
            target.set(valorCargaTributaria);
        }
    }
    
    /**
     * Unsets the "ValorCargaTributaria" element
     */
    public void unsetValorCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCARGATRIBUTARIA$54, 0);
        }
    }
    
    /**
     * Gets the "PercentualCargaTributaria" element
     */
    public java.math.BigDecimal getPercentualCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCENTUALCARGATRIBUTARIA$56, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "PercentualCargaTributaria" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria xgetPercentualCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria)get_store().find_element_user(PERCENTUALCARGATRIBUTARIA$56, 0);
            return target;
        }
    }
    
    /**
     * True if has "PercentualCargaTributaria" element
     */
    public boolean isSetPercentualCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERCENTUALCARGATRIBUTARIA$56) != 0;
        }
    }
    
    /**
     * Sets the "PercentualCargaTributaria" element
     */
    public void setPercentualCargaTributaria(java.math.BigDecimal percentualCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCENTUALCARGATRIBUTARIA$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCENTUALCARGATRIBUTARIA$56);
            }
            target.setBigDecimalValue(percentualCargaTributaria);
        }
    }
    
    /**
     * Sets (as xml) the "PercentualCargaTributaria" element
     */
    public void xsetPercentualCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria percentualCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria)get_store().find_element_user(PERCENTUALCARGATRIBUTARIA$56, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria)get_store().add_element_user(PERCENTUALCARGATRIBUTARIA$56);
            }
            target.set(percentualCargaTributaria);
        }
    }
    
    /**
     * Unsets the "PercentualCargaTributaria" element
     */
    public void unsetPercentualCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERCENTUALCARGATRIBUTARIA$56, 0);
        }
    }
    
    /**
     * Gets the "FonteCargaTributaria" element
     */
    public java.lang.String getFonteCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONTECARGATRIBUTARIA$58, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "FonteCargaTributaria" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria xgetFonteCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria)get_store().find_element_user(FONTECARGATRIBUTARIA$58, 0);
            return target;
        }
    }
    
    /**
     * True if has "FonteCargaTributaria" element
     */
    public boolean isSetFonteCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FONTECARGATRIBUTARIA$58) != 0;
        }
    }
    
    /**
     * Sets the "FonteCargaTributaria" element
     */
    public void setFonteCargaTributaria(java.lang.String fonteCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FONTECARGATRIBUTARIA$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FONTECARGATRIBUTARIA$58);
            }
            target.setStringValue(fonteCargaTributaria);
        }
    }
    
    /**
     * Sets (as xml) the "FonteCargaTributaria" element
     */
    public void xsetFonteCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria fonteCargaTributaria)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria)get_store().find_element_user(FONTECARGATRIBUTARIA$58, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria)get_store().add_element_user(FONTECARGATRIBUTARIA$58);
            }
            target.set(fonteCargaTributaria);
        }
    }
    
    /**
     * Unsets the "FonteCargaTributaria" element
     */
    public void unsetFonteCargaTributaria()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FONTECARGATRIBUTARIA$58, 0);
        }
    }
    
    /**
     * Gets the "CodigoCEI" element
     */
    public long getCodigoCEI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCEI$60, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoCEI" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetCodigoCEI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(CODIGOCEI$60, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoCEI" element
     */
    public boolean isSetCodigoCEI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOCEI$60) != 0;
        }
    }
    
    /**
     * Sets the "CodigoCEI" element
     */
    public void setCodigoCEI(long codigoCEI)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCEI$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOCEI$60);
            }
            target.setLongValue(codigoCEI);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoCEI" element
     */
    public void xsetCodigoCEI(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero codigoCEI)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(CODIGOCEI$60, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(CODIGOCEI$60);
            }
            target.set(codigoCEI);
        }
    }
    
    /**
     * Unsets the "CodigoCEI" element
     */
    public void unsetCodigoCEI()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOCEI$60, 0);
        }
    }
    
    /**
     * Gets the "MatriculaObra" element
     */
    public long getMatriculaObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MATRICULAOBRA$62, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "MatriculaObra" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetMatriculaObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(MATRICULAOBRA$62, 0);
            return target;
        }
    }
    
    /**
     * True if has "MatriculaObra" element
     */
    public boolean isSetMatriculaObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MATRICULAOBRA$62) != 0;
        }
    }
    
    /**
     * Sets the "MatriculaObra" element
     */
    public void setMatriculaObra(long matriculaObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MATRICULAOBRA$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MATRICULAOBRA$62);
            }
            target.setLongValue(matriculaObra);
        }
    }
    
    /**
     * Sets (as xml) the "MatriculaObra" element
     */
    public void xsetMatriculaObra(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero matriculaObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(MATRICULAOBRA$62, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(MATRICULAOBRA$62);
            }
            target.set(matriculaObra);
        }
    }
    
    /**
     * Unsets the "MatriculaObra" element
     */
    public void unsetMatriculaObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MATRICULAOBRA$62, 0);
        }
    }
    
    /**
     * Gets the "MunicipioPrestacao" element
     */
    public int getMunicipioPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUNICIPIOPRESTACAO$64, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "MunicipioPrestacao" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade xgetMunicipioPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().find_element_user(MUNICIPIOPRESTACAO$64, 0);
            return target;
        }
    }
    
    /**
     * True if has "MunicipioPrestacao" element
     */
    public boolean isSetMunicipioPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MUNICIPIOPRESTACAO$64) != 0;
        }
    }
    
    /**
     * Sets the "MunicipioPrestacao" element
     */
    public void setMunicipioPrestacao(int municipioPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUNICIPIOPRESTACAO$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MUNICIPIOPRESTACAO$64);
            }
            target.setIntValue(municipioPrestacao);
        }
    }
    
    /**
     * Sets (as xml) the "MunicipioPrestacao" element
     */
    public void xsetMunicipioPrestacao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade municipioPrestacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().find_element_user(MUNICIPIOPRESTACAO$64, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade)get_store().add_element_user(MUNICIPIOPRESTACAO$64);
            }
            target.set(municipioPrestacao);
        }
    }
    
    /**
     * Unsets the "MunicipioPrestacao" element
     */
    public void unsetMunicipioPrestacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MUNICIPIOPRESTACAO$64, 0);
        }
    }
}
