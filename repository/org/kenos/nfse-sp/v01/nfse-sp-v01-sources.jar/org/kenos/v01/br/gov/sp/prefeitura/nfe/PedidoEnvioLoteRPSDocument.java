/*
 * An XML document type.
 * Localname: PedidoEnvioLoteRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one PedidoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface PedidoEnvioLoteRPSDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoEnvioLoteRPSDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoenvioloterps6f9ddoctype");
    
    /**
     * Gets the "PedidoEnvioLoteRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS getPedidoEnvioLoteRPS();
    
    /**
     * Sets the "PedidoEnvioLoteRPS" element
     */
    void setPedidoEnvioLoteRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS pedidoEnvioLoteRPS);
    
    /**
     * Appends and returns a new empty "PedidoEnvioLoteRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS addNewPedidoEnvioLoteRPS();
    
    /**
     * An XML PedidoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface PedidoEnvioLoteRPS extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoEnvioLoteRPS.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoenvioloterpsbc0eelemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho addNewCabecalho();
        
        /**
         * Gets array of all "RPS" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[] getRPSArray();
        
        /**
         * Gets ith "RPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS getRPSArray(int i);
        
        /**
         * Returns number of "RPS" element
         */
        int sizeOfRPSArray();
        
        /**
         * Sets array of all "RPS" element
         */
        void setRPSArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[] rpsArray);
        
        /**
         * Sets ith "RPS" element
         */
        void setRPSArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS rps);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "RPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS insertNewRPS(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "RPS" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS addNewRPS();
        
        /**
         * Removes the ith "RPS" element
         */
        void removeRPS(int i);
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalho3b3eelemtype");
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
            
            /**
             * Gets the "transacao" element
             */
            boolean getTransacao();
            
            /**
             * Gets (as xml) the "transacao" element
             */
            org.apache.xmlbeans.XmlBoolean xgetTransacao();
            
            /**
             * True if has "transacao" element
             */
            boolean isSetTransacao();
            
            /**
             * Sets the "transacao" element
             */
            void setTransacao(boolean transacao);
            
            /**
             * Sets (as xml) the "transacao" element
             */
            void xsetTransacao(org.apache.xmlbeans.XmlBoolean transacao);
            
            /**
             * Unsets the "transacao" element
             */
            void unsetTransacao();
            
            /**
             * Gets the "dtInicio" element
             */
            java.util.Calendar getDtInicio();
            
            /**
             * Gets (as xml) the "dtInicio" element
             */
            org.apache.xmlbeans.XmlDate xgetDtInicio();
            
            /**
             * Sets the "dtInicio" element
             */
            void setDtInicio(java.util.Calendar dtInicio);
            
            /**
             * Sets (as xml) the "dtInicio" element
             */
            void xsetDtInicio(org.apache.xmlbeans.XmlDate dtInicio);
            
            /**
             * Gets the "dtFim" element
             */
            java.util.Calendar getDtFim();
            
            /**
             * Gets (as xml) the "dtFim" element
             */
            org.apache.xmlbeans.XmlDate xgetDtFim();
            
            /**
             * Sets the "dtFim" element
             */
            void setDtFim(java.util.Calendar dtFim);
            
            /**
             * Sets (as xml) the "dtFim" element
             */
            void xsetDtFim(org.apache.xmlbeans.XmlDate dtFim);
            
            /**
             * Gets the "QtdRPS" element
             */
            long getQtdRPS();
            
            /**
             * Gets (as xml) the "QtdRPS" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade xgetQtdRPS();
            
            /**
             * Sets the "QtdRPS" element
             */
            void setQtdRPS(long qtdRPS);
            
            /**
             * Sets (as xml) the "QtdRPS" element
             */
            void xsetQtdRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade qtdRPS);
            
            /**
             * Gets the "ValorTotalServicos" element
             */
            java.math.BigDecimal getValorTotalServicos();
            
            /**
             * Gets (as xml) the "ValorTotalServicos" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalServicos();
            
            /**
             * Sets the "ValorTotalServicos" element
             */
            void setValorTotalServicos(java.math.BigDecimal valorTotalServicos);
            
            /**
             * Sets (as xml) the "ValorTotalServicos" element
             */
            void xsetValorTotalServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalServicos);
            
            /**
             * Gets the "ValorTotalDeducoes" element
             */
            java.math.BigDecimal getValorTotalDeducoes();
            
            /**
             * Gets (as xml) the "ValorTotalDeducoes" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalDeducoes();
            
            /**
             * True if has "ValorTotalDeducoes" element
             */
            boolean isSetValorTotalDeducoes();
            
            /**
             * Sets the "ValorTotalDeducoes" element
             */
            void setValorTotalDeducoes(java.math.BigDecimal valorTotalDeducoes);
            
            /**
             * Sets (as xml) the "ValorTotalDeducoes" element
             */
            void xsetValorTotalDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalDeducoes);
            
            /**
             * Unsets the "ValorTotalDeducoes" element
             */
            void unsetValorTotalDeducoes();
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
