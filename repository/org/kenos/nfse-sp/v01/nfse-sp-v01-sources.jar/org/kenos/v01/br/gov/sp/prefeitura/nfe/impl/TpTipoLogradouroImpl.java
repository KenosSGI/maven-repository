/*
 * XML Type:  tpTipoLogradouro
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpTipoLogradouro(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro.
 */
public class TpTipoLogradouroImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro
{
    private static final long serialVersionUID = 1L;
    
    public TpTipoLogradouroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpTipoLogradouroImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
