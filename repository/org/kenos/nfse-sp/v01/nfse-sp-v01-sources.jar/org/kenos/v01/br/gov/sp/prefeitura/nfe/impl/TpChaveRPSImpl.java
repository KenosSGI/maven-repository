/*
 * XML Type:  tpChaveRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpChaveRPS(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpChaveRPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS
{
    private static final long serialVersionUID = 1L;
    
    public TpChaveRPSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INSCRICAOPRESTADOR$0 = 
        new javax.xml.namespace.QName("", "InscricaoPrestador");
    private static final javax.xml.namespace.QName SERIERPS$2 = 
        new javax.xml.namespace.QName("", "SerieRPS");
    private static final javax.xml.namespace.QName NUMERORPS$4 = 
        new javax.xml.namespace.QName("", "NumeroRPS");
    
    
    /**
     * Gets the "InscricaoPrestador" element
     */
    public long getInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoPrestador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "InscricaoPrestador" element
     */
    public void setInscricaoPrestador(long inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOPRESTADOR$0);
            }
            target.setLongValue(inscricaoPrestador);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoPrestador" element
     */
    public void xsetInscricaoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAOPRESTADOR$0);
            }
            target.set(inscricaoPrestador);
        }
    }
    
    /**
     * Gets the "SerieRPS" element
     */
    public java.lang.String getSerieRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIERPS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "SerieRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS xgetSerieRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS)get_store().find_element_user(SERIERPS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "SerieRPS" element
     */
    public boolean isSetSerieRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERIERPS$2) != 0;
        }
    }
    
    /**
     * Sets the "SerieRPS" element
     */
    public void setSerieRPS(java.lang.String serieRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIERPS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERIERPS$2);
            }
            target.setStringValue(serieRPS);
        }
    }
    
    /**
     * Sets (as xml) the "SerieRPS" element
     */
    public void xsetSerieRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS serieRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS)get_store().find_element_user(SERIERPS$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSerieRPS)get_store().add_element_user(SERIERPS$2);
            }
            target.set(serieRPS);
        }
    }
    
    /**
     * Unsets the "SerieRPS" element
     */
    public void unsetSerieRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERIERPS$2, 0);
        }
    }
    
    /**
     * Gets the "NumeroRPS" element
     */
    public long getNumeroRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERORPS$4, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMERORPS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "NumeroRPS" element
     */
    public void setNumeroRPS(long numeroRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERORPS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERORPS$4);
            }
            target.setLongValue(numeroRPS);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroRPS" element
     */
    public void xsetNumeroRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroRPS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMERORPS$4, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(NUMERORPS$4);
            }
            target.set(numeroRPS);
        }
    }
}
