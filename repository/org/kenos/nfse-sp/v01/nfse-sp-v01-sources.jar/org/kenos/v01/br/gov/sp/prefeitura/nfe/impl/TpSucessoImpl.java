/*
 * XML Type:  tpSucesso
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpSucesso(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso.
 */
public class TpSucessoImpl extends org.apache.xmlbeans.impl.values.JavaBooleanHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso
{
    private static final long serialVersionUID = 1L;
    
    public TpSucessoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpSucessoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
