/*
 * An XML document type.
 * Localname: RetornoConsultaCNPJ
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one RetornoConsultaCNPJ(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface RetornoConsultaCNPJDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetornoConsultaCNPJDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("retornoconsultacnpj7017doctype");
    
    /**
     * Gets the "RetornoConsultaCNPJ" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ getRetornoConsultaCNPJ();
    
    /**
     * Sets the "RetornoConsultaCNPJ" element
     */
    void setRetornoConsultaCNPJ(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ retornoConsultaCNPJ);
    
    /**
     * Appends and returns a new empty "RetornoConsultaCNPJ" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ addNewRetornoConsultaCNPJ();
    
    /**
     * An XML RetornoConsultaCNPJ(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface RetornoConsultaCNPJ extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetornoConsultaCNPJ.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("retornoconsultacnpj4b62elemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho addNewCabecalho();
        
        /**
         * Gets array of all "Alerta" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getAlertaArray();
        
        /**
         * Gets ith "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getAlertaArray(int i);
        
        /**
         * Returns number of "Alerta" element
         */
        int sizeOfAlertaArray();
        
        /**
         * Sets array of all "Alerta" element
         */
        void setAlertaArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] alertaArray);
        
        /**
         * Sets ith "Alerta" element
         */
        void setAlertaArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento alerta);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewAlerta(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Alerta" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewAlerta();
        
        /**
         * Removes the ith "Alerta" element
         */
        void removeAlerta(int i);
        
        /**
         * Gets array of all "Erro" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getErroArray();
        
        /**
         * Gets ith "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getErroArray(int i);
        
        /**
         * Returns number of "Erro" element
         */
        int sizeOfErroArray();
        
        /**
         * Sets array of all "Erro" element
         */
        void setErroArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] erroArray);
        
        /**
         * Sets ith "Erro" element
         */
        void setErroArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento erro);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewErro(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Erro" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewErro();
        
        /**
         * Removes the ith "Erro" element
         */
        void removeErro(int i);
        
        /**
         * Gets array of all "Detalhe" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe[] getDetalheArray();
        
        /**
         * Gets ith "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe getDetalheArray(int i);
        
        /**
         * Returns number of "Detalhe" element
         */
        int sizeOfDetalheArray();
        
        /**
         * Sets array of all "Detalhe" element
         */
        void setDetalheArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe[] detalheArray);
        
        /**
         * Sets ith "Detalhe" element
         */
        void setDetalheArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe detalhe);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe insertNewDetalhe(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe addNewDetalhe();
        
        /**
         * Removes the ith "Detalhe" element
         */
        void removeDetalhe(int i);
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalhobe92elemtype");
            
            /**
             * Gets the "Sucesso" element
             */
            boolean getSucesso();
            
            /**
             * Gets (as xml) the "Sucesso" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso xgetSucesso();
            
            /**
             * Sets the "Sucesso" element
             */
            void setSucesso(boolean sucesso);
            
            /**
             * Sets (as xml) the "Sucesso" element
             */
            void xsetSucesso(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso sucesso);
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * An XML Detalhe(@).
         *
         * This is a complex type.
         */
        public interface Detalhe extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Detalhe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("detalhea6b9elemtype");
            
            /**
             * Gets the "InscricaoMunicipal" element
             */
            long getInscricaoMunicipal();
            
            /**
             * Gets (as xml) the "InscricaoMunicipal" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoMunicipal();
            
            /**
             * Sets the "InscricaoMunicipal" element
             */
            void setInscricaoMunicipal(long inscricaoMunicipal);
            
            /**
             * Sets (as xml) the "InscricaoMunicipal" element
             */
            void xsetInscricaoMunicipal(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoMunicipal);
            
            /**
             * Gets the "EmiteNFe" element
             */
            boolean getEmiteNFe();
            
            /**
             * Gets (as xml) the "EmiteNFe" element
             */
            org.apache.xmlbeans.XmlBoolean xgetEmiteNFe();
            
            /**
             * Sets the "EmiteNFe" element
             */
            void setEmiteNFe(boolean emiteNFe);
            
            /**
             * Sets (as xml) the "EmiteNFe" element
             */
            void xsetEmiteNFe(org.apache.xmlbeans.XmlBoolean emiteNFe);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ.Detalhe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument.RetornoConsultaCNPJ) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoConsultaCNPJDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
