/*
 * An XML document type.
 * Localname: PedidoConsultaNFe
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one PedidoConsultaNFe(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class PedidoConsultaNFeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedidoConsultaNFeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDOCONSULTANFE$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "PedidoConsultaNFe");
    
    
    /**
     * Gets the "PedidoConsultaNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe getPedidoConsultaNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe)get_store().find_element_user(PEDIDOCONSULTANFE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PedidoConsultaNFe" element
     */
    public void setPedidoConsultaNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe pedidoConsultaNFe)
    {
        generatedSetterHelperImpl(pedidoConsultaNFe, PEDIDOCONSULTANFE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PedidoConsultaNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe addNewPedidoConsultaNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe)get_store().add_element_user(PEDIDOCONSULTANFE$0);
            return target;
        }
    }
    /**
     * An XML PedidoConsultaNFe(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class PedidoConsultaNFeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe
    {
        private static final long serialVersionUID = 1L;
        
        public PedidoConsultaNFeImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName DETALHE$2 = 
            new javax.xml.namespace.QName("", "Detalhe");
        private static final javax.xml.namespace.QName SIGNATURE$4 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "Detalhe" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[] getDetalheArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(DETALHE$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe getDetalheArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe)get_store().find_element_user(DETALHE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Detalhe" element
         */
        public int sizeOfDetalheArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DETALHE$2);
            }
        }
        
        /**
         * Sets array of all "Detalhe" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setDetalheArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[] detalheArray)
        {
            check_orphaned();
            arraySetterHelper(detalheArray, DETALHE$2);
        }
        
        /**
         * Sets ith "Detalhe" element
         */
        public void setDetalheArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe detalhe)
        {
            generatedSetterHelperImpl(detalhe, DETALHE$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe insertNewDetalhe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe)get_store().insert_element_user(DETALHE$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Detalhe" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe addNewDetalhe()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe)get_store().add_element_user(DETALHE$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "Detalhe" element
         */
        public void removeDetalhe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DETALHE$2, i);
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$4);
                return target;
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CPFCNPJREMETENTE$0 = 
                new javax.xml.namespace.QName("", "CPFCNPJRemetente");
            private static final javax.xml.namespace.QName VERSAO$2 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
            {
                generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$2);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$2);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.set(versao);
                }
            }
        }
        /**
         * An XML Detalhe(@).
         *
         * This is a complex type.
         */
        public static class DetalheImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe
        {
            private static final long serialVersionUID = 1L;
            
            public DetalheImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CHAVERPS$0 = 
                new javax.xml.namespace.QName("", "ChaveRPS");
            private static final javax.xml.namespace.QName CHAVENFE$2 = 
                new javax.xml.namespace.QName("", "ChaveNFe");
            
            
            /**
             * Gets the "ChaveRPS" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().find_element_user(CHAVERPS$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "ChaveRPS" element
             */
            public boolean isSetChaveRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(CHAVERPS$0) != 0;
                }
            }
            
            /**
             * Sets the "ChaveRPS" element
             */
            public void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS)
            {
                generatedSetterHelperImpl(chaveRPS, CHAVERPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ChaveRPS" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().add_element_user(CHAVERPS$0);
                    return target;
                }
            }
            
            /**
             * Unsets the "ChaveRPS" element
             */
            public void unsetChaveRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(CHAVERPS$0, 0);
                }
            }
            
            /**
             * Gets the "ChaveNFe" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().find_element_user(CHAVENFE$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "ChaveNFe" element
             */
            public boolean isSetChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(CHAVENFE$2) != 0;
                }
            }
            
            /**
             * Sets the "ChaveNFe" element
             */
            public void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe)
            {
                generatedSetterHelperImpl(chaveNFe, CHAVENFE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ChaveNFe" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().add_element_user(CHAVENFE$2);
                    return target;
                }
            }
            
            /**
             * Unsets the "ChaveNFe" element
             */
            public void unsetChaveNFe()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(CHAVENFE$2, 0);
                }
            }
        }
    }
}
