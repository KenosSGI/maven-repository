/*
 * An XML document type.
 * Localname: RetornoInformacoesLote
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one RetornoInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class RetornoInformacoesLoteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument
{
    private static final long serialVersionUID = 1L;
    
    public RetornoInformacoesLoteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETORNOINFORMACOESLOTE$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "RetornoInformacoesLote");
    
    
    /**
     * Gets the "RetornoInformacoesLote" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote getRetornoInformacoesLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote)get_store().find_element_user(RETORNOINFORMACOESLOTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "RetornoInformacoesLote" element
     */
    public void setRetornoInformacoesLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote retornoInformacoesLote)
    {
        generatedSetterHelperImpl(retornoInformacoesLote, RETORNOINFORMACOESLOTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "RetornoInformacoesLote" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote addNewRetornoInformacoesLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote)get_store().add_element_user(RETORNOINFORMACOESLOTE$0);
            return target;
        }
    }
    /**
     * An XML RetornoInformacoesLote(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class RetornoInformacoesLoteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote
    {
        private static final long serialVersionUID = 1L;
        
        public RetornoInformacoesLoteImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName ALERTA$2 = 
            new javax.xml.namespace.QName("", "Alerta");
        private static final javax.xml.namespace.QName ERRO$4 = 
            new javax.xml.namespace.QName("", "Erro");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "Alerta" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ALERTA$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getAlertaArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ALERTA$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Alerta" element
         */
        public int sizeOfAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ALERTA$2);
            }
        }
        
        /**
         * Sets array of all "Alerta" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setAlertaArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] alertaArray)
        {
            check_orphaned();
            arraySetterHelper(alertaArray, ALERTA$2);
        }
        
        /**
         * Sets ith "Alerta" element
         */
        public void setAlertaArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento alerta)
        {
            generatedSetterHelperImpl(alerta, ALERTA$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ALERTA$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewAlerta()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ALERTA$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "Alerta" element
         */
        public void removeAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ALERTA$2, i);
            }
        }
        
        /**
         * Gets array of all "Erro" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ERRO$4, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getErroArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ERRO$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Erro" element
         */
        public int sizeOfErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRO$4);
            }
        }
        
        /**
         * Sets array of all "Erro" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setErroArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] erroArray)
        {
            check_orphaned();
            arraySetterHelper(erroArray, ERRO$4);
        }
        
        /**
         * Sets ith "Erro" element
         */
        public void setErroArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento erro)
        {
            generatedSetterHelperImpl(erro, ERRO$4, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ERRO$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewErro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ERRO$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "Erro" element
         */
        public void removeErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRO$4, i);
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoInformacoesLoteDocument.RetornoInformacoesLote.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName SUCESSO$0 = 
                new javax.xml.namespace.QName("", "Sucesso");
            private static final javax.xml.namespace.QName INFORMACOESLOTE$2 = 
                new javax.xml.namespace.QName("", "InformacoesLote");
            private static final javax.xml.namespace.QName VERSAO$4 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "Sucesso" element
             */
            public boolean getSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      return false;
                    }
                    return target.getBooleanValue();
                }
            }
            
            /**
             * Gets (as xml) the "Sucesso" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso xgetSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "Sucesso" element
             */
            public void setSucesso(boolean sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUCESSO$0);
                    }
                    target.setBooleanValue(sucesso);
                }
            }
            
            /**
             * Sets (as xml) the "Sucesso" element
             */
            public void xsetSucesso(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().add_element_user(SUCESSO$0);
                    }
                    target.set(sucesso);
                }
            }
            
            /**
             * Gets the "InformacoesLote" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote getInformacoesLote()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote)get_store().find_element_user(INFORMACOESLOTE$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "InformacoesLote" element
             */
            public boolean isSetInformacoesLote()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(INFORMACOESLOTE$2) != 0;
                }
            }
            
            /**
             * Sets the "InformacoesLote" element
             */
            public void setInformacoesLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote informacoesLote)
            {
                generatedSetterHelperImpl(informacoesLote, INFORMACOESLOTE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "InformacoesLote" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote addNewInformacoesLote()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInformacoesLote)get_store().add_element_user(INFORMACOESLOTE$2);
                    return target;
                }
            }
            
            /**
             * Unsets the "InformacoesLote" element
             */
            public void unsetInformacoesLote()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(INFORMACOESLOTE$2, 0);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$4);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$4);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$4);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$4);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$4);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
