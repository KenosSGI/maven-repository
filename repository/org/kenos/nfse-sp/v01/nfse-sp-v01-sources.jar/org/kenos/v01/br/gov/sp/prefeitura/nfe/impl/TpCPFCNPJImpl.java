/*
 * XML Type:  tpCPFCNPJ
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpCPFCNPJ(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpCPFCNPJImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ
{
    private static final long serialVersionUID = 1L;
    
    public TpCPFCNPJImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CPF$0 = 
        new javax.xml.namespace.QName("", "CPF");
    private static final javax.xml.namespace.QName CNPJ$2 = 
        new javax.xml.namespace.QName("", "CNPJ");
    
    
    /**
     * Gets the "CPF" element
     */
    public java.lang.String getCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CPF" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF xgetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF)get_store().find_element_user(CPF$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CPF" element
     */
    public boolean isSetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$0) != 0;
        }
    }
    
    /**
     * Sets the "CPF" element
     */
    public void setCPF(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$0);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "CPF" element
     */
    public void xsetCPF(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPF)get_store().add_element_user(CPF$0);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "CPF" element
     */
    public void unsetCPF()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$0, 0);
        }
    }
    
    /**
     * Gets the "CNPJ" element
     */
    public java.lang.String getCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CNPJ" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ xgetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ)get_store().find_element_user(CNPJ$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CNPJ" element
     */
    public boolean isSetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$2) != 0;
        }
    }
    
    /**
     * Sets the "CNPJ" element
     */
    public void setCNPJ(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$2);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "CNPJ" element
     */
    public void xsetCNPJ(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCNPJ)get_store().add_element_user(CNPJ$2);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "CNPJ" element
     */
    public void unsetCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$2, 0);
        }
    }
}
