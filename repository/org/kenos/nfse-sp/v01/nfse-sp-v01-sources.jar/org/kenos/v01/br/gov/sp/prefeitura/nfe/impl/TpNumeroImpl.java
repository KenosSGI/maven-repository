/*
 * XML Type:  tpNumero
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpNumero(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero.
 */
public class TpNumeroImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero
{
    private static final long serialVersionUID = 1L;
    
    public TpNumeroImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpNumeroImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
