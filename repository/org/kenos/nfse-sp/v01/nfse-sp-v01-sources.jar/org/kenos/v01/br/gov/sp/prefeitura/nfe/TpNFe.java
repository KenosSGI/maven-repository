/*
 * XML Type:  tpNFe
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * An XML tpNFe(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public interface TpNFe extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TpNFe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("tpnfe34a9type");
    
    /**
     * Gets the "Assinatura" element
     */
    byte[] getAssinatura();
    
    /**
     * Gets (as xml) the "Assinatura" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura xgetAssinatura();
    
    /**
     * True if has "Assinatura" element
     */
    boolean isSetAssinatura();
    
    /**
     * Sets the "Assinatura" element
     */
    void setAssinatura(byte[] assinatura);
    
    /**
     * Sets (as xml) the "Assinatura" element
     */
    void xsetAssinatura(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAssinatura assinatura);
    
    /**
     * Unsets the "Assinatura" element
     */
    void unsetAssinatura();
    
    /**
     * Gets the "ChaveNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe();
    
    /**
     * Sets the "ChaveNFe" element
     */
    void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe);
    
    /**
     * Appends and returns a new empty "ChaveNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe();
    
    /**
     * Gets the "DataEmissaoNFe" element
     */
    java.util.Calendar getDataEmissaoNFe();
    
    /**
     * Gets (as xml) the "DataEmissaoNFe" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataEmissaoNFe();
    
    /**
     * Sets the "DataEmissaoNFe" element
     */
    void setDataEmissaoNFe(java.util.Calendar dataEmissaoNFe);
    
    /**
     * Sets (as xml) the "DataEmissaoNFe" element
     */
    void xsetDataEmissaoNFe(org.apache.xmlbeans.XmlDateTime dataEmissaoNFe);
    
    /**
     * Gets the "NumeroLote" element
     */
    long getNumeroLote();
    
    /**
     * Gets (as xml) the "NumeroLote" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroLote();
    
    /**
     * True if has "NumeroLote" element
     */
    boolean isSetNumeroLote();
    
    /**
     * Sets the "NumeroLote" element
     */
    void setNumeroLote(long numeroLote);
    
    /**
     * Sets (as xml) the "NumeroLote" element
     */
    void xsetNumeroLote(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroLote);
    
    /**
     * Unsets the "NumeroLote" element
     */
    void unsetNumeroLote();
    
    /**
     * Gets the "ChaveRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS();
    
    /**
     * True if has "ChaveRPS" element
     */
    boolean isSetChaveRPS();
    
    /**
     * Sets the "ChaveRPS" element
     */
    void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS);
    
    /**
     * Appends and returns a new empty "ChaveRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS();
    
    /**
     * Unsets the "ChaveRPS" element
     */
    void unsetChaveRPS();
    
    /**
     * Gets the "TipoRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.Enum getTipoRPS();
    
    /**
     * Gets (as xml) the "TipoRPS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS xgetTipoRPS();
    
    /**
     * True if has "TipoRPS" element
     */
    boolean isSetTipoRPS();
    
    /**
     * Sets the "TipoRPS" element
     */
    void setTipoRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS.Enum tipoRPS);
    
    /**
     * Sets (as xml) the "TipoRPS" element
     */
    void xsetTipoRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoRPS tipoRPS);
    
    /**
     * Unsets the "TipoRPS" element
     */
    void unsetTipoRPS();
    
    /**
     * Gets the "DataEmissaoRPS" element
     */
    java.util.Calendar getDataEmissaoRPS();
    
    /**
     * Gets (as xml) the "DataEmissaoRPS" element
     */
    org.apache.xmlbeans.XmlDate xgetDataEmissaoRPS();
    
    /**
     * True if has "DataEmissaoRPS" element
     */
    boolean isSetDataEmissaoRPS();
    
    /**
     * Sets the "DataEmissaoRPS" element
     */
    void setDataEmissaoRPS(java.util.Calendar dataEmissaoRPS);
    
    /**
     * Sets (as xml) the "DataEmissaoRPS" element
     */
    void xsetDataEmissaoRPS(org.apache.xmlbeans.XmlDate dataEmissaoRPS);
    
    /**
     * Unsets the "DataEmissaoRPS" element
     */
    void unsetDataEmissaoRPS();
    
    /**
     * Gets the "CPFCNPJPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJPrestador();
    
    /**
     * Sets the "CPFCNPJPrestador" element
     */
    void setCPFCNPJPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjPrestador);
    
    /**
     * Appends and returns a new empty "CPFCNPJPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJPrestador();
    
    /**
     * Gets the "RazaoSocialPrestador" element
     */
    java.lang.String getRazaoSocialPrestador();
    
    /**
     * Gets (as xml) the "RazaoSocialPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial xgetRazaoSocialPrestador();
    
    /**
     * Sets the "RazaoSocialPrestador" element
     */
    void setRazaoSocialPrestador(java.lang.String razaoSocialPrestador);
    
    /**
     * Sets (as xml) the "RazaoSocialPrestador" element
     */
    void xsetRazaoSocialPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial razaoSocialPrestador);
    
    /**
     * Gets the "EnderecoPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco getEnderecoPrestador();
    
    /**
     * Sets the "EnderecoPrestador" element
     */
    void setEnderecoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco enderecoPrestador);
    
    /**
     * Appends and returns a new empty "EnderecoPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco addNewEnderecoPrestador();
    
    /**
     * Gets the "EmailPrestador" element
     */
    java.lang.String getEmailPrestador();
    
    /**
     * Gets (as xml) the "EmailPrestador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail xgetEmailPrestador();
    
    /**
     * True if has "EmailPrestador" element
     */
    boolean isSetEmailPrestador();
    
    /**
     * Sets the "EmailPrestador" element
     */
    void setEmailPrestador(java.lang.String emailPrestador);
    
    /**
     * Sets (as xml) the "EmailPrestador" element
     */
    void xsetEmailPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail emailPrestador);
    
    /**
     * Unsets the "EmailPrestador" element
     */
    void unsetEmailPrestador();
    
    /**
     * Gets the "StatusNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe.Enum getStatusNFe();
    
    /**
     * Gets (as xml) the "StatusNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe xgetStatusNFe();
    
    /**
     * Sets the "StatusNFe" element
     */
    void setStatusNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe.Enum statusNFe);
    
    /**
     * Sets (as xml) the "StatusNFe" element
     */
    void xsetStatusNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpStatusNFe statusNFe);
    
    /**
     * Gets the "DataCancelamento" element
     */
    java.util.Calendar getDataCancelamento();
    
    /**
     * Gets (as xml) the "DataCancelamento" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataCancelamento();
    
    /**
     * True if has "DataCancelamento" element
     */
    boolean isSetDataCancelamento();
    
    /**
     * Sets the "DataCancelamento" element
     */
    void setDataCancelamento(java.util.Calendar dataCancelamento);
    
    /**
     * Sets (as xml) the "DataCancelamento" element
     */
    void xsetDataCancelamento(org.apache.xmlbeans.XmlDateTime dataCancelamento);
    
    /**
     * Unsets the "DataCancelamento" element
     */
    void unsetDataCancelamento();
    
    /**
     * Gets the "TributacaoNFe" element
     */
    java.lang.String getTributacaoNFe();
    
    /**
     * Gets (as xml) the "TributacaoNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe xgetTributacaoNFe();
    
    /**
     * Sets the "TributacaoNFe" element
     */
    void setTributacaoNFe(java.lang.String tributacaoNFe);
    
    /**
     * Sets (as xml) the "TributacaoNFe" element
     */
    void xsetTributacaoNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTributacaoNFe tributacaoNFe);
    
    /**
     * Gets the "OpcaoSimples" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpOpcaoSimples.Enum getOpcaoSimples();
    
    /**
     * Gets (as xml) the "OpcaoSimples" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpOpcaoSimples xgetOpcaoSimples();
    
    /**
     * Sets the "OpcaoSimples" element
     */
    void setOpcaoSimples(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpOpcaoSimples.Enum opcaoSimples);
    
    /**
     * Sets (as xml) the "OpcaoSimples" element
     */
    void xsetOpcaoSimples(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpOpcaoSimples opcaoSimples);
    
    /**
     * Gets the "NumeroGuia" element
     */
    long getNumeroGuia();
    
    /**
     * Gets (as xml) the "NumeroGuia" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroGuia();
    
    /**
     * True if has "NumeroGuia" element
     */
    boolean isSetNumeroGuia();
    
    /**
     * Sets the "NumeroGuia" element
     */
    void setNumeroGuia(long numeroGuia);
    
    /**
     * Sets (as xml) the "NumeroGuia" element
     */
    void xsetNumeroGuia(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroGuia);
    
    /**
     * Unsets the "NumeroGuia" element
     */
    void unsetNumeroGuia();
    
    /**
     * Gets the "DataQuitacaoGuia" element
     */
    java.util.Calendar getDataQuitacaoGuia();
    
    /**
     * Gets (as xml) the "DataQuitacaoGuia" element
     */
    org.apache.xmlbeans.XmlDate xgetDataQuitacaoGuia();
    
    /**
     * True if has "DataQuitacaoGuia" element
     */
    boolean isSetDataQuitacaoGuia();
    
    /**
     * Sets the "DataQuitacaoGuia" element
     */
    void setDataQuitacaoGuia(java.util.Calendar dataQuitacaoGuia);
    
    /**
     * Sets (as xml) the "DataQuitacaoGuia" element
     */
    void xsetDataQuitacaoGuia(org.apache.xmlbeans.XmlDate dataQuitacaoGuia);
    
    /**
     * Unsets the "DataQuitacaoGuia" element
     */
    void unsetDataQuitacaoGuia();
    
    /**
     * Gets the "ValorServicos" element
     */
    java.math.BigDecimal getValorServicos();
    
    /**
     * Gets (as xml) the "ValorServicos" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorServicos();
    
    /**
     * Sets the "ValorServicos" element
     */
    void setValorServicos(java.math.BigDecimal valorServicos);
    
    /**
     * Sets (as xml) the "ValorServicos" element
     */
    void xsetValorServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorServicos);
    
    /**
     * Gets the "ValorDeducoes" element
     */
    java.math.BigDecimal getValorDeducoes();
    
    /**
     * Gets (as xml) the "ValorDeducoes" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorDeducoes();
    
    /**
     * True if has "ValorDeducoes" element
     */
    boolean isSetValorDeducoes();
    
    /**
     * Sets the "ValorDeducoes" element
     */
    void setValorDeducoes(java.math.BigDecimal valorDeducoes);
    
    /**
     * Sets (as xml) the "ValorDeducoes" element
     */
    void xsetValorDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorDeducoes);
    
    /**
     * Unsets the "ValorDeducoes" element
     */
    void unsetValorDeducoes();
    
    /**
     * Gets the "ValorPIS" element
     */
    java.math.BigDecimal getValorPIS();
    
    /**
     * Gets (as xml) the "ValorPIS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorPIS();
    
    /**
     * True if has "ValorPIS" element
     */
    boolean isSetValorPIS();
    
    /**
     * Sets the "ValorPIS" element
     */
    void setValorPIS(java.math.BigDecimal valorPIS);
    
    /**
     * Sets (as xml) the "ValorPIS" element
     */
    void xsetValorPIS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorPIS);
    
    /**
     * Unsets the "ValorPIS" element
     */
    void unsetValorPIS();
    
    /**
     * Gets the "ValorCOFINS" element
     */
    java.math.BigDecimal getValorCOFINS();
    
    /**
     * Gets (as xml) the "ValorCOFINS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCOFINS();
    
    /**
     * True if has "ValorCOFINS" element
     */
    boolean isSetValorCOFINS();
    
    /**
     * Sets the "ValorCOFINS" element
     */
    void setValorCOFINS(java.math.BigDecimal valorCOFINS);
    
    /**
     * Sets (as xml) the "ValorCOFINS" element
     */
    void xsetValorCOFINS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCOFINS);
    
    /**
     * Unsets the "ValorCOFINS" element
     */
    void unsetValorCOFINS();
    
    /**
     * Gets the "ValorINSS" element
     */
    java.math.BigDecimal getValorINSS();
    
    /**
     * Gets (as xml) the "ValorINSS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorINSS();
    
    /**
     * True if has "ValorINSS" element
     */
    boolean isSetValorINSS();
    
    /**
     * Sets the "ValorINSS" element
     */
    void setValorINSS(java.math.BigDecimal valorINSS);
    
    /**
     * Sets (as xml) the "ValorINSS" element
     */
    void xsetValorINSS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorINSS);
    
    /**
     * Unsets the "ValorINSS" element
     */
    void unsetValorINSS();
    
    /**
     * Gets the "ValorIR" element
     */
    java.math.BigDecimal getValorIR();
    
    /**
     * Gets (as xml) the "ValorIR" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorIR();
    
    /**
     * True if has "ValorIR" element
     */
    boolean isSetValorIR();
    
    /**
     * Sets the "ValorIR" element
     */
    void setValorIR(java.math.BigDecimal valorIR);
    
    /**
     * Sets (as xml) the "ValorIR" element
     */
    void xsetValorIR(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorIR);
    
    /**
     * Unsets the "ValorIR" element
     */
    void unsetValorIR();
    
    /**
     * Gets the "ValorCSLL" element
     */
    java.math.BigDecimal getValorCSLL();
    
    /**
     * Gets (as xml) the "ValorCSLL" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCSLL();
    
    /**
     * True if has "ValorCSLL" element
     */
    boolean isSetValorCSLL();
    
    /**
     * Sets the "ValorCSLL" element
     */
    void setValorCSLL(java.math.BigDecimal valorCSLL);
    
    /**
     * Sets (as xml) the "ValorCSLL" element
     */
    void xsetValorCSLL(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCSLL);
    
    /**
     * Unsets the "ValorCSLL" element
     */
    void unsetValorCSLL();
    
    /**
     * Gets the "CodigoServico" element
     */
    java.lang.String getCodigoServico();
    
    /**
     * Gets (as xml) the "CodigoServico" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico xgetCodigoServico();
    
    /**
     * Sets the "CodigoServico" element
     */
    void setCodigoServico(java.lang.String codigoServico);
    
    /**
     * Sets (as xml) the "CodigoServico" element
     */
    void xsetCodigoServico(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoServico codigoServico);
    
    /**
     * Gets the "AliquotaServicos" element
     */
    java.math.BigDecimal getAliquotaServicos();
    
    /**
     * Gets (as xml) the "AliquotaServicos" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota xgetAliquotaServicos();
    
    /**
     * Sets the "AliquotaServicos" element
     */
    void setAliquotaServicos(java.math.BigDecimal aliquotaServicos);
    
    /**
     * Sets (as xml) the "AliquotaServicos" element
     */
    void xsetAliquotaServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota aliquotaServicos);
    
    /**
     * Gets the "ValorISS" element
     */
    java.math.BigDecimal getValorISS();
    
    /**
     * Gets (as xml) the "ValorISS" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorISS();
    
    /**
     * Sets the "ValorISS" element
     */
    void setValorISS(java.math.BigDecimal valorISS);
    
    /**
     * Sets (as xml) the "ValorISS" element
     */
    void xsetValorISS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorISS);
    
    /**
     * Gets the "ValorCredito" element
     */
    java.math.BigDecimal getValorCredito();
    
    /**
     * Gets (as xml) the "ValorCredito" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCredito();
    
    /**
     * Sets the "ValorCredito" element
     */
    void setValorCredito(java.math.BigDecimal valorCredito);
    
    /**
     * Sets (as xml) the "ValorCredito" element
     */
    void xsetValorCredito(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCredito);
    
    /**
     * Gets the "ISSRetido" element
     */
    boolean getISSRetido();
    
    /**
     * Gets (as xml) the "ISSRetido" element
     */
    org.apache.xmlbeans.XmlBoolean xgetISSRetido();
    
    /**
     * Sets the "ISSRetido" element
     */
    void setISSRetido(boolean issRetido);
    
    /**
     * Sets (as xml) the "ISSRetido" element
     */
    void xsetISSRetido(org.apache.xmlbeans.XmlBoolean issRetido);
    
    /**
     * Gets the "CPFCNPJTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJTomador();
    
    /**
     * True if has "CPFCNPJTomador" element
     */
    boolean isSetCPFCNPJTomador();
    
    /**
     * Sets the "CPFCNPJTomador" element
     */
    void setCPFCNPJTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjTomador);
    
    /**
     * Appends and returns a new empty "CPFCNPJTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJTomador();
    
    /**
     * Unsets the "CPFCNPJTomador" element
     */
    void unsetCPFCNPJTomador();
    
    /**
     * Gets the "InscricaoMunicipalTomador" element
     */
    long getInscricaoMunicipalTomador();
    
    /**
     * Gets (as xml) the "InscricaoMunicipalTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoMunicipalTomador();
    
    /**
     * True if has "InscricaoMunicipalTomador" element
     */
    boolean isSetInscricaoMunicipalTomador();
    
    /**
     * Sets the "InscricaoMunicipalTomador" element
     */
    void setInscricaoMunicipalTomador(long inscricaoMunicipalTomador);
    
    /**
     * Sets (as xml) the "InscricaoMunicipalTomador" element
     */
    void xsetInscricaoMunicipalTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoMunicipalTomador);
    
    /**
     * Unsets the "InscricaoMunicipalTomador" element
     */
    void unsetInscricaoMunicipalTomador();
    
    /**
     * Gets the "InscricaoEstadualTomador" element
     */
    long getInscricaoEstadualTomador();
    
    /**
     * Gets (as xml) the "InscricaoEstadualTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual xgetInscricaoEstadualTomador();
    
    /**
     * True if has "InscricaoEstadualTomador" element
     */
    boolean isSetInscricaoEstadualTomador();
    
    /**
     * Sets the "InscricaoEstadualTomador" element
     */
    void setInscricaoEstadualTomador(long inscricaoEstadualTomador);
    
    /**
     * Sets (as xml) the "InscricaoEstadualTomador" element
     */
    void xsetInscricaoEstadualTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoEstadual inscricaoEstadualTomador);
    
    /**
     * Unsets the "InscricaoEstadualTomador" element
     */
    void unsetInscricaoEstadualTomador();
    
    /**
     * Gets the "RazaoSocialTomador" element
     */
    java.lang.String getRazaoSocialTomador();
    
    /**
     * Gets (as xml) the "RazaoSocialTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial xgetRazaoSocialTomador();
    
    /**
     * True if has "RazaoSocialTomador" element
     */
    boolean isSetRazaoSocialTomador();
    
    /**
     * Sets the "RazaoSocialTomador" element
     */
    void setRazaoSocialTomador(java.lang.String razaoSocialTomador);
    
    /**
     * Sets (as xml) the "RazaoSocialTomador" element
     */
    void xsetRazaoSocialTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRazaoSocial razaoSocialTomador);
    
    /**
     * Unsets the "RazaoSocialTomador" element
     */
    void unsetRazaoSocialTomador();
    
    /**
     * Gets the "EnderecoTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco getEnderecoTomador();
    
    /**
     * True if has "EnderecoTomador" element
     */
    boolean isSetEnderecoTomador();
    
    /**
     * Sets the "EnderecoTomador" element
     */
    void setEnderecoTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco enderecoTomador);
    
    /**
     * Appends and returns a new empty "EnderecoTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco addNewEnderecoTomador();
    
    /**
     * Unsets the "EnderecoTomador" element
     */
    void unsetEnderecoTomador();
    
    /**
     * Gets the "EmailTomador" element
     */
    java.lang.String getEmailTomador();
    
    /**
     * Gets (as xml) the "EmailTomador" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail xgetEmailTomador();
    
    /**
     * True if has "EmailTomador" element
     */
    boolean isSetEmailTomador();
    
    /**
     * Sets the "EmailTomador" element
     */
    void setEmailTomador(java.lang.String emailTomador);
    
    /**
     * Sets (as xml) the "EmailTomador" element
     */
    void xsetEmailTomador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail emailTomador);
    
    /**
     * Unsets the "EmailTomador" element
     */
    void unsetEmailTomador();
    
    /**
     * Gets the "CPFCNPJIntermediario" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJIntermediario();
    
    /**
     * True if has "CPFCNPJIntermediario" element
     */
    boolean isSetCPFCNPJIntermediario();
    
    /**
     * Sets the "CPFCNPJIntermediario" element
     */
    void setCPFCNPJIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjIntermediario);
    
    /**
     * Appends and returns a new empty "CPFCNPJIntermediario" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJIntermediario();
    
    /**
     * Unsets the "CPFCNPJIntermediario" element
     */
    void unsetCPFCNPJIntermediario();
    
    /**
     * Gets the "InscricaoMunicipalIntermediario" element
     */
    long getInscricaoMunicipalIntermediario();
    
    /**
     * Gets (as xml) the "InscricaoMunicipalIntermediario" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoMunicipalIntermediario();
    
    /**
     * True if has "InscricaoMunicipalIntermediario" element
     */
    boolean isSetInscricaoMunicipalIntermediario();
    
    /**
     * Sets the "InscricaoMunicipalIntermediario" element
     */
    void setInscricaoMunicipalIntermediario(long inscricaoMunicipalIntermediario);
    
    /**
     * Sets (as xml) the "InscricaoMunicipalIntermediario" element
     */
    void xsetInscricaoMunicipalIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoMunicipalIntermediario);
    
    /**
     * Unsets the "InscricaoMunicipalIntermediario" element
     */
    void unsetInscricaoMunicipalIntermediario();
    
    /**
     * Gets the "ISSRetidoIntermediario" element
     */
    java.lang.String getISSRetidoIntermediario();
    
    /**
     * Gets (as xml) the "ISSRetidoIntermediario" element
     */
    org.apache.xmlbeans.XmlString xgetISSRetidoIntermediario();
    
    /**
     * True if has "ISSRetidoIntermediario" element
     */
    boolean isSetISSRetidoIntermediario();
    
    /**
     * Sets the "ISSRetidoIntermediario" element
     */
    void setISSRetidoIntermediario(java.lang.String issRetidoIntermediario);
    
    /**
     * Sets (as xml) the "ISSRetidoIntermediario" element
     */
    void xsetISSRetidoIntermediario(org.apache.xmlbeans.XmlString issRetidoIntermediario);
    
    /**
     * Unsets the "ISSRetidoIntermediario" element
     */
    void unsetISSRetidoIntermediario();
    
    /**
     * Gets the "EmailIntermediario" element
     */
    java.lang.String getEmailIntermediario();
    
    /**
     * Gets (as xml) the "EmailIntermediario" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail xgetEmailIntermediario();
    
    /**
     * True if has "EmailIntermediario" element
     */
    boolean isSetEmailIntermediario();
    
    /**
     * Sets the "EmailIntermediario" element
     */
    void setEmailIntermediario(java.lang.String emailIntermediario);
    
    /**
     * Sets (as xml) the "EmailIntermediario" element
     */
    void xsetEmailIntermediario(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEmail emailIntermediario);
    
    /**
     * Unsets the "EmailIntermediario" element
     */
    void unsetEmailIntermediario();
    
    /**
     * Gets the "Discriminacao" element
     */
    java.lang.String getDiscriminacao();
    
    /**
     * Gets (as xml) the "Discriminacao" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao xgetDiscriminacao();
    
    /**
     * Sets the "Discriminacao" element
     */
    void setDiscriminacao(java.lang.String discriminacao);
    
    /**
     * Sets (as xml) the "Discriminacao" element
     */
    void xsetDiscriminacao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDiscriminacao discriminacao);
    
    /**
     * Gets the "ValorCargaTributaria" element
     */
    java.math.BigDecimal getValorCargaTributaria();
    
    /**
     * Gets (as xml) the "ValorCargaTributaria" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorCargaTributaria();
    
    /**
     * True if has "ValorCargaTributaria" element
     */
    boolean isSetValorCargaTributaria();
    
    /**
     * Sets the "ValorCargaTributaria" element
     */
    void setValorCargaTributaria(java.math.BigDecimal valorCargaTributaria);
    
    /**
     * Sets (as xml) the "ValorCargaTributaria" element
     */
    void xsetValorCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorCargaTributaria);
    
    /**
     * Unsets the "ValorCargaTributaria" element
     */
    void unsetValorCargaTributaria();
    
    /**
     * Gets the "PercentualCargaTributaria" element
     */
    java.math.BigDecimal getPercentualCargaTributaria();
    
    /**
     * Gets (as xml) the "PercentualCargaTributaria" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria xgetPercentualCargaTributaria();
    
    /**
     * True if has "PercentualCargaTributaria" element
     */
    boolean isSetPercentualCargaTributaria();
    
    /**
     * Sets the "PercentualCargaTributaria" element
     */
    void setPercentualCargaTributaria(java.math.BigDecimal percentualCargaTributaria);
    
    /**
     * Sets (as xml) the "PercentualCargaTributaria" element
     */
    void xsetPercentualCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpPercentualCargaTributaria percentualCargaTributaria);
    
    /**
     * Unsets the "PercentualCargaTributaria" element
     */
    void unsetPercentualCargaTributaria();
    
    /**
     * Gets the "FonteCargaTributaria" element
     */
    java.lang.String getFonteCargaTributaria();
    
    /**
     * Gets (as xml) the "FonteCargaTributaria" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria xgetFonteCargaTributaria();
    
    /**
     * True if has "FonteCargaTributaria" element
     */
    boolean isSetFonteCargaTributaria();
    
    /**
     * Sets the "FonteCargaTributaria" element
     */
    void setFonteCargaTributaria(java.lang.String fonteCargaTributaria);
    
    /**
     * Sets (as xml) the "FonteCargaTributaria" element
     */
    void xsetFonteCargaTributaria(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpFonteCargaTributaria fonteCargaTributaria);
    
    /**
     * Unsets the "FonteCargaTributaria" element
     */
    void unsetFonteCargaTributaria();
    
    /**
     * Gets the "CodigoCEI" element
     */
    long getCodigoCEI();
    
    /**
     * Gets (as xml) the "CodigoCEI" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetCodigoCEI();
    
    /**
     * True if has "CodigoCEI" element
     */
    boolean isSetCodigoCEI();
    
    /**
     * Sets the "CodigoCEI" element
     */
    void setCodigoCEI(long codigoCEI);
    
    /**
     * Sets (as xml) the "CodigoCEI" element
     */
    void xsetCodigoCEI(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero codigoCEI);
    
    /**
     * Unsets the "CodigoCEI" element
     */
    void unsetCodigoCEI();
    
    /**
     * Gets the "MatriculaObra" element
     */
    long getMatriculaObra();
    
    /**
     * Gets (as xml) the "MatriculaObra" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetMatriculaObra();
    
    /**
     * True if has "MatriculaObra" element
     */
    boolean isSetMatriculaObra();
    
    /**
     * Sets the "MatriculaObra" element
     */
    void setMatriculaObra(long matriculaObra);
    
    /**
     * Sets (as xml) the "MatriculaObra" element
     */
    void xsetMatriculaObra(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero matriculaObra);
    
    /**
     * Unsets the "MatriculaObra" element
     */
    void unsetMatriculaObra();
    
    /**
     * Gets the "MunicipioPrestacao" element
     */
    int getMunicipioPrestacao();
    
    /**
     * Gets (as xml) the "MunicipioPrestacao" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade xgetMunicipioPrestacao();
    
    /**
     * True if has "MunicipioPrestacao" element
     */
    boolean isSetMunicipioPrestacao();
    
    /**
     * Sets the "MunicipioPrestacao" element
     */
    void setMunicipioPrestacao(int municipioPrestacao);
    
    /**
     * Sets (as xml) the "MunicipioPrestacao" element
     */
    void xsetMunicipioPrestacao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade municipioPrestacao);
    
    /**
     * Unsets the "MunicipioPrestacao" element
     */
    void unsetMunicipioPrestacao();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
