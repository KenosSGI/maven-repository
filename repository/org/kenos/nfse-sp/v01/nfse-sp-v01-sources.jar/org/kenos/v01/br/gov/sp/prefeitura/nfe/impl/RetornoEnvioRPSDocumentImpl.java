/*
 * An XML document type.
 * Localname: RetornoEnvioRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one RetornoEnvioRPS(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class RetornoEnvioRPSDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument
{
    private static final long serialVersionUID = 1L;
    
    public RetornoEnvioRPSDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETORNOENVIORPS$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "RetornoEnvioRPS");
    
    
    /**
     * Gets the "RetornoEnvioRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS getRetornoEnvioRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS)get_store().find_element_user(RETORNOENVIORPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "RetornoEnvioRPS" element
     */
    public void setRetornoEnvioRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS retornoEnvioRPS)
    {
        generatedSetterHelperImpl(retornoEnvioRPS, RETORNOENVIORPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "RetornoEnvioRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS addNewRetornoEnvioRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS)get_store().add_element_user(RETORNOENVIORPS$0);
            return target;
        }
    }
    /**
     * An XML RetornoEnvioRPS(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class RetornoEnvioRPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS
    {
        private static final long serialVersionUID = 1L;
        
        public RetornoEnvioRPSImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName ALERTA$2 = 
            new javax.xml.namespace.QName("", "Alerta");
        private static final javax.xml.namespace.QName ERRO$4 = 
            new javax.xml.namespace.QName("", "Erro");
        private static final javax.xml.namespace.QName CHAVENFERPS$6 = 
            new javax.xml.namespace.QName("", "ChaveNFeRPS");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "Alerta" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ALERTA$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getAlertaArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ALERTA$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Alerta" element
         */
        public int sizeOfAlertaArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ALERTA$2);
            }
        }
        
        /**
         * Sets array of all "Alerta" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setAlertaArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] alertaArray)
        {
            check_orphaned();
            arraySetterHelper(alertaArray, ALERTA$2);
        }
        
        /**
         * Sets ith "Alerta" element
         */
        public void setAlertaArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento alerta)
        {
            generatedSetterHelperImpl(alerta, ALERTA$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ALERTA$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Alerta" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewAlerta()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ALERTA$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "Alerta" element
         */
        public void removeAlerta(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ALERTA$2, i);
            }
        }
        
        /**
         * Gets array of all "Erro" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] getErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ERRO$4, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento getErroArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().find_element_user(ERRO$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Erro" element
         */
        public int sizeOfErroArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRO$4);
            }
        }
        
        /**
         * Sets array of all "Erro" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setErroArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento[] erroArray)
        {
            check_orphaned();
            arraySetterHelper(erroArray, ERRO$4);
        }
        
        /**
         * Sets ith "Erro" element
         */
        public void setErroArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento erro)
        {
            generatedSetterHelperImpl(erro, ERRO$4, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento insertNewErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().insert_element_user(ERRO$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Erro" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento addNewErro()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento)get_store().add_element_user(ERRO$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "Erro" element
         */
        public void removeErro(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRO$4, i);
            }
        }
        
        /**
         * Gets the "ChaveNFeRPS" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS getChaveNFeRPS()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS)get_store().find_element_user(CHAVENFERPS$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ChaveNFeRPS" element
         */
        public boolean isSetChaveNFeRPS()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CHAVENFERPS$6) != 0;
            }
        }
        
        /**
         * Sets the "ChaveNFeRPS" element
         */
        public void setChaveNFeRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS chaveNFeRPS)
        {
            generatedSetterHelperImpl(chaveNFeRPS, CHAVENFERPS$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ChaveNFeRPS" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS addNewChaveNFeRPS()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFeRPS)get_store().add_element_user(CHAVENFERPS$6);
                return target;
            }
        }
        
        /**
         * Unsets the "ChaveNFeRPS" element
         */
        public void unsetChaveNFeRPS()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CHAVENFERPS$6, 0);
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.RetornoEnvioRPSDocument.RetornoEnvioRPS.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName SUCESSO$0 = 
                new javax.xml.namespace.QName("", "Sucesso");
            private static final javax.xml.namespace.QName VERSAO$2 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "Sucesso" element
             */
            public boolean getSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      return false;
                    }
                    return target.getBooleanValue();
                }
            }
            
            /**
             * Gets (as xml) the "Sucesso" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso xgetSucesso()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "Sucesso" element
             */
            public void setSucesso(boolean sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUCESSO$0);
                    }
                    target.setBooleanValue(sucesso);
                }
            }
            
            /**
             * Sets (as xml) the "Sucesso" element
             */
            public void xsetSucesso(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso sucesso)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().find_element_user(SUCESSO$0, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpSucesso)get_store().add_element_user(SUCESSO$0);
                    }
                    target.set(sucesso);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$2);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$2);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
