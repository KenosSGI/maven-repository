/*
 * An XML document type.
 * Localname: PedidoConsultaCNPJ
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one PedidoConsultaCNPJ(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class PedidoConsultaCNPJDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedidoConsultaCNPJDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDOCONSULTACNPJ$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "PedidoConsultaCNPJ");
    
    
    /**
     * Gets the "PedidoConsultaCNPJ" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ getPedidoConsultaCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ)get_store().find_element_user(PEDIDOCONSULTACNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PedidoConsultaCNPJ" element
     */
    public void setPedidoConsultaCNPJ(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ pedidoConsultaCNPJ)
    {
        generatedSetterHelperImpl(pedidoConsultaCNPJ, PEDIDOCONSULTACNPJ$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PedidoConsultaCNPJ" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ addNewPedidoConsultaCNPJ()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ)get_store().add_element_user(PEDIDOCONSULTACNPJ$0);
            return target;
        }
    }
    /**
     * An XML PedidoConsultaCNPJ(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class PedidoConsultaCNPJImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ
    {
        private static final long serialVersionUID = 1L;
        
        public PedidoConsultaCNPJImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName CNPJCONTRIBUINTE$2 = 
            new javax.xml.namespace.QName("", "CNPJContribuinte");
        private static final javax.xml.namespace.QName SIGNATURE$4 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets the "CNPJContribuinte" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCNPJContribuinte()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CNPJCONTRIBUINTE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "CNPJContribuinte" element
         */
        public void setCNPJContribuinte(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cnpjContribuinte)
        {
            generatedSetterHelperImpl(cnpjContribuinte, CNPJCONTRIBUINTE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CNPJContribuinte" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCNPJContribuinte()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CNPJCONTRIBUINTE$2);
                return target;
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$4);
                return target;
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaCNPJDocument.PedidoConsultaCNPJ.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CPFCNPJREMETENTE$0 = 
                new javax.xml.namespace.QName("", "CPFCNPJRemetente");
            private static final javax.xml.namespace.QName VERSAO$2 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
            {
                generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$2);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$2);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$2);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$2);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
