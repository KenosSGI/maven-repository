/*
 * XML Type:  tpEvento
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpEvento(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpEventoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEvento
{
    private static final long serialVersionUID = 1L;
    
    public TpEventoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGO$0 = 
        new javax.xml.namespace.QName("", "Codigo");
    private static final javax.xml.namespace.QName DESCRICAO$2 = 
        new javax.xml.namespace.QName("", "Descricao");
    private static final javax.xml.namespace.QName CHAVERPS$4 = 
        new javax.xml.namespace.QName("", "ChaveRPS");
    private static final javax.xml.namespace.QName CHAVENFE$6 = 
        new javax.xml.namespace.QName("", "ChaveNFe");
    
    
    /**
     * Gets the "Codigo" element
     */
    public short getCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getShortValue();
        }
    }
    
    /**
     * Gets (as xml) the "Codigo" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento xgetCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento)get_store().find_element_user(CODIGO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Codigo" element
     */
    public void setCodigo(short codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGO$0);
            }
            target.setShortValue(codigo);
        }
    }
    
    /**
     * Sets (as xml) the "Codigo" element
     */
    public void xsetCodigo(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoEvento)get_store().add_element_user(CODIGO$0);
            }
            target.set(codigo);
        }
    }
    
    /**
     * Gets the "Descricao" element
     */
    public java.lang.String getDescricao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Descricao" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento xgetDescricao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento)get_store().find_element_user(DESCRICAO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Descricao" element
     */
    public boolean isSetDescricao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRICAO$2) != 0;
        }
    }
    
    /**
     * Sets the "Descricao" element
     */
    public void setDescricao(java.lang.String descricao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRICAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRICAO$2);
            }
            target.setStringValue(descricao);
        }
    }
    
    /**
     * Sets (as xml) the "Descricao" element
     */
    public void xsetDescricao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento descricao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento)get_store().find_element_user(DESCRICAO$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpDescricaoEvento)get_store().add_element_user(DESCRICAO$2);
            }
            target.set(descricao);
        }
    }
    
    /**
     * Unsets the "Descricao" element
     */
    public void unsetDescricao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRICAO$2, 0);
        }
    }
    
    /**
     * Gets the "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().find_element_user(CHAVERPS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ChaveRPS" element
     */
    public boolean isSetChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CHAVERPS$4) != 0;
        }
    }
    
    /**
     * Sets the "ChaveRPS" element
     */
    public void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS)
    {
        generatedSetterHelperImpl(chaveRPS, CHAVERPS$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ChaveRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS)get_store().add_element_user(CHAVERPS$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ChaveRPS" element
     */
    public void unsetChaveRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CHAVERPS$4, 0);
        }
    }
    
    /**
     * Gets the "ChaveNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().find_element_user(CHAVENFE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ChaveNFe" element
     */
    public boolean isSetChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CHAVENFE$6) != 0;
        }
    }
    
    /**
     * Sets the "ChaveNFe" element
     */
    public void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe)
    {
        generatedSetterHelperImpl(chaveNFe, CHAVENFE$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ChaveNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe)get_store().add_element_user(CHAVENFE$6);
            return target;
        }
    }
    
    /**
     * Unsets the "ChaveNFe" element
     */
    public void unsetChaveNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CHAVENFE$6, 0);
        }
    }
}
