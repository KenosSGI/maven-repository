/*
 * XML Type:  tpEndereco
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * An XML tpEndereco(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public interface TpEndereco extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TpEndereco.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("tpenderecob1cftype");
    
    /**
     * Gets the "TipoLogradouro" element
     */
    java.lang.String getTipoLogradouro();
    
    /**
     * Gets (as xml) the "TipoLogradouro" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro xgetTipoLogradouro();
    
    /**
     * True if has "TipoLogradouro" element
     */
    boolean isSetTipoLogradouro();
    
    /**
     * Sets the "TipoLogradouro" element
     */
    void setTipoLogradouro(java.lang.String tipoLogradouro);
    
    /**
     * Sets (as xml) the "TipoLogradouro" element
     */
    void xsetTipoLogradouro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpTipoLogradouro tipoLogradouro);
    
    /**
     * Unsets the "TipoLogradouro" element
     */
    void unsetTipoLogradouro();
    
    /**
     * Gets the "Logradouro" element
     */
    java.lang.String getLogradouro();
    
    /**
     * Gets (as xml) the "Logradouro" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro xgetLogradouro();
    
    /**
     * True if has "Logradouro" element
     */
    boolean isSetLogradouro();
    
    /**
     * Sets the "Logradouro" element
     */
    void setLogradouro(java.lang.String logradouro);
    
    /**
     * Sets (as xml) the "Logradouro" element
     */
    void xsetLogradouro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpLogradouro logradouro);
    
    /**
     * Unsets the "Logradouro" element
     */
    void unsetLogradouro();
    
    /**
     * Gets the "NumeroEndereco" element
     */
    java.lang.String getNumeroEndereco();
    
    /**
     * Gets (as xml) the "NumeroEndereco" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco xgetNumeroEndereco();
    
    /**
     * True if has "NumeroEndereco" element
     */
    boolean isSetNumeroEndereco();
    
    /**
     * Sets the "NumeroEndereco" element
     */
    void setNumeroEndereco(java.lang.String numeroEndereco);
    
    /**
     * Sets (as xml) the "NumeroEndereco" element
     */
    void xsetNumeroEndereco(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumeroEndereco numeroEndereco);
    
    /**
     * Unsets the "NumeroEndereco" element
     */
    void unsetNumeroEndereco();
    
    /**
     * Gets the "ComplementoEndereco" element
     */
    java.lang.String getComplementoEndereco();
    
    /**
     * Gets (as xml) the "ComplementoEndereco" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco xgetComplementoEndereco();
    
    /**
     * True if has "ComplementoEndereco" element
     */
    boolean isSetComplementoEndereco();
    
    /**
     * Sets the "ComplementoEndereco" element
     */
    void setComplementoEndereco(java.lang.String complementoEndereco);
    
    /**
     * Sets (as xml) the "ComplementoEndereco" element
     */
    void xsetComplementoEndereco(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpComplementoEndereco complementoEndereco);
    
    /**
     * Unsets the "ComplementoEndereco" element
     */
    void unsetComplementoEndereco();
    
    /**
     * Gets the "Bairro" element
     */
    java.lang.String getBairro();
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro xgetBairro();
    
    /**
     * True if has "Bairro" element
     */
    boolean isSetBairro();
    
    /**
     * Sets the "Bairro" element
     */
    void setBairro(java.lang.String bairro);
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    void xsetBairro(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpBairro bairro);
    
    /**
     * Unsets the "Bairro" element
     */
    void unsetBairro();
    
    /**
     * Gets the "Cidade" element
     */
    int getCidade();
    
    /**
     * Gets (as xml) the "Cidade" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade xgetCidade();
    
    /**
     * True if has "Cidade" element
     */
    boolean isSetCidade();
    
    /**
     * Sets the "Cidade" element
     */
    void setCidade(int cidade);
    
    /**
     * Sets (as xml) the "Cidade" element
     */
    void xsetCidade(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade cidade);
    
    /**
     * Unsets the "Cidade" element
     */
    void unsetCidade();
    
    /**
     * Gets the "UF" element
     */
    java.lang.String getUF();
    
    /**
     * Gets (as xml) the "UF" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF xgetUF();
    
    /**
     * True if has "UF" element
     */
    boolean isSetUF();
    
    /**
     * Sets the "UF" element
     */
    void setUF(java.lang.String uf);
    
    /**
     * Sets (as xml) the "UF" element
     */
    void xsetUF(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpUF uf);
    
    /**
     * Unsets the "UF" element
     */
    void unsetUF();
    
    /**
     * Gets the "CEP" element
     */
    java.lang.String getCEP();
    
    /**
     * Gets (as xml) the "CEP" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP xgetCEP();
    
    /**
     * True if has "CEP" element
     */
    boolean isSetCEP();
    
    /**
     * Sets the "CEP" element
     */
    void setCEP(java.lang.String cep);
    
    /**
     * Sets (as xml) the "CEP" element
     */
    void xsetCEP(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCEP cep);
    
    /**
     * Unsets the "CEP" element
     */
    void unsetCEP();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
