/*
 * XML Type:  tpCidade
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpCidade(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade.
 */
public class TpCidadeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCidade
{
    private static final long serialVersionUID = 1L;
    
    public TpCidadeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpCidadeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
