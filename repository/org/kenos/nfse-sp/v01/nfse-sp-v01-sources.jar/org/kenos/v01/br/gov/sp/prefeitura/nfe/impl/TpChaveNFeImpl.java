/*
 * XML Type:  tpChaveNFe
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpChaveNFe(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is a complex type.
 */
public class TpChaveNFeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe
{
    private static final long serialVersionUID = 1L;
    
    public TpChaveNFeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INSCRICAOPRESTADOR$0 = 
        new javax.xml.namespace.QName("", "InscricaoPrestador");
    private static final javax.xml.namespace.QName NUMERONFE$2 = 
        new javax.xml.namespace.QName("", "NumeroNFe");
    private static final javax.xml.namespace.QName CODIGOVERIFICACAO$4 = 
        new javax.xml.namespace.QName("", "CodigoVerificacao");
    
    
    /**
     * Gets the "InscricaoPrestador" element
     */
    public long getInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoPrestador" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal xgetInscricaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "InscricaoPrestador" element
     */
    public void setInscricaoPrestador(long inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOPRESTADOR$0);
            }
            target.setLongValue(inscricaoPrestador);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoPrestador" element
     */
    public void xsetInscricaoPrestador(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal inscricaoPrestador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().find_element_user(INSCRICAOPRESTADOR$0, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpInscricaoMunicipal)get_store().add_element_user(INSCRICAOPRESTADOR$0);
            }
            target.set(inscricaoPrestador);
        }
    }
    
    /**
     * Gets the "NumeroNFe" element
     */
    public long getNumeroNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFE$2, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroNFe" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero xgetNumeroNFe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMERONFE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "NumeroNFe" element
     */
    public void setNumeroNFe(long numeroNFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERONFE$2);
            }
            target.setLongValue(numeroNFe);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroNFe" element
     */
    public void xsetNumeroNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero numeroNFe)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().find_element_user(NUMERONFE$2, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpNumero)get_store().add_element_user(NUMERONFE$2);
            }
            target.set(numeroNFe);
        }
    }
    
    /**
     * Gets the "CodigoVerificacao" element
     */
    public java.lang.String getCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOVERIFICACAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoVerificacao" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao xgetCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao)get_store().find_element_user(CODIGOVERIFICACAO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoVerificacao" element
     */
    public boolean isSetCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOVERIFICACAO$4) != 0;
        }
    }
    
    /**
     * Sets the "CodigoVerificacao" element
     */
    public void setCodigoVerificacao(java.lang.String codigoVerificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOVERIFICACAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOVERIFICACAO$4);
            }
            target.setStringValue(codigoVerificacao);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoVerificacao" element
     */
    public void xsetCodigoVerificacao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao codigoVerificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao)get_store().find_element_user(CODIGOVERIFICACAO$4, 0);
            if (target == null)
            {
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCodigoVerificacao)get_store().add_element_user(CODIGOVERIFICACAO$4);
            }
            target.set(codigoVerificacao);
        }
    }
    
    /**
     * Unsets the "CodigoVerificacao" element
     */
    public void unsetCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOVERIFICACAO$4, 0);
        }
    }
}
