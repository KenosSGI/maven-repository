/*
 * XML Type:  tpQuantidade
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpQuantidade(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade.
 */
public class TpQuantidadeImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade
{
    private static final long serialVersionUID = 1L;
    
    public TpQuantidadeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpQuantidadeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
