/*
 * XML Type:  tpAliquota
 * Namespace: http://www.prefeitura.sp.gov.br/nfe/tipos
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * An XML tpAliquota(@http://www.prefeitura.sp.gov.br/nfe/tipos).
 *
 * This is an atomic type that is a restriction of org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota.
 */
public class TpAliquotaImpl extends org.apache.xmlbeans.impl.values.JavaDecimalHolderEx implements org.kenos.v01.br.gov.sp.prefeitura.nfe.TpAliquota
{
    private static final long serialVersionUID = 1L;
    
    public TpAliquotaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpAliquotaImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
