/*
 * An XML document type.
 * Localname: PedidoConsultaNFe
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe;


/**
 * A document containing one PedidoConsultaNFe(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public interface PedidoConsultaNFeDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoConsultaNFeDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoconsultanfe642bdoctype");
    
    /**
     * Gets the "PedidoConsultaNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe getPedidoConsultaNFe();
    
    /**
     * Sets the "PedidoConsultaNFe" element
     */
    void setPedidoConsultaNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe pedidoConsultaNFe);
    
    /**
     * Appends and returns a new empty "PedidoConsultaNFe" element
     */
    org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe addNewPedidoConsultaNFe();
    
    /**
     * An XML PedidoConsultaNFe(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public interface PedidoConsultaNFe extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PedidoConsultaNFe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("pedidoconsultanfe648aelemtype");
        
        /**
         * Gets the "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho getCabecalho();
        
        /**
         * Sets the "Cabecalho" element
         */
        void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho cabecalho);
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho addNewCabecalho();
        
        /**
         * Gets array of all "Detalhe" elements
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[] getDetalheArray();
        
        /**
         * Gets ith "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe getDetalheArray(int i);
        
        /**
         * Returns number of "Detalhe" element
         */
        int sizeOfDetalheArray();
        
        /**
         * Sets array of all "Detalhe" element
         */
        void setDetalheArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe[] detalheArray);
        
        /**
         * Sets ith "Detalhe" element
         */
        void setDetalheArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe detalhe);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe insertNewDetalhe(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Detalhe" element
         */
        org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe addNewDetalhe();
        
        /**
         * Removes the ith "Detalhe" element
         */
        void removeDetalhe(int i);
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public interface Cabecalho extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Cabecalho.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("cabecalhoefbaelemtype");
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente();
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente);
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente();
            
            /**
             * Gets the "Versao" attribute
             */
            long getVersao();
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao();
            
            /**
             * Sets the "Versao" attribute
             */
            void setVersao(long versao);
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Cabecalho) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * An XML Detalhe(@).
         *
         * This is a complex type.
         */
        public interface Detalhe extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Detalhe.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s9BFB038F280EB6AFD011F4FF09CC3C68").resolveHandle("detalhe0361elemtype");
            
            /**
             * Gets the "ChaveRPS" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS getChaveRPS();
            
            /**
             * True if has "ChaveRPS" element
             */
            boolean isSetChaveRPS();
            
            /**
             * Sets the "ChaveRPS" element
             */
            void setChaveRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS chaveRPS);
            
            /**
             * Appends and returns a new empty "ChaveRPS" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveRPS addNewChaveRPS();
            
            /**
             * Unsets the "ChaveRPS" element
             */
            void unsetChaveRPS();
            
            /**
             * Gets the "ChaveNFe" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe getChaveNFe();
            
            /**
             * True if has "ChaveNFe" element
             */
            boolean isSetChaveNFe();
            
            /**
             * Sets the "ChaveNFe" element
             */
            void setChaveNFe(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe chaveNFe);
            
            /**
             * Appends and returns a new empty "ChaveNFe" element
             */
            org.kenos.v01.br.gov.sp.prefeitura.nfe.TpChaveNFe addNewChaveNFe();
            
            /**
             * Unsets the "ChaveNFe" element
             */
            void unsetChaveNFe();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe newInstance() {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe.Detalhe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe newInstance() {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument.PedidoConsultaNFe) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument newInstance() {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoConsultaNFeDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
