/*
 * An XML document type.
 * Localname: PedidoEnvioLoteRPS
 * Namespace: http://www.prefeitura.sp.gov.br/nfe
 * Java type: org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument
 *
 * Automatically generated - do not modify.
 */
package org.kenos.v01.br.gov.sp.prefeitura.nfe.impl;
/**
 * A document containing one PedidoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe) element.
 *
 * This is a complex type.
 */
public class PedidoEnvioLoteRPSDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument
{
    private static final long serialVersionUID = 1L;
    
    public PedidoEnvioLoteRPSDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDOENVIOLOTERPS$0 = 
        new javax.xml.namespace.QName("http://www.prefeitura.sp.gov.br/nfe", "PedidoEnvioLoteRPS");
    
    
    /**
     * Gets the "PedidoEnvioLoteRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS getPedidoEnvioLoteRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS)get_store().find_element_user(PEDIDOENVIOLOTERPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PedidoEnvioLoteRPS" element
     */
    public void setPedidoEnvioLoteRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS pedidoEnvioLoteRPS)
    {
        generatedSetterHelperImpl(pedidoEnvioLoteRPS, PEDIDOENVIOLOTERPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PedidoEnvioLoteRPS" element
     */
    public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS addNewPedidoEnvioLoteRPS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS target = null;
            target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS)get_store().add_element_user(PEDIDOENVIOLOTERPS$0);
            return target;
        }
    }
    /**
     * An XML PedidoEnvioLoteRPS(@http://www.prefeitura.sp.gov.br/nfe).
     *
     * This is a complex type.
     */
    public static class PedidoEnvioLoteRPSImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS
    {
        private static final long serialVersionUID = 1L;
        
        public PedidoEnvioLoteRPSImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CABECALHO$0 = 
            new javax.xml.namespace.QName("", "Cabecalho");
        private static final javax.xml.namespace.QName RPS$2 = 
            new javax.xml.namespace.QName("", "RPS");
        private static final javax.xml.namespace.QName SIGNATURE$4 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho getCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Cabecalho" element
         */
        public void setCabecalho(org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho cabecalho)
        {
            generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Cabecalho" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho addNewCabecalho()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho)get_store().add_element_user(CABECALHO$0);
                return target;
            }
        }
        
        /**
         * Gets array of all "RPS" elements
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[] getRPSArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(RPS$2, targetList);
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[] result = new org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "RPS" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS getRPSArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS)get_store().find_element_user(RPS$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "RPS" element
         */
        public int sizeOfRPSArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RPS$2);
            }
        }
        
        /**
         * Sets array of all "RPS" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setRPSArray(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS[] rpsArray)
        {
            check_orphaned();
            arraySetterHelper(rpsArray, RPS$2);
        }
        
        /**
         * Sets ith "RPS" element
         */
        public void setRPSArray(int i, org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS rps)
        {
            generatedSetterHelperImpl(rps, RPS$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "RPS" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS insertNewRPS(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS)get_store().insert_element_user(RPS$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "RPS" element
         */
        public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS addNewRPS()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS target = null;
                target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpRPS)get_store().add_element_user(RPS$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "RPS" element
         */
        public void removeRPS(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RPS$2, i);
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$4);
                return target;
            }
        }
        /**
         * An XML Cabecalho(@).
         *
         * This is a complex type.
         */
        public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.kenos.v01.br.gov.sp.prefeitura.nfe.PedidoEnvioLoteRPSDocument.PedidoEnvioLoteRPS.Cabecalho
        {
            private static final long serialVersionUID = 1L;
            
            public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName CPFCNPJREMETENTE$0 = 
                new javax.xml.namespace.QName("", "CPFCNPJRemetente");
            private static final javax.xml.namespace.QName TRANSACAO$2 = 
                new javax.xml.namespace.QName("", "transacao");
            private static final javax.xml.namespace.QName DTINICIO$4 = 
                new javax.xml.namespace.QName("", "dtInicio");
            private static final javax.xml.namespace.QName DTFIM$6 = 
                new javax.xml.namespace.QName("", "dtFim");
            private static final javax.xml.namespace.QName QTDRPS$8 = 
                new javax.xml.namespace.QName("", "QtdRPS");
            private static final javax.xml.namespace.QName VALORTOTALSERVICOS$10 = 
                new javax.xml.namespace.QName("", "ValorTotalServicos");
            private static final javax.xml.namespace.QName VALORTOTALDEDUCOES$12 = 
                new javax.xml.namespace.QName("", "ValorTotalDeducoes");
            private static final javax.xml.namespace.QName VERSAO$14 = 
                new javax.xml.namespace.QName("", "Versao");
            
            
            /**
             * Gets the "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ getCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().find_element_user(CPFCNPJREMETENTE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CPFCNPJRemetente" element
             */
            public void setCPFCNPJRemetente(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ cpfcnpjRemetente)
            {
                generatedSetterHelperImpl(cpfcnpjRemetente, CPFCNPJREMETENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CPFCNPJRemetente" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ addNewCPFCNPJRemetente()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpCPFCNPJ)get_store().add_element_user(CPFCNPJREMETENTE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "transacao" element
             */
            public boolean getTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      return false;
                    }
                    return target.getBooleanValue();
                }
            }
            
            /**
             * Gets (as xml) the "transacao" element
             */
            public org.apache.xmlbeans.XmlBoolean xgetTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlBoolean target = null;
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRANSACAO$2, 0);
                    return target;
                }
            }
            
            /**
             * True if has "transacao" element
             */
            public boolean isSetTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(TRANSACAO$2) != 0;
                }
            }
            
            /**
             * Sets the "transacao" element
             */
            public void setTransacao(boolean transacao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRANSACAO$2);
                    }
                    target.setBooleanValue(transacao);
                }
            }
            
            /**
             * Sets (as xml) the "transacao" element
             */
            public void xsetTransacao(org.apache.xmlbeans.XmlBoolean transacao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlBoolean target = null;
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRANSACAO$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(TRANSACAO$2);
                    }
                    target.set(transacao);
                }
            }
            
            /**
             * Unsets the "transacao" element
             */
            public void unsetTransacao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(TRANSACAO$2, 0);
                }
            }
            
            /**
             * Gets the "dtInicio" element
             */
            public java.util.Calendar getDtInicio()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINICIO$4, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "dtInicio" element
             */
            public org.apache.xmlbeans.XmlDate xgetDtInicio()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTINICIO$4, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "dtInicio" element
             */
            public void setDtInicio(java.util.Calendar dtInicio)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTINICIO$4, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTINICIO$4);
                    }
                    target.setCalendarValue(dtInicio);
                }
            }
            
            /**
             * Sets (as xml) the "dtInicio" element
             */
            public void xsetDtInicio(org.apache.xmlbeans.XmlDate dtInicio)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTINICIO$4, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DTINICIO$4);
                    }
                    target.set(dtInicio);
                }
            }
            
            /**
             * Gets the "dtFim" element
             */
            public java.util.Calendar getDtFim()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$6, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "dtFim" element
             */
            public org.apache.xmlbeans.XmlDate xgetDtFim()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTFIM$6, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "dtFim" element
             */
            public void setDtFim(java.util.Calendar dtFim)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DTFIM$6, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DTFIM$6);
                    }
                    target.setCalendarValue(dtFim);
                }
            }
            
            /**
             * Sets (as xml) the "dtFim" element
             */
            public void xsetDtFim(org.apache.xmlbeans.XmlDate dtFim)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DTFIM$6, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DTFIM$6);
                    }
                    target.set(dtFim);
                }
            }
            
            /**
             * Gets the "QtdRPS" element
             */
            public long getQtdRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDRPS$8, 0);
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "QtdRPS" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade xgetQtdRPS()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().find_element_user(QTDRPS$8, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "QtdRPS" element
             */
            public void setQtdRPS(long qtdRPS)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QTDRPS$8, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(QTDRPS$8);
                    }
                    target.setLongValue(qtdRPS);
                }
            }
            
            /**
             * Sets (as xml) the "QtdRPS" element
             */
            public void xsetQtdRPS(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade qtdRPS)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().find_element_user(QTDRPS$8, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpQuantidade)get_store().add_element_user(QTDRPS$8);
                    }
                    target.set(qtdRPS);
                }
            }
            
            /**
             * Gets the "ValorTotalServicos" element
             */
            public java.math.BigDecimal getValorTotalServicos()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALSERVICOS$10, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getBigDecimalValue();
                }
            }
            
            /**
             * Gets (as xml) the "ValorTotalServicos" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalServicos()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALSERVICOS$10, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "ValorTotalServicos" element
             */
            public void setValorTotalServicos(java.math.BigDecimal valorTotalServicos)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALSERVICOS$10, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORTOTALSERVICOS$10);
                    }
                    target.setBigDecimalValue(valorTotalServicos);
                }
            }
            
            /**
             * Sets (as xml) the "ValorTotalServicos" element
             */
            public void xsetValorTotalServicos(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalServicos)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALSERVICOS$10, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORTOTALSERVICOS$10);
                    }
                    target.set(valorTotalServicos);
                }
            }
            
            /**
             * Gets the "ValorTotalDeducoes" element
             */
            public java.math.BigDecimal getValorTotalDeducoes()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALDEDUCOES$12, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getBigDecimalValue();
                }
            }
            
            /**
             * Gets (as xml) the "ValorTotalDeducoes" element
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor xgetValorTotalDeducoes()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALDEDUCOES$12, 0);
                    return target;
                }
            }
            
            /**
             * True if has "ValorTotalDeducoes" element
             */
            public boolean isSetValorTotalDeducoes()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(VALORTOTALDEDUCOES$12) != 0;
                }
            }
            
            /**
             * Sets the "ValorTotalDeducoes" element
             */
            public void setValorTotalDeducoes(java.math.BigDecimal valorTotalDeducoes)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORTOTALDEDUCOES$12, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORTOTALDEDUCOES$12);
                    }
                    target.setBigDecimalValue(valorTotalDeducoes);
                }
            }
            
            /**
             * Sets (as xml) the "ValorTotalDeducoes" element
             */
            public void xsetValorTotalDeducoes(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor valorTotalDeducoes)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().find_element_user(VALORTOTALDEDUCOES$12, 0);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpValor)get_store().add_element_user(VALORTOTALDEDUCOES$12);
                    }
                    target.set(valorTotalDeducoes);
                }
            }
            
            /**
             * Unsets the "ValorTotalDeducoes" element
             */
            public void unsetValorTotalDeducoes()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(VALORTOTALDEDUCOES$12, 0);
                }
            }
            
            /**
             * Gets the "Versao" attribute
             */
            public long getVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$14);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_default_attribute_value(VERSAO$14);
                    }
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "Versao" attribute
             */
            public org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao xgetVersao()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$14);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_default_attribute_value(VERSAO$14);
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Versao" attribute
             */
            public void setVersao(long versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$14);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$14);
                    }
                    target.setLongValue(versao);
                }
            }
            
            /**
             * Sets (as xml) the "Versao" attribute
             */
            public void xsetVersao(org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao versao)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao target = null;
                    target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().find_attribute_user(VERSAO$14);
                    if (target == null)
                    {
                      target = (org.kenos.v01.br.gov.sp.prefeitura.nfe.TpVersao)get_store().add_attribute_user(VERSAO$14);
                    }
                    target.set(versao);
                }
            }
        }
    }
}
