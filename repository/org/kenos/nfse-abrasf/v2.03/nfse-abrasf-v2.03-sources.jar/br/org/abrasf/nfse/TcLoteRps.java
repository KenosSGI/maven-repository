/*
 * XML Type:  tcLoteRps
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcLoteRps
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcLoteRps(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcLoteRps extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcLoteRps.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcloterpsa9e1type");
    
    /**
     * Gets the "NumeroLote" element
     */
    long getNumeroLote();
    
    /**
     * Gets (as xml) the "NumeroLote" element
     */
    br.org.abrasf.nfse.TsNumeroLote xgetNumeroLote();
    
    /**
     * Sets the "NumeroLote" element
     */
    void setNumeroLote(long numeroLote);
    
    /**
     * Sets (as xml) the "NumeroLote" element
     */
    void xsetNumeroLote(br.org.abrasf.nfse.TsNumeroLote numeroLote);
    
    /**
     * Gets the "CpfCnpj" element
     */
    br.org.abrasf.nfse.TcCpfCnpj getCpfCnpj();
    
    /**
     * Sets the "CpfCnpj" element
     */
    void setCpfCnpj(br.org.abrasf.nfse.TcCpfCnpj cpfCnpj);
    
    /**
     * Appends and returns a new empty "CpfCnpj" element
     */
    br.org.abrasf.nfse.TcCpfCnpj addNewCpfCnpj();
    
    /**
     * Gets the "InscricaoMunicipal" element
     */
    java.lang.String getInscricaoMunicipal();
    
    /**
     * Gets (as xml) the "InscricaoMunicipal" element
     */
    br.org.abrasf.nfse.TsInscricaoMunicipal xgetInscricaoMunicipal();
    
    /**
     * True if has "InscricaoMunicipal" element
     */
    boolean isSetInscricaoMunicipal();
    
    /**
     * Sets the "InscricaoMunicipal" element
     */
    void setInscricaoMunicipal(java.lang.String inscricaoMunicipal);
    
    /**
     * Sets (as xml) the "InscricaoMunicipal" element
     */
    void xsetInscricaoMunicipal(br.org.abrasf.nfse.TsInscricaoMunicipal inscricaoMunicipal);
    
    /**
     * Unsets the "InscricaoMunicipal" element
     */
    void unsetInscricaoMunicipal();
    
    /**
     * Gets the "QuantidadeRps" element
     */
    int getQuantidadeRps();
    
    /**
     * Gets (as xml) the "QuantidadeRps" element
     */
    br.org.abrasf.nfse.TsQuantidadeRps xgetQuantidadeRps();
    
    /**
     * Sets the "QuantidadeRps" element
     */
    void setQuantidadeRps(int quantidadeRps);
    
    /**
     * Sets (as xml) the "QuantidadeRps" element
     */
    void xsetQuantidadeRps(br.org.abrasf.nfse.TsQuantidadeRps quantidadeRps);
    
    /**
     * Gets the "ListaRps" element
     */
    br.org.abrasf.nfse.TcLoteRps.ListaRps getListaRps();
    
    /**
     * Sets the "ListaRps" element
     */
    void setListaRps(br.org.abrasf.nfse.TcLoteRps.ListaRps listaRps);
    
    /**
     * Appends and returns a new empty "ListaRps" element
     */
    br.org.abrasf.nfse.TcLoteRps.ListaRps addNewListaRps();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    br.org.abrasf.nfse.TsIdTag xgetId();
    
    /**
     * True if has "Id" attribute
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(br.org.abrasf.nfse.TsIdTag id);
    
    /**
     * Unsets the "Id" attribute
     */
    void unsetId();
    
    /**
     * Gets the "versao" attribute
     */
    java.lang.String getVersao();
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    br.org.abrasf.nfse.TsVersao xgetVersao();
    
    /**
     * Sets the "versao" attribute
     */
    void setVersao(java.lang.String versao);
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    void xsetVersao(br.org.abrasf.nfse.TsVersao versao);
    
    /**
     * An XML ListaRps(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ListaRps extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaRps.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("listarps698felemtype");
        
        /**
         * Gets array of all "Rps" elements
         */
        br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[] getRpsArray();
        
        /**
         * Gets ith "Rps" element
         */
        br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getRpsArray(int i);
        
        /**
         * Returns number of "Rps" element
         */
        int sizeOfRpsArray();
        
        /**
         * Sets array of all "Rps" element
         */
        void setRpsArray(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[] rpsArray);
        
        /**
         * Sets ith "Rps" element
         */
        void setRpsArray(int i, br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico rps);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Rps" element
         */
        br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico insertNewRps(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Rps" element
         */
        br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewRps();
        
        /**
         * Removes the ith "Rps" element
         */
        void removeRps(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.TcLoteRps.ListaRps newInstance() {
              return (br.org.abrasf.nfse.TcLoteRps.ListaRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.TcLoteRps.ListaRps newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.TcLoteRps.ListaRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcLoteRps newInstance() {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcLoteRps parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcLoteRps parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcLoteRps parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcLoteRps parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcLoteRps) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
