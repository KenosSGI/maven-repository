/*
 * XML Type:  tsCodigoObra
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsCodigoObra
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsCodigoObra(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsCodigoObra.
 */
public class TsCodigoObraImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsCodigoObra
{
    private static final long serialVersionUID = 1L;
    
    public TsCodigoObraImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsCodigoObraImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
