/*
 * XML Type:  tcInfRps
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfRps
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcInfRps(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcInfRpsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcInfRps
{
    private static final long serialVersionUID = 1L;
    
    public TcInfRpsImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAORPS$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoRps");
    private static final javax.xml.namespace.QName DATAEMISSAO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataEmissao");
    private static final javax.xml.namespace.QName STATUS$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Status");
    private static final javax.xml.namespace.QName RPSSUBSTITUIDO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RpsSubstituido");
    private static final javax.xml.namespace.QName ID$8 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "IdentificacaoRps" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps getIdentificacaoRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().find_element_user(IDENTIFICACAORPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "IdentificacaoRps" element
     */
    public void setIdentificacaoRps(br.org.abrasf.nfse.TcIdentificacaoRps identificacaoRps)
    {
        generatedSetterHelperImpl(identificacaoRps, IDENTIFICACAORPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoRps" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps addNewIdentificacaoRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().add_element_user(IDENTIFICACAORPS$0);
            return target;
        }
    }
    
    /**
     * Gets the "DataEmissao" element
     */
    public java.util.Calendar getDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataEmissao" element
     */
    public org.apache.xmlbeans.XmlDate xgetDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAEMISSAO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "DataEmissao" element
     */
    public void setDataEmissao(java.util.Calendar dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAEMISSAO$2);
            }
            target.setCalendarValue(dataEmissao);
        }
    }
    
    /**
     * Sets (as xml) the "DataEmissao" element
     */
    public void xsetDataEmissao(org.apache.xmlbeans.XmlDate dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAEMISSAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAEMISSAO$2);
            }
            target.set(dataEmissao);
        }
    }
    
    /**
     * Gets the "Status" element
     */
    public byte getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "Status" element
     */
    public br.org.abrasf.nfse.TsStatusRps xgetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsStatusRps target = null;
            target = (br.org.abrasf.nfse.TsStatusRps)get_store().find_element_user(STATUS$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Status" element
     */
    public void setStatus(byte status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATUS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATUS$4);
            }
            target.setByteValue(status);
        }
    }
    
    /**
     * Sets (as xml) the "Status" element
     */
    public void xsetStatus(br.org.abrasf.nfse.TsStatusRps status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsStatusRps target = null;
            target = (br.org.abrasf.nfse.TsStatusRps)get_store().find_element_user(STATUS$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsStatusRps)get_store().add_element_user(STATUS$4);
            }
            target.set(status);
        }
    }
    
    /**
     * Gets the "RpsSubstituido" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps getRpsSubstituido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().find_element_user(RPSSUBSTITUIDO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "RpsSubstituido" element
     */
    public boolean isSetRpsSubstituido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RPSSUBSTITUIDO$6) != 0;
        }
    }
    
    /**
     * Sets the "RpsSubstituido" element
     */
    public void setRpsSubstituido(br.org.abrasf.nfse.TcIdentificacaoRps rpsSubstituido)
    {
        generatedSetterHelperImpl(rpsSubstituido, RPSSUBSTITUIDO$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "RpsSubstituido" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps addNewRpsSubstituido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().add_element_user(RPSSUBSTITUIDO$6);
            return target;
        }
    }
    
    /**
     * Unsets the "RpsSubstituido" element
     */
    public void unsetRpsSubstituido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RPSSUBSTITUIDO$6, 0);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$8);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$8);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$8) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$8);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$8);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$8);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$8);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$8);
        }
    }
}
