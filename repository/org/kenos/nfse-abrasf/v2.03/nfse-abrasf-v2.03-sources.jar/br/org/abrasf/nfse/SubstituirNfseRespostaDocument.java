/*
 * An XML document type.
 * Localname: SubstituirNfseResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.SubstituirNfseRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one SubstituirNfseResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface SubstituirNfseRespostaDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubstituirNfseRespostaDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("substituirnfseresposta25cedoctype");
    
    /**
     * Gets the "SubstituirNfseResposta" element
     */
    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta getSubstituirNfseResposta();
    
    /**
     * Sets the "SubstituirNfseResposta" element
     */
    void setSubstituirNfseResposta(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta substituirNfseResposta);
    
    /**
     * Appends and returns a new empty "SubstituirNfseResposta" element
     */
    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta addNewSubstituirNfseResposta();
    
    /**
     * An XML SubstituirNfseResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface SubstituirNfseResposta extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubstituirNfseResposta.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("substituirnfserespostad7b5elemtype");
        
        /**
         * Gets the "RetSubstituicao" element
         */
        br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao getRetSubstituicao();
        
        /**
         * True if has "RetSubstituicao" element
         */
        boolean isSetRetSubstituicao();
        
        /**
         * Sets the "RetSubstituicao" element
         */
        void setRetSubstituicao(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao retSubstituicao);
        
        /**
         * Appends and returns a new empty "RetSubstituicao" element
         */
        br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao addNewRetSubstituicao();
        
        /**
         * Unsets the "RetSubstituicao" element
         */
        void unsetRetSubstituicao();
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno();
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        boolean isSetListaMensagemRetorno();
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno();
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        void unsetListaMensagemRetorno();
        
        /**
         * An XML RetSubstituicao(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface RetSubstituicao extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetSubstituicao.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("retsubstituicaod6f3elemtype");
            
            /**
             * Gets the "NfseSubstituida" element
             */
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida getNfseSubstituida();
            
            /**
             * Sets the "NfseSubstituida" element
             */
            void setNfseSubstituida(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida nfseSubstituida);
            
            /**
             * Appends and returns a new empty "NfseSubstituida" element
             */
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida addNewNfseSubstituida();
            
            /**
             * Gets the "NfseSubstituidora" element
             */
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora getNfseSubstituidora();
            
            /**
             * Sets the "NfseSubstituidora" element
             */
            void setNfseSubstituidora(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora nfseSubstituidora);
            
            /**
             * Appends and returns a new empty "NfseSubstituidora" element
             */
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora addNewNfseSubstituidora();
            
            /**
             * An XML NfseSubstituida(@http://www.abrasf.org.br/nfse.xsd).
             *
             * This is a complex type.
             */
            public interface NfseSubstituida extends org.apache.xmlbeans.XmlObject
            {
                public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                    org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(NfseSubstituida.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("nfsesubstituida4932elemtype");
                
                /**
                 * Gets the "CompNfse" element
                 */
                br.org.abrasf.nfse.TcCompNfse getCompNfse();
                
                /**
                 * Sets the "CompNfse" element
                 */
                void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse);
                
                /**
                 * Appends and returns a new empty "CompNfse" element
                 */
                br.org.abrasf.nfse.TcCompNfse addNewCompNfse();
                
                /**
                 * Gets the "ListaMensagemAlertaRetorno" element
                 */
                br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno();
                
                /**
                 * True if has "ListaMensagemAlertaRetorno" element
                 */
                boolean isSetListaMensagemAlertaRetorno();
                
                /**
                 * Sets the "ListaMensagemAlertaRetorno" element
                 */
                void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno);
                
                /**
                 * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
                 */
                br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno();
                
                /**
                 * Unsets the "ListaMensagemAlertaRetorno" element
                 */
                void unsetListaMensagemAlertaRetorno();
                
                /**
                 * A factory class with static methods for creating instances
                 * of this type.
                 */
                
                public static final class Factory
                {
                    public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida newInstance() {
                      return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                    
                    public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida newInstance(org.apache.xmlbeans.XmlOptions options) {
                      return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                    
                    private Factory() { } // No instance of this class allowed
                }
            }
            
            /**
             * An XML NfseSubstituidora(@http://www.abrasf.org.br/nfse.xsd).
             *
             * This is a complex type.
             */
            public interface NfseSubstituidora extends org.apache.xmlbeans.XmlObject
            {
                public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                    org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(NfseSubstituidora.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("nfsesubstituidoracb6felemtype");
                
                /**
                 * Gets the "CompNfse" element
                 */
                br.org.abrasf.nfse.TcCompNfse getCompNfse();
                
                /**
                 * Sets the "CompNfse" element
                 */
                void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse);
                
                /**
                 * Appends and returns a new empty "CompNfse" element
                 */
                br.org.abrasf.nfse.TcCompNfse addNewCompNfse();
                
                /**
                 * A factory class with static methods for creating instances
                 * of this type.
                 */
                
                public static final class Factory
                {
                    public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora newInstance() {
                      return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                    
                    public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora newInstance(org.apache.xmlbeans.XmlOptions options) {
                      return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                    
                    private Factory() { } // No instance of this class allowed
                }
            }
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao newInstance() {
                  return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta newInstance() {
              return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument newInstance() {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.SubstituirNfseRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.SubstituirNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
