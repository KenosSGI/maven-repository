/*
 * XML Type:  tsNumeroRps
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsNumeroRps
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsNumeroRps(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsNumeroRps.
 */
public class TsNumeroRpsImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements br.org.abrasf.nfse.TsNumeroRps
{
    private static final long serialVersionUID = 1L;
    
    public TsNumeroRpsImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsNumeroRpsImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
