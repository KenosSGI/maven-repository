/*
 * XML Type:  tcConfirmacaoCancelamento
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcConfirmacaoCancelamento
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcConfirmacaoCancelamento(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcConfirmacaoCancelamentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcConfirmacaoCancelamento
{
    private static final long serialVersionUID = 1L;
    
    public TcConfirmacaoCancelamentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PEDIDO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Pedido");
    private static final javax.xml.namespace.QName DATAHORA$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataHora");
    private static final javax.xml.namespace.QName ID$4 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "Pedido" element
     */
    public br.org.abrasf.nfse.TcPedidoCancelamento getPedido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcPedidoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().find_element_user(PEDIDO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Pedido" element
     */
    public void setPedido(br.org.abrasf.nfse.TcPedidoCancelamento pedido)
    {
        generatedSetterHelperImpl(pedido, PEDIDO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Pedido" element
     */
    public br.org.abrasf.nfse.TcPedidoCancelamento addNewPedido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcPedidoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().add_element_user(PEDIDO$0);
            return target;
        }
    }
    
    /**
     * Gets the "DataHora" element
     */
    public java.util.Calendar getDataHora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAHORA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataHora" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataHora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAHORA$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "DataHora" element
     */
    public void setDataHora(java.util.Calendar dataHora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAHORA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAHORA$2);
            }
            target.setCalendarValue(dataHora);
        }
    }
    
    /**
     * Sets (as xml) the "DataHora" element
     */
    public void xsetDataHora(org.apache.xmlbeans.XmlDateTime dataHora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAHORA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAHORA$2);
            }
            target.set(dataHora);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$4) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$4);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$4);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$4);
        }
    }
}
