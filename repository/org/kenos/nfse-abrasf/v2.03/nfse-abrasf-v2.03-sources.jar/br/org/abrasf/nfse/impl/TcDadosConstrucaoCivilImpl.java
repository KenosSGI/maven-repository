/*
 * XML Type:  tcDadosConstrucaoCivil
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosConstrucaoCivil
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcDadosConstrucaoCivil(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcDadosConstrucaoCivilImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcDadosConstrucaoCivil
{
    private static final long serialVersionUID = 1L;
    
    public TcDadosConstrucaoCivilImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGOOBRA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoObra");
    private static final javax.xml.namespace.QName ART$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Art");
    
    
    /**
     * Gets the "CodigoObra" element
     */
    public java.lang.String getCodigoObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOOBRA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoObra" element
     */
    public br.org.abrasf.nfse.TsCodigoObra xgetCodigoObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoObra target = null;
            target = (br.org.abrasf.nfse.TsCodigoObra)get_store().find_element_user(CODIGOOBRA$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoObra" element
     */
    public boolean isSetCodigoObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOOBRA$0) != 0;
        }
    }
    
    /**
     * Sets the "CodigoObra" element
     */
    public void setCodigoObra(java.lang.String codigoObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOOBRA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOOBRA$0);
            }
            target.setStringValue(codigoObra);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoObra" element
     */
    public void xsetCodigoObra(br.org.abrasf.nfse.TsCodigoObra codigoObra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoObra target = null;
            target = (br.org.abrasf.nfse.TsCodigoObra)get_store().find_element_user(CODIGOOBRA$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoObra)get_store().add_element_user(CODIGOOBRA$0);
            }
            target.set(codigoObra);
        }
    }
    
    /**
     * Unsets the "CodigoObra" element
     */
    public void unsetCodigoObra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOOBRA$0, 0);
        }
    }
    
    /**
     * Gets the "Art" element
     */
    public java.lang.String getArt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ART$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Art" element
     */
    public br.org.abrasf.nfse.TsArt xgetArt()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsArt target = null;
            target = (br.org.abrasf.nfse.TsArt)get_store().find_element_user(ART$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Art" element
     */
    public void setArt(java.lang.String art)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ART$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ART$2);
            }
            target.setStringValue(art);
        }
    }
    
    /**
     * Sets (as xml) the "Art" element
     */
    public void xsetArt(br.org.abrasf.nfse.TsArt art)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsArt target = null;
            target = (br.org.abrasf.nfse.TsArt)get_store().find_element_user(ART$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsArt)get_store().add_element_user(ART$2);
            }
            target.set(art);
        }
    }
}
