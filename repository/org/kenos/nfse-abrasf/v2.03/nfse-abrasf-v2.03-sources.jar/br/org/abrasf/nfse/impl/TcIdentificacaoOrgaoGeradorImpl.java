/*
 * XML Type:  tcIdentificacaoOrgaoGerador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcIdentificacaoOrgaoGerador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcIdentificacaoOrgaoGeradorImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador
{
    private static final long serialVersionUID = 1L;
    
    public TcIdentificacaoOrgaoGeradorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGOMUNICIPIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoMunicipio");
    private static final javax.xml.namespace.QName UF$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Uf");
    
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    public int getCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$0, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    public void setCodigoMunicipio(int codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOMUNICIPIO$0);
            }
            target.setIntValue(codigoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    public void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(CODIGOMUNICIPIO$0);
            }
            target.set(codigoMunicipio);
        }
    }
    
    /**
     * Gets the "Uf" element
     */
    public br.org.abrasf.nfse.TsUf.Enum getUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$2, 0);
            if (target == null)
            {
                return null;
            }
            return (br.org.abrasf.nfse.TsUf.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "Uf" element
     */
    public br.org.abrasf.nfse.TsUf xgetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsUf target = null;
            target = (br.org.abrasf.nfse.TsUf)get_store().find_element_user(UF$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Uf" element
     */
    public void setUf(br.org.abrasf.nfse.TsUf.Enum uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$2);
            }
            target.setEnumValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "Uf" element
     */
    public void xsetUf(br.org.abrasf.nfse.TsUf uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsUf target = null;
            target = (br.org.abrasf.nfse.TsUf)get_store().find_element_user(UF$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsUf)get_store().add_element_user(UF$2);
            }
            target.set(uf);
        }
    }
}
