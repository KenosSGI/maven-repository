/*
 * XML Type:  tcSubstituicaoNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcSubstituicaoNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcSubstituicaoNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcSubstituicaoNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcSubstituicaoNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcSubstituicaoNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSTITUICAONFSE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "SubstituicaoNfse");
    private static final javax.xml.namespace.QName SIGNATURE$2 = 
        new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
    private static final javax.xml.namespace.QName VERSAO$4 = 
        new javax.xml.namespace.QName("", "versao");
    
    
    /**
     * Gets the "SubstituicaoNfse" element
     */
    public br.org.abrasf.nfse.TcInfSubstituicaoNfse getSubstituicaoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfSubstituicaoNfse target = null;
            target = (br.org.abrasf.nfse.TcInfSubstituicaoNfse)get_store().find_element_user(SUBSTITUICAONFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "SubstituicaoNfse" element
     */
    public void setSubstituicaoNfse(br.org.abrasf.nfse.TcInfSubstituicaoNfse substituicaoNfse)
    {
        generatedSetterHelperImpl(substituicaoNfse, SUBSTITUICAONFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "SubstituicaoNfse" element
     */
    public br.org.abrasf.nfse.TcInfSubstituicaoNfse addNewSubstituicaoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfSubstituicaoNfse target = null;
            target = (br.org.abrasf.nfse.TcInfSubstituicaoNfse)get_store().add_element_user(SUBSTITUICAONFSE$0);
            return target;
        }
    }
    
    /**
     * Gets array of all "Signature" elements
     */
    public org.w3.x2000.x09.xmldsig.SignatureType[] getSignatureArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SIGNATURE$2, targetList);
            org.w3.x2000.x09.xmldsig.SignatureType[] result = new org.w3.x2000.x09.xmldsig.SignatureType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType getSignatureArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "Signature" element
     */
    public int sizeOfSignatureArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATURE$2);
        }
    }
    
    /**
     * Sets array of all "Signature" element  WARNING: This method is not atomicaly synchronized.
     */
    public void setSignatureArray(org.w3.x2000.x09.xmldsig.SignatureType[] signatureArray)
    {
        check_orphaned();
        arraySetterHelper(signatureArray, SIGNATURE$2);
    }
    
    /**
     * Sets ith "Signature" element
     */
    public void setSignatureArray(int i, org.w3.x2000.x09.xmldsig.SignatureType signature)
    {
        generatedSetterHelperImpl(signature, SIGNATURE$2, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType insertNewSignature(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().insert_element_user(SIGNATURE$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "Signature" element
     */
    public void removeSignature(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATURE$2, i);
        }
    }
    
    /**
     * Gets the "versao" attribute
     */
    public java.lang.String getVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    public br.org.abrasf.nfse.TsVersao xgetVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$4);
            return target;
        }
    }
    
    /**
     * Sets the "versao" attribute
     */
    public void setVersao(java.lang.String versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$4);
            }
            target.setStringValue(versao);
        }
    }
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    public void xsetVersao(br.org.abrasf.nfse.TsVersao versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsVersao)get_store().add_attribute_user(VERSAO$4);
            }
            target.set(versao);
        }
    }
}
