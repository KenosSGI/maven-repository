/*
 * An XML document type.
 * Localname: EnviarLoteRpsResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one EnviarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class EnviarLoteRpsRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarLoteRpsRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARLOTERPSRESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "EnviarLoteRpsResposta");
    
    
    /**
     * Gets the "EnviarLoteRpsResposta" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta getEnviarLoteRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta)get_store().find_element_user(ENVIARLOTERPSRESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarLoteRpsResposta" element
     */
    public void setEnviarLoteRpsResposta(br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta enviarLoteRpsResposta)
    {
        generatedSetterHelperImpl(enviarLoteRpsResposta, ENVIARLOTERPSRESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsResposta" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta addNewEnviarLoteRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta)get_store().add_element_user(ENVIARLOTERPSRESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML EnviarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class EnviarLoteRpsRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarLoteRpsRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NUMEROLOTE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroLote");
        private static final javax.xml.namespace.QName DATARECEBIMENTO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataRecebimento");
        private static final javax.xml.namespace.QName PROTOCOLO$4 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Protocolo");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$6 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "NumeroLote" element
         */
        public long getNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "NumeroLote" element
         */
        public br.org.abrasf.nfse.TsNumeroLote xgetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroLote target = null;
                target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "NumeroLote" element
         */
        public boolean isSetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NUMEROLOTE$0) != 0;
            }
        }
        
        /**
         * Sets the "NumeroLote" element
         */
        public void setNumeroLote(long numeroLote)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROLOTE$0);
                }
                target.setLongValue(numeroLote);
            }
        }
        
        /**
         * Sets (as xml) the "NumeroLote" element
         */
        public void xsetNumeroLote(br.org.abrasf.nfse.TsNumeroLote numeroLote)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroLote target = null;
                target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroLote)get_store().add_element_user(NUMEROLOTE$0);
                }
                target.set(numeroLote);
            }
        }
        
        /**
         * Unsets the "NumeroLote" element
         */
        public void unsetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NUMEROLOTE$0, 0);
            }
        }
        
        /**
         * Gets the "DataRecebimento" element
         */
        public java.util.Calendar getDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "DataRecebimento" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "DataRecebimento" element
         */
        public boolean isSetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DATARECEBIMENTO$2) != 0;
            }
        }
        
        /**
         * Sets the "DataRecebimento" element
         */
        public void setDataRecebimento(java.util.Calendar dataRecebimento)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATARECEBIMENTO$2);
                }
                target.setCalendarValue(dataRecebimento);
            }
        }
        
        /**
         * Sets (as xml) the "DataRecebimento" element
         */
        public void xsetDataRecebimento(org.apache.xmlbeans.XmlDateTime dataRecebimento)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATARECEBIMENTO$2);
                }
                target.set(dataRecebimento);
            }
        }
        
        /**
         * Unsets the "DataRecebimento" element
         */
        public void unsetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DATARECEBIMENTO$2, 0);
            }
        }
        
        /**
         * Gets the "Protocolo" element
         */
        public java.lang.String getProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "Protocolo" element
         */
        public br.org.abrasf.nfse.TsNumeroProtocolo xgetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "Protocolo" element
         */
        public boolean isSetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PROTOCOLO$4) != 0;
            }
        }
        
        /**
         * Sets the "Protocolo" element
         */
        public void setProtocolo(java.lang.String protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLO$4);
                }
                target.setStringValue(protocolo);
            }
        }
        
        /**
         * Sets (as xml) the "Protocolo" element
         */
        public void xsetProtocolo(br.org.abrasf.nfse.TsNumeroProtocolo protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().add_element_user(PROTOCOLO$4);
                }
                target.set(protocolo);
            }
        }
        
        /**
         * Unsets the "Protocolo" element
         */
        public void unsetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PROTOCOLO$4, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$6) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$6);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$6, 0);
            }
        }
    }
}
