/*
 * XML Type:  tcValoresNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcValoresNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcValoresNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcValoresNfse extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcValoresNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcvaloresnfsede9ctype");
    
    /**
     * Gets the "BaseCalculo" element
     */
    java.math.BigDecimal getBaseCalculo();
    
    /**
     * Gets (as xml) the "BaseCalculo" element
     */
    br.org.abrasf.nfse.TsValor xgetBaseCalculo();
    
    /**
     * True if has "BaseCalculo" element
     */
    boolean isSetBaseCalculo();
    
    /**
     * Sets the "BaseCalculo" element
     */
    void setBaseCalculo(java.math.BigDecimal baseCalculo);
    
    /**
     * Sets (as xml) the "BaseCalculo" element
     */
    void xsetBaseCalculo(br.org.abrasf.nfse.TsValor baseCalculo);
    
    /**
     * Unsets the "BaseCalculo" element
     */
    void unsetBaseCalculo();
    
    /**
     * Gets the "Aliquota" element
     */
    java.math.BigDecimal getAliquota();
    
    /**
     * Gets (as xml) the "Aliquota" element
     */
    br.org.abrasf.nfse.TsAliquota xgetAliquota();
    
    /**
     * True if has "Aliquota" element
     */
    boolean isSetAliquota();
    
    /**
     * Sets the "Aliquota" element
     */
    void setAliquota(java.math.BigDecimal aliquota);
    
    /**
     * Sets (as xml) the "Aliquota" element
     */
    void xsetAliquota(br.org.abrasf.nfse.TsAliquota aliquota);
    
    /**
     * Unsets the "Aliquota" element
     */
    void unsetAliquota();
    
    /**
     * Gets the "ValorIss" element
     */
    java.math.BigDecimal getValorIss();
    
    /**
     * Gets (as xml) the "ValorIss" element
     */
    br.org.abrasf.nfse.TsValor xgetValorIss();
    
    /**
     * True if has "ValorIss" element
     */
    boolean isSetValorIss();
    
    /**
     * Sets the "ValorIss" element
     */
    void setValorIss(java.math.BigDecimal valorIss);
    
    /**
     * Sets (as xml) the "ValorIss" element
     */
    void xsetValorIss(br.org.abrasf.nfse.TsValor valorIss);
    
    /**
     * Unsets the "ValorIss" element
     */
    void unsetValorIss();
    
    /**
     * Gets the "ValorLiquidoNfse" element
     */
    java.math.BigDecimal getValorLiquidoNfse();
    
    /**
     * Gets (as xml) the "ValorLiquidoNfse" element
     */
    br.org.abrasf.nfse.TsValor xgetValorLiquidoNfse();
    
    /**
     * Sets the "ValorLiquidoNfse" element
     */
    void setValorLiquidoNfse(java.math.BigDecimal valorLiquidoNfse);
    
    /**
     * Sets (as xml) the "ValorLiquidoNfse" element
     */
    void xsetValorLiquidoNfse(br.org.abrasf.nfse.TsValor valorLiquidoNfse);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcValoresNfse newInstance() {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresNfse parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcValoresNfse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcValoresNfse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcValoresNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
