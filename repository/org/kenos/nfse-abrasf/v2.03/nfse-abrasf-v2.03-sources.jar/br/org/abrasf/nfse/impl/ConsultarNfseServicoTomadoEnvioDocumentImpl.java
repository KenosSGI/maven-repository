/*
 * An XML document type.
 * Localname: ConsultarNfseServicoTomadoEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarNfseServicoTomadoEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarNfseServicoTomadoEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarNfseServicoTomadoEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARNFSESERVICOTOMADOENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarNfseServicoTomadoEnvio");
    
    
    /**
     * Gets the "ConsultarNfseServicoTomadoEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio getConsultarNfseServicoTomadoEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio)get_store().find_element_user(CONSULTARNFSESERVICOTOMADOENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarNfseServicoTomadoEnvio" element
     */
    public void setConsultarNfseServicoTomadoEnvio(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio consultarNfseServicoTomadoEnvio)
    {
        generatedSetterHelperImpl(consultarNfseServicoTomadoEnvio, CONSULTARNFSESERVICOTOMADOENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarNfseServicoTomadoEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio addNewConsultarNfseServicoTomadoEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio)get_store().add_element_user(CONSULTARNFSESERVICOTOMADOENVIO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarNfseServicoTomadoEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarNfseServicoTomadoEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarNfseServicoTomadoEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSULENTE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Consulente");
        private static final javax.xml.namespace.QName NUMERONFSE$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroNfse");
        private static final javax.xml.namespace.QName PERIODOEMISSAO$4 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "PeriodoEmissao");
        private static final javax.xml.namespace.QName PERIODOCOMPETENCIA$6 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "PeriodoCompetencia");
        private static final javax.xml.namespace.QName PRESTADOR$8 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Prestador");
        private static final javax.xml.namespace.QName TOMADOR$10 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Tomador");
        private static final javax.xml.namespace.QName INTERMEDIARIO$12 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Intermediario");
        private static final javax.xml.namespace.QName PAGINA$14 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Pagina");
        
        
        /**
         * Gets the "Consulente" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoConsulente getConsulente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoConsulente target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoConsulente)get_store().find_element_user(CONSULENTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Consulente" element
         */
        public void setConsulente(br.org.abrasf.nfse.TcIdentificacaoConsulente consulente)
        {
            generatedSetterHelperImpl(consulente, CONSULENTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Consulente" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoConsulente addNewConsulente()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoConsulente target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoConsulente)get_store().add_element_user(CONSULENTE$0);
                return target;
            }
        }
        
        /**
         * Gets the "NumeroNfse" element
         */
        public long getNumeroNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSE$2, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "NumeroNfse" element
         */
        public br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroNfse target = null;
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSE$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "NumeroNfse" element
         */
        public boolean isSetNumeroNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NUMERONFSE$2) != 0;
            }
        }
        
        /**
         * Sets the "NumeroNfse" element
         */
        public void setNumeroNfse(long numeroNfse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERONFSE$2);
                }
                target.setLongValue(numeroNfse);
            }
        }
        
        /**
         * Sets (as xml) the "NumeroNfse" element
         */
        public void xsetNumeroNfse(br.org.abrasf.nfse.TsNumeroNfse numeroNfse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroNfse target = null;
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSE$2, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NUMERONFSE$2);
                }
                target.set(numeroNfse);
            }
        }
        
        /**
         * Unsets the "NumeroNfse" element
         */
        public void unsetNumeroNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NUMERONFSE$2, 0);
            }
        }
        
        /**
         * Gets the "PeriodoEmissao" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao getPeriodoEmissao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao)get_store().find_element_user(PERIODOEMISSAO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "PeriodoEmissao" element
         */
        public boolean isSetPeriodoEmissao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PERIODOEMISSAO$4) != 0;
            }
        }
        
        /**
         * Sets the "PeriodoEmissao" element
         */
        public void setPeriodoEmissao(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao periodoEmissao)
        {
            generatedSetterHelperImpl(periodoEmissao, PERIODOEMISSAO$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "PeriodoEmissao" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao addNewPeriodoEmissao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao)get_store().add_element_user(PERIODOEMISSAO$4);
                return target;
            }
        }
        
        /**
         * Unsets the "PeriodoEmissao" element
         */
        public void unsetPeriodoEmissao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PERIODOEMISSAO$4, 0);
            }
        }
        
        /**
         * Gets the "PeriodoCompetencia" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia getPeriodoCompetencia()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia)get_store().find_element_user(PERIODOCOMPETENCIA$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "PeriodoCompetencia" element
         */
        public boolean isSetPeriodoCompetencia()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PERIODOCOMPETENCIA$6) != 0;
            }
        }
        
        /**
         * Sets the "PeriodoCompetencia" element
         */
        public void setPeriodoCompetencia(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia periodoCompetencia)
        {
            generatedSetterHelperImpl(periodoCompetencia, PERIODOCOMPETENCIA$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "PeriodoCompetencia" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia addNewPeriodoCompetencia()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia)get_store().add_element_user(PERIODOCOMPETENCIA$6);
                return target;
            }
        }
        
        /**
         * Unsets the "PeriodoCompetencia" element
         */
        public void unsetPeriodoCompetencia()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PERIODOCOMPETENCIA$6, 0);
            }
        }
        
        /**
         * Gets the "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(PRESTADOR$8, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Prestador" element
         */
        public boolean isSetPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PRESTADOR$8) != 0;
            }
        }
        
        /**
         * Sets the "Prestador" element
         */
        public void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador)
        {
            generatedSetterHelperImpl(prestador, PRESTADOR$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(PRESTADOR$8);
                return target;
            }
        }
        
        /**
         * Unsets the "Prestador" element
         */
        public void unsetPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PRESTADOR$8, 0);
            }
        }
        
        /**
         * Gets the "Tomador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoTomador getTomador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoTomador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoTomador)get_store().find_element_user(TOMADOR$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Tomador" element
         */
        public boolean isSetTomador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOMADOR$10) != 0;
            }
        }
        
        /**
         * Sets the "Tomador" element
         */
        public void setTomador(br.org.abrasf.nfse.TcIdentificacaoTomador tomador)
        {
            generatedSetterHelperImpl(tomador, TOMADOR$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Tomador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoTomador addNewTomador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoTomador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoTomador)get_store().add_element_user(TOMADOR$10);
                return target;
            }
        }
        
        /**
         * Unsets the "Tomador" element
         */
        public void unsetTomador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOMADOR$10, 0);
            }
        }
        
        /**
         * Gets the "Intermediario" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoIntermediario getIntermediario()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoIntermediario target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoIntermediario)get_store().find_element_user(INTERMEDIARIO$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Intermediario" element
         */
        public boolean isSetIntermediario()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INTERMEDIARIO$12) != 0;
            }
        }
        
        /**
         * Sets the "Intermediario" element
         */
        public void setIntermediario(br.org.abrasf.nfse.TcIdentificacaoIntermediario intermediario)
        {
            generatedSetterHelperImpl(intermediario, INTERMEDIARIO$12, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Intermediario" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoIntermediario addNewIntermediario()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoIntermediario target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoIntermediario)get_store().add_element_user(INTERMEDIARIO$12);
                return target;
            }
        }
        
        /**
         * Unsets the "Intermediario" element
         */
        public void unsetIntermediario()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INTERMEDIARIO$12, 0);
            }
        }
        
        /**
         * Gets the "Pagina" element
         */
        public int getPagina()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGINA$14, 0);
                if (target == null)
                {
                    return 0;
                }
                return target.getIntValue();
            }
        }
        
        /**
         * Gets (as xml) the "Pagina" element
         */
        public br.org.abrasf.nfse.TsPagina xgetPagina()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsPagina target = null;
                target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PAGINA$14, 0);
                return target;
            }
        }
        
        /**
         * Sets the "Pagina" element
         */
        public void setPagina(int pagina)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGINA$14, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGINA$14);
                }
                target.setIntValue(pagina);
            }
        }
        
        /**
         * Sets (as xml) the "Pagina" element
         */
        public void xsetPagina(br.org.abrasf.nfse.TsPagina pagina)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsPagina target = null;
                target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PAGINA$14, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsPagina)get_store().add_element_user(PAGINA$14);
                }
                target.set(pagina);
            }
        }
        /**
         * An XML PeriodoEmissao(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class PeriodoEmissaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao
        {
            private static final long serialVersionUID = 1L;
            
            public PeriodoEmissaoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName DATAINICIAL$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataInicial");
            private static final javax.xml.namespace.QName DATAFINAL$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataFinal");
            
            
            /**
             * Gets the "DataInicial" element
             */
            public java.util.Calendar getDataInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            public org.apache.xmlbeans.XmlDate xgetDataInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAINICIAL$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "DataInicial" element
             */
            public void setDataInicial(java.util.Calendar dataInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAINICIAL$0);
                    }
                    target.setCalendarValue(dataInicial);
                }
            }
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            public void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAINICIAL$0);
                    }
                    target.set(dataInicial);
                }
            }
            
            /**
             * Gets the "DataFinal" element
             */
            public java.util.Calendar getDataFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            public org.apache.xmlbeans.XmlDate xgetDataFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAFINAL$2, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "DataFinal" element
             */
            public void setDataFinal(java.util.Calendar dataFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAFINAL$2);
                    }
                    target.setCalendarValue(dataFinal);
                }
            }
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            public void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAFINAL$2);
                    }
                    target.set(dataFinal);
                }
            }
        }
        /**
         * An XML PeriodoCompetencia(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class PeriodoCompetenciaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia
        {
            private static final long serialVersionUID = 1L;
            
            public PeriodoCompetenciaImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName DATAINICIAL$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataInicial");
            private static final javax.xml.namespace.QName DATAFINAL$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataFinal");
            
            
            /**
             * Gets the "DataInicial" element
             */
            public java.util.Calendar getDataInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            public org.apache.xmlbeans.XmlDate xgetDataInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAINICIAL$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "DataInicial" element
             */
            public void setDataInicial(java.util.Calendar dataInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAINICIAL$0);
                    }
                    target.setCalendarValue(dataInicial);
                }
            }
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            public void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAINICIAL$0);
                    }
                    target.set(dataInicial);
                }
            }
            
            /**
             * Gets the "DataFinal" element
             */
            public java.util.Calendar getDataFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getCalendarValue();
                }
            }
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            public org.apache.xmlbeans.XmlDate xgetDataFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAFINAL$2, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "DataFinal" element
             */
            public void setDataFinal(java.util.Calendar dataFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAFINAL$2);
                    }
                    target.setCalendarValue(dataFinal);
                }
            }
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            public void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.XmlDate target = null;
                    target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(DATAFINAL$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(DATAFINAL$2);
                    }
                    target.set(dataFinal);
                }
            }
        }
    }
}
