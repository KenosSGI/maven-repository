/*
 * XML Type:  tcInfSubstituicaoNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfSubstituicaoNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcInfSubstituicaoNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcInfSubstituicaoNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcInfSubstituicaoNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcInfSubstituicaoNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NFSESUBSTITUIDORA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseSubstituidora");
    private static final javax.xml.namespace.QName ID$2 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "NfseSubstituidora" element
     */
    public long getNfseSubstituidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NFSESUBSTITUIDORA$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NfseSubstituidora" element
     */
    public br.org.abrasf.nfse.TsNumeroNfse xgetNfseSubstituidora()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NFSESUBSTITUIDORA$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "NfseSubstituidora" element
     */
    public void setNfseSubstituidora(long nfseSubstituidora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NFSESUBSTITUIDORA$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NFSESUBSTITUIDORA$0);
            }
            target.setLongValue(nfseSubstituidora);
        }
    }
    
    /**
     * Sets (as xml) the "NfseSubstituidora" element
     */
    public void xsetNfseSubstituidora(br.org.abrasf.nfse.TsNumeroNfse nfseSubstituidora)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NFSESUBSTITUIDORA$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NFSESUBSTITUIDORA$0);
            }
            target.set(nfseSubstituidora);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$2);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$2);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$2) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$2);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$2);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$2);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$2);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$2);
        }
    }
}
