/*
 * XML Type:  tcMensagemRetorno
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcMensagemRetorno
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcMensagemRetorno(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcMensagemRetornoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcMensagemRetorno
{
    private static final long serialVersionUID = 1L;
    
    public TcMensagemRetornoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CODIGO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Codigo");
    private static final javax.xml.namespace.QName MENSAGEM$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Mensagem");
    private static final javax.xml.namespace.QName CORRECAO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Correcao");
    
    
    /**
     * Gets the "Codigo" element
     */
    public java.lang.String getCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Codigo" element
     */
    public br.org.abrasf.nfse.TsCodigoMensagemAlerta xgetCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().find_element_user(CODIGO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Codigo" element
     */
    public void setCodigo(java.lang.String codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGO$0);
            }
            target.setStringValue(codigo);
        }
    }
    
    /**
     * Sets (as xml) the "Codigo" element
     */
    public void xsetCodigo(br.org.abrasf.nfse.TsCodigoMensagemAlerta codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().find_element_user(CODIGO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().add_element_user(CODIGO$0);
            }
            target.set(codigo);
        }
    }
    
    /**
     * Gets the "Mensagem" element
     */
    public java.lang.String getMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Mensagem" element
     */
    public br.org.abrasf.nfse.TsDescricaoMensagemAlerta xgetMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(MENSAGEM$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Mensagem" element
     */
    public void setMensagem(java.lang.String mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MENSAGEM$2);
            }
            target.setStringValue(mensagem);
        }
    }
    
    /**
     * Sets (as xml) the "Mensagem" element
     */
    public void xsetMensagem(br.org.abrasf.nfse.TsDescricaoMensagemAlerta mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(MENSAGEM$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().add_element_user(MENSAGEM$2);
            }
            target.set(mensagem);
        }
    }
    
    /**
     * Gets the "Correcao" element
     */
    public java.lang.String getCorrecao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRECAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Correcao" element
     */
    public br.org.abrasf.nfse.TsDescricaoMensagemAlerta xgetCorrecao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(CORRECAO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "Correcao" element
     */
    public boolean isSetCorrecao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRECAO$4) != 0;
        }
    }
    
    /**
     * Sets the "Correcao" element
     */
    public void setCorrecao(java.lang.String correcao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRECAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRECAO$4);
            }
            target.setStringValue(correcao);
        }
    }
    
    /**
     * Sets (as xml) the "Correcao" element
     */
    public void xsetCorrecao(br.org.abrasf.nfse.TsDescricaoMensagemAlerta correcao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(CORRECAO$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().add_element_user(CORRECAO$4);
            }
            target.set(correcao);
        }
    }
    
    /**
     * Unsets the "Correcao" element
     */
    public void unsetCorrecao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRECAO$4, 0);
        }
    }
}
