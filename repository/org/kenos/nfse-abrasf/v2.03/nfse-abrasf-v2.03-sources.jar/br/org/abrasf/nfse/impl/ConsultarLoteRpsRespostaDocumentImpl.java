/*
 * An XML document type.
 * Localname: ConsultarLoteRpsResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarLoteRpsRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarLoteRpsRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARLOTERPSRESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarLoteRpsResposta");
    
    
    /**
     * Gets the "ConsultarLoteRpsResposta" element
     */
    public br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta getConsultarLoteRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta)get_store().find_element_user(CONSULTARLOTERPSRESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarLoteRpsResposta" element
     */
    public void setConsultarLoteRpsResposta(br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta consultarLoteRpsResposta)
    {
        generatedSetterHelperImpl(consultarLoteRpsResposta, CONSULTARLOTERPSRESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarLoteRpsResposta" element
     */
    public br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta addNewConsultarLoteRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta)get_store().add_element_user(CONSULTARLOTERPSRESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML ConsultarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarLoteRpsRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarLoteRpsRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SITUACAO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Situacao");
        private static final javax.xml.namespace.QName LISTANFSE$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaNfse");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$4 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNOLOTE$6 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetornoLote");
        
        
        /**
         * Gets the "Situacao" element
         */
        public byte getSituacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAO$0, 0);
                if (target == null)
                {
                    return 0;
                }
                return target.getByteValue();
            }
        }
        
        /**
         * Gets (as xml) the "Situacao" element
         */
        public br.org.abrasf.nfse.TsSituacaoLoteRps xgetSituacao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsSituacaoLoteRps target = null;
                target = (br.org.abrasf.nfse.TsSituacaoLoteRps)get_store().find_element_user(SITUACAO$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "Situacao" element
         */
        public void setSituacao(byte situacao)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SITUACAO$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SITUACAO$0);
                }
                target.setByteValue(situacao);
            }
        }
        
        /**
         * Sets (as xml) the "Situacao" element
         */
        public void xsetSituacao(br.org.abrasf.nfse.TsSituacaoLoteRps situacao)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsSituacaoLoteRps target = null;
                target = (br.org.abrasf.nfse.TsSituacaoLoteRps)get_store().find_element_user(SITUACAO$0, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsSituacaoLoteRps)get_store().add_element_user(SITUACAO$0);
                }
                target.set(situacao);
            }
        }
        
        /**
         * Gets the "ListaNfse" element
         */
        public br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse getListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse)get_store().find_element_user(LISTANFSE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaNfse" element
         */
        public boolean isSetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTANFSE$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaNfse" element
         */
        public void setListaNfse(br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse listaNfse)
        {
            generatedSetterHelperImpl(listaNfse, LISTANFSE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        public br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse addNewListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse)get_store().add_element_user(LISTANFSE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaNfse" element
         */
        public void unsetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTANFSE$2, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$4) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$4);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$4, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetornoLote" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote getListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().find_element_user(LISTAMENSAGEMRETORNOLOTE$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetornoLote" element
         */
        public boolean isSetListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNOLOTE$6) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetornoLote" element
         */
        public void setListaMensagemRetornoLote(br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote listaMensagemRetornoLote)
        {
            generatedSetterHelperImpl(listaMensagemRetornoLote, LISTAMENSAGEMRETORNOLOTE$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetornoLote" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote addNewListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().add_element_user(LISTAMENSAGEMRETORNOLOTE$6);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetornoLote" element
         */
        public void unsetListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNOLOTE$6, 0);
            }
        }
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class ListaNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse
        {
            private static final long serialVersionUID = 1L;
            
            public ListaNfseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName COMPNFSE$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
            private static final javax.xml.namespace.QName LISTAMENSAGEMALERTARETORNO$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemAlertaRetorno");
            
            
            /**
             * Gets array of all "CompNfse" elements
             */
            public br.org.abrasf.nfse.TcCompNfse[] getCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(COMPNFSE$0, targetList);
                    br.org.abrasf.nfse.TcCompNfse[] result = new br.org.abrasf.nfse.TcCompNfse[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse getCompNfseArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "CompNfse" element
             */
            public int sizeOfCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(COMPNFSE$0);
                }
            }
            
            /**
             * Sets array of all "CompNfse" element  WARNING: This method is not atomicaly synchronized.
             */
            public void setCompNfseArray(br.org.abrasf.nfse.TcCompNfse[] compNfseArray)
            {
                check_orphaned();
                arraySetterHelper(compNfseArray, COMPNFSE$0);
            }
            
            /**
             * Sets ith "CompNfse" element
             */
            public void setCompNfseArray(int i, br.org.abrasf.nfse.TcCompNfse compNfse)
            {
                generatedSetterHelperImpl(compNfse, COMPNFSE$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse insertNewCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().insert_element_user(COMPNFSE$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "CompNfse" element
             */
            public void removeCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(COMPNFSE$0, i);
                }
            }
            
            /**
             * Gets the "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().find_element_user(LISTAMENSAGEMALERTARETORNO$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "ListaMensagemAlertaRetorno" element
             */
            public boolean isSetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(LISTAMENSAGEMALERTARETORNO$2) != 0;
                }
            }
            
            /**
             * Sets the "ListaMensagemAlertaRetorno" element
             */
            public void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno)
            {
                generatedSetterHelperImpl(listaMensagemAlertaRetorno, LISTAMENSAGEMALERTARETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().add_element_user(LISTAMENSAGEMALERTARETORNO$2);
                    return target;
                }
            }
            
            /**
             * Unsets the "ListaMensagemAlertaRetorno" element
             */
            public void unsetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(LISTAMENSAGEMALERTARETORNO$2, 0);
                }
            }
        }
    }
}
