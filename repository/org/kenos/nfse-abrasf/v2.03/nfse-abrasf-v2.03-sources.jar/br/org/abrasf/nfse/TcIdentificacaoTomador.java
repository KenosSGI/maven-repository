/*
 * XML Type:  tcIdentificacaoTomador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcIdentificacaoTomador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcIdentificacaoTomador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcIdentificacaoTomador extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcIdentificacaoTomador.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcidentificacaotomador4491type");
    
    /**
     * Gets the "CpfCnpj" element
     */
    br.org.abrasf.nfse.TcCpfCnpj getCpfCnpj();
    
    /**
     * True if has "CpfCnpj" element
     */
    boolean isSetCpfCnpj();
    
    /**
     * Sets the "CpfCnpj" element
     */
    void setCpfCnpj(br.org.abrasf.nfse.TcCpfCnpj cpfCnpj);
    
    /**
     * Appends and returns a new empty "CpfCnpj" element
     */
    br.org.abrasf.nfse.TcCpfCnpj addNewCpfCnpj();
    
    /**
     * Unsets the "CpfCnpj" element
     */
    void unsetCpfCnpj();
    
    /**
     * Gets the "InscricaoMunicipal" element
     */
    java.lang.String getInscricaoMunicipal();
    
    /**
     * Gets (as xml) the "InscricaoMunicipal" element
     */
    br.org.abrasf.nfse.TsInscricaoMunicipal xgetInscricaoMunicipal();
    
    /**
     * True if has "InscricaoMunicipal" element
     */
    boolean isSetInscricaoMunicipal();
    
    /**
     * Sets the "InscricaoMunicipal" element
     */
    void setInscricaoMunicipal(java.lang.String inscricaoMunicipal);
    
    /**
     * Sets (as xml) the "InscricaoMunicipal" element
     */
    void xsetInscricaoMunicipal(br.org.abrasf.nfse.TsInscricaoMunicipal inscricaoMunicipal);
    
    /**
     * Unsets the "InscricaoMunicipal" element
     */
    void unsetInscricaoMunicipal();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcIdentificacaoTomador newInstance() {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcIdentificacaoTomador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcIdentificacaoTomador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
