/*
 * An XML document type.
 * Localname: ConsultarNfseServicoTomadoResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarNfseServicoTomadoResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarNfseServicoTomadoRespostaDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoTomadoRespostaDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("consultarnfseservicotomadorespostaa084doctype");
    
    /**
     * Gets the "ConsultarNfseServicoTomadoResposta" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta getConsultarNfseServicoTomadoResposta();
    
    /**
     * Sets the "ConsultarNfseServicoTomadoResposta" element
     */
    void setConsultarNfseServicoTomadoResposta(br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta consultarNfseServicoTomadoResposta);
    
    /**
     * Appends and returns a new empty "ConsultarNfseServicoTomadoResposta" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta addNewConsultarNfseServicoTomadoResposta();
    
    /**
     * An XML ConsultarNfseServicoTomadoResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarNfseServicoTomadoResposta extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoTomadoResposta.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("consultarnfseservicotomadoresposta7575elemtype");
        
        /**
         * Gets the "ListaNfse" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse getListaNfse();
        
        /**
         * True if has "ListaNfse" element
         */
        boolean isSetListaNfse();
        
        /**
         * Sets the "ListaNfse" element
         */
        void setListaNfse(br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse listaNfse);
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse addNewListaNfse();
        
        /**
         * Unsets the "ListaNfse" element
         */
        void unsetListaNfse();
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno();
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        boolean isSetListaMensagemRetorno();
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno();
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        void unsetListaMensagemRetorno();
        
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface ListaNfse extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("listanfse4a6eelemtype");
            
            /**
             * Gets array of all "CompNfse" elements
             */
            br.org.abrasf.nfse.TcCompNfse[] getCompNfseArray();
            
            /**
             * Gets ith "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse getCompNfseArray(int i);
            
            /**
             * Returns number of "CompNfse" element
             */
            int sizeOfCompNfseArray();
            
            /**
             * Sets array of all "CompNfse" element
             */
            void setCompNfseArray(br.org.abrasf.nfse.TcCompNfse[] compNfseArray);
            
            /**
             * Sets ith "CompNfse" element
             */
            void setCompNfseArray(int i, br.org.abrasf.nfse.TcCompNfse compNfse);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse insertNewCompNfse(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse addNewCompNfse();
            
            /**
             * Removes the ith "CompNfse" element
             */
            void removeCompNfse(int i);
            
            /**
             * Gets the "ProximaPagina" element
             */
            int getProximaPagina();
            
            /**
             * Gets (as xml) the "ProximaPagina" element
             */
            br.org.abrasf.nfse.TsPagina xgetProximaPagina();
            
            /**
             * True if has "ProximaPagina" element
             */
            boolean isSetProximaPagina();
            
            /**
             * Sets the "ProximaPagina" element
             */
            void setProximaPagina(int proximaPagina);
            
            /**
             * Sets (as xml) the "ProximaPagina" element
             */
            void xsetProximaPagina(br.org.abrasf.nfse.TsPagina proximaPagina);
            
            /**
             * Unsets the "ProximaPagina" element
             */
            void unsetProximaPagina();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta newInstance() {
              return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument.ConsultarNfseServicoTomadoResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
