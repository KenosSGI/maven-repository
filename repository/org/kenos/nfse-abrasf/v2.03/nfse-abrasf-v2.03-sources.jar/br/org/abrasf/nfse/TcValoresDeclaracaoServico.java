/*
 * XML Type:  tcValoresDeclaracaoServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcValoresDeclaracaoServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcValoresDeclaracaoServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcValoresDeclaracaoServico extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcValoresDeclaracaoServico.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcvaloresdeclaracaoservicoc132type");
    
    /**
     * Gets the "ValorServicos" element
     */
    java.math.BigDecimal getValorServicos();
    
    /**
     * Gets (as xml) the "ValorServicos" element
     */
    br.org.abrasf.nfse.TsValor xgetValorServicos();
    
    /**
     * Sets the "ValorServicos" element
     */
    void setValorServicos(java.math.BigDecimal valorServicos);
    
    /**
     * Sets (as xml) the "ValorServicos" element
     */
    void xsetValorServicos(br.org.abrasf.nfse.TsValor valorServicos);
    
    /**
     * Gets the "ValorDeducoes" element
     */
    java.math.BigDecimal getValorDeducoes();
    
    /**
     * Gets (as xml) the "ValorDeducoes" element
     */
    br.org.abrasf.nfse.TsValor xgetValorDeducoes();
    
    /**
     * True if has "ValorDeducoes" element
     */
    boolean isSetValorDeducoes();
    
    /**
     * Sets the "ValorDeducoes" element
     */
    void setValorDeducoes(java.math.BigDecimal valorDeducoes);
    
    /**
     * Sets (as xml) the "ValorDeducoes" element
     */
    void xsetValorDeducoes(br.org.abrasf.nfse.TsValor valorDeducoes);
    
    /**
     * Unsets the "ValorDeducoes" element
     */
    void unsetValorDeducoes();
    
    /**
     * Gets the "ValorPis" element
     */
    java.math.BigDecimal getValorPis();
    
    /**
     * Gets (as xml) the "ValorPis" element
     */
    br.org.abrasf.nfse.TsValor xgetValorPis();
    
    /**
     * True if has "ValorPis" element
     */
    boolean isSetValorPis();
    
    /**
     * Sets the "ValorPis" element
     */
    void setValorPis(java.math.BigDecimal valorPis);
    
    /**
     * Sets (as xml) the "ValorPis" element
     */
    void xsetValorPis(br.org.abrasf.nfse.TsValor valorPis);
    
    /**
     * Unsets the "ValorPis" element
     */
    void unsetValorPis();
    
    /**
     * Gets the "ValorCofins" element
     */
    java.math.BigDecimal getValorCofins();
    
    /**
     * Gets (as xml) the "ValorCofins" element
     */
    br.org.abrasf.nfse.TsValor xgetValorCofins();
    
    /**
     * True if has "ValorCofins" element
     */
    boolean isSetValorCofins();
    
    /**
     * Sets the "ValorCofins" element
     */
    void setValorCofins(java.math.BigDecimal valorCofins);
    
    /**
     * Sets (as xml) the "ValorCofins" element
     */
    void xsetValorCofins(br.org.abrasf.nfse.TsValor valorCofins);
    
    /**
     * Unsets the "ValorCofins" element
     */
    void unsetValorCofins();
    
    /**
     * Gets the "ValorInss" element
     */
    java.math.BigDecimal getValorInss();
    
    /**
     * Gets (as xml) the "ValorInss" element
     */
    br.org.abrasf.nfse.TsValor xgetValorInss();
    
    /**
     * True if has "ValorInss" element
     */
    boolean isSetValorInss();
    
    /**
     * Sets the "ValorInss" element
     */
    void setValorInss(java.math.BigDecimal valorInss);
    
    /**
     * Sets (as xml) the "ValorInss" element
     */
    void xsetValorInss(br.org.abrasf.nfse.TsValor valorInss);
    
    /**
     * Unsets the "ValorInss" element
     */
    void unsetValorInss();
    
    /**
     * Gets the "ValorIr" element
     */
    java.math.BigDecimal getValorIr();
    
    /**
     * Gets (as xml) the "ValorIr" element
     */
    br.org.abrasf.nfse.TsValor xgetValorIr();
    
    /**
     * True if has "ValorIr" element
     */
    boolean isSetValorIr();
    
    /**
     * Sets the "ValorIr" element
     */
    void setValorIr(java.math.BigDecimal valorIr);
    
    /**
     * Sets (as xml) the "ValorIr" element
     */
    void xsetValorIr(br.org.abrasf.nfse.TsValor valorIr);
    
    /**
     * Unsets the "ValorIr" element
     */
    void unsetValorIr();
    
    /**
     * Gets the "ValorCsll" element
     */
    java.math.BigDecimal getValorCsll();
    
    /**
     * Gets (as xml) the "ValorCsll" element
     */
    br.org.abrasf.nfse.TsValor xgetValorCsll();
    
    /**
     * True if has "ValorCsll" element
     */
    boolean isSetValorCsll();
    
    /**
     * Sets the "ValorCsll" element
     */
    void setValorCsll(java.math.BigDecimal valorCsll);
    
    /**
     * Sets (as xml) the "ValorCsll" element
     */
    void xsetValorCsll(br.org.abrasf.nfse.TsValor valorCsll);
    
    /**
     * Unsets the "ValorCsll" element
     */
    void unsetValorCsll();
    
    /**
     * Gets the "OutrasRetencoes" element
     */
    java.math.BigDecimal getOutrasRetencoes();
    
    /**
     * Gets (as xml) the "OutrasRetencoes" element
     */
    br.org.abrasf.nfse.TsValor xgetOutrasRetencoes();
    
    /**
     * True if has "OutrasRetencoes" element
     */
    boolean isSetOutrasRetencoes();
    
    /**
     * Sets the "OutrasRetencoes" element
     */
    void setOutrasRetencoes(java.math.BigDecimal outrasRetencoes);
    
    /**
     * Sets (as xml) the "OutrasRetencoes" element
     */
    void xsetOutrasRetencoes(br.org.abrasf.nfse.TsValor outrasRetencoes);
    
    /**
     * Unsets the "OutrasRetencoes" element
     */
    void unsetOutrasRetencoes();
    
    /**
     * Gets the "ValTotTributos" element
     */
    java.math.BigDecimal getValTotTributos();
    
    /**
     * Gets (as xml) the "ValTotTributos" element
     */
    br.org.abrasf.nfse.TsValor xgetValTotTributos();
    
    /**
     * True if has "ValTotTributos" element
     */
    boolean isSetValTotTributos();
    
    /**
     * Sets the "ValTotTributos" element
     */
    void setValTotTributos(java.math.BigDecimal valTotTributos);
    
    /**
     * Sets (as xml) the "ValTotTributos" element
     */
    void xsetValTotTributos(br.org.abrasf.nfse.TsValor valTotTributos);
    
    /**
     * Unsets the "ValTotTributos" element
     */
    void unsetValTotTributos();
    
    /**
     * Gets the "ValorIss" element
     */
    java.math.BigDecimal getValorIss();
    
    /**
     * Gets (as xml) the "ValorIss" element
     */
    br.org.abrasf.nfse.TsValor xgetValorIss();
    
    /**
     * True if has "ValorIss" element
     */
    boolean isSetValorIss();
    
    /**
     * Sets the "ValorIss" element
     */
    void setValorIss(java.math.BigDecimal valorIss);
    
    /**
     * Sets (as xml) the "ValorIss" element
     */
    void xsetValorIss(br.org.abrasf.nfse.TsValor valorIss);
    
    /**
     * Unsets the "ValorIss" element
     */
    void unsetValorIss();
    
    /**
     * Gets the "Aliquota" element
     */
    java.math.BigDecimal getAliquota();
    
    /**
     * Gets (as xml) the "Aliquota" element
     */
    br.org.abrasf.nfse.TsAliquota xgetAliquota();
    
    /**
     * True if has "Aliquota" element
     */
    boolean isSetAliquota();
    
    /**
     * Sets the "Aliquota" element
     */
    void setAliquota(java.math.BigDecimal aliquota);
    
    /**
     * Sets (as xml) the "Aliquota" element
     */
    void xsetAliquota(br.org.abrasf.nfse.TsAliquota aliquota);
    
    /**
     * Unsets the "Aliquota" element
     */
    void unsetAliquota();
    
    /**
     * Gets the "DescontoIncondicionado" element
     */
    java.math.BigDecimal getDescontoIncondicionado();
    
    /**
     * Gets (as xml) the "DescontoIncondicionado" element
     */
    br.org.abrasf.nfse.TsValor xgetDescontoIncondicionado();
    
    /**
     * True if has "DescontoIncondicionado" element
     */
    boolean isSetDescontoIncondicionado();
    
    /**
     * Sets the "DescontoIncondicionado" element
     */
    void setDescontoIncondicionado(java.math.BigDecimal descontoIncondicionado);
    
    /**
     * Sets (as xml) the "DescontoIncondicionado" element
     */
    void xsetDescontoIncondicionado(br.org.abrasf.nfse.TsValor descontoIncondicionado);
    
    /**
     * Unsets the "DescontoIncondicionado" element
     */
    void unsetDescontoIncondicionado();
    
    /**
     * Gets the "DescontoCondicionado" element
     */
    java.math.BigDecimal getDescontoCondicionado();
    
    /**
     * Gets (as xml) the "DescontoCondicionado" element
     */
    br.org.abrasf.nfse.TsValor xgetDescontoCondicionado();
    
    /**
     * True if has "DescontoCondicionado" element
     */
    boolean isSetDescontoCondicionado();
    
    /**
     * Sets the "DescontoCondicionado" element
     */
    void setDescontoCondicionado(java.math.BigDecimal descontoCondicionado);
    
    /**
     * Sets (as xml) the "DescontoCondicionado" element
     */
    void xsetDescontoCondicionado(br.org.abrasf.nfse.TsValor descontoCondicionado);
    
    /**
     * Unsets the "DescontoCondicionado" element
     */
    void unsetDescontoCondicionado();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico newInstance() {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcValoresDeclaracaoServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcValoresDeclaracaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
