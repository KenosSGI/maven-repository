/*
 * An XML document type.
 * Localname: GerarNfseResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.GerarNfseRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one GerarNfseResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface GerarNfseRespostaDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GerarNfseRespostaDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("gerarnfseresposta40efdoctype");
    
    /**
     * Gets the "GerarNfseResposta" element
     */
    br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta getGerarNfseResposta();
    
    /**
     * Sets the "GerarNfseResposta" element
     */
    void setGerarNfseResposta(br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta gerarNfseResposta);
    
    /**
     * Appends and returns a new empty "GerarNfseResposta" element
     */
    br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta addNewGerarNfseResposta();
    
    /**
     * An XML GerarNfseResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface GerarNfseResposta extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GerarNfseResposta.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("gerarnfseresposta90abelemtype");
        
        /**
         * Gets the "ListaNfse" element
         */
        br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse getListaNfse();
        
        /**
         * True if has "ListaNfse" element
         */
        boolean isSetListaNfse();
        
        /**
         * Sets the "ListaNfse" element
         */
        void setListaNfse(br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse listaNfse);
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse addNewListaNfse();
        
        /**
         * Unsets the "ListaNfse" element
         */
        void unsetListaNfse();
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno();
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        boolean isSetListaMensagemRetorno();
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno();
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        void unsetListaMensagemRetorno();
        
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface ListaNfse extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("listanfse73e4elemtype");
            
            /**
             * Gets the "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse getCompNfse();
            
            /**
             * Sets the "CompNfse" element
             */
            void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse);
            
            /**
             * Appends and returns a new empty "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse addNewCompNfse();
            
            /**
             * Gets the "ListaMensagemAlertaRetorno" element
             */
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno();
            
            /**
             * True if has "ListaMensagemAlertaRetorno" element
             */
            boolean isSetListaMensagemAlertaRetorno();
            
            /**
             * Sets the "ListaMensagemAlertaRetorno" element
             */
            void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno);
            
            /**
             * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
             */
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno();
            
            /**
             * Unsets the "ListaMensagemAlertaRetorno" element
             */
            void unsetListaMensagemAlertaRetorno();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse newInstance() {
                  return (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta newInstance() {
              return (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument newInstance() {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.GerarNfseRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.GerarNfseRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
