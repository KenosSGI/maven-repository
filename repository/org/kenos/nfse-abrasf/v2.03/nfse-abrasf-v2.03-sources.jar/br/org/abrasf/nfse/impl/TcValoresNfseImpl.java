/*
 * XML Type:  tcValoresNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcValoresNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcValoresNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcValoresNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcValoresNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcValoresNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName BASECALCULO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "BaseCalculo");
    private static final javax.xml.namespace.QName ALIQUOTA$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Aliquota");
    private static final javax.xml.namespace.QName VALORISS$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorIss");
    private static final javax.xml.namespace.QName VALORLIQUIDONFSE$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorLiquidoNfse");
    
    
    /**
     * Gets the "BaseCalculo" element
     */
    public java.math.BigDecimal getBaseCalculo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BASECALCULO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "BaseCalculo" element
     */
    public br.org.abrasf.nfse.TsValor xgetBaseCalculo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(BASECALCULO$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "BaseCalculo" element
     */
    public boolean isSetBaseCalculo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BASECALCULO$0) != 0;
        }
    }
    
    /**
     * Sets the "BaseCalculo" element
     */
    public void setBaseCalculo(java.math.BigDecimal baseCalculo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BASECALCULO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BASECALCULO$0);
            }
            target.setBigDecimalValue(baseCalculo);
        }
    }
    
    /**
     * Sets (as xml) the "BaseCalculo" element
     */
    public void xsetBaseCalculo(br.org.abrasf.nfse.TsValor baseCalculo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(BASECALCULO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(BASECALCULO$0);
            }
            target.set(baseCalculo);
        }
    }
    
    /**
     * Unsets the "BaseCalculo" element
     */
    public void unsetBaseCalculo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BASECALCULO$0, 0);
        }
    }
    
    /**
     * Gets the "Aliquota" element
     */
    public java.math.BigDecimal getAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "Aliquota" element
     */
    public br.org.abrasf.nfse.TsAliquota xgetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsAliquota target = null;
            target = (br.org.abrasf.nfse.TsAliquota)get_store().find_element_user(ALIQUOTA$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Aliquota" element
     */
    public boolean isSetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIQUOTA$2) != 0;
        }
    }
    
    /**
     * Sets the "Aliquota" element
     */
    public void setAliquota(java.math.BigDecimal aliquota)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALIQUOTA$2);
            }
            target.setBigDecimalValue(aliquota);
        }
    }
    
    /**
     * Sets (as xml) the "Aliquota" element
     */
    public void xsetAliquota(br.org.abrasf.nfse.TsAliquota aliquota)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsAliquota target = null;
            target = (br.org.abrasf.nfse.TsAliquota)get_store().find_element_user(ALIQUOTA$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsAliquota)get_store().add_element_user(ALIQUOTA$2);
            }
            target.set(aliquota);
        }
    }
    
    /**
     * Unsets the "Aliquota" element
     */
    public void unsetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIQUOTA$2, 0);
        }
    }
    
    /**
     * Gets the "ValorIss" element
     */
    public java.math.BigDecimal getValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORISS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorIss" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORISS$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorIss" element
     */
    public boolean isSetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORISS$4) != 0;
        }
    }
    
    /**
     * Sets the "ValorIss" element
     */
    public void setValorIss(java.math.BigDecimal valorIss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORISS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORISS$4);
            }
            target.setBigDecimalValue(valorIss);
        }
    }
    
    /**
     * Sets (as xml) the "ValorIss" element
     */
    public void xsetValorIss(br.org.abrasf.nfse.TsValor valorIss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORISS$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORISS$4);
            }
            target.set(valorIss);
        }
    }
    
    /**
     * Unsets the "ValorIss" element
     */
    public void unsetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORISS$4, 0);
        }
    }
    
    /**
     * Gets the "ValorLiquidoNfse" element
     */
    public java.math.BigDecimal getValorLiquidoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORLIQUIDONFSE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorLiquidoNfse" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorLiquidoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORLIQUIDONFSE$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ValorLiquidoNfse" element
     */
    public void setValorLiquidoNfse(java.math.BigDecimal valorLiquidoNfse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORLIQUIDONFSE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORLIQUIDONFSE$6);
            }
            target.setBigDecimalValue(valorLiquidoNfse);
        }
    }
    
    /**
     * Sets (as xml) the "ValorLiquidoNfse" element
     */
    public void xsetValorLiquidoNfse(br.org.abrasf.nfse.TsValor valorLiquidoNfse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORLIQUIDONFSE$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORLIQUIDONFSE$6);
            }
            target.set(valorLiquidoNfse);
        }
    }
}
