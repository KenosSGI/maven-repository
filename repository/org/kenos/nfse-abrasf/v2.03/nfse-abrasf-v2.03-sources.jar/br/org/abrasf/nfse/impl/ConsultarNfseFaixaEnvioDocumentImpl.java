/*
 * An XML document type.
 * Localname: ConsultarNfseFaixaEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarNfseFaixaEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarNfseFaixaEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarNfseFaixaEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARNFSEFAIXAENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarNfseFaixaEnvio");
    
    
    /**
     * Gets the "ConsultarNfseFaixaEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio getConsultarNfseFaixaEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio)get_store().find_element_user(CONSULTARNFSEFAIXAENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarNfseFaixaEnvio" element
     */
    public void setConsultarNfseFaixaEnvio(br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio consultarNfseFaixaEnvio)
    {
        generatedSetterHelperImpl(consultarNfseFaixaEnvio, CONSULTARNFSEFAIXAENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarNfseFaixaEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio addNewConsultarNfseFaixaEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio)get_store().add_element_user(CONSULTARNFSEFAIXAENVIO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarNfseFaixaEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarNfseFaixaEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarNfseFaixaEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PRESTADOR$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Prestador");
        private static final javax.xml.namespace.QName FAIXA$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Faixa");
        private static final javax.xml.namespace.QName PAGINA$4 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Pagina");
        
        
        /**
         * Gets the "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(PRESTADOR$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Prestador" element
         */
        public void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador)
        {
            generatedSetterHelperImpl(prestador, PRESTADOR$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(PRESTADOR$0);
                return target;
            }
        }
        
        /**
         * Gets the "Faixa" element
         */
        public br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa getFaixa()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa)get_store().find_element_user(FAIXA$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Faixa" element
         */
        public void setFaixa(br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa faixa)
        {
            generatedSetterHelperImpl(faixa, FAIXA$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Faixa" element
         */
        public br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa addNewFaixa()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa)get_store().add_element_user(FAIXA$2);
                return target;
            }
        }
        
        /**
         * Gets the "Pagina" element
         */
        public int getPagina()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGINA$4, 0);
                if (target == null)
                {
                    return 0;
                }
                return target.getIntValue();
            }
        }
        
        /**
         * Gets (as xml) the "Pagina" element
         */
        public br.org.abrasf.nfse.TsPagina xgetPagina()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsPagina target = null;
                target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PAGINA$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "Pagina" element
         */
        public void setPagina(int pagina)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PAGINA$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PAGINA$4);
                }
                target.setIntValue(pagina);
            }
        }
        
        /**
         * Sets (as xml) the "Pagina" element
         */
        public void xsetPagina(br.org.abrasf.nfse.TsPagina pagina)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsPagina target = null;
                target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PAGINA$4, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsPagina)get_store().add_element_user(PAGINA$4);
                }
                target.set(pagina);
            }
        }
        /**
         * An XML Faixa(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class FaixaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa
        {
            private static final long serialVersionUID = 1L;
            
            public FaixaImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName NUMERONFSEINICIAL$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroNfseInicial");
            private static final javax.xml.namespace.QName NUMERONFSEFINAL$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroNfseFinal");
            
            
            /**
             * Gets the "NumeroNfseInicial" element
             */
            public long getNumeroNfseInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSEINICIAL$0, 0);
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "NumeroNfseInicial" element
             */
            public br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfseInicial()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsNumeroNfse target = null;
                    target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSEINICIAL$0, 0);
                    return target;
                }
            }
            
            /**
             * Sets the "NumeroNfseInicial" element
             */
            public void setNumeroNfseInicial(long numeroNfseInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSEINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERONFSEINICIAL$0);
                    }
                    target.setLongValue(numeroNfseInicial);
                }
            }
            
            /**
             * Sets (as xml) the "NumeroNfseInicial" element
             */
            public void xsetNumeroNfseInicial(br.org.abrasf.nfse.TsNumeroNfse numeroNfseInicial)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsNumeroNfse target = null;
                    target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSEINICIAL$0, 0);
                    if (target == null)
                    {
                      target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NUMERONFSEINICIAL$0);
                    }
                    target.set(numeroNfseInicial);
                }
            }
            
            /**
             * Gets the "NumeroNfseFinal" element
             */
            public long getNumeroNfseFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSEFINAL$2, 0);
                    if (target == null)
                    {
                      return 0L;
                    }
                    return target.getLongValue();
                }
            }
            
            /**
             * Gets (as xml) the "NumeroNfseFinal" element
             */
            public br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfseFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsNumeroNfse target = null;
                    target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSEFINAL$2, 0);
                    return target;
                }
            }
            
            /**
             * True if has "NumeroNfseFinal" element
             */
            public boolean isSetNumeroNfseFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(NUMERONFSEFINAL$2) != 0;
                }
            }
            
            /**
             * Sets the "NumeroNfseFinal" element
             */
            public void setNumeroNfseFinal(long numeroNfseFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERONFSEFINAL$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERONFSEFINAL$2);
                    }
                    target.setLongValue(numeroNfseFinal);
                }
            }
            
            /**
             * Sets (as xml) the "NumeroNfseFinal" element
             */
            public void xsetNumeroNfseFinal(br.org.abrasf.nfse.TsNumeroNfse numeroNfseFinal)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsNumeroNfse target = null;
                    target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERONFSEFINAL$2, 0);
                    if (target == null)
                    {
                      target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NUMERONFSEFINAL$2);
                    }
                    target.set(numeroNfseFinal);
                }
            }
            
            /**
             * Unsets the "NumeroNfseFinal" element
             */
            public void unsetNumeroNfseFinal()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(NUMERONFSEFINAL$2, 0);
                }
            }
        }
    }
}
