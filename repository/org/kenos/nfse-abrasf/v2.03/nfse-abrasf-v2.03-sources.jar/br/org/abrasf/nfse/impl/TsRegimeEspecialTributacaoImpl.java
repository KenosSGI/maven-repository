/*
 * XML Type:  tsRegimeEspecialTributacao
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsRegimeEspecialTributacao
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsRegimeEspecialTributacao(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsRegimeEspecialTributacao.
 */
public class TsRegimeEspecialTributacaoImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements br.org.abrasf.nfse.TsRegimeEspecialTributacao
{
    private static final long serialVersionUID = 1L;
    
    public TsRegimeEspecialTributacaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsRegimeEspecialTributacaoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
