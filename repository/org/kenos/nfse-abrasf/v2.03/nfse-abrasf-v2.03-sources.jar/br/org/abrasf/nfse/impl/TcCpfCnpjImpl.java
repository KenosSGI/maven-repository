/*
 * XML Type:  tcCpfCnpj
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcCpfCnpj
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcCpfCnpj(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcCpfCnpjImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcCpfCnpj
{
    private static final long serialVersionUID = 1L;
    
    public TcCpfCnpjImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CPF$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Cpf");
    private static final javax.xml.namespace.QName CNPJ$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Cnpj");
    
    
    /**
     * Gets the "Cpf" element
     */
    public java.lang.String getCpf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cpf" element
     */
    public br.org.abrasf.nfse.TsCpf xgetCpf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCpf target = null;
            target = (br.org.abrasf.nfse.TsCpf)get_store().find_element_user(CPF$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "Cpf" element
     */
    public boolean isSetCpf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPF$0) != 0;
        }
    }
    
    /**
     * Sets the "Cpf" element
     */
    public void setCpf(java.lang.String cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CPF$0);
            }
            target.setStringValue(cpf);
        }
    }
    
    /**
     * Sets (as xml) the "Cpf" element
     */
    public void xsetCpf(br.org.abrasf.nfse.TsCpf cpf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCpf target = null;
            target = (br.org.abrasf.nfse.TsCpf)get_store().find_element_user(CPF$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCpf)get_store().add_element_user(CPF$0);
            }
            target.set(cpf);
        }
    }
    
    /**
     * Unsets the "Cpf" element
     */
    public void unsetCpf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPF$0, 0);
        }
    }
    
    /**
     * Gets the "Cnpj" element
     */
    public java.lang.String getCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cnpj" element
     */
    public br.org.abrasf.nfse.TsCnpj xgetCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCnpj target = null;
            target = (br.org.abrasf.nfse.TsCnpj)get_store().find_element_user(CNPJ$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Cnpj" element
     */
    public boolean isSetCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CNPJ$2) != 0;
        }
    }
    
    /**
     * Sets the "Cnpj" element
     */
    public void setCnpj(java.lang.String cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CNPJ$2);
            }
            target.setStringValue(cnpj);
        }
    }
    
    /**
     * Sets (as xml) the "Cnpj" element
     */
    public void xsetCnpj(br.org.abrasf.nfse.TsCnpj cnpj)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCnpj target = null;
            target = (br.org.abrasf.nfse.TsCnpj)get_store().find_element_user(CNPJ$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCnpj)get_store().add_element_user(CNPJ$2);
            }
            target.set(cnpj);
        }
    }
    
    /**
     * Unsets the "Cnpj" element
     */
    public void unsetCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CNPJ$2, 0);
        }
    }
}
