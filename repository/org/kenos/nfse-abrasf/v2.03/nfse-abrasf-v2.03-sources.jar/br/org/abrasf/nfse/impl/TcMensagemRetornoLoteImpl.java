/*
 * XML Type:  tcMensagemRetornoLote
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcMensagemRetornoLote
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcMensagemRetornoLote(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcMensagemRetornoLoteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcMensagemRetornoLote
{
    private static final long serialVersionUID = 1L;
    
    public TcMensagemRetornoLoteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAORPS$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoRps");
    private static final javax.xml.namespace.QName CODIGO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Codigo");
    private static final javax.xml.namespace.QName MENSAGEM$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Mensagem");
    
    
    /**
     * Gets the "IdentificacaoRps" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps getIdentificacaoRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().find_element_user(IDENTIFICACAORPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "IdentificacaoRps" element
     */
    public void setIdentificacaoRps(br.org.abrasf.nfse.TcIdentificacaoRps identificacaoRps)
    {
        generatedSetterHelperImpl(identificacaoRps, IDENTIFICACAORPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoRps" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoRps addNewIdentificacaoRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoRps target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().add_element_user(IDENTIFICACAORPS$0);
            return target;
        }
    }
    
    /**
     * Gets the "Codigo" element
     */
    public java.lang.String getCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Codigo" element
     */
    public br.org.abrasf.nfse.TsCodigoMensagemAlerta xgetCodigo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().find_element_user(CODIGO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Codigo" element
     */
    public void setCodigo(java.lang.String codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGO$2);
            }
            target.setStringValue(codigo);
        }
    }
    
    /**
     * Sets (as xml) the "Codigo" element
     */
    public void xsetCodigo(br.org.abrasf.nfse.TsCodigoMensagemAlerta codigo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().find_element_user(CODIGO$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMensagemAlerta)get_store().add_element_user(CODIGO$2);
            }
            target.set(codigo);
        }
    }
    
    /**
     * Gets the "Mensagem" element
     */
    public java.lang.String getMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Mensagem" element
     */
    public br.org.abrasf.nfse.TsDescricaoMensagemAlerta xgetMensagem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(MENSAGEM$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Mensagem" element
     */
    public void setMensagem(java.lang.String mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENSAGEM$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MENSAGEM$4);
            }
            target.setStringValue(mensagem);
        }
    }
    
    /**
     * Sets (as xml) the "Mensagem" element
     */
    public void xsetMensagem(br.org.abrasf.nfse.TsDescricaoMensagemAlerta mensagem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDescricaoMensagemAlerta target = null;
            target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().find_element_user(MENSAGEM$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsDescricaoMensagemAlerta)get_store().add_element_user(MENSAGEM$4);
            }
            target.set(mensagem);
        }
    }
}
