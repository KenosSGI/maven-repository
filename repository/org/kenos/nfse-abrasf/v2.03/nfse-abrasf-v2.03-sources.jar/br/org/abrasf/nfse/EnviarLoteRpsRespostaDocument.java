/*
 * An XML document type.
 * Localname: EnviarLoteRpsResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one EnviarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface EnviarLoteRpsRespostaDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EnviarLoteRpsRespostaDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("enviarloterpsresposta1414doctype");
    
    /**
     * Gets the "EnviarLoteRpsResposta" element
     */
    br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta getEnviarLoteRpsResposta();
    
    /**
     * Sets the "EnviarLoteRpsResposta" element
     */
    void setEnviarLoteRpsResposta(br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta enviarLoteRpsResposta);
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsResposta" element
     */
    br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta addNewEnviarLoteRpsResposta();
    
    /**
     * An XML EnviarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface EnviarLoteRpsResposta extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EnviarLoteRpsResposta.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("enviarloterpsrespostaf175elemtype");
        
        /**
         * Gets the "NumeroLote" element
         */
        long getNumeroLote();
        
        /**
         * Gets (as xml) the "NumeroLote" element
         */
        br.org.abrasf.nfse.TsNumeroLote xgetNumeroLote();
        
        /**
         * True if has "NumeroLote" element
         */
        boolean isSetNumeroLote();
        
        /**
         * Sets the "NumeroLote" element
         */
        void setNumeroLote(long numeroLote);
        
        /**
         * Sets (as xml) the "NumeroLote" element
         */
        void xsetNumeroLote(br.org.abrasf.nfse.TsNumeroLote numeroLote);
        
        /**
         * Unsets the "NumeroLote" element
         */
        void unsetNumeroLote();
        
        /**
         * Gets the "DataRecebimento" element
         */
        java.util.Calendar getDataRecebimento();
        
        /**
         * Gets (as xml) the "DataRecebimento" element
         */
        org.apache.xmlbeans.XmlDateTime xgetDataRecebimento();
        
        /**
         * True if has "DataRecebimento" element
         */
        boolean isSetDataRecebimento();
        
        /**
         * Sets the "DataRecebimento" element
         */
        void setDataRecebimento(java.util.Calendar dataRecebimento);
        
        /**
         * Sets (as xml) the "DataRecebimento" element
         */
        void xsetDataRecebimento(org.apache.xmlbeans.XmlDateTime dataRecebimento);
        
        /**
         * Unsets the "DataRecebimento" element
         */
        void unsetDataRecebimento();
        
        /**
         * Gets the "Protocolo" element
         */
        java.lang.String getProtocolo();
        
        /**
         * Gets (as xml) the "Protocolo" element
         */
        br.org.abrasf.nfse.TsNumeroProtocolo xgetProtocolo();
        
        /**
         * True if has "Protocolo" element
         */
        boolean isSetProtocolo();
        
        /**
         * Sets the "Protocolo" element
         */
        void setProtocolo(java.lang.String protocolo);
        
        /**
         * Sets (as xml) the "Protocolo" element
         */
        void xsetProtocolo(br.org.abrasf.nfse.TsNumeroProtocolo protocolo);
        
        /**
         * Unsets the "Protocolo" element
         */
        void unsetProtocolo();
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno();
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        boolean isSetListaMensagemRetorno();
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno();
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        void unsetListaMensagemRetorno();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta newInstance() {
              return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument.EnviarLoteRpsResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument newInstance() {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.EnviarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
