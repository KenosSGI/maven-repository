/*
 * XML Type:  tsStatusNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsStatusNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsStatusNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsStatusNfse.
 */
public class TsStatusNfseImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements br.org.abrasf.nfse.TsStatusNfse
{
    private static final long serialVersionUID = 1L;
    
    public TsStatusNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsStatusNfseImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
