/*
 * XML Type:  tcDadosPrestador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosPrestador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcDadosPrestador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcDadosPrestadorImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcDadosPrestador
{
    private static final long serialVersionUID = 1L;
    
    public TcDadosPrestadorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAOPRESTADOR$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoPrestador");
    private static final javax.xml.namespace.QName RAZAOSOCIAL$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RazaoSocial");
    private static final javax.xml.namespace.QName NOMEFANTASIA$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NomeFantasia");
    private static final javax.xml.namespace.QName ENDERECO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Endereco");
    private static final javax.xml.namespace.QName CONTATO$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Contato");
    
    
    /**
     * Gets the "IdentificacaoPrestador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoPrestador getIdentificacaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(IDENTIFICACAOPRESTADOR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "IdentificacaoPrestador" element
     */
    public void setIdentificacaoPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador identificacaoPrestador)
    {
        generatedSetterHelperImpl(identificacaoPrestador, IDENTIFICACAOPRESTADOR$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoPrestador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewIdentificacaoPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(IDENTIFICACAOPRESTADOR$0);
            return target;
        }
    }
    
    /**
     * Gets the "RazaoSocial" element
     */
    public java.lang.String getRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocial" element
     */
    public br.org.abrasf.nfse.TsRazaoSocial xgetRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "RazaoSocial" element
     */
    public void setRazaoSocial(java.lang.String razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIAL$2);
            }
            target.setStringValue(razaoSocial);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocial" element
     */
    public void xsetRazaoSocial(br.org.abrasf.nfse.TsRazaoSocial razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().add_element_user(RAZAOSOCIAL$2);
            }
            target.set(razaoSocial);
        }
    }
    
    /**
     * Gets the "NomeFantasia" element
     */
    public java.lang.String getNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEFANTASIA$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NomeFantasia" element
     */
    public br.org.abrasf.nfse.TsNomeFantasia xgetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNomeFantasia target = null;
            target = (br.org.abrasf.nfse.TsNomeFantasia)get_store().find_element_user(NOMEFANTASIA$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "NomeFantasia" element
     */
    public boolean isSetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOMEFANTASIA$4) != 0;
        }
    }
    
    /**
     * Sets the "NomeFantasia" element
     */
    public void setNomeFantasia(java.lang.String nomeFantasia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOMEFANTASIA$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOMEFANTASIA$4);
            }
            target.setStringValue(nomeFantasia);
        }
    }
    
    /**
     * Sets (as xml) the "NomeFantasia" element
     */
    public void xsetNomeFantasia(br.org.abrasf.nfse.TsNomeFantasia nomeFantasia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNomeFantasia target = null;
            target = (br.org.abrasf.nfse.TsNomeFantasia)get_store().find_element_user(NOMEFANTASIA$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNomeFantasia)get_store().add_element_user(NOMEFANTASIA$4);
            }
            target.set(nomeFantasia);
        }
    }
    
    /**
     * Unsets the "NomeFantasia" element
     */
    public void unsetNomeFantasia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOMEFANTASIA$4, 0);
        }
    }
    
    /**
     * Gets the "Endereco" element
     */
    public br.org.abrasf.nfse.TcEndereco getEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcEndereco target = null;
            target = (br.org.abrasf.nfse.TcEndereco)get_store().find_element_user(ENDERECO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Endereco" element
     */
    public void setEndereco(br.org.abrasf.nfse.TcEndereco endereco)
    {
        generatedSetterHelperImpl(endereco, ENDERECO$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Endereco" element
     */
    public br.org.abrasf.nfse.TcEndereco addNewEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcEndereco target = null;
            target = (br.org.abrasf.nfse.TcEndereco)get_store().add_element_user(ENDERECO$6);
            return target;
        }
    }
    
    /**
     * Gets the "Contato" element
     */
    public br.org.abrasf.nfse.TcContato getContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcContato target = null;
            target = (br.org.abrasf.nfse.TcContato)get_store().find_element_user(CONTATO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Contato" element
     */
    public boolean isSetContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTATO$8) != 0;
        }
    }
    
    /**
     * Sets the "Contato" element
     */
    public void setContato(br.org.abrasf.nfse.TcContato contato)
    {
        generatedSetterHelperImpl(contato, CONTATO$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Contato" element
     */
    public br.org.abrasf.nfse.TcContato addNewContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcContato target = null;
            target = (br.org.abrasf.nfse.TcContato)get_store().add_element_user(CONTATO$8);
            return target;
        }
    }
    
    /**
     * Unsets the "Contato" element
     */
    public void unsetContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTATO$8, 0);
        }
    }
}
