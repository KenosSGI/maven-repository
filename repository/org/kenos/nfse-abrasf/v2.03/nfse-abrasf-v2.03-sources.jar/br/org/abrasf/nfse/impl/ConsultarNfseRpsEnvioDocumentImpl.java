/*
 * An XML document type.
 * Localname: ConsultarNfseRpsEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarNfseRpsEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarNfseRpsEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarNfseRpsEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARNFSERPSENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarNfseRpsEnvio");
    
    
    /**
     * Gets the "ConsultarNfseRpsEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio getConsultarNfseRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio)get_store().find_element_user(CONSULTARNFSERPSENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarNfseRpsEnvio" element
     */
    public void setConsultarNfseRpsEnvio(br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio consultarNfseRpsEnvio)
    {
        generatedSetterHelperImpl(consultarNfseRpsEnvio, CONSULTARNFSERPSENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarNfseRpsEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio addNewConsultarNfseRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio)get_store().add_element_user(CONSULTARNFSERPSENVIO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarNfseRpsEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarNfseRpsEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseRpsEnvioDocument.ConsultarNfseRpsEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarNfseRpsEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName IDENTIFICACAORPS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoRps");
        private static final javax.xml.namespace.QName PRESTADOR$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Prestador");
        
        
        /**
         * Gets the "IdentificacaoRps" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoRps getIdentificacaoRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoRps target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().find_element_user(IDENTIFICACAORPS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "IdentificacaoRps" element
         */
        public void setIdentificacaoRps(br.org.abrasf.nfse.TcIdentificacaoRps identificacaoRps)
        {
            generatedSetterHelperImpl(identificacaoRps, IDENTIFICACAORPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "IdentificacaoRps" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoRps addNewIdentificacaoRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoRps target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoRps)get_store().add_element_user(IDENTIFICACAORPS$0);
                return target;
            }
        }
        
        /**
         * Gets the "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(PRESTADOR$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Prestador" element
         */
        public void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador)
        {
            generatedSetterHelperImpl(prestador, PRESTADOR$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(PRESTADOR$2);
                return target;
            }
        }
    }
}
