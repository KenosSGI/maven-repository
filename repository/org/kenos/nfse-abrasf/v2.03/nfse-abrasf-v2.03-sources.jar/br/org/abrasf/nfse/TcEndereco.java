/*
 * XML Type:  tcEndereco
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcEndereco
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcEndereco(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcEndereco extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcEndereco.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("tcendereco61f9type");
    
    /**
     * Gets the "Endereco" element
     */
    java.lang.String getEndereco();
    
    /**
     * Gets (as xml) the "Endereco" element
     */
    br.org.abrasf.nfse.TsEndereco xgetEndereco();
    
    /**
     * True if has "Endereco" element
     */
    boolean isSetEndereco();
    
    /**
     * Sets the "Endereco" element
     */
    void setEndereco(java.lang.String endereco);
    
    /**
     * Sets (as xml) the "Endereco" element
     */
    void xsetEndereco(br.org.abrasf.nfse.TsEndereco endereco);
    
    /**
     * Unsets the "Endereco" element
     */
    void unsetEndereco();
    
    /**
     * Gets the "Numero" element
     */
    java.lang.String getNumero();
    
    /**
     * Gets (as xml) the "Numero" element
     */
    br.org.abrasf.nfse.TsNumeroEndereco xgetNumero();
    
    /**
     * True if has "Numero" element
     */
    boolean isSetNumero();
    
    /**
     * Sets the "Numero" element
     */
    void setNumero(java.lang.String numero);
    
    /**
     * Sets (as xml) the "Numero" element
     */
    void xsetNumero(br.org.abrasf.nfse.TsNumeroEndereco numero);
    
    /**
     * Unsets the "Numero" element
     */
    void unsetNumero();
    
    /**
     * Gets the "Complemento" element
     */
    java.lang.String getComplemento();
    
    /**
     * Gets (as xml) the "Complemento" element
     */
    br.org.abrasf.nfse.TsComplementoEndereco xgetComplemento();
    
    /**
     * True if has "Complemento" element
     */
    boolean isSetComplemento();
    
    /**
     * Sets the "Complemento" element
     */
    void setComplemento(java.lang.String complemento);
    
    /**
     * Sets (as xml) the "Complemento" element
     */
    void xsetComplemento(br.org.abrasf.nfse.TsComplementoEndereco complemento);
    
    /**
     * Unsets the "Complemento" element
     */
    void unsetComplemento();
    
    /**
     * Gets the "Bairro" element
     */
    java.lang.String getBairro();
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    br.org.abrasf.nfse.TsBairro xgetBairro();
    
    /**
     * True if has "Bairro" element
     */
    boolean isSetBairro();
    
    /**
     * Sets the "Bairro" element
     */
    void setBairro(java.lang.String bairro);
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    void xsetBairro(br.org.abrasf.nfse.TsBairro bairro);
    
    /**
     * Unsets the "Bairro" element
     */
    void unsetBairro();
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    int getCodigoMunicipio();
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio();
    
    /**
     * True if has "CodigoMunicipio" element
     */
    boolean isSetCodigoMunicipio();
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    void setCodigoMunicipio(int codigoMunicipio);
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio);
    
    /**
     * Unsets the "CodigoMunicipio" element
     */
    void unsetCodigoMunicipio();
    
    /**
     * Gets the "Uf" element
     */
    br.org.abrasf.nfse.TsUf.Enum getUf();
    
    /**
     * Gets (as xml) the "Uf" element
     */
    br.org.abrasf.nfse.TsUf xgetUf();
    
    /**
     * True if has "Uf" element
     */
    boolean isSetUf();
    
    /**
     * Sets the "Uf" element
     */
    void setUf(br.org.abrasf.nfse.TsUf.Enum uf);
    
    /**
     * Sets (as xml) the "Uf" element
     */
    void xsetUf(br.org.abrasf.nfse.TsUf uf);
    
    /**
     * Unsets the "Uf" element
     */
    void unsetUf();
    
    /**
     * Gets the "CodigoPais" element
     */
    java.lang.String getCodigoPais();
    
    /**
     * Gets (as xml) the "CodigoPais" element
     */
    br.org.abrasf.nfse.TsCodigoPaisBacen xgetCodigoPais();
    
    /**
     * True if has "CodigoPais" element
     */
    boolean isSetCodigoPais();
    
    /**
     * Sets the "CodigoPais" element
     */
    void setCodigoPais(java.lang.String codigoPais);
    
    /**
     * Sets (as xml) the "CodigoPais" element
     */
    void xsetCodigoPais(br.org.abrasf.nfse.TsCodigoPaisBacen codigoPais);
    
    /**
     * Unsets the "CodigoPais" element
     */
    void unsetCodigoPais();
    
    /**
     * Gets the "Cep" element
     */
    java.lang.String getCep();
    
    /**
     * Gets (as xml) the "Cep" element
     */
    br.org.abrasf.nfse.TsCep xgetCep();
    
    /**
     * True if has "Cep" element
     */
    boolean isSetCep();
    
    /**
     * Sets the "Cep" element
     */
    void setCep(java.lang.String cep);
    
    /**
     * Sets (as xml) the "Cep" element
     */
    void xsetCep(br.org.abrasf.nfse.TsCep cep);
    
    /**
     * Unsets the "Cep" element
     */
    void unsetCep();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcEndereco newInstance() {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcEndereco parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcEndereco parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcEndereco parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcEndereco parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcEndereco) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
