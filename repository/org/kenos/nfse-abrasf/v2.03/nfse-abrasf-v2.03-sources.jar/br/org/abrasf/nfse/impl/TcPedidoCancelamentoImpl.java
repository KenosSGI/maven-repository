/*
 * XML Type:  tcPedidoCancelamento
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcPedidoCancelamento
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcPedidoCancelamento(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcPedidoCancelamentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcPedidoCancelamento
{
    private static final long serialVersionUID = 1L;
    
    public TcPedidoCancelamentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INFPEDIDOCANCELAMENTO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "InfPedidoCancelamento");
    private static final javax.xml.namespace.QName SIGNATURE$2 = 
        new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
    
    
    /**
     * Gets the "InfPedidoCancelamento" element
     */
    public br.org.abrasf.nfse.TcInfPedidoCancelamento getInfPedidoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfPedidoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcInfPedidoCancelamento)get_store().find_element_user(INFPEDIDOCANCELAMENTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "InfPedidoCancelamento" element
     */
    public void setInfPedidoCancelamento(br.org.abrasf.nfse.TcInfPedidoCancelamento infPedidoCancelamento)
    {
        generatedSetterHelperImpl(infPedidoCancelamento, INFPEDIDOCANCELAMENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "InfPedidoCancelamento" element
     */
    public br.org.abrasf.nfse.TcInfPedidoCancelamento addNewInfPedidoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfPedidoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcInfPedidoCancelamento)get_store().add_element_user(INFPEDIDOCANCELAMENTO$0);
            return target;
        }
    }
    
    /**
     * Gets the "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Signature" element
     */
    public boolean isSetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATURE$2) != 0;
        }
    }
    
    /**
     * Sets the "Signature" element
     */
    public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
    {
        generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "Signature" element
     */
    public void unsetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATURE$2, 0);
        }
    }
}
