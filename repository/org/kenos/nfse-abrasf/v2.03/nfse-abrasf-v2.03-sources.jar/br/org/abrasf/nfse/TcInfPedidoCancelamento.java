/*
 * XML Type:  tcInfPedidoCancelamento
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfPedidoCancelamento
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcInfPedidoCancelamento(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcInfPedidoCancelamento extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcInfPedidoCancelamento.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcinfpedidocancelamento69b0type");
    
    /**
     * Gets the "IdentificacaoNfse" element
     */
    br.org.abrasf.nfse.TcIdentificacaoNfse getIdentificacaoNfse();
    
    /**
     * Sets the "IdentificacaoNfse" element
     */
    void setIdentificacaoNfse(br.org.abrasf.nfse.TcIdentificacaoNfse identificacaoNfse);
    
    /**
     * Appends and returns a new empty "IdentificacaoNfse" element
     */
    br.org.abrasf.nfse.TcIdentificacaoNfse addNewIdentificacaoNfse();
    
    /**
     * Gets the "CodigoCancelamento" element
     */
    byte getCodigoCancelamento();
    
    /**
     * Gets (as xml) the "CodigoCancelamento" element
     */
    br.org.abrasf.nfse.TsCodigoCancelamentoNfse xgetCodigoCancelamento();
    
    /**
     * True if has "CodigoCancelamento" element
     */
    boolean isSetCodigoCancelamento();
    
    /**
     * Sets the "CodigoCancelamento" element
     */
    void setCodigoCancelamento(byte codigoCancelamento);
    
    /**
     * Sets (as xml) the "CodigoCancelamento" element
     */
    void xsetCodigoCancelamento(br.org.abrasf.nfse.TsCodigoCancelamentoNfse codigoCancelamento);
    
    /**
     * Unsets the "CodigoCancelamento" element
     */
    void unsetCodigoCancelamento();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    br.org.abrasf.nfse.TsIdTag xgetId();
    
    /**
     * True if has "Id" attribute
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(br.org.abrasf.nfse.TsIdTag id);
    
    /**
     * Unsets the "Id" attribute
     */
    void unsetId();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento newInstance() {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfPedidoCancelamento parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfPedidoCancelamento) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
