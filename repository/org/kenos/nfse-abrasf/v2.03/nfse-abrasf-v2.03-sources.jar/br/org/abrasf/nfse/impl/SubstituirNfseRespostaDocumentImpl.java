/*
 * An XML document type.
 * Localname: SubstituirNfseResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.SubstituirNfseRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one SubstituirNfseResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class SubstituirNfseRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public SubstituirNfseRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSTITUIRNFSERESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "SubstituirNfseResposta");
    
    
    /**
     * Gets the "SubstituirNfseResposta" element
     */
    public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta getSubstituirNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta target = null;
            target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta)get_store().find_element_user(SUBSTITUIRNFSERESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "SubstituirNfseResposta" element
     */
    public void setSubstituirNfseResposta(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta substituirNfseResposta)
    {
        generatedSetterHelperImpl(substituirNfseResposta, SUBSTITUIRNFSERESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "SubstituirNfseResposta" element
     */
    public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta addNewSubstituirNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta target = null;
            target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta)get_store().add_element_user(SUBSTITUIRNFSERESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML SubstituirNfseResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class SubstituirNfseRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta
    {
        private static final long serialVersionUID = 1L;
        
        public SubstituirNfseRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RETSUBSTITUICAO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RetSubstituicao");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "RetSubstituicao" element
         */
        public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao getRetSubstituicao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao target = null;
                target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao)get_store().find_element_user(RETSUBSTITUICAO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "RetSubstituicao" element
         */
        public boolean isSetRetSubstituicao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RETSUBSTITUICAO$0) != 0;
            }
        }
        
        /**
         * Sets the "RetSubstituicao" element
         */
        public void setRetSubstituicao(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao retSubstituicao)
        {
            generatedSetterHelperImpl(retSubstituicao, RETSUBSTITUICAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "RetSubstituicao" element
         */
        public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao addNewRetSubstituicao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao target = null;
                target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao)get_store().add_element_user(RETSUBSTITUICAO$0);
                return target;
            }
        }
        
        /**
         * Unsets the "RetSubstituicao" element
         */
        public void unsetRetSubstituicao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RETSUBSTITUICAO$0, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$2, 0);
            }
        }
        /**
         * An XML RetSubstituicao(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class RetSubstituicaoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao
        {
            private static final long serialVersionUID = 1L;
            
            public RetSubstituicaoImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName NFSESUBSTITUIDA$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseSubstituida");
            private static final javax.xml.namespace.QName NFSESUBSTITUIDORA$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseSubstituidora");
            
            
            /**
             * Gets the "NfseSubstituida" element
             */
            public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida getNfseSubstituida()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida target = null;
                    target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida)get_store().find_element_user(NFSESUBSTITUIDA$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "NfseSubstituida" element
             */
            public void setNfseSubstituida(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida nfseSubstituida)
            {
                generatedSetterHelperImpl(nfseSubstituida, NFSESUBSTITUIDA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "NfseSubstituida" element
             */
            public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida addNewNfseSubstituida()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida target = null;
                    target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida)get_store().add_element_user(NFSESUBSTITUIDA$0);
                    return target;
                }
            }
            
            /**
             * Gets the "NfseSubstituidora" element
             */
            public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora getNfseSubstituidora()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora target = null;
                    target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora)get_store().find_element_user(NFSESUBSTITUIDORA$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "NfseSubstituidora" element
             */
            public void setNfseSubstituidora(br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora nfseSubstituidora)
            {
                generatedSetterHelperImpl(nfseSubstituidora, NFSESUBSTITUIDORA$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "NfseSubstituidora" element
             */
            public br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora addNewNfseSubstituidora()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora target = null;
                    target = (br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora)get_store().add_element_user(NFSESUBSTITUIDORA$2);
                    return target;
                }
            }
            /**
             * An XML NfseSubstituida(@http://www.abrasf.org.br/nfse.xsd).
             *
             * This is a complex type.
             */
            public static class NfseSubstituidaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituida
            {
                private static final long serialVersionUID = 1L;
                
                public NfseSubstituidaImpl(org.apache.xmlbeans.SchemaType sType)
                {
                    super(sType);
                }
                
                private static final javax.xml.namespace.QName COMPNFSE$0 = 
                    new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
                private static final javax.xml.namespace.QName LISTAMENSAGEMALERTARETORNO$2 = 
                    new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemAlertaRetorno");
                
                
                /**
                 * Gets the "CompNfse" element
                 */
                public br.org.abrasf.nfse.TcCompNfse getCompNfse()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.TcCompNfse target = null;
                      target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, 0);
                      if (target == null)
                      {
                        return null;
                      }
                      return target;
                    }
                }
                
                /**
                 * Sets the "CompNfse" element
                 */
                public void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse)
                {
                    generatedSetterHelperImpl(compNfse, COMPNFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
                }
                
                /**
                 * Appends and returns a new empty "CompNfse" element
                 */
                public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.TcCompNfse target = null;
                      target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                      return target;
                    }
                }
                
                /**
                 * Gets the "ListaMensagemAlertaRetorno" element
                 */
                public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                      target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().find_element_user(LISTAMENSAGEMALERTARETORNO$2, 0);
                      if (target == null)
                      {
                        return null;
                      }
                      return target;
                    }
                }
                
                /**
                 * True if has "ListaMensagemAlertaRetorno" element
                 */
                public boolean isSetListaMensagemAlertaRetorno()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      return get_store().count_elements(LISTAMENSAGEMALERTARETORNO$2) != 0;
                    }
                }
                
                /**
                 * Sets the "ListaMensagemAlertaRetorno" element
                 */
                public void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno)
                {
                    generatedSetterHelperImpl(listaMensagemAlertaRetorno, LISTAMENSAGEMALERTARETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
                }
                
                /**
                 * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
                 */
                public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                      target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().add_element_user(LISTAMENSAGEMALERTARETORNO$2);
                      return target;
                    }
                }
                
                /**
                 * Unsets the "ListaMensagemAlertaRetorno" element
                 */
                public void unsetListaMensagemAlertaRetorno()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      get_store().remove_element(LISTAMENSAGEMALERTARETORNO$2, 0);
                    }
                }
            }
            /**
             * An XML NfseSubstituidora(@http://www.abrasf.org.br/nfse.xsd).
             *
             * This is a complex type.
             */
            public static class NfseSubstituidoraImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseRespostaDocument.SubstituirNfseResposta.RetSubstituicao.NfseSubstituidora
            {
                private static final long serialVersionUID = 1L;
                
                public NfseSubstituidoraImpl(org.apache.xmlbeans.SchemaType sType)
                {
                    super(sType);
                }
                
                private static final javax.xml.namespace.QName COMPNFSE$0 = 
                    new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
                
                
                /**
                 * Gets the "CompNfse" element
                 */
                public br.org.abrasf.nfse.TcCompNfse getCompNfse()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.TcCompNfse target = null;
                      target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, 0);
                      if (target == null)
                      {
                        return null;
                      }
                      return target;
                    }
                }
                
                /**
                 * Sets the "CompNfse" element
                 */
                public void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse)
                {
                    generatedSetterHelperImpl(compNfse, COMPNFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
                }
                
                /**
                 * Appends and returns a new empty "CompNfse" element
                 */
                public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      br.org.abrasf.nfse.TcCompNfse target = null;
                      target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                      return target;
                    }
                }
            }
        }
    }
}
