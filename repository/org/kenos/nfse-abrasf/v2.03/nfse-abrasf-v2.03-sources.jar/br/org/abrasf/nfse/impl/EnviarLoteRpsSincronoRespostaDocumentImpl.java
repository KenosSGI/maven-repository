/*
 * An XML document type.
 * Localname: EnviarLoteRpsSincronoResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one EnviarLoteRpsSincronoResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class EnviarLoteRpsSincronoRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarLoteRpsSincronoRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARLOTERPSSINCRONORESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "EnviarLoteRpsSincronoResposta");
    
    
    /**
     * Gets the "EnviarLoteRpsSincronoResposta" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta getEnviarLoteRpsSincronoResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta)get_store().find_element_user(ENVIARLOTERPSSINCRONORESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarLoteRpsSincronoResposta" element
     */
    public void setEnviarLoteRpsSincronoResposta(br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta enviarLoteRpsSincronoResposta)
    {
        generatedSetterHelperImpl(enviarLoteRpsSincronoResposta, ENVIARLOTERPSSINCRONORESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsSincronoResposta" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta addNewEnviarLoteRpsSincronoResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta)get_store().add_element_user(ENVIARLOTERPSSINCRONORESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML EnviarLoteRpsSincronoResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class EnviarLoteRpsSincronoRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarLoteRpsSincronoRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NUMEROLOTE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroLote");
        private static final javax.xml.namespace.QName DATARECEBIMENTO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataRecebimento");
        private static final javax.xml.namespace.QName PROTOCOLO$4 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Protocolo");
        private static final javax.xml.namespace.QName LISTANFSE$6 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaNfse");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$8 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNOLOTE$10 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetornoLote");
        
        
        /**
         * Gets the "NumeroLote" element
         */
        public long getNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "NumeroLote" element
         */
        public br.org.abrasf.nfse.TsNumeroLote xgetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroLote target = null;
                target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "NumeroLote" element
         */
        public boolean isSetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NUMEROLOTE$0) != 0;
            }
        }
        
        /**
         * Sets the "NumeroLote" element
         */
        public void setNumeroLote(long numeroLote)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROLOTE$0);
                }
                target.setLongValue(numeroLote);
            }
        }
        
        /**
         * Sets (as xml) the "NumeroLote" element
         */
        public void xsetNumeroLote(br.org.abrasf.nfse.TsNumeroLote numeroLote)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroLote target = null;
                target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroLote)get_store().add_element_user(NUMEROLOTE$0);
                }
                target.set(numeroLote);
            }
        }
        
        /**
         * Unsets the "NumeroLote" element
         */
        public void unsetNumeroLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NUMEROLOTE$0, 0);
            }
        }
        
        /**
         * Gets the "DataRecebimento" element
         */
        public java.util.Calendar getDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "DataRecebimento" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "DataRecebimento" element
         */
        public boolean isSetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DATARECEBIMENTO$2) != 0;
            }
        }
        
        /**
         * Sets the "DataRecebimento" element
         */
        public void setDataRecebimento(java.util.Calendar dataRecebimento)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATARECEBIMENTO$2);
                }
                target.setCalendarValue(dataRecebimento);
            }
        }
        
        /**
         * Sets (as xml) the "DataRecebimento" element
         */
        public void xsetDataRecebimento(org.apache.xmlbeans.XmlDateTime dataRecebimento)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATARECEBIMENTO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATARECEBIMENTO$2);
                }
                target.set(dataRecebimento);
            }
        }
        
        /**
         * Unsets the "DataRecebimento" element
         */
        public void unsetDataRecebimento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DATARECEBIMENTO$2, 0);
            }
        }
        
        /**
         * Gets the "Protocolo" element
         */
        public java.lang.String getProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "Protocolo" element
         */
        public br.org.abrasf.nfse.TsNumeroProtocolo xgetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "Protocolo" element
         */
        public boolean isSetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PROTOCOLO$4) != 0;
            }
        }
        
        /**
         * Sets the "Protocolo" element
         */
        public void setProtocolo(java.lang.String protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLO$4);
                }
                target.setStringValue(protocolo);
            }
        }
        
        /**
         * Sets (as xml) the "Protocolo" element
         */
        public void xsetProtocolo(br.org.abrasf.nfse.TsNumeroProtocolo protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$4, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().add_element_user(PROTOCOLO$4);
                }
                target.set(protocolo);
            }
        }
        
        /**
         * Unsets the "Protocolo" element
         */
        public void unsetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PROTOCOLO$4, 0);
            }
        }
        
        /**
         * Gets the "ListaNfse" element
         */
        public br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse getListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse)get_store().find_element_user(LISTANFSE$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaNfse" element
         */
        public boolean isSetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTANFSE$6) != 0;
            }
        }
        
        /**
         * Sets the "ListaNfse" element
         */
        public void setListaNfse(br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse listaNfse)
        {
            generatedSetterHelperImpl(listaNfse, LISTANFSE$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        public br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse addNewListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse)get_store().add_element_user(LISTANFSE$6);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaNfse" element
         */
        public void unsetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTANFSE$6, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$8, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$8) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$8);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$8, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetornoLote" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote getListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().find_element_user(LISTAMENSAGEMRETORNOLOTE$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetornoLote" element
         */
        public boolean isSetListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNOLOTE$10) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetornoLote" element
         */
        public void setListaMensagemRetornoLote(br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote listaMensagemRetornoLote)
        {
            generatedSetterHelperImpl(listaMensagemRetornoLote, LISTAMENSAGEMRETORNOLOTE$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetornoLote" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote addNewListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().add_element_user(LISTAMENSAGEMRETORNOLOTE$10);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetornoLote" element
         */
        public void unsetListaMensagemRetornoLote()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNOLOTE$10, 0);
            }
        }
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class ListaNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsSincronoRespostaDocument.EnviarLoteRpsSincronoResposta.ListaNfse
        {
            private static final long serialVersionUID = 1L;
            
            public ListaNfseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName COMPNFSE$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
            private static final javax.xml.namespace.QName LISTAMENSAGEMALERTARETORNO$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemAlertaRetorno");
            
            
            /**
             * Gets array of all "CompNfse" elements
             */
            public br.org.abrasf.nfse.TcCompNfse[] getCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(COMPNFSE$0, targetList);
                    br.org.abrasf.nfse.TcCompNfse[] result = new br.org.abrasf.nfse.TcCompNfse[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse getCompNfseArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "CompNfse" element
             */
            public int sizeOfCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(COMPNFSE$0);
                }
            }
            
            /**
             * Sets array of all "CompNfse" element  WARNING: This method is not atomicaly synchronized.
             */
            public void setCompNfseArray(br.org.abrasf.nfse.TcCompNfse[] compNfseArray)
            {
                check_orphaned();
                arraySetterHelper(compNfseArray, COMPNFSE$0);
            }
            
            /**
             * Sets ith "CompNfse" element
             */
            public void setCompNfseArray(int i, br.org.abrasf.nfse.TcCompNfse compNfse)
            {
                generatedSetterHelperImpl(compNfse, COMPNFSE$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse insertNewCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().insert_element_user(COMPNFSE$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "CompNfse" element
             */
            public void removeCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(COMPNFSE$0, i);
                }
            }
            
            /**
             * Gets the "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().find_element_user(LISTAMENSAGEMALERTARETORNO$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "ListaMensagemAlertaRetorno" element
             */
            public boolean isSetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(LISTAMENSAGEMALERTARETORNO$2) != 0;
                }
            }
            
            /**
             * Sets the "ListaMensagemAlertaRetorno" element
             */
            public void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno)
            {
                generatedSetterHelperImpl(listaMensagemAlertaRetorno, LISTAMENSAGEMALERTARETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().add_element_user(LISTAMENSAGEMALERTARETORNO$2);
                    return target;
                }
            }
            
            /**
             * Unsets the "ListaMensagemAlertaRetorno" element
             */
            public void unsetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(LISTAMENSAGEMALERTARETORNO$2, 0);
                }
            }
        }
    }
}
