/*
 * An XML document type.
 * Localname: CompNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.CompNfseDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one CompNfse(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class CompNfseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CompNfseDocument
{
    private static final long serialVersionUID = 1L;
    
    public CompNfseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMPNFSE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
    
    
    /**
     * Gets the "CompNfse" element
     */
    public br.org.abrasf.nfse.TcCompNfse getCompNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCompNfse target = null;
            target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CompNfse" element
     */
    public void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse)
    {
        generatedSetterHelperImpl(compNfse, COMPNFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CompNfse" element
     */
    public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCompNfse target = null;
            target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
            return target;
        }
    }
}
