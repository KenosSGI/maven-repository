/*
 * An XML document type.
 * Localname: ConsultarLoteRpsResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarLoteRpsRespostaDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarLoteRpsRespostaDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarloterpsrespostacb56doctype");
    
    /**
     * Gets the "ConsultarLoteRpsResposta" element
     */
    br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta getConsultarLoteRpsResposta();
    
    /**
     * Sets the "ConsultarLoteRpsResposta" element
     */
    void setConsultarLoteRpsResposta(br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta consultarLoteRpsResposta);
    
    /**
     * Appends and returns a new empty "ConsultarLoteRpsResposta" element
     */
    br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta addNewConsultarLoteRpsResposta();
    
    /**
     * An XML ConsultarLoteRpsResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarLoteRpsResposta extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarLoteRpsResposta.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarloterpsresposta68b5elemtype");
        
        /**
         * Gets the "Situacao" element
         */
        byte getSituacao();
        
        /**
         * Gets (as xml) the "Situacao" element
         */
        br.org.abrasf.nfse.TsSituacaoLoteRps xgetSituacao();
        
        /**
         * Sets the "Situacao" element
         */
        void setSituacao(byte situacao);
        
        /**
         * Sets (as xml) the "Situacao" element
         */
        void xsetSituacao(br.org.abrasf.nfse.TsSituacaoLoteRps situacao);
        
        /**
         * Gets the "ListaNfse" element
         */
        br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse getListaNfse();
        
        /**
         * True if has "ListaNfse" element
         */
        boolean isSetListaNfse();
        
        /**
         * Sets the "ListaNfse" element
         */
        void setListaNfse(br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse listaNfse);
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse addNewListaNfse();
        
        /**
         * Unsets the "ListaNfse" element
         */
        void unsetListaNfse();
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno();
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        boolean isSetListaMensagemRetorno();
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno();
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        void unsetListaMensagemRetorno();
        
        /**
         * Gets the "ListaMensagemRetornoLote" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote getListaMensagemRetornoLote();
        
        /**
         * True if has "ListaMensagemRetornoLote" element
         */
        boolean isSetListaMensagemRetornoLote();
        
        /**
         * Sets the "ListaMensagemRetornoLote" element
         */
        void setListaMensagemRetornoLote(br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote listaMensagemRetornoLote);
        
        /**
         * Appends and returns a new empty "ListaMensagemRetornoLote" element
         */
        br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote addNewListaMensagemRetornoLote();
        
        /**
         * Unsets the "ListaMensagemRetornoLote" element
         */
        void unsetListaMensagemRetornoLote();
        
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface ListaNfse extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("listanfseb42eelemtype");
            
            /**
             * Gets array of all "CompNfse" elements
             */
            br.org.abrasf.nfse.TcCompNfse[] getCompNfseArray();
            
            /**
             * Gets ith "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse getCompNfseArray(int i);
            
            /**
             * Returns number of "CompNfse" element
             */
            int sizeOfCompNfseArray();
            
            /**
             * Sets array of all "CompNfse" element
             */
            void setCompNfseArray(br.org.abrasf.nfse.TcCompNfse[] compNfseArray);
            
            /**
             * Sets ith "CompNfse" element
             */
            void setCompNfseArray(int i, br.org.abrasf.nfse.TcCompNfse compNfse);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse insertNewCompNfse(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "CompNfse" element
             */
            br.org.abrasf.nfse.TcCompNfse addNewCompNfse();
            
            /**
             * Removes the ith "CompNfse" element
             */
            void removeCompNfse(int i);
            
            /**
             * Gets the "ListaMensagemAlertaRetorno" element
             */
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno();
            
            /**
             * True if has "ListaMensagemAlertaRetorno" element
             */
            boolean isSetListaMensagemAlertaRetorno();
            
            /**
             * Sets the "ListaMensagemAlertaRetorno" element
             */
            void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno);
            
            /**
             * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
             */
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno();
            
            /**
             * Unsets the "ListaMensagemAlertaRetorno" element
             */
            void unsetListaMensagemAlertaRetorno();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse newInstance() {
                  return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta.ListaNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta newInstance() {
              return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument.ConsultarLoteRpsResposta) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsRespostaDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
