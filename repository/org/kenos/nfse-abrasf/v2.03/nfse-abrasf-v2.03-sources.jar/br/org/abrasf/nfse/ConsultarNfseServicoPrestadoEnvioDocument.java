/*
 * An XML document type.
 * Localname: ConsultarNfseServicoPrestadoEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarNfseServicoPrestadoEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarNfseServicoPrestadoEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoPrestadoEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfseservicoprestadoenvio2472doctype");
    
    /**
     * Gets the "ConsultarNfseServicoPrestadoEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio getConsultarNfseServicoPrestadoEnvio();
    
    /**
     * Sets the "ConsultarNfseServicoPrestadoEnvio" element
     */
    void setConsultarNfseServicoPrestadoEnvio(br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio consultarNfseServicoPrestadoEnvio);
    
    /**
     * Appends and returns a new empty "ConsultarNfseServicoPrestadoEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio addNewConsultarNfseServicoPrestadoEnvio();
    
    /**
     * An XML ConsultarNfseServicoPrestadoEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarNfseServicoPrestadoEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoPrestadoEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfseservicoprestadoenviof831elemtype");
        
        /**
         * Gets the "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador();
        
        /**
         * Sets the "Prestador" element
         */
        void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador);
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador();
        
        /**
         * Gets the "NumeroNfse" element
         */
        long getNumeroNfse();
        
        /**
         * Gets (as xml) the "NumeroNfse" element
         */
        br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfse();
        
        /**
         * True if has "NumeroNfse" element
         */
        boolean isSetNumeroNfse();
        
        /**
         * Sets the "NumeroNfse" element
         */
        void setNumeroNfse(long numeroNfse);
        
        /**
         * Sets (as xml) the "NumeroNfse" element
         */
        void xsetNumeroNfse(br.org.abrasf.nfse.TsNumeroNfse numeroNfse);
        
        /**
         * Unsets the "NumeroNfse" element
         */
        void unsetNumeroNfse();
        
        /**
         * Gets the "PeriodoEmissao" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao getPeriodoEmissao();
        
        /**
         * True if has "PeriodoEmissao" element
         */
        boolean isSetPeriodoEmissao();
        
        /**
         * Sets the "PeriodoEmissao" element
         */
        void setPeriodoEmissao(br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao periodoEmissao);
        
        /**
         * Appends and returns a new empty "PeriodoEmissao" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao addNewPeriodoEmissao();
        
        /**
         * Unsets the "PeriodoEmissao" element
         */
        void unsetPeriodoEmissao();
        
        /**
         * Gets the "PeriodoCompetencia" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia getPeriodoCompetencia();
        
        /**
         * True if has "PeriodoCompetencia" element
         */
        boolean isSetPeriodoCompetencia();
        
        /**
         * Sets the "PeriodoCompetencia" element
         */
        void setPeriodoCompetencia(br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia periodoCompetencia);
        
        /**
         * Appends and returns a new empty "PeriodoCompetencia" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia addNewPeriodoCompetencia();
        
        /**
         * Unsets the "PeriodoCompetencia" element
         */
        void unsetPeriodoCompetencia();
        
        /**
         * Gets the "Tomador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoTomador getTomador();
        
        /**
         * True if has "Tomador" element
         */
        boolean isSetTomador();
        
        /**
         * Sets the "Tomador" element
         */
        void setTomador(br.org.abrasf.nfse.TcIdentificacaoTomador tomador);
        
        /**
         * Appends and returns a new empty "Tomador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoTomador addNewTomador();
        
        /**
         * Unsets the "Tomador" element
         */
        void unsetTomador();
        
        /**
         * Gets the "Intermediario" element
         */
        br.org.abrasf.nfse.TcIdentificacaoIntermediario getIntermediario();
        
        /**
         * True if has "Intermediario" element
         */
        boolean isSetIntermediario();
        
        /**
         * Sets the "Intermediario" element
         */
        void setIntermediario(br.org.abrasf.nfse.TcIdentificacaoIntermediario intermediario);
        
        /**
         * Appends and returns a new empty "Intermediario" element
         */
        br.org.abrasf.nfse.TcIdentificacaoIntermediario addNewIntermediario();
        
        /**
         * Unsets the "Intermediario" element
         */
        void unsetIntermediario();
        
        /**
         * Gets the "Pagina" element
         */
        int getPagina();
        
        /**
         * Gets (as xml) the "Pagina" element
         */
        br.org.abrasf.nfse.TsPagina xgetPagina();
        
        /**
         * Sets the "Pagina" element
         */
        void setPagina(int pagina);
        
        /**
         * Sets (as xml) the "Pagina" element
         */
        void xsetPagina(br.org.abrasf.nfse.TsPagina pagina);
        
        /**
         * An XML PeriodoEmissao(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface PeriodoEmissao extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PeriodoEmissao.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("periodoemissao0aceelemtype");
            
            /**
             * Gets the "DataInicial" element
             */
            java.util.Calendar getDataInicial();
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            org.apache.xmlbeans.XmlDate xgetDataInicial();
            
            /**
             * Sets the "DataInicial" element
             */
            void setDataInicial(java.util.Calendar dataInicial);
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial);
            
            /**
             * Gets the "DataFinal" element
             */
            java.util.Calendar getDataFinal();
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            org.apache.xmlbeans.XmlDate xgetDataFinal();
            
            /**
             * Sets the "DataFinal" element
             */
            void setDataFinal(java.util.Calendar dataFinal);
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoEmissao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * An XML PeriodoCompetencia(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface PeriodoCompetencia extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PeriodoCompetencia.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("periodocompetencia9ef3elemtype");
            
            /**
             * Gets the "DataInicial" element
             */
            java.util.Calendar getDataInicial();
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            org.apache.xmlbeans.XmlDate xgetDataInicial();
            
            /**
             * Sets the "DataInicial" element
             */
            void setDataInicial(java.util.Calendar dataInicial);
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial);
            
            /**
             * Gets the "DataFinal" element
             */
            java.util.Calendar getDataFinal();
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            org.apache.xmlbeans.XmlDate xgetDataFinal();
            
            /**
             * Sets the "DataFinal" element
             */
            void setDataFinal(java.util.Calendar dataFinal);
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio.PeriodoCompetencia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio newInstance() {
              return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument.ConsultarNfseServicoPrestadoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
