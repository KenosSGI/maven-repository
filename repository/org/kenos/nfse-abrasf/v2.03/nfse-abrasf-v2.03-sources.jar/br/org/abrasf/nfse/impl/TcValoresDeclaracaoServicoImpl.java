/*
 * XML Type:  tcValoresDeclaracaoServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcValoresDeclaracaoServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcValoresDeclaracaoServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcValoresDeclaracaoServicoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcValoresDeclaracaoServico
{
    private static final long serialVersionUID = 1L;
    
    public TcValoresDeclaracaoServicoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALORSERVICOS$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorServicos");
    private static final javax.xml.namespace.QName VALORDEDUCOES$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorDeducoes");
    private static final javax.xml.namespace.QName VALORPIS$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorPis");
    private static final javax.xml.namespace.QName VALORCOFINS$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorCofins");
    private static final javax.xml.namespace.QName VALORINSS$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorInss");
    private static final javax.xml.namespace.QName VALORIR$10 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorIr");
    private static final javax.xml.namespace.QName VALORCSLL$12 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorCsll");
    private static final javax.xml.namespace.QName OUTRASRETENCOES$14 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "OutrasRetencoes");
    private static final javax.xml.namespace.QName VALTOTTRIBUTOS$16 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValTotTributos");
    private static final javax.xml.namespace.QName VALORISS$18 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorIss");
    private static final javax.xml.namespace.QName ALIQUOTA$20 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Aliquota");
    private static final javax.xml.namespace.QName DESCONTOINCONDICIONADO$22 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DescontoIncondicionado");
    private static final javax.xml.namespace.QName DESCONTOCONDICIONADO$24 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DescontoCondicionado");
    
    
    /**
     * Gets the "ValorServicos" element
     */
    public java.math.BigDecimal getValorServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORSERVICOS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorServicos" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorServicos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORSERVICOS$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ValorServicos" element
     */
    public void setValorServicos(java.math.BigDecimal valorServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORSERVICOS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORSERVICOS$0);
            }
            target.setBigDecimalValue(valorServicos);
        }
    }
    
    /**
     * Sets (as xml) the "ValorServicos" element
     */
    public void xsetValorServicos(br.org.abrasf.nfse.TsValor valorServicos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORSERVICOS$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORSERVICOS$0);
            }
            target.set(valorServicos);
        }
    }
    
    /**
     * Gets the "ValorDeducoes" element
     */
    public java.math.BigDecimal getValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORDEDUCOES$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorDeducoes" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORDEDUCOES$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorDeducoes" element
     */
    public boolean isSetValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORDEDUCOES$2) != 0;
        }
    }
    
    /**
     * Sets the "ValorDeducoes" element
     */
    public void setValorDeducoes(java.math.BigDecimal valorDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORDEDUCOES$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORDEDUCOES$2);
            }
            target.setBigDecimalValue(valorDeducoes);
        }
    }
    
    /**
     * Sets (as xml) the "ValorDeducoes" element
     */
    public void xsetValorDeducoes(br.org.abrasf.nfse.TsValor valorDeducoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORDEDUCOES$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORDEDUCOES$2);
            }
            target.set(valorDeducoes);
        }
    }
    
    /**
     * Unsets the "ValorDeducoes" element
     */
    public void unsetValorDeducoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORDEDUCOES$2, 0);
        }
    }
    
    /**
     * Gets the "ValorPis" element
     */
    public java.math.BigDecimal getValorPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORPIS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorPis" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORPIS$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorPis" element
     */
    public boolean isSetValorPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORPIS$4) != 0;
        }
    }
    
    /**
     * Sets the "ValorPis" element
     */
    public void setValorPis(java.math.BigDecimal valorPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORPIS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORPIS$4);
            }
            target.setBigDecimalValue(valorPis);
        }
    }
    
    /**
     * Sets (as xml) the "ValorPis" element
     */
    public void xsetValorPis(br.org.abrasf.nfse.TsValor valorPis)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORPIS$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORPIS$4);
            }
            target.set(valorPis);
        }
    }
    
    /**
     * Unsets the "ValorPis" element
     */
    public void unsetValorPis()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORPIS$4, 0);
        }
    }
    
    /**
     * Gets the "ValorCofins" element
     */
    public java.math.BigDecimal getValorCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCOFINS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCofins" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCOFINS$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCofins" element
     */
    public boolean isSetValorCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCOFINS$6) != 0;
        }
    }
    
    /**
     * Sets the "ValorCofins" element
     */
    public void setValorCofins(java.math.BigDecimal valorCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCOFINS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCOFINS$6);
            }
            target.setBigDecimalValue(valorCofins);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCofins" element
     */
    public void xsetValorCofins(br.org.abrasf.nfse.TsValor valorCofins)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCOFINS$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORCOFINS$6);
            }
            target.set(valorCofins);
        }
    }
    
    /**
     * Unsets the "ValorCofins" element
     */
    public void unsetValorCofins()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCOFINS$6, 0);
        }
    }
    
    /**
     * Gets the "ValorInss" element
     */
    public java.math.BigDecimal getValorInss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORINSS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorInss" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorInss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORINSS$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorInss" element
     */
    public boolean isSetValorInss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORINSS$8) != 0;
        }
    }
    
    /**
     * Sets the "ValorInss" element
     */
    public void setValorInss(java.math.BigDecimal valorInss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORINSS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORINSS$8);
            }
            target.setBigDecimalValue(valorInss);
        }
    }
    
    /**
     * Sets (as xml) the "ValorInss" element
     */
    public void xsetValorInss(br.org.abrasf.nfse.TsValor valorInss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORINSS$8, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORINSS$8);
            }
            target.set(valorInss);
        }
    }
    
    /**
     * Unsets the "ValorInss" element
     */
    public void unsetValorInss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORINSS$8, 0);
        }
    }
    
    /**
     * Gets the "ValorIr" element
     */
    public java.math.BigDecimal getValorIr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORIR$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorIr" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorIr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORIR$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorIr" element
     */
    public boolean isSetValorIr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORIR$10) != 0;
        }
    }
    
    /**
     * Sets the "ValorIr" element
     */
    public void setValorIr(java.math.BigDecimal valorIr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORIR$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORIR$10);
            }
            target.setBigDecimalValue(valorIr);
        }
    }
    
    /**
     * Sets (as xml) the "ValorIr" element
     */
    public void xsetValorIr(br.org.abrasf.nfse.TsValor valorIr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORIR$10, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORIR$10);
            }
            target.set(valorIr);
        }
    }
    
    /**
     * Unsets the "ValorIr" element
     */
    public void unsetValorIr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORIR$10, 0);
        }
    }
    
    /**
     * Gets the "ValorCsll" element
     */
    public java.math.BigDecimal getValorCsll()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCSLL$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCsll" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorCsll()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCSLL$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCsll" element
     */
    public boolean isSetValorCsll()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCSLL$12) != 0;
        }
    }
    
    /**
     * Sets the "ValorCsll" element
     */
    public void setValorCsll(java.math.BigDecimal valorCsll)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCSLL$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCSLL$12);
            }
            target.setBigDecimalValue(valorCsll);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCsll" element
     */
    public void xsetValorCsll(br.org.abrasf.nfse.TsValor valorCsll)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCSLL$12, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORCSLL$12);
            }
            target.set(valorCsll);
        }
    }
    
    /**
     * Unsets the "ValorCsll" element
     */
    public void unsetValorCsll()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCSLL$12, 0);
        }
    }
    
    /**
     * Gets the "OutrasRetencoes" element
     */
    public java.math.BigDecimal getOutrasRetencoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OUTRASRETENCOES$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "OutrasRetencoes" element
     */
    public br.org.abrasf.nfse.TsValor xgetOutrasRetencoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(OUTRASRETENCOES$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "OutrasRetencoes" element
     */
    public boolean isSetOutrasRetencoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OUTRASRETENCOES$14) != 0;
        }
    }
    
    /**
     * Sets the "OutrasRetencoes" element
     */
    public void setOutrasRetencoes(java.math.BigDecimal outrasRetencoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OUTRASRETENCOES$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OUTRASRETENCOES$14);
            }
            target.setBigDecimalValue(outrasRetencoes);
        }
    }
    
    /**
     * Sets (as xml) the "OutrasRetencoes" element
     */
    public void xsetOutrasRetencoes(br.org.abrasf.nfse.TsValor outrasRetencoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(OUTRASRETENCOES$14, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(OUTRASRETENCOES$14);
            }
            target.set(outrasRetencoes);
        }
    }
    
    /**
     * Unsets the "OutrasRetencoes" element
     */
    public void unsetOutrasRetencoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OUTRASRETENCOES$14, 0);
        }
    }
    
    /**
     * Gets the "ValTotTributos" element
     */
    public java.math.BigDecimal getValTotTributos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALTOTTRIBUTOS$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValTotTributos" element
     */
    public br.org.abrasf.nfse.TsValor xgetValTotTributos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALTOTTRIBUTOS$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValTotTributos" element
     */
    public boolean isSetValTotTributos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALTOTTRIBUTOS$16) != 0;
        }
    }
    
    /**
     * Sets the "ValTotTributos" element
     */
    public void setValTotTributos(java.math.BigDecimal valTotTributos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALTOTTRIBUTOS$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALTOTTRIBUTOS$16);
            }
            target.setBigDecimalValue(valTotTributos);
        }
    }
    
    /**
     * Sets (as xml) the "ValTotTributos" element
     */
    public void xsetValTotTributos(br.org.abrasf.nfse.TsValor valTotTributos)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALTOTTRIBUTOS$16, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALTOTTRIBUTOS$16);
            }
            target.set(valTotTributos);
        }
    }
    
    /**
     * Unsets the "ValTotTributos" element
     */
    public void unsetValTotTributos()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALTOTTRIBUTOS$16, 0);
        }
    }
    
    /**
     * Gets the "ValorIss" element
     */
    public java.math.BigDecimal getValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORISS$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorIss" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORISS$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorIss" element
     */
    public boolean isSetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORISS$18) != 0;
        }
    }
    
    /**
     * Sets the "ValorIss" element
     */
    public void setValorIss(java.math.BigDecimal valorIss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORISS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORISS$18);
            }
            target.setBigDecimalValue(valorIss);
        }
    }
    
    /**
     * Sets (as xml) the "ValorIss" element
     */
    public void xsetValorIss(br.org.abrasf.nfse.TsValor valorIss)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORISS$18, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORISS$18);
            }
            target.set(valorIss);
        }
    }
    
    /**
     * Unsets the "ValorIss" element
     */
    public void unsetValorIss()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORISS$18, 0);
        }
    }
    
    /**
     * Gets the "Aliquota" element
     */
    public java.math.BigDecimal getAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTA$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "Aliquota" element
     */
    public br.org.abrasf.nfse.TsAliquota xgetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsAliquota target = null;
            target = (br.org.abrasf.nfse.TsAliquota)get_store().find_element_user(ALIQUOTA$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "Aliquota" element
     */
    public boolean isSetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIQUOTA$20) != 0;
        }
    }
    
    /**
     * Sets the "Aliquota" element
     */
    public void setAliquota(java.math.BigDecimal aliquota)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIQUOTA$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALIQUOTA$20);
            }
            target.setBigDecimalValue(aliquota);
        }
    }
    
    /**
     * Sets (as xml) the "Aliquota" element
     */
    public void xsetAliquota(br.org.abrasf.nfse.TsAliquota aliquota)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsAliquota target = null;
            target = (br.org.abrasf.nfse.TsAliquota)get_store().find_element_user(ALIQUOTA$20, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsAliquota)get_store().add_element_user(ALIQUOTA$20);
            }
            target.set(aliquota);
        }
    }
    
    /**
     * Unsets the "Aliquota" element
     */
    public void unsetAliquota()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIQUOTA$20, 0);
        }
    }
    
    /**
     * Gets the "DescontoIncondicionado" element
     */
    public java.math.BigDecimal getDescontoIncondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCONTOINCONDICIONADO$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescontoIncondicionado" element
     */
    public br.org.abrasf.nfse.TsValor xgetDescontoIncondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(DESCONTOINCONDICIONADO$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "DescontoIncondicionado" element
     */
    public boolean isSetDescontoIncondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCONTOINCONDICIONADO$22) != 0;
        }
    }
    
    /**
     * Sets the "DescontoIncondicionado" element
     */
    public void setDescontoIncondicionado(java.math.BigDecimal descontoIncondicionado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCONTOINCONDICIONADO$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCONTOINCONDICIONADO$22);
            }
            target.setBigDecimalValue(descontoIncondicionado);
        }
    }
    
    /**
     * Sets (as xml) the "DescontoIncondicionado" element
     */
    public void xsetDescontoIncondicionado(br.org.abrasf.nfse.TsValor descontoIncondicionado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(DESCONTOINCONDICIONADO$22, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(DESCONTOINCONDICIONADO$22);
            }
            target.set(descontoIncondicionado);
        }
    }
    
    /**
     * Unsets the "DescontoIncondicionado" element
     */
    public void unsetDescontoIncondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCONTOINCONDICIONADO$22, 0);
        }
    }
    
    /**
     * Gets the "DescontoCondicionado" element
     */
    public java.math.BigDecimal getDescontoCondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCONTOCONDICIONADO$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "DescontoCondicionado" element
     */
    public br.org.abrasf.nfse.TsValor xgetDescontoCondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(DESCONTOCONDICIONADO$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "DescontoCondicionado" element
     */
    public boolean isSetDescontoCondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCONTOCONDICIONADO$24) != 0;
        }
    }
    
    /**
     * Sets the "DescontoCondicionado" element
     */
    public void setDescontoCondicionado(java.math.BigDecimal descontoCondicionado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCONTOCONDICIONADO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCONTOCONDICIONADO$24);
            }
            target.setBigDecimalValue(descontoCondicionado);
        }
    }
    
    /**
     * Sets (as xml) the "DescontoCondicionado" element
     */
    public void xsetDescontoCondicionado(br.org.abrasf.nfse.TsValor descontoCondicionado)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(DESCONTOCONDICIONADO$24, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(DESCONTOCONDICIONADO$24);
            }
            target.set(descontoCondicionado);
        }
    }
    
    /**
     * Unsets the "DescontoCondicionado" element
     */
    public void unsetDescontoCondicionado()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCONTOCONDICIONADO$24, 0);
        }
    }
}
