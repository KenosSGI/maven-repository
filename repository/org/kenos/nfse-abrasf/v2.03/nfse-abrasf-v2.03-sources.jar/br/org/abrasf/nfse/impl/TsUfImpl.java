/*
 * XML Type:  tsUf
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsUf
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsUf(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsUf.
 */
public class TsUfImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements br.org.abrasf.nfse.TsUf
{
    private static final long serialVersionUID = 1L;
    
    public TsUfImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsUfImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
