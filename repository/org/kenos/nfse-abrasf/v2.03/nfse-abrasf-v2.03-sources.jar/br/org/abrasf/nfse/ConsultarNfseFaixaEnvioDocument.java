/*
 * An XML document type.
 * Localname: ConsultarNfseFaixaEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarNfseFaixaEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarNfseFaixaEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseFaixaEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfsefaixaenviofb42doctype");
    
    /**
     * Gets the "ConsultarNfseFaixaEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio getConsultarNfseFaixaEnvio();
    
    /**
     * Sets the "ConsultarNfseFaixaEnvio" element
     */
    void setConsultarNfseFaixaEnvio(br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio consultarNfseFaixaEnvio);
    
    /**
     * Appends and returns a new empty "ConsultarNfseFaixaEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio addNewConsultarNfseFaixaEnvio();
    
    /**
     * An XML ConsultarNfseFaixaEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarNfseFaixaEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseFaixaEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfsefaixaenvioc1d1elemtype");
        
        /**
         * Gets the "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador();
        
        /**
         * Sets the "Prestador" element
         */
        void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador);
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador();
        
        /**
         * Gets the "Faixa" element
         */
        br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa getFaixa();
        
        /**
         * Sets the "Faixa" element
         */
        void setFaixa(br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa faixa);
        
        /**
         * Appends and returns a new empty "Faixa" element
         */
        br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa addNewFaixa();
        
        /**
         * Gets the "Pagina" element
         */
        int getPagina();
        
        /**
         * Gets (as xml) the "Pagina" element
         */
        br.org.abrasf.nfse.TsPagina xgetPagina();
        
        /**
         * Sets the "Pagina" element
         */
        void setPagina(int pagina);
        
        /**
         * Sets (as xml) the "Pagina" element
         */
        void xsetPagina(br.org.abrasf.nfse.TsPagina pagina);
        
        /**
         * An XML Faixa(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface Faixa extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Faixa.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("faixa9a54elemtype");
            
            /**
             * Gets the "NumeroNfseInicial" element
             */
            long getNumeroNfseInicial();
            
            /**
             * Gets (as xml) the "NumeroNfseInicial" element
             */
            br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfseInicial();
            
            /**
             * Sets the "NumeroNfseInicial" element
             */
            void setNumeroNfseInicial(long numeroNfseInicial);
            
            /**
             * Sets (as xml) the "NumeroNfseInicial" element
             */
            void xsetNumeroNfseInicial(br.org.abrasf.nfse.TsNumeroNfse numeroNfseInicial);
            
            /**
             * Gets the "NumeroNfseFinal" element
             */
            long getNumeroNfseFinal();
            
            /**
             * Gets (as xml) the "NumeroNfseFinal" element
             */
            br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfseFinal();
            
            /**
             * True if has "NumeroNfseFinal" element
             */
            boolean isSetNumeroNfseFinal();
            
            /**
             * Sets the "NumeroNfseFinal" element
             */
            void setNumeroNfseFinal(long numeroNfseFinal);
            
            /**
             * Sets (as xml) the "NumeroNfseFinal" element
             */
            void xsetNumeroNfseFinal(br.org.abrasf.nfse.TsNumeroNfse numeroNfseFinal);
            
            /**
             * Unsets the "NumeroNfseFinal" element
             */
            void unsetNumeroNfseFinal();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio.Faixa) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio newInstance() {
              return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument.ConsultarNfseFaixaEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseFaixaEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
