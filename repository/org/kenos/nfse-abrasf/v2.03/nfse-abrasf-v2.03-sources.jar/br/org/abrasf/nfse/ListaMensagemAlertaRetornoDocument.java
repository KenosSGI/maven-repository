/*
 * An XML document type.
 * Localname: ListaMensagemAlertaRetorno
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ListaMensagemAlertaRetorno(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ListaMensagemAlertaRetornoDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaMensagemAlertaRetornoDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("listamensagemalertaretorno48e3doctype");
    
    /**
     * Gets the "ListaMensagemAlertaRetorno" element
     */
    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno();
    
    /**
     * Sets the "ListaMensagemAlertaRetorno" element
     */
    void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno);
    
    /**
     * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
     */
    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno();
    
    /**
     * An XML ListaMensagemAlertaRetorno(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ListaMensagemAlertaRetorno extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ListaMensagemAlertaRetorno.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("listamensagemalertaretornof7d5elemtype");
        
        /**
         * Gets array of all "MensagemRetorno" elements
         */
        br.org.abrasf.nfse.TcMensagemRetorno[] getMensagemRetornoArray();
        
        /**
         * Gets ith "MensagemRetorno" element
         */
        br.org.abrasf.nfse.TcMensagemRetorno getMensagemRetornoArray(int i);
        
        /**
         * Returns number of "MensagemRetorno" element
         */
        int sizeOfMensagemRetornoArray();
        
        /**
         * Sets array of all "MensagemRetorno" element
         */
        void setMensagemRetornoArray(br.org.abrasf.nfse.TcMensagemRetorno[] mensagemRetornoArray);
        
        /**
         * Sets ith "MensagemRetorno" element
         */
        void setMensagemRetornoArray(int i, br.org.abrasf.nfse.TcMensagemRetorno mensagemRetorno);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "MensagemRetorno" element
         */
        br.org.abrasf.nfse.TcMensagemRetorno insertNewMensagemRetorno(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "MensagemRetorno" element
         */
        br.org.abrasf.nfse.TcMensagemRetorno addNewMensagemRetorno();
        
        /**
         * Removes the ith "MensagemRetorno" element
         */
        void removeMensagemRetorno(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno newInstance() {
              return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument newInstance() {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
