/*
 * An XML document type.
 * Localname: ConsultarNfseServicoTomadoEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarNfseServicoTomadoEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarNfseServicoTomadoEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoTomadoEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfseservicotomadoenvioafc0doctype");
    
    /**
     * Gets the "ConsultarNfseServicoTomadoEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio getConsultarNfseServicoTomadoEnvio();
    
    /**
     * Sets the "ConsultarNfseServicoTomadoEnvio" element
     */
    void setConsultarNfseServicoTomadoEnvio(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio consultarNfseServicoTomadoEnvio);
    
    /**
     * Appends and returns a new empty "ConsultarNfseServicoTomadoEnvio" element
     */
    br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio addNewConsultarNfseServicoTomadoEnvio();
    
    /**
     * An XML ConsultarNfseServicoTomadoEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarNfseServicoTomadoEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarNfseServicoTomadoEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("consultarnfseservicotomadoenvio7b4delemtype");
        
        /**
         * Gets the "Consulente" element
         */
        br.org.abrasf.nfse.TcIdentificacaoConsulente getConsulente();
        
        /**
         * Sets the "Consulente" element
         */
        void setConsulente(br.org.abrasf.nfse.TcIdentificacaoConsulente consulente);
        
        /**
         * Appends and returns a new empty "Consulente" element
         */
        br.org.abrasf.nfse.TcIdentificacaoConsulente addNewConsulente();
        
        /**
         * Gets the "NumeroNfse" element
         */
        long getNumeroNfse();
        
        /**
         * Gets (as xml) the "NumeroNfse" element
         */
        br.org.abrasf.nfse.TsNumeroNfse xgetNumeroNfse();
        
        /**
         * True if has "NumeroNfse" element
         */
        boolean isSetNumeroNfse();
        
        /**
         * Sets the "NumeroNfse" element
         */
        void setNumeroNfse(long numeroNfse);
        
        /**
         * Sets (as xml) the "NumeroNfse" element
         */
        void xsetNumeroNfse(br.org.abrasf.nfse.TsNumeroNfse numeroNfse);
        
        /**
         * Unsets the "NumeroNfse" element
         */
        void unsetNumeroNfse();
        
        /**
         * Gets the "PeriodoEmissao" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao getPeriodoEmissao();
        
        /**
         * True if has "PeriodoEmissao" element
         */
        boolean isSetPeriodoEmissao();
        
        /**
         * Sets the "PeriodoEmissao" element
         */
        void setPeriodoEmissao(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao periodoEmissao);
        
        /**
         * Appends and returns a new empty "PeriodoEmissao" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao addNewPeriodoEmissao();
        
        /**
         * Unsets the "PeriodoEmissao" element
         */
        void unsetPeriodoEmissao();
        
        /**
         * Gets the "PeriodoCompetencia" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia getPeriodoCompetencia();
        
        /**
         * True if has "PeriodoCompetencia" element
         */
        boolean isSetPeriodoCompetencia();
        
        /**
         * Sets the "PeriodoCompetencia" element
         */
        void setPeriodoCompetencia(br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia periodoCompetencia);
        
        /**
         * Appends and returns a new empty "PeriodoCompetencia" element
         */
        br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia addNewPeriodoCompetencia();
        
        /**
         * Unsets the "PeriodoCompetencia" element
         */
        void unsetPeriodoCompetencia();
        
        /**
         * Gets the "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador();
        
        /**
         * True if has "Prestador" element
         */
        boolean isSetPrestador();
        
        /**
         * Sets the "Prestador" element
         */
        void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador);
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador();
        
        /**
         * Unsets the "Prestador" element
         */
        void unsetPrestador();
        
        /**
         * Gets the "Tomador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoTomador getTomador();
        
        /**
         * True if has "Tomador" element
         */
        boolean isSetTomador();
        
        /**
         * Sets the "Tomador" element
         */
        void setTomador(br.org.abrasf.nfse.TcIdentificacaoTomador tomador);
        
        /**
         * Appends and returns a new empty "Tomador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoTomador addNewTomador();
        
        /**
         * Unsets the "Tomador" element
         */
        void unsetTomador();
        
        /**
         * Gets the "Intermediario" element
         */
        br.org.abrasf.nfse.TcIdentificacaoIntermediario getIntermediario();
        
        /**
         * True if has "Intermediario" element
         */
        boolean isSetIntermediario();
        
        /**
         * Sets the "Intermediario" element
         */
        void setIntermediario(br.org.abrasf.nfse.TcIdentificacaoIntermediario intermediario);
        
        /**
         * Appends and returns a new empty "Intermediario" element
         */
        br.org.abrasf.nfse.TcIdentificacaoIntermediario addNewIntermediario();
        
        /**
         * Unsets the "Intermediario" element
         */
        void unsetIntermediario();
        
        /**
         * Gets the "Pagina" element
         */
        int getPagina();
        
        /**
         * Gets (as xml) the "Pagina" element
         */
        br.org.abrasf.nfse.TsPagina xgetPagina();
        
        /**
         * Sets the "Pagina" element
         */
        void setPagina(int pagina);
        
        /**
         * Sets (as xml) the "Pagina" element
         */
        void xsetPagina(br.org.abrasf.nfse.TsPagina pagina);
        
        /**
         * An XML PeriodoEmissao(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface PeriodoEmissao extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PeriodoEmissao.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("periodoemissao646aelemtype");
            
            /**
             * Gets the "DataInicial" element
             */
            java.util.Calendar getDataInicial();
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            org.apache.xmlbeans.XmlDate xgetDataInicial();
            
            /**
             * Sets the "DataInicial" element
             */
            void setDataInicial(java.util.Calendar dataInicial);
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial);
            
            /**
             * Gets the "DataFinal" element
             */
            java.util.Calendar getDataFinal();
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            org.apache.xmlbeans.XmlDate xgetDataFinal();
            
            /**
             * Sets the "DataFinal" element
             */
            void setDataFinal(java.util.Calendar dataFinal);
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoEmissao) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * An XML PeriodoCompetencia(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface PeriodoCompetencia extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PeriodoCompetencia.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("periodocompetenciad30felemtype");
            
            /**
             * Gets the "DataInicial" element
             */
            java.util.Calendar getDataInicial();
            
            /**
             * Gets (as xml) the "DataInicial" element
             */
            org.apache.xmlbeans.XmlDate xgetDataInicial();
            
            /**
             * Sets the "DataInicial" element
             */
            void setDataInicial(java.util.Calendar dataInicial);
            
            /**
             * Sets (as xml) the "DataInicial" element
             */
            void xsetDataInicial(org.apache.xmlbeans.XmlDate dataInicial);
            
            /**
             * Gets the "DataFinal" element
             */
            java.util.Calendar getDataFinal();
            
            /**
             * Gets (as xml) the "DataFinal" element
             */
            org.apache.xmlbeans.XmlDate xgetDataFinal();
            
            /**
             * Sets the "DataFinal" element
             */
            void setDataFinal(java.util.Calendar dataFinal);
            
            /**
             * Sets (as xml) the "DataFinal" element
             */
            void xsetDataFinal(org.apache.xmlbeans.XmlDate dataFinal);
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia newInstance() {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio.PeriodoCompetencia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio newInstance() {
              return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument.ConsultarNfseServicoTomadoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarNfseServicoTomadoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
