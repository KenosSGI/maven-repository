/*
 * XML Type:  tsDescricaoMensagemAlerta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsDescricaoMensagemAlerta
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsDescricaoMensagemAlerta(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsDescricaoMensagemAlerta.
 */
public class TsDescricaoMensagemAlertaImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsDescricaoMensagemAlerta
{
    private static final long serialVersionUID = 1L;
    
    public TsDescricaoMensagemAlertaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsDescricaoMensagemAlertaImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
