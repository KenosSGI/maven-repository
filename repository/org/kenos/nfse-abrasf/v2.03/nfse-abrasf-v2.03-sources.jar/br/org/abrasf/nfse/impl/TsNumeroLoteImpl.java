/*
 * XML Type:  tsNumeroLote
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsNumeroLote
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsNumeroLote(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsNumeroLote.
 */
public class TsNumeroLoteImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements br.org.abrasf.nfse.TsNumeroLote
{
    private static final long serialVersionUID = 1L;
    
    public TsNumeroLoteImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsNumeroLoteImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
