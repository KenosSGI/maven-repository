/*
 * An XML document type.
 * Localname: ConsultarNfseRpsResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarNfseRpsResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarNfseRpsRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarNfseRpsRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARNFSERPSRESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarNfseRpsResposta");
    
    
    /**
     * Gets the "ConsultarNfseRpsResposta" element
     */
    public br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta getConsultarNfseRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta)get_store().find_element_user(CONSULTARNFSERPSRESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarNfseRpsResposta" element
     */
    public void setConsultarNfseRpsResposta(br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta consultarNfseRpsResposta)
    {
        generatedSetterHelperImpl(consultarNfseRpsResposta, CONSULTARNFSERPSRESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarNfseRpsResposta" element
     */
    public br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta addNewConsultarNfseRpsResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta)get_store().add_element_user(CONSULTARNFSERPSRESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML ConsultarNfseRpsResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarNfseRpsRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseRpsRespostaDocument.ConsultarNfseRpsResposta
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarNfseRpsRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName COMPNFSE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "CompNfse" element
         */
        public br.org.abrasf.nfse.TcCompNfse getCompNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcCompNfse target = null;
                target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "CompNfse" element
         */
        public boolean isSetCompNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COMPNFSE$0) != 0;
            }
        }
        
        /**
         * Sets the "CompNfse" element
         */
        public void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse)
        {
            generatedSetterHelperImpl(compNfse, COMPNFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "CompNfse" element
         */
        public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcCompNfse target = null;
                target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "CompNfse" element
         */
        public void unsetCompNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COMPNFSE$0, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$2, 0);
            }
        }
    }
}
