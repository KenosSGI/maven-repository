/*
 * An XML document type.
 * Localname: ConsultarNfseServicoPrestadoResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarNfseServicoPrestadoResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarNfseServicoPrestadoRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarNfseServicoPrestadoRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARNFSESERVICOPRESTADORESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarNfseServicoPrestadoResposta");
    
    
    /**
     * Gets the "ConsultarNfseServicoPrestadoResposta" element
     */
    public br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta getConsultarNfseServicoPrestadoResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta)get_store().find_element_user(CONSULTARNFSESERVICOPRESTADORESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarNfseServicoPrestadoResposta" element
     */
    public void setConsultarNfseServicoPrestadoResposta(br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta consultarNfseServicoPrestadoResposta)
    {
        generatedSetterHelperImpl(consultarNfseServicoPrestadoResposta, CONSULTARNFSESERVICOPRESTADORESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarNfseServicoPrestadoResposta" element
     */
    public br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta addNewConsultarNfseServicoPrestadoResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta target = null;
            target = (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta)get_store().add_element_user(CONSULTARNFSESERVICOPRESTADORESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML ConsultarNfseServicoPrestadoResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarNfseServicoPrestadoRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarNfseServicoPrestadoRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName LISTANFSE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaNfse");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "ListaNfse" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse getListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse)get_store().find_element_user(LISTANFSE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaNfse" element
         */
        public boolean isSetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTANFSE$0) != 0;
            }
        }
        
        /**
         * Sets the "ListaNfse" element
         */
        public void setListaNfse(br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse listaNfse)
        {
            generatedSetterHelperImpl(listaNfse, LISTANFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        public br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse addNewListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse)get_store().add_element_user(LISTANFSE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaNfse" element
         */
        public void unsetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTANFSE$0, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$2, 0);
            }
        }
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class ListaNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarNfseServicoPrestadoRespostaDocument.ConsultarNfseServicoPrestadoResposta.ListaNfse
        {
            private static final long serialVersionUID = 1L;
            
            public ListaNfseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName COMPNFSE$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
            private static final javax.xml.namespace.QName PROXIMAPAGINA$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ProximaPagina");
            
            
            /**
             * Gets array of all "CompNfse" elements
             */
            public br.org.abrasf.nfse.TcCompNfse[] getCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(COMPNFSE$0, targetList);
                    br.org.abrasf.nfse.TcCompNfse[] result = new br.org.abrasf.nfse.TcCompNfse[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse getCompNfseArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "CompNfse" element
             */
            public int sizeOfCompNfseArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(COMPNFSE$0);
                }
            }
            
            /**
             * Sets array of all "CompNfse" element  WARNING: This method is not atomicaly synchronized.
             */
            public void setCompNfseArray(br.org.abrasf.nfse.TcCompNfse[] compNfseArray)
            {
                check_orphaned();
                arraySetterHelper(compNfseArray, COMPNFSE$0);
            }
            
            /**
             * Sets ith "CompNfse" element
             */
            public void setCompNfseArray(int i, br.org.abrasf.nfse.TcCompNfse compNfse)
            {
                generatedSetterHelperImpl(compNfse, COMPNFSE$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse insertNewCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().insert_element_user(COMPNFSE$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "CompNfse" element
             */
            public void removeCompNfse(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(COMPNFSE$0, i);
                }
            }
            
            /**
             * Gets the "ProximaPagina" element
             */
            public int getProximaPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROXIMAPAGINA$2, 0);
                    if (target == null)
                    {
                      return 0;
                    }
                    return target.getIntValue();
                }
            }
            
            /**
             * Gets (as xml) the "ProximaPagina" element
             */
            public br.org.abrasf.nfse.TsPagina xgetProximaPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsPagina target = null;
                    target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PROXIMAPAGINA$2, 0);
                    return target;
                }
            }
            
            /**
             * True if has "ProximaPagina" element
             */
            public boolean isSetProximaPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(PROXIMAPAGINA$2) != 0;
                }
            }
            
            /**
             * Sets the "ProximaPagina" element
             */
            public void setProximaPagina(int proximaPagina)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROXIMAPAGINA$2, 0);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROXIMAPAGINA$2);
                    }
                    target.setIntValue(proximaPagina);
                }
            }
            
            /**
             * Sets (as xml) the "ProximaPagina" element
             */
            public void xsetProximaPagina(br.org.abrasf.nfse.TsPagina proximaPagina)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsPagina target = null;
                    target = (br.org.abrasf.nfse.TsPagina)get_store().find_element_user(PROXIMAPAGINA$2, 0);
                    if (target == null)
                    {
                      target = (br.org.abrasf.nfse.TsPagina)get_store().add_element_user(PROXIMAPAGINA$2);
                    }
                    target.set(proximaPagina);
                }
            }
            
            /**
             * Unsets the "ProximaPagina" element
             */
            public void unsetProximaPagina()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(PROXIMAPAGINA$2, 0);
                }
            }
        }
    }
}
