/*
 * An XML document type.
 * Localname: EnviarLoteRpsSincronoEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one EnviarLoteRpsSincronoEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class EnviarLoteRpsSincronoEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarLoteRpsSincronoEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARLOTERPSSINCRONOENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "EnviarLoteRpsSincronoEnvio");
    
    
    /**
     * Gets the "EnviarLoteRpsSincronoEnvio" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio getEnviarLoteRpsSincronoEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio)get_store().find_element_user(ENVIARLOTERPSSINCRONOENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarLoteRpsSincronoEnvio" element
     */
    public void setEnviarLoteRpsSincronoEnvio(br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio enviarLoteRpsSincronoEnvio)
    {
        generatedSetterHelperImpl(enviarLoteRpsSincronoEnvio, ENVIARLOTERPSSINCRONOENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsSincronoEnvio" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio addNewEnviarLoteRpsSincronoEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio)get_store().add_element_user(ENVIARLOTERPSSINCRONOENVIO$0);
            return target;
        }
    }
    /**
     * An XML EnviarLoteRpsSincronoEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class EnviarLoteRpsSincronoEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarLoteRpsSincronoEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName LOTERPS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "LoteRps");
        private static final javax.xml.namespace.QName SIGNATURE$2 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "LoteRps" element
         */
        public br.org.abrasf.nfse.TcLoteRps getLoteRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcLoteRps target = null;
                target = (br.org.abrasf.nfse.TcLoteRps)get_store().find_element_user(LOTERPS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "LoteRps" element
         */
        public void setLoteRps(br.org.abrasf.nfse.TcLoteRps loteRps)
        {
            generatedSetterHelperImpl(loteRps, LOTERPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "LoteRps" element
         */
        public br.org.abrasf.nfse.TcLoteRps addNewLoteRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcLoteRps target = null;
                target = (br.org.abrasf.nfse.TcLoteRps)get_store().add_element_user(LOTERPS$0);
                return target;
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Signature" element
         */
        public boolean isSetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SIGNATURE$2) != 0;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "Signature" element
         */
        public void unsetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SIGNATURE$2, 0);
            }
        }
    }
}
