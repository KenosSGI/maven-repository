/*
 * XML Type:  tsNomeFantasia
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsNomeFantasia
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tsNomeFantasia(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsNomeFantasia.
 */
public interface TsNomeFantasia extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TsNomeFantasia.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("tsnomefantasiab1c4type");
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TsNomeFantasia newValue(java.lang.Object obj) {
          return (br.org.abrasf.nfse.TsNomeFantasia) type.newValue( obj ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia newInstance() {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TsNomeFantasia parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TsNomeFantasia parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TsNomeFantasia parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TsNomeFantasia) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
