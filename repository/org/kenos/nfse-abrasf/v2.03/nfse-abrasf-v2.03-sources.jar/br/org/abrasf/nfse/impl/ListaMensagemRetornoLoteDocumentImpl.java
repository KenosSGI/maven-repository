/*
 * An XML document type.
 * Localname: ListaMensagemRetornoLote
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ListaMensagemRetornoLote(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ListaMensagemRetornoLoteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument
{
    private static final long serialVersionUID = 1L;
    
    public ListaMensagemRetornoLoteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNOLOTE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetornoLote");
    
    
    /**
     * Gets the "ListaMensagemRetornoLote" element
     */
    public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote getListaMensagemRetornoLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
            target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().find_element_user(LISTAMENSAGEMRETORNOLOTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ListaMensagemRetornoLote" element
     */
    public void setListaMensagemRetornoLote(br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote listaMensagemRetornoLote)
    {
        generatedSetterHelperImpl(listaMensagemRetornoLote, LISTAMENSAGEMRETORNOLOTE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaMensagemRetornoLote" element
     */
    public br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote addNewListaMensagemRetornoLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote target = null;
            target = (br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote)get_store().add_element_user(LISTAMENSAGEMRETORNOLOTE$0);
            return target;
        }
    }
    /**
     * An XML ListaMensagemRetornoLote(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ListaMensagemRetornoLoteImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemRetornoLoteDocument.ListaMensagemRetornoLote
    {
        private static final long serialVersionUID = 1L;
        
        public ListaMensagemRetornoLoteImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENSAGEMRETORNO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "MensagemRetorno");
        
        
        /**
         * Gets array of all "MensagemRetorno" elements
         */
        public br.org.abrasf.nfse.TcMensagemRetornoLote[] getMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MENSAGEMRETORNO$0, targetList);
                br.org.abrasf.nfse.TcMensagemRetornoLote[] result = new br.org.abrasf.nfse.TcMensagemRetornoLote[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetornoLote getMensagemRetornoArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetornoLote)get_store().find_element_user(MENSAGEMRETORNO$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "MensagemRetorno" element
         */
        public int sizeOfMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENSAGEMRETORNO$0);
            }
        }
        
        /**
         * Sets array of all "MensagemRetorno" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setMensagemRetornoArray(br.org.abrasf.nfse.TcMensagemRetornoLote[] mensagemRetornoArray)
        {
            check_orphaned();
            arraySetterHelper(mensagemRetornoArray, MENSAGEMRETORNO$0);
        }
        
        /**
         * Sets ith "MensagemRetorno" element
         */
        public void setMensagemRetornoArray(int i, br.org.abrasf.nfse.TcMensagemRetornoLote mensagemRetorno)
        {
            generatedSetterHelperImpl(mensagemRetorno, MENSAGEMRETORNO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetornoLote insertNewMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetornoLote)get_store().insert_element_user(MENSAGEMRETORNO$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetornoLote addNewMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetornoLote target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetornoLote)get_store().add_element_user(MENSAGEMRETORNO$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "MensagemRetorno" element
         */
        public void removeMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENSAGEMRETORNO$0, i);
            }
        }
    }
}
