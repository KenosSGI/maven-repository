/*
 * XML Type:  tsItemListaServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsItemListaServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsItemListaServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsItemListaServico.
 */
public class TsItemListaServicoImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements br.org.abrasf.nfse.TsItemListaServico
{
    private static final long serialVersionUID = 1L;
    
    public TsItemListaServicoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsItemListaServicoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
