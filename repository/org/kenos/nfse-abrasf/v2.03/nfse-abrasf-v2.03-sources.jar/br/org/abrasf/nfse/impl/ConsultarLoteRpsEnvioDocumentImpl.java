/*
 * An XML document type.
 * Localname: ConsultarLoteRpsEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ConsultarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ConsultarLoteRpsEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public ConsultarLoteRpsEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONSULTARLOTERPSENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConsultarLoteRpsEnvio");
    
    
    /**
     * Gets the "ConsultarLoteRpsEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio getConsultarLoteRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio)get_store().find_element_user(CONSULTARLOTERPSENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ConsultarLoteRpsEnvio" element
     */
    public void setConsultarLoteRpsEnvio(br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio consultarLoteRpsEnvio)
    {
        generatedSetterHelperImpl(consultarLoteRpsEnvio, CONSULTARLOTERPSENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConsultarLoteRpsEnvio" element
     */
    public br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio addNewConsultarLoteRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio target = null;
            target = (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio)get_store().add_element_user(CONSULTARLOTERPSENVIO$0);
            return target;
        }
    }
    /**
     * An XML ConsultarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ConsultarLoteRpsEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public ConsultarLoteRpsEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PRESTADOR$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Prestador");
        private static final javax.xml.namespace.QName PROTOCOLO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Protocolo");
        
        
        /**
         * Gets the "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(PRESTADOR$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Prestador" element
         */
        public void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador)
        {
            generatedSetterHelperImpl(prestador, PRESTADOR$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
                target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(PRESTADOR$0);
                return target;
            }
        }
        
        /**
         * Gets the "Protocolo" element
         */
        public java.lang.String getProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "Protocolo" element
         */
        public br.org.abrasf.nfse.TsNumeroProtocolo xgetProtocolo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "Protocolo" element
         */
        public void setProtocolo(java.lang.String protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTOCOLO$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTOCOLO$2);
                }
                target.setStringValue(protocolo);
            }
        }
        
        /**
         * Sets (as xml) the "Protocolo" element
         */
        public void xsetProtocolo(br.org.abrasf.nfse.TsNumeroProtocolo protocolo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsNumeroProtocolo target = null;
                target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().find_element_user(PROTOCOLO$2, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsNumeroProtocolo)get_store().add_element_user(PROTOCOLO$2);
                }
                target.set(protocolo);
            }
        }
    }
}
