/*
 * XML Type:  tcIdentificacaoNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcIdentificacaoNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcIdentificacaoNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcIdentificacaoNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcIdentificacaoNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcIdentificacaoNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMERO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Numero");
    private static final javax.xml.namespace.QName CPFCNPJ$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CpfCnpj");
    private static final javax.xml.namespace.QName INSCRICAOMUNICIPAL$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "InscricaoMunicipal");
    private static final javax.xml.namespace.QName CODIGOMUNICIPIO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoMunicipio");
    
    
    /**
     * Gets the "Numero" element
     */
    public long getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public br.org.abrasf.nfse.TsNumeroNfse xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(long numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$0);
            }
            target.setLongValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(br.org.abrasf.nfse.TsNumeroNfse numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NUMERO$0);
            }
            target.set(numero);
        }
    }
    
    /**
     * Gets the "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj getCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().find_element_user(CPFCNPJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CpfCnpj" element
     */
    public void setCpfCnpj(br.org.abrasf.nfse.TcCpfCnpj cpfCnpj)
    {
        generatedSetterHelperImpl(cpfCnpj, CPFCNPJ$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj addNewCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().add_element_user(CPFCNPJ$2);
            return target;
        }
    }
    
    /**
     * Gets the "InscricaoMunicipal" element
     */
    public java.lang.String getInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoMunicipal" element
     */
    public br.org.abrasf.nfse.TsInscricaoMunicipal xgetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoMunicipal" element
     */
    public boolean isSetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOMUNICIPAL$4) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoMunicipal" element
     */
    public void setInscricaoMunicipal(java.lang.String inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOMUNICIPAL$4);
            }
            target.setStringValue(inscricaoMunicipal);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoMunicipal" element
     */
    public void xsetInscricaoMunicipal(br.org.abrasf.nfse.TsInscricaoMunicipal inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().add_element_user(INSCRICAOMUNICIPAL$4);
            }
            target.set(inscricaoMunicipal);
        }
    }
    
    /**
     * Unsets the "InscricaoMunicipal" element
     */
    public void unsetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOMUNICIPAL$4, 0);
        }
    }
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    public int getCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$6, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    public void setCodigoMunicipio(int codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOMUNICIPIO$6);
            }
            target.setIntValue(codigoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    public void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(CODIGOMUNICIPIO$6);
            }
            target.set(codigoMunicipio);
        }
    }
}
