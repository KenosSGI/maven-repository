/*
 * XML Type:  tcDadosTomador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosTomador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcDadosTomador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcDadosTomadorImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcDadosTomador
{
    private static final long serialVersionUID = 1L;
    
    public TcDadosTomadorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAOTOMADOR$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoTomador");
    private static final javax.xml.namespace.QName NIFTOMADOR$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NifTomador");
    private static final javax.xml.namespace.QName RAZAOSOCIAL$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RazaoSocial");
    private static final javax.xml.namespace.QName ENDERECO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Endereco");
    private static final javax.xml.namespace.QName CONTATO$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Contato");
    
    
    /**
     * Gets the "IdentificacaoTomador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoTomador getIdentificacaoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoTomador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoTomador)get_store().find_element_user(IDENTIFICACAOTOMADOR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "IdentificacaoTomador" element
     */
    public boolean isSetIdentificacaoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(IDENTIFICACAOTOMADOR$0) != 0;
        }
    }
    
    /**
     * Sets the "IdentificacaoTomador" element
     */
    public void setIdentificacaoTomador(br.org.abrasf.nfse.TcIdentificacaoTomador identificacaoTomador)
    {
        generatedSetterHelperImpl(identificacaoTomador, IDENTIFICACAOTOMADOR$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoTomador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoTomador addNewIdentificacaoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoTomador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoTomador)get_store().add_element_user(IDENTIFICACAOTOMADOR$0);
            return target;
        }
    }
    
    /**
     * Unsets the "IdentificacaoTomador" element
     */
    public void unsetIdentificacaoTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(IDENTIFICACAOTOMADOR$0, 0);
        }
    }
    
    /**
     * Gets the "NifTomador" element
     */
    public java.lang.String getNifTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIFTOMADOR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NifTomador" element
     */
    public br.org.abrasf.nfse.TsNif xgetNifTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNif target = null;
            target = (br.org.abrasf.nfse.TsNif)get_store().find_element_user(NIFTOMADOR$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "NifTomador" element
     */
    public boolean isSetNifTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NIFTOMADOR$2) != 0;
        }
    }
    
    /**
     * Sets the "NifTomador" element
     */
    public void setNifTomador(java.lang.String nifTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NIFTOMADOR$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NIFTOMADOR$2);
            }
            target.setStringValue(nifTomador);
        }
    }
    
    /**
     * Sets (as xml) the "NifTomador" element
     */
    public void xsetNifTomador(br.org.abrasf.nfse.TsNif nifTomador)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNif target = null;
            target = (br.org.abrasf.nfse.TsNif)get_store().find_element_user(NIFTOMADOR$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNif)get_store().add_element_user(NIFTOMADOR$2);
            }
            target.set(nifTomador);
        }
    }
    
    /**
     * Unsets the "NifTomador" element
     */
    public void unsetNifTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NIFTOMADOR$2, 0);
        }
    }
    
    /**
     * Gets the "RazaoSocial" element
     */
    public java.lang.String getRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocial" element
     */
    public br.org.abrasf.nfse.TsRazaoSocial xgetRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "RazaoSocial" element
     */
    public boolean isSetRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RAZAOSOCIAL$4) != 0;
        }
    }
    
    /**
     * Sets the "RazaoSocial" element
     */
    public void setRazaoSocial(java.lang.String razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIAL$4);
            }
            target.setStringValue(razaoSocial);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocial" element
     */
    public void xsetRazaoSocial(br.org.abrasf.nfse.TsRazaoSocial razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().add_element_user(RAZAOSOCIAL$4);
            }
            target.set(razaoSocial);
        }
    }
    
    /**
     * Unsets the "RazaoSocial" element
     */
    public void unsetRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RAZAOSOCIAL$4, 0);
        }
    }
    
    /**
     * Gets the "Endereco" element
     */
    public br.org.abrasf.nfse.TcEndereco getEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcEndereco target = null;
            target = (br.org.abrasf.nfse.TcEndereco)get_store().find_element_user(ENDERECO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Endereco" element
     */
    public boolean isSetEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENDERECO$6) != 0;
        }
    }
    
    /**
     * Sets the "Endereco" element
     */
    public void setEndereco(br.org.abrasf.nfse.TcEndereco endereco)
    {
        generatedSetterHelperImpl(endereco, ENDERECO$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Endereco" element
     */
    public br.org.abrasf.nfse.TcEndereco addNewEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcEndereco target = null;
            target = (br.org.abrasf.nfse.TcEndereco)get_store().add_element_user(ENDERECO$6);
            return target;
        }
    }
    
    /**
     * Unsets the "Endereco" element
     */
    public void unsetEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENDERECO$6, 0);
        }
    }
    
    /**
     * Gets the "Contato" element
     */
    public br.org.abrasf.nfse.TcContato getContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcContato target = null;
            target = (br.org.abrasf.nfse.TcContato)get_store().find_element_user(CONTATO$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Contato" element
     */
    public boolean isSetContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTATO$8) != 0;
        }
    }
    
    /**
     * Sets the "Contato" element
     */
    public void setContato(br.org.abrasf.nfse.TcContato contato)
    {
        generatedSetterHelperImpl(contato, CONTATO$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Contato" element
     */
    public br.org.abrasf.nfse.TcContato addNewContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcContato target = null;
            target = (br.org.abrasf.nfse.TcContato)get_store().add_element_user(CONTATO$8);
            return target;
        }
    }
    
    /**
     * Unsets the "Contato" element
     */
    public void unsetContato()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTATO$8, 0);
        }
    }
}
