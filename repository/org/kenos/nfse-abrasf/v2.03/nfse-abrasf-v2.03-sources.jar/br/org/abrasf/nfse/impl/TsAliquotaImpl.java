/*
 * XML Type:  tsAliquota
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsAliquota
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsAliquota(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsAliquota.
 */
public class TsAliquotaImpl extends org.apache.xmlbeans.impl.values.JavaDecimalHolderEx implements br.org.abrasf.nfse.TsAliquota
{
    private static final long serialVersionUID = 1L;
    
    public TsAliquotaImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsAliquotaImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
