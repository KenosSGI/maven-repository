/*
 * XML Type:  tcDadosServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcDadosServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcDadosServicoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcDadosServico
{
    private static final long serialVersionUID = 1L;
    
    public TcDadosServicoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALORES$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Valores");
    private static final javax.xml.namespace.QName ISSRETIDO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IssRetido");
    private static final javax.xml.namespace.QName RESPONSAVELRETENCAO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ResponsavelRetencao");
    private static final javax.xml.namespace.QName ITEMLISTASERVICO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ItemListaServico");
    private static final javax.xml.namespace.QName CODIGOCNAE$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoCnae");
    private static final javax.xml.namespace.QName CODIGOTRIBUTACAOMUNICIPIO$10 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoTributacaoMunicipio");
    private static final javax.xml.namespace.QName CODIGONBS$12 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoNbs");
    private static final javax.xml.namespace.QName DISCRIMINACAO$14 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Discriminacao");
    private static final javax.xml.namespace.QName CODIGOMUNICIPIO$16 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoMunicipio");
    private static final javax.xml.namespace.QName CODIGOPAIS$18 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoPais");
    private static final javax.xml.namespace.QName EXIGIBILIDADEISS$20 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ExigibilidadeISS");
    private static final javax.xml.namespace.QName MUNICIPIOINCIDENCIA$22 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "MunicipioIncidencia");
    private static final javax.xml.namespace.QName NUMEROPROCESSO$24 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroProcesso");
    
    
    /**
     * Gets the "Valores" element
     */
    public br.org.abrasf.nfse.TcValoresDeclaracaoServico getValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcValoresDeclaracaoServico target = null;
            target = (br.org.abrasf.nfse.TcValoresDeclaracaoServico)get_store().find_element_user(VALORES$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Valores" element
     */
    public void setValores(br.org.abrasf.nfse.TcValoresDeclaracaoServico valores)
    {
        generatedSetterHelperImpl(valores, VALORES$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Valores" element
     */
    public br.org.abrasf.nfse.TcValoresDeclaracaoServico addNewValores()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcValoresDeclaracaoServico target = null;
            target = (br.org.abrasf.nfse.TcValoresDeclaracaoServico)get_store().add_element_user(VALORES$0);
            return target;
        }
    }
    
    /**
     * Gets the "IssRetido" element
     */
    public byte getIssRetido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDO$2, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "IssRetido" element
     */
    public br.org.abrasf.nfse.TsSimNao xgetIssRetido()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(ISSRETIDO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "IssRetido" element
     */
    public void setIssRetido(byte issRetido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSRETIDO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSRETIDO$2);
            }
            target.setByteValue(issRetido);
        }
    }
    
    /**
     * Sets (as xml) the "IssRetido" element
     */
    public void xsetIssRetido(br.org.abrasf.nfse.TsSimNao issRetido)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(ISSRETIDO$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsSimNao)get_store().add_element_user(ISSRETIDO$2);
            }
            target.set(issRetido);
        }
    }
    
    /**
     * Gets the "ResponsavelRetencao" element
     */
    public byte getResponsavelRetencao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESPONSAVELRETENCAO$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "ResponsavelRetencao" element
     */
    public br.org.abrasf.nfse.TsResponsavelRetencao xgetResponsavelRetencao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsResponsavelRetencao target = null;
            target = (br.org.abrasf.nfse.TsResponsavelRetencao)get_store().find_element_user(RESPONSAVELRETENCAO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "ResponsavelRetencao" element
     */
    public boolean isSetResponsavelRetencao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESPONSAVELRETENCAO$4) != 0;
        }
    }
    
    /**
     * Sets the "ResponsavelRetencao" element
     */
    public void setResponsavelRetencao(byte responsavelRetencao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESPONSAVELRETENCAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESPONSAVELRETENCAO$4);
            }
            target.setByteValue(responsavelRetencao);
        }
    }
    
    /**
     * Sets (as xml) the "ResponsavelRetencao" element
     */
    public void xsetResponsavelRetencao(br.org.abrasf.nfse.TsResponsavelRetencao responsavelRetencao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsResponsavelRetencao target = null;
            target = (br.org.abrasf.nfse.TsResponsavelRetencao)get_store().find_element_user(RESPONSAVELRETENCAO$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsResponsavelRetencao)get_store().add_element_user(RESPONSAVELRETENCAO$4);
            }
            target.set(responsavelRetencao);
        }
    }
    
    /**
     * Unsets the "ResponsavelRetencao" element
     */
    public void unsetResponsavelRetencao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESPONSAVELRETENCAO$4, 0);
        }
    }
    
    /**
     * Gets the "ItemListaServico" element
     */
    public br.org.abrasf.nfse.TsItemListaServico.Enum getItemListaServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ITEMLISTASERVICO$6, 0);
            if (target == null)
            {
                return null;
            }
            return (br.org.abrasf.nfse.TsItemListaServico.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ItemListaServico" element
     */
    public br.org.abrasf.nfse.TsItemListaServico xgetItemListaServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsItemListaServico target = null;
            target = (br.org.abrasf.nfse.TsItemListaServico)get_store().find_element_user(ITEMLISTASERVICO$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ItemListaServico" element
     */
    public void setItemListaServico(br.org.abrasf.nfse.TsItemListaServico.Enum itemListaServico)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ITEMLISTASERVICO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ITEMLISTASERVICO$6);
            }
            target.setEnumValue(itemListaServico);
        }
    }
    
    /**
     * Sets (as xml) the "ItemListaServico" element
     */
    public void xsetItemListaServico(br.org.abrasf.nfse.TsItemListaServico itemListaServico)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsItemListaServico target = null;
            target = (br.org.abrasf.nfse.TsItemListaServico)get_store().find_element_user(ITEMLISTASERVICO$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsItemListaServico)get_store().add_element_user(ITEMLISTASERVICO$6);
            }
            target.set(itemListaServico);
        }
    }
    
    /**
     * Gets the "CodigoCnae" element
     */
    public int getCodigoCnae()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCNAE$8, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoCnae" element
     */
    public br.org.abrasf.nfse.TsCodigoCnae xgetCodigoCnae()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoCnae target = null;
            target = (br.org.abrasf.nfse.TsCodigoCnae)get_store().find_element_user(CODIGOCNAE$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoCnae" element
     */
    public boolean isSetCodigoCnae()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOCNAE$8) != 0;
        }
    }
    
    /**
     * Sets the "CodigoCnae" element
     */
    public void setCodigoCnae(int codigoCnae)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCNAE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOCNAE$8);
            }
            target.setIntValue(codigoCnae);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoCnae" element
     */
    public void xsetCodigoCnae(br.org.abrasf.nfse.TsCodigoCnae codigoCnae)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoCnae target = null;
            target = (br.org.abrasf.nfse.TsCodigoCnae)get_store().find_element_user(CODIGOCNAE$8, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoCnae)get_store().add_element_user(CODIGOCNAE$8);
            }
            target.set(codigoCnae);
        }
    }
    
    /**
     * Unsets the "CodigoCnae" element
     */
    public void unsetCodigoCnae()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOCNAE$8, 0);
        }
    }
    
    /**
     * Gets the "CodigoTributacaoMunicipio" element
     */
    public java.lang.String getCodigoTributacaoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOTRIBUTACAOMUNICIPIO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoTributacaoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoTributacao xgetCodigoTributacaoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoTributacao target = null;
            target = (br.org.abrasf.nfse.TsCodigoTributacao)get_store().find_element_user(CODIGOTRIBUTACAOMUNICIPIO$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoTributacaoMunicipio" element
     */
    public boolean isSetCodigoTributacaoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOTRIBUTACAOMUNICIPIO$10) != 0;
        }
    }
    
    /**
     * Sets the "CodigoTributacaoMunicipio" element
     */
    public void setCodigoTributacaoMunicipio(java.lang.String codigoTributacaoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOTRIBUTACAOMUNICIPIO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOTRIBUTACAOMUNICIPIO$10);
            }
            target.setStringValue(codigoTributacaoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoTributacaoMunicipio" element
     */
    public void xsetCodigoTributacaoMunicipio(br.org.abrasf.nfse.TsCodigoTributacao codigoTributacaoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoTributacao target = null;
            target = (br.org.abrasf.nfse.TsCodigoTributacao)get_store().find_element_user(CODIGOTRIBUTACAOMUNICIPIO$10, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoTributacao)get_store().add_element_user(CODIGOTRIBUTACAOMUNICIPIO$10);
            }
            target.set(codigoTributacaoMunicipio);
        }
    }
    
    /**
     * Unsets the "CodigoTributacaoMunicipio" element
     */
    public void unsetCodigoTributacaoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOTRIBUTACAOMUNICIPIO$10, 0);
        }
    }
    
    /**
     * Gets the "CodigoNbs" element
     */
    public java.lang.String getCodigoNbs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGONBS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoNbs" element
     */
    public br.org.abrasf.nfse.TsCodigoNbs xgetCodigoNbs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoNbs target = null;
            target = (br.org.abrasf.nfse.TsCodigoNbs)get_store().find_element_user(CODIGONBS$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoNbs" element
     */
    public boolean isSetCodigoNbs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGONBS$12) != 0;
        }
    }
    
    /**
     * Sets the "CodigoNbs" element
     */
    public void setCodigoNbs(java.lang.String codigoNbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGONBS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGONBS$12);
            }
            target.setStringValue(codigoNbs);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoNbs" element
     */
    public void xsetCodigoNbs(br.org.abrasf.nfse.TsCodigoNbs codigoNbs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoNbs target = null;
            target = (br.org.abrasf.nfse.TsCodigoNbs)get_store().find_element_user(CODIGONBS$12, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoNbs)get_store().add_element_user(CODIGONBS$12);
            }
            target.set(codigoNbs);
        }
    }
    
    /**
     * Unsets the "CodigoNbs" element
     */
    public void unsetCodigoNbs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGONBS$12, 0);
        }
    }
    
    /**
     * Gets the "Discriminacao" element
     */
    public java.lang.String getDiscriminacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCRIMINACAO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Discriminacao" element
     */
    public br.org.abrasf.nfse.TsDiscriminacao xgetDiscriminacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDiscriminacao target = null;
            target = (br.org.abrasf.nfse.TsDiscriminacao)get_store().find_element_user(DISCRIMINACAO$14, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Discriminacao" element
     */
    public void setDiscriminacao(java.lang.String discriminacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCRIMINACAO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISCRIMINACAO$14);
            }
            target.setStringValue(discriminacao);
        }
    }
    
    /**
     * Sets (as xml) the "Discriminacao" element
     */
    public void xsetDiscriminacao(br.org.abrasf.nfse.TsDiscriminacao discriminacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsDiscriminacao target = null;
            target = (br.org.abrasf.nfse.TsDiscriminacao)get_store().find_element_user(DISCRIMINACAO$14, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsDiscriminacao)get_store().add_element_user(DISCRIMINACAO$14);
            }
            target.set(discriminacao);
        }
    }
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    public int getCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$16, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$16, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    public void setCodigoMunicipio(int codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOMUNICIPIO$16);
            }
            target.setIntValue(codigoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    public void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$16, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(CODIGOMUNICIPIO$16);
            }
            target.set(codigoMunicipio);
        }
    }
    
    /**
     * Gets the "CodigoPais" element
     */
    public java.lang.String getCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPAIS$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoPais" element
     */
    public br.org.abrasf.nfse.TsCodigoPaisBacen xgetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoPaisBacen target = null;
            target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().find_element_user(CODIGOPAIS$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoPais" element
     */
    public boolean isSetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOPAIS$18) != 0;
        }
    }
    
    /**
     * Sets the "CodigoPais" element
     */
    public void setCodigoPais(java.lang.String codigoPais)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPAIS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOPAIS$18);
            }
            target.setStringValue(codigoPais);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoPais" element
     */
    public void xsetCodigoPais(br.org.abrasf.nfse.TsCodigoPaisBacen codigoPais)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoPaisBacen target = null;
            target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().find_element_user(CODIGOPAIS$18, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().add_element_user(CODIGOPAIS$18);
            }
            target.set(codigoPais);
        }
    }
    
    /**
     * Unsets the "CodigoPais" element
     */
    public void unsetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOPAIS$18, 0);
        }
    }
    
    /**
     * Gets the "ExigibilidadeISS" element
     */
    public byte getExigibilidadeISS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXIGIBILIDADEISS$20, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "ExigibilidadeISS" element
     */
    public br.org.abrasf.nfse.TsExigibilidadeISS xgetExigibilidadeISS()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsExigibilidadeISS target = null;
            target = (br.org.abrasf.nfse.TsExigibilidadeISS)get_store().find_element_user(EXIGIBILIDADEISS$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "ExigibilidadeISS" element
     */
    public void setExigibilidadeISS(byte exigibilidadeISS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXIGIBILIDADEISS$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXIGIBILIDADEISS$20);
            }
            target.setByteValue(exigibilidadeISS);
        }
    }
    
    /**
     * Sets (as xml) the "ExigibilidadeISS" element
     */
    public void xsetExigibilidadeISS(br.org.abrasf.nfse.TsExigibilidadeISS exigibilidadeISS)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsExigibilidadeISS target = null;
            target = (br.org.abrasf.nfse.TsExigibilidadeISS)get_store().find_element_user(EXIGIBILIDADEISS$20, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsExigibilidadeISS)get_store().add_element_user(EXIGIBILIDADEISS$20);
            }
            target.set(exigibilidadeISS);
        }
    }
    
    /**
     * Gets the "MunicipioIncidencia" element
     */
    public int getMunicipioIncidencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUNICIPIOINCIDENCIA$22, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "MunicipioIncidencia" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetMunicipioIncidencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(MUNICIPIOINCIDENCIA$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "MunicipioIncidencia" element
     */
    public boolean isSetMunicipioIncidencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MUNICIPIOINCIDENCIA$22) != 0;
        }
    }
    
    /**
     * Sets the "MunicipioIncidencia" element
     */
    public void setMunicipioIncidencia(int municipioIncidencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUNICIPIOINCIDENCIA$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MUNICIPIOINCIDENCIA$22);
            }
            target.setIntValue(municipioIncidencia);
        }
    }
    
    /**
     * Sets (as xml) the "MunicipioIncidencia" element
     */
    public void xsetMunicipioIncidencia(br.org.abrasf.nfse.TsCodigoMunicipioIbge municipioIncidencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(MUNICIPIOINCIDENCIA$22, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(MUNICIPIOINCIDENCIA$22);
            }
            target.set(municipioIncidencia);
        }
    }
    
    /**
     * Unsets the "MunicipioIncidencia" element
     */
    public void unsetMunicipioIncidencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MUNICIPIOINCIDENCIA$22, 0);
        }
    }
    
    /**
     * Gets the "NumeroProcesso" element
     */
    public java.lang.String getNumeroProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPROCESSO$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroProcesso" element
     */
    public br.org.abrasf.nfse.TsNumeroProcesso xgetNumeroProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroProcesso target = null;
            target = (br.org.abrasf.nfse.TsNumeroProcesso)get_store().find_element_user(NUMEROPROCESSO$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "NumeroProcesso" element
     */
    public boolean isSetNumeroProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMEROPROCESSO$24) != 0;
        }
    }
    
    /**
     * Sets the "NumeroProcesso" element
     */
    public void setNumeroProcesso(java.lang.String numeroProcesso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROPROCESSO$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROPROCESSO$24);
            }
            target.setStringValue(numeroProcesso);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroProcesso" element
     */
    public void xsetNumeroProcesso(br.org.abrasf.nfse.TsNumeroProcesso numeroProcesso)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroProcesso target = null;
            target = (br.org.abrasf.nfse.TsNumeroProcesso)get_store().find_element_user(NUMEROPROCESSO$24, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroProcesso)get_store().add_element_user(NUMEROPROCESSO$24);
            }
            target.set(numeroProcesso);
        }
    }
    
    /**
     * Unsets the "NumeroProcesso" element
     */
    public void unsetNumeroProcesso()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMEROPROCESSO$24, 0);
        }
    }
}
