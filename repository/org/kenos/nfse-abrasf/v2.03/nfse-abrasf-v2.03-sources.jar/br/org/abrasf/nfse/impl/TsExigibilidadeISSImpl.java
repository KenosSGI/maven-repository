/*
 * XML Type:  tsExigibilidadeISS
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsExigibilidadeISS
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsExigibilidadeISS(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsExigibilidadeISS.
 */
public class TsExigibilidadeISSImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements br.org.abrasf.nfse.TsExigibilidadeISS
{
    private static final long serialVersionUID = 1L;
    
    public TsExigibilidadeISSImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsExigibilidadeISSImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
