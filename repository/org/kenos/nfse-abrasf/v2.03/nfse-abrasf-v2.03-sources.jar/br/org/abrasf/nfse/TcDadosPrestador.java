/*
 * XML Type:  tcDadosPrestador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosPrestador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcDadosPrestador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcDadosPrestador extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcDadosPrestador.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("tcdadosprestadorbecftype");
    
    /**
     * Gets the "IdentificacaoPrestador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoPrestador getIdentificacaoPrestador();
    
    /**
     * Sets the "IdentificacaoPrestador" element
     */
    void setIdentificacaoPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador identificacaoPrestador);
    
    /**
     * Appends and returns a new empty "IdentificacaoPrestador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoPrestador addNewIdentificacaoPrestador();
    
    /**
     * Gets the "RazaoSocial" element
     */
    java.lang.String getRazaoSocial();
    
    /**
     * Gets (as xml) the "RazaoSocial" element
     */
    br.org.abrasf.nfse.TsRazaoSocial xgetRazaoSocial();
    
    /**
     * Sets the "RazaoSocial" element
     */
    void setRazaoSocial(java.lang.String razaoSocial);
    
    /**
     * Sets (as xml) the "RazaoSocial" element
     */
    void xsetRazaoSocial(br.org.abrasf.nfse.TsRazaoSocial razaoSocial);
    
    /**
     * Gets the "NomeFantasia" element
     */
    java.lang.String getNomeFantasia();
    
    /**
     * Gets (as xml) the "NomeFantasia" element
     */
    br.org.abrasf.nfse.TsNomeFantasia xgetNomeFantasia();
    
    /**
     * True if has "NomeFantasia" element
     */
    boolean isSetNomeFantasia();
    
    /**
     * Sets the "NomeFantasia" element
     */
    void setNomeFantasia(java.lang.String nomeFantasia);
    
    /**
     * Sets (as xml) the "NomeFantasia" element
     */
    void xsetNomeFantasia(br.org.abrasf.nfse.TsNomeFantasia nomeFantasia);
    
    /**
     * Unsets the "NomeFantasia" element
     */
    void unsetNomeFantasia();
    
    /**
     * Gets the "Endereco" element
     */
    br.org.abrasf.nfse.TcEndereco getEndereco();
    
    /**
     * Sets the "Endereco" element
     */
    void setEndereco(br.org.abrasf.nfse.TcEndereco endereco);
    
    /**
     * Appends and returns a new empty "Endereco" element
     */
    br.org.abrasf.nfse.TcEndereco addNewEndereco();
    
    /**
     * Gets the "Contato" element
     */
    br.org.abrasf.nfse.TcContato getContato();
    
    /**
     * True if has "Contato" element
     */
    boolean isSetContato();
    
    /**
     * Sets the "Contato" element
     */
    void setContato(br.org.abrasf.nfse.TcContato contato);
    
    /**
     * Appends and returns a new empty "Contato" element
     */
    br.org.abrasf.nfse.TcContato addNewContato();
    
    /**
     * Unsets the "Contato" element
     */
    void unsetContato();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcDadosPrestador newInstance() {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosPrestador parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcDadosPrestador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcDadosPrestador parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcDadosPrestador) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
