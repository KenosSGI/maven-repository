/*
 * XML Type:  tcDadosServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcDadosServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcDadosServico extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcDadosServico.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("tcdadosservico1804type");
    
    /**
     * Gets the "Valores" element
     */
    br.org.abrasf.nfse.TcValoresDeclaracaoServico getValores();
    
    /**
     * Sets the "Valores" element
     */
    void setValores(br.org.abrasf.nfse.TcValoresDeclaracaoServico valores);
    
    /**
     * Appends and returns a new empty "Valores" element
     */
    br.org.abrasf.nfse.TcValoresDeclaracaoServico addNewValores();
    
    /**
     * Gets the "IssRetido" element
     */
    byte getIssRetido();
    
    /**
     * Gets (as xml) the "IssRetido" element
     */
    br.org.abrasf.nfse.TsSimNao xgetIssRetido();
    
    /**
     * Sets the "IssRetido" element
     */
    void setIssRetido(byte issRetido);
    
    /**
     * Sets (as xml) the "IssRetido" element
     */
    void xsetIssRetido(br.org.abrasf.nfse.TsSimNao issRetido);
    
    /**
     * Gets the "ResponsavelRetencao" element
     */
    byte getResponsavelRetencao();
    
    /**
     * Gets (as xml) the "ResponsavelRetencao" element
     */
    br.org.abrasf.nfse.TsResponsavelRetencao xgetResponsavelRetencao();
    
    /**
     * True if has "ResponsavelRetencao" element
     */
    boolean isSetResponsavelRetencao();
    
    /**
     * Sets the "ResponsavelRetencao" element
     */
    void setResponsavelRetencao(byte responsavelRetencao);
    
    /**
     * Sets (as xml) the "ResponsavelRetencao" element
     */
    void xsetResponsavelRetencao(br.org.abrasf.nfse.TsResponsavelRetencao responsavelRetencao);
    
    /**
     * Unsets the "ResponsavelRetencao" element
     */
    void unsetResponsavelRetencao();
    
    /**
     * Gets the "ItemListaServico" element
     */
    br.org.abrasf.nfse.TsItemListaServico.Enum getItemListaServico();
    
    /**
     * Gets (as xml) the "ItemListaServico" element
     */
    br.org.abrasf.nfse.TsItemListaServico xgetItemListaServico();
    
    /**
     * Sets the "ItemListaServico" element
     */
    void setItemListaServico(br.org.abrasf.nfse.TsItemListaServico.Enum itemListaServico);
    
    /**
     * Sets (as xml) the "ItemListaServico" element
     */
    void xsetItemListaServico(br.org.abrasf.nfse.TsItemListaServico itemListaServico);
    
    /**
     * Gets the "CodigoCnae" element
     */
    int getCodigoCnae();
    
    /**
     * Gets (as xml) the "CodigoCnae" element
     */
    br.org.abrasf.nfse.TsCodigoCnae xgetCodigoCnae();
    
    /**
     * True if has "CodigoCnae" element
     */
    boolean isSetCodigoCnae();
    
    /**
     * Sets the "CodigoCnae" element
     */
    void setCodigoCnae(int codigoCnae);
    
    /**
     * Sets (as xml) the "CodigoCnae" element
     */
    void xsetCodigoCnae(br.org.abrasf.nfse.TsCodigoCnae codigoCnae);
    
    /**
     * Unsets the "CodigoCnae" element
     */
    void unsetCodigoCnae();
    
    /**
     * Gets the "CodigoTributacaoMunicipio" element
     */
    java.lang.String getCodigoTributacaoMunicipio();
    
    /**
     * Gets (as xml) the "CodigoTributacaoMunicipio" element
     */
    br.org.abrasf.nfse.TsCodigoTributacao xgetCodigoTributacaoMunicipio();
    
    /**
     * True if has "CodigoTributacaoMunicipio" element
     */
    boolean isSetCodigoTributacaoMunicipio();
    
    /**
     * Sets the "CodigoTributacaoMunicipio" element
     */
    void setCodigoTributacaoMunicipio(java.lang.String codigoTributacaoMunicipio);
    
    /**
     * Sets (as xml) the "CodigoTributacaoMunicipio" element
     */
    void xsetCodigoTributacaoMunicipio(br.org.abrasf.nfse.TsCodigoTributacao codigoTributacaoMunicipio);
    
    /**
     * Unsets the "CodigoTributacaoMunicipio" element
     */
    void unsetCodigoTributacaoMunicipio();
    
    /**
     * Gets the "CodigoNbs" element
     */
    java.lang.String getCodigoNbs();
    
    /**
     * Gets (as xml) the "CodigoNbs" element
     */
    br.org.abrasf.nfse.TsCodigoNbs xgetCodigoNbs();
    
    /**
     * True if has "CodigoNbs" element
     */
    boolean isSetCodigoNbs();
    
    /**
     * Sets the "CodigoNbs" element
     */
    void setCodigoNbs(java.lang.String codigoNbs);
    
    /**
     * Sets (as xml) the "CodigoNbs" element
     */
    void xsetCodigoNbs(br.org.abrasf.nfse.TsCodigoNbs codigoNbs);
    
    /**
     * Unsets the "CodigoNbs" element
     */
    void unsetCodigoNbs();
    
    /**
     * Gets the "Discriminacao" element
     */
    java.lang.String getDiscriminacao();
    
    /**
     * Gets (as xml) the "Discriminacao" element
     */
    br.org.abrasf.nfse.TsDiscriminacao xgetDiscriminacao();
    
    /**
     * Sets the "Discriminacao" element
     */
    void setDiscriminacao(java.lang.String discriminacao);
    
    /**
     * Sets (as xml) the "Discriminacao" element
     */
    void xsetDiscriminacao(br.org.abrasf.nfse.TsDiscriminacao discriminacao);
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    int getCodigoMunicipio();
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio();
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    void setCodigoMunicipio(int codigoMunicipio);
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio);
    
    /**
     * Gets the "CodigoPais" element
     */
    java.lang.String getCodigoPais();
    
    /**
     * Gets (as xml) the "CodigoPais" element
     */
    br.org.abrasf.nfse.TsCodigoPaisBacen xgetCodigoPais();
    
    /**
     * True if has "CodigoPais" element
     */
    boolean isSetCodigoPais();
    
    /**
     * Sets the "CodigoPais" element
     */
    void setCodigoPais(java.lang.String codigoPais);
    
    /**
     * Sets (as xml) the "CodigoPais" element
     */
    void xsetCodigoPais(br.org.abrasf.nfse.TsCodigoPaisBacen codigoPais);
    
    /**
     * Unsets the "CodigoPais" element
     */
    void unsetCodigoPais();
    
    /**
     * Gets the "ExigibilidadeISS" element
     */
    byte getExigibilidadeISS();
    
    /**
     * Gets (as xml) the "ExigibilidadeISS" element
     */
    br.org.abrasf.nfse.TsExigibilidadeISS xgetExigibilidadeISS();
    
    /**
     * Sets the "ExigibilidadeISS" element
     */
    void setExigibilidadeISS(byte exigibilidadeISS);
    
    /**
     * Sets (as xml) the "ExigibilidadeISS" element
     */
    void xsetExigibilidadeISS(br.org.abrasf.nfse.TsExigibilidadeISS exigibilidadeISS);
    
    /**
     * Gets the "MunicipioIncidencia" element
     */
    int getMunicipioIncidencia();
    
    /**
     * Gets (as xml) the "MunicipioIncidencia" element
     */
    br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetMunicipioIncidencia();
    
    /**
     * True if has "MunicipioIncidencia" element
     */
    boolean isSetMunicipioIncidencia();
    
    /**
     * Sets the "MunicipioIncidencia" element
     */
    void setMunicipioIncidencia(int municipioIncidencia);
    
    /**
     * Sets (as xml) the "MunicipioIncidencia" element
     */
    void xsetMunicipioIncidencia(br.org.abrasf.nfse.TsCodigoMunicipioIbge municipioIncidencia);
    
    /**
     * Unsets the "MunicipioIncidencia" element
     */
    void unsetMunicipioIncidencia();
    
    /**
     * Gets the "NumeroProcesso" element
     */
    java.lang.String getNumeroProcesso();
    
    /**
     * Gets (as xml) the "NumeroProcesso" element
     */
    br.org.abrasf.nfse.TsNumeroProcesso xgetNumeroProcesso();
    
    /**
     * True if has "NumeroProcesso" element
     */
    boolean isSetNumeroProcesso();
    
    /**
     * Sets the "NumeroProcesso" element
     */
    void setNumeroProcesso(java.lang.String numeroProcesso);
    
    /**
     * Sets (as xml) the "NumeroProcesso" element
     */
    void xsetNumeroProcesso(br.org.abrasf.nfse.TsNumeroProcesso numeroProcesso);
    
    /**
     * Unsets the "NumeroProcesso" element
     */
    void unsetNumeroProcesso();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcDadosServico newInstance() {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcDadosServico parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcDadosServico parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcDadosServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcDadosServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcDadosServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
