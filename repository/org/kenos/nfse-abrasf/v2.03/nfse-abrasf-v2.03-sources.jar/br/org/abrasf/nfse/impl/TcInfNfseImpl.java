/*
 * XML Type:  tcInfNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcInfNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcInfNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcInfNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcInfNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMERO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Numero");
    private static final javax.xml.namespace.QName CODIGOVERIFICACAO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoVerificacao");
    private static final javax.xml.namespace.QName DATAEMISSAO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DataEmissao");
    private static final javax.xml.namespace.QName NFSESUBSTITUIDA$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseSubstituida");
    private static final javax.xml.namespace.QName OUTRASINFORMACOES$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "OutrasInformacoes");
    private static final javax.xml.namespace.QName VALORESNFSE$10 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValoresNfse");
    private static final javax.xml.namespace.QName VALORCREDITO$12 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ValorCredito");
    private static final javax.xml.namespace.QName PRESTADORSERVICO$14 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "PrestadorServico");
    private static final javax.xml.namespace.QName ORGAOGERADOR$16 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "OrgaoGerador");
    private static final javax.xml.namespace.QName DECLARACAOPRESTACAOSERVICO$18 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "DeclaracaoPrestacaoServico");
    private static final javax.xml.namespace.QName ID$20 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "Numero" element
     */
    public long getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public br.org.abrasf.nfse.TsNumeroNfse xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(long numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$0);
            }
            target.setLongValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(br.org.abrasf.nfse.TsNumeroNfse numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NUMERO$0);
            }
            target.set(numero);
        }
    }
    
    /**
     * Gets the "CodigoVerificacao" element
     */
    public java.lang.String getCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOVERIFICACAO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoVerificacao" element
     */
    public br.org.abrasf.nfse.TsCodigoVerificacao xgetCodigoVerificacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoVerificacao target = null;
            target = (br.org.abrasf.nfse.TsCodigoVerificacao)get_store().find_element_user(CODIGOVERIFICACAO$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoVerificacao" element
     */
    public void setCodigoVerificacao(java.lang.String codigoVerificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOVERIFICACAO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOVERIFICACAO$2);
            }
            target.setStringValue(codigoVerificacao);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoVerificacao" element
     */
    public void xsetCodigoVerificacao(br.org.abrasf.nfse.TsCodigoVerificacao codigoVerificacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoVerificacao target = null;
            target = (br.org.abrasf.nfse.TsCodigoVerificacao)get_store().find_element_user(CODIGOVERIFICACAO$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoVerificacao)get_store().add_element_user(CODIGOVERIFICACAO$2);
            }
            target.set(codigoVerificacao);
        }
    }
    
    /**
     * Gets the "DataEmissao" element
     */
    public java.util.Calendar getDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "DataEmissao" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetDataEmissao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAEMISSAO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "DataEmissao" element
     */
    public void setDataEmissao(java.util.Calendar dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DATAEMISSAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DATAEMISSAO$4);
            }
            target.setCalendarValue(dataEmissao);
        }
    }
    
    /**
     * Sets (as xml) the "DataEmissao" element
     */
    public void xsetDataEmissao(org.apache.xmlbeans.XmlDateTime dataEmissao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(DATAEMISSAO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(DATAEMISSAO$4);
            }
            target.set(dataEmissao);
        }
    }
    
    /**
     * Gets the "NfseSubstituida" element
     */
    public long getNfseSubstituida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NFSESUBSTITUIDA$6, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NfseSubstituida" element
     */
    public br.org.abrasf.nfse.TsNumeroNfse xgetNfseSubstituida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NFSESUBSTITUIDA$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "NfseSubstituida" element
     */
    public boolean isSetNfseSubstituida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NFSESUBSTITUIDA$6) != 0;
        }
    }
    
    /**
     * Sets the "NfseSubstituida" element
     */
    public void setNfseSubstituida(long nfseSubstituida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NFSESUBSTITUIDA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NFSESUBSTITUIDA$6);
            }
            target.setLongValue(nfseSubstituida);
        }
    }
    
    /**
     * Sets (as xml) the "NfseSubstituida" element
     */
    public void xsetNfseSubstituida(br.org.abrasf.nfse.TsNumeroNfse nfseSubstituida)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroNfse target = null;
            target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().find_element_user(NFSESUBSTITUIDA$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroNfse)get_store().add_element_user(NFSESUBSTITUIDA$6);
            }
            target.set(nfseSubstituida);
        }
    }
    
    /**
     * Unsets the "NfseSubstituida" element
     */
    public void unsetNfseSubstituida()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NFSESUBSTITUIDA$6, 0);
        }
    }
    
    /**
     * Gets the "OutrasInformacoes" element
     */
    public java.lang.String getOutrasInformacoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OUTRASINFORMACOES$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "OutrasInformacoes" element
     */
    public br.org.abrasf.nfse.TsOutrasInformacoes xgetOutrasInformacoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsOutrasInformacoes target = null;
            target = (br.org.abrasf.nfse.TsOutrasInformacoes)get_store().find_element_user(OUTRASINFORMACOES$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "OutrasInformacoes" element
     */
    public boolean isSetOutrasInformacoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OUTRASINFORMACOES$8) != 0;
        }
    }
    
    /**
     * Sets the "OutrasInformacoes" element
     */
    public void setOutrasInformacoes(java.lang.String outrasInformacoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OUTRASINFORMACOES$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OUTRASINFORMACOES$8);
            }
            target.setStringValue(outrasInformacoes);
        }
    }
    
    /**
     * Sets (as xml) the "OutrasInformacoes" element
     */
    public void xsetOutrasInformacoes(br.org.abrasf.nfse.TsOutrasInformacoes outrasInformacoes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsOutrasInformacoes target = null;
            target = (br.org.abrasf.nfse.TsOutrasInformacoes)get_store().find_element_user(OUTRASINFORMACOES$8, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsOutrasInformacoes)get_store().add_element_user(OUTRASINFORMACOES$8);
            }
            target.set(outrasInformacoes);
        }
    }
    
    /**
     * Unsets the "OutrasInformacoes" element
     */
    public void unsetOutrasInformacoes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OUTRASINFORMACOES$8, 0);
        }
    }
    
    /**
     * Gets the "ValoresNfse" element
     */
    public br.org.abrasf.nfse.TcValoresNfse getValoresNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcValoresNfse target = null;
            target = (br.org.abrasf.nfse.TcValoresNfse)get_store().find_element_user(VALORESNFSE$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ValoresNfse" element
     */
    public void setValoresNfse(br.org.abrasf.nfse.TcValoresNfse valoresNfse)
    {
        generatedSetterHelperImpl(valoresNfse, VALORESNFSE$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ValoresNfse" element
     */
    public br.org.abrasf.nfse.TcValoresNfse addNewValoresNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcValoresNfse target = null;
            target = (br.org.abrasf.nfse.TcValoresNfse)get_store().add_element_user(VALORESNFSE$10);
            return target;
        }
    }
    
    /**
     * Gets the "ValorCredito" element
     */
    public java.math.BigDecimal getValorCredito()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCREDITO$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigDecimalValue();
        }
    }
    
    /**
     * Gets (as xml) the "ValorCredito" element
     */
    public br.org.abrasf.nfse.TsValor xgetValorCredito()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCREDITO$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "ValorCredito" element
     */
    public boolean isSetValorCredito()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALORCREDITO$12) != 0;
        }
    }
    
    /**
     * Sets the "ValorCredito" element
     */
    public void setValorCredito(java.math.BigDecimal valorCredito)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALORCREDITO$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALORCREDITO$12);
            }
            target.setBigDecimalValue(valorCredito);
        }
    }
    
    /**
     * Sets (as xml) the "ValorCredito" element
     */
    public void xsetValorCredito(br.org.abrasf.nfse.TsValor valorCredito)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsValor target = null;
            target = (br.org.abrasf.nfse.TsValor)get_store().find_element_user(VALORCREDITO$12, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsValor)get_store().add_element_user(VALORCREDITO$12);
            }
            target.set(valorCredito);
        }
    }
    
    /**
     * Unsets the "ValorCredito" element
     */
    public void unsetValorCredito()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALORCREDITO$12, 0);
        }
    }
    
    /**
     * Gets the "PrestadorServico" element
     */
    public br.org.abrasf.nfse.TcDadosPrestador getPrestadorServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosPrestador target = null;
            target = (br.org.abrasf.nfse.TcDadosPrestador)get_store().find_element_user(PRESTADORSERVICO$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "PrestadorServico" element
     */
    public void setPrestadorServico(br.org.abrasf.nfse.TcDadosPrestador prestadorServico)
    {
        generatedSetterHelperImpl(prestadorServico, PRESTADORSERVICO$14, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "PrestadorServico" element
     */
    public br.org.abrasf.nfse.TcDadosPrestador addNewPrestadorServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosPrestador target = null;
            target = (br.org.abrasf.nfse.TcDadosPrestador)get_store().add_element_user(PRESTADORSERVICO$14);
            return target;
        }
    }
    
    /**
     * Gets the "OrgaoGerador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador getOrgaoGerador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador)get_store().find_element_user(ORGAOGERADOR$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "OrgaoGerador" element
     */
    public void setOrgaoGerador(br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador orgaoGerador)
    {
        generatedSetterHelperImpl(orgaoGerador, ORGAOGERADOR$16, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "OrgaoGerador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador addNewOrgaoGerador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador)get_store().add_element_user(ORGAOGERADOR$16);
            return target;
        }
    }
    
    /**
     * Gets the "DeclaracaoPrestacaoServico" element
     */
    public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getDeclaracaoPrestacaoServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
            target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().find_element_user(DECLARACAOPRESTACAOSERVICO$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "DeclaracaoPrestacaoServico" element
     */
    public void setDeclaracaoPrestacaoServico(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico declaracaoPrestacaoServico)
    {
        generatedSetterHelperImpl(declaracaoPrestacaoServico, DECLARACAOPRESTACAOSERVICO$18, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "DeclaracaoPrestacaoServico" element
     */
    public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewDeclaracaoPrestacaoServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
            target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().add_element_user(DECLARACAOPRESTACAOSERVICO$18);
            return target;
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$20);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$20) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$20);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$20);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$20);
        }
    }
}
