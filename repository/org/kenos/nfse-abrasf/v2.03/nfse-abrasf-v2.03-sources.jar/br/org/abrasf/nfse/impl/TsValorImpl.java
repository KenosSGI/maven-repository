/*
 * XML Type:  tsValor
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsValor
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsValor(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsValor.
 */
public class TsValorImpl extends org.apache.xmlbeans.impl.values.JavaDecimalHolderEx implements br.org.abrasf.nfse.TsValor
{
    private static final long serialVersionUID = 1L;
    
    public TsValorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsValorImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
