/*
 * XML Type:  tsComplementoEndereco
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsComplementoEndereco
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsComplementoEndereco(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsComplementoEndereco.
 */
public class TsComplementoEnderecoImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsComplementoEndereco
{
    private static final long serialVersionUID = 1L;
    
    public TsComplementoEnderecoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsComplementoEnderecoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
