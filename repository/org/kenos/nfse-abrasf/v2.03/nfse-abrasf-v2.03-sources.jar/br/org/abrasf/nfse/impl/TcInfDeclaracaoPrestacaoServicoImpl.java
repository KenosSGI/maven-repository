/*
 * XML Type:  tcInfDeclaracaoPrestacaoServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcInfDeclaracaoPrestacaoServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcInfDeclaracaoPrestacaoServicoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico
{
    private static final long serialVersionUID = 1L;
    
    public TcInfDeclaracaoPrestacaoServicoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RPS$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Rps");
    private static final javax.xml.namespace.QName COMPETENCIA$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Competencia");
    private static final javax.xml.namespace.QName SERVICO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Servico");
    private static final javax.xml.namespace.QName PRESTADOR$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Prestador");
    private static final javax.xml.namespace.QName TOMADOR$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Tomador");
    private static final javax.xml.namespace.QName INTERMEDIARIO$10 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Intermediario");
    private static final javax.xml.namespace.QName CONSTRUCAOCIVIL$12 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ConstrucaoCivil");
    private static final javax.xml.namespace.QName REGIMEESPECIALTRIBUTACAO$14 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RegimeEspecialTributacao");
    private static final javax.xml.namespace.QName OPTANTESIMPLESNACIONAL$16 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "OptanteSimplesNacional");
    private static final javax.xml.namespace.QName INCENTIVOFISCAL$18 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IncentivoFiscal");
    private static final javax.xml.namespace.QName ID$20 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "Rps" element
     */
    public br.org.abrasf.nfse.TcInfRps getRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfRps target = null;
            target = (br.org.abrasf.nfse.TcInfRps)get_store().find_element_user(RPS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Rps" element
     */
    public boolean isSetRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RPS$0) != 0;
        }
    }
    
    /**
     * Sets the "Rps" element
     */
    public void setRps(br.org.abrasf.nfse.TcInfRps rps)
    {
        generatedSetterHelperImpl(rps, RPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Rps" element
     */
    public br.org.abrasf.nfse.TcInfRps addNewRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcInfRps target = null;
            target = (br.org.abrasf.nfse.TcInfRps)get_store().add_element_user(RPS$0);
            return target;
        }
    }
    
    /**
     * Unsets the "Rps" element
     */
    public void unsetRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RPS$0, 0);
        }
    }
    
    /**
     * Gets the "Competencia" element
     */
    public java.util.Calendar getCompetencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPETENCIA$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "Competencia" element
     */
    public org.apache.xmlbeans.XmlDate xgetCompetencia()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(COMPETENCIA$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Competencia" element
     */
    public void setCompetencia(java.util.Calendar competencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPETENCIA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMPETENCIA$2);
            }
            target.setCalendarValue(competencia);
        }
    }
    
    /**
     * Sets (as xml) the "Competencia" element
     */
    public void xsetCompetencia(org.apache.xmlbeans.XmlDate competencia)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(COMPETENCIA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(COMPETENCIA$2);
            }
            target.set(competencia);
        }
    }
    
    /**
     * Gets the "Servico" element
     */
    public br.org.abrasf.nfse.TcDadosServico getServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosServico target = null;
            target = (br.org.abrasf.nfse.TcDadosServico)get_store().find_element_user(SERVICO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Servico" element
     */
    public void setServico(br.org.abrasf.nfse.TcDadosServico servico)
    {
        generatedSetterHelperImpl(servico, SERVICO$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Servico" element
     */
    public br.org.abrasf.nfse.TcDadosServico addNewServico()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosServico target = null;
            target = (br.org.abrasf.nfse.TcDadosServico)get_store().add_element_user(SERVICO$4);
            return target;
        }
    }
    
    /**
     * Gets the "Prestador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().find_element_user(PRESTADOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Prestador" element
     */
    public void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador)
    {
        generatedSetterHelperImpl(prestador, PRESTADOR$6, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Prestador" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoPrestador target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoPrestador)get_store().add_element_user(PRESTADOR$6);
            return target;
        }
    }
    
    /**
     * Gets the "Tomador" element
     */
    public br.org.abrasf.nfse.TcDadosTomador getTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosTomador target = null;
            target = (br.org.abrasf.nfse.TcDadosTomador)get_store().find_element_user(TOMADOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Tomador" element
     */
    public boolean isSetTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TOMADOR$8) != 0;
        }
    }
    
    /**
     * Sets the "Tomador" element
     */
    public void setTomador(br.org.abrasf.nfse.TcDadosTomador tomador)
    {
        generatedSetterHelperImpl(tomador, TOMADOR$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Tomador" element
     */
    public br.org.abrasf.nfse.TcDadosTomador addNewTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosTomador target = null;
            target = (br.org.abrasf.nfse.TcDadosTomador)get_store().add_element_user(TOMADOR$8);
            return target;
        }
    }
    
    /**
     * Unsets the "Tomador" element
     */
    public void unsetTomador()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TOMADOR$8, 0);
        }
    }
    
    /**
     * Gets the "Intermediario" element
     */
    public br.org.abrasf.nfse.TcDadosIntermediario getIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosIntermediario target = null;
            target = (br.org.abrasf.nfse.TcDadosIntermediario)get_store().find_element_user(INTERMEDIARIO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Intermediario" element
     */
    public boolean isSetIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERMEDIARIO$10) != 0;
        }
    }
    
    /**
     * Sets the "Intermediario" element
     */
    public void setIntermediario(br.org.abrasf.nfse.TcDadosIntermediario intermediario)
    {
        generatedSetterHelperImpl(intermediario, INTERMEDIARIO$10, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Intermediario" element
     */
    public br.org.abrasf.nfse.TcDadosIntermediario addNewIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosIntermediario target = null;
            target = (br.org.abrasf.nfse.TcDadosIntermediario)get_store().add_element_user(INTERMEDIARIO$10);
            return target;
        }
    }
    
    /**
     * Unsets the "Intermediario" element
     */
    public void unsetIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERMEDIARIO$10, 0);
        }
    }
    
    /**
     * Gets the "ConstrucaoCivil" element
     */
    public br.org.abrasf.nfse.TcDadosConstrucaoCivil getConstrucaoCivil()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosConstrucaoCivil target = null;
            target = (br.org.abrasf.nfse.TcDadosConstrucaoCivil)get_store().find_element_user(CONSTRUCAOCIVIL$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ConstrucaoCivil" element
     */
    public boolean isSetConstrucaoCivil()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONSTRUCAOCIVIL$12) != 0;
        }
    }
    
    /**
     * Sets the "ConstrucaoCivil" element
     */
    public void setConstrucaoCivil(br.org.abrasf.nfse.TcDadosConstrucaoCivil construcaoCivil)
    {
        generatedSetterHelperImpl(construcaoCivil, CONSTRUCAOCIVIL$12, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ConstrucaoCivil" element
     */
    public br.org.abrasf.nfse.TcDadosConstrucaoCivil addNewConstrucaoCivil()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcDadosConstrucaoCivil target = null;
            target = (br.org.abrasf.nfse.TcDadosConstrucaoCivil)get_store().add_element_user(CONSTRUCAOCIVIL$12);
            return target;
        }
    }
    
    /**
     * Unsets the "ConstrucaoCivil" element
     */
    public void unsetConstrucaoCivil()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONSTRUCAOCIVIL$12, 0);
        }
    }
    
    /**
     * Gets the "RegimeEspecialTributacao" element
     */
    public byte getRegimeEspecialTributacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGIMEESPECIALTRIBUTACAO$14, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "RegimeEspecialTributacao" element
     */
    public br.org.abrasf.nfse.TsRegimeEspecialTributacao xgetRegimeEspecialTributacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRegimeEspecialTributacao target = null;
            target = (br.org.abrasf.nfse.TsRegimeEspecialTributacao)get_store().find_element_user(REGIMEESPECIALTRIBUTACAO$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "RegimeEspecialTributacao" element
     */
    public boolean isSetRegimeEspecialTributacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REGIMEESPECIALTRIBUTACAO$14) != 0;
        }
    }
    
    /**
     * Sets the "RegimeEspecialTributacao" element
     */
    public void setRegimeEspecialTributacao(byte regimeEspecialTributacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REGIMEESPECIALTRIBUTACAO$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REGIMEESPECIALTRIBUTACAO$14);
            }
            target.setByteValue(regimeEspecialTributacao);
        }
    }
    
    /**
     * Sets (as xml) the "RegimeEspecialTributacao" element
     */
    public void xsetRegimeEspecialTributacao(br.org.abrasf.nfse.TsRegimeEspecialTributacao regimeEspecialTributacao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRegimeEspecialTributacao target = null;
            target = (br.org.abrasf.nfse.TsRegimeEspecialTributacao)get_store().find_element_user(REGIMEESPECIALTRIBUTACAO$14, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsRegimeEspecialTributacao)get_store().add_element_user(REGIMEESPECIALTRIBUTACAO$14);
            }
            target.set(regimeEspecialTributacao);
        }
    }
    
    /**
     * Unsets the "RegimeEspecialTributacao" element
     */
    public void unsetRegimeEspecialTributacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REGIMEESPECIALTRIBUTACAO$14, 0);
        }
    }
    
    /**
     * Gets the "OptanteSimplesNacional" element
     */
    public byte getOptanteSimplesNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPTANTESIMPLESNACIONAL$16, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "OptanteSimplesNacional" element
     */
    public br.org.abrasf.nfse.TsSimNao xgetOptanteSimplesNacional()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(OPTANTESIMPLESNACIONAL$16, 0);
            return target;
        }
    }
    
    /**
     * Sets the "OptanteSimplesNacional" element
     */
    public void setOptanteSimplesNacional(byte optanteSimplesNacional)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPTANTESIMPLESNACIONAL$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPTANTESIMPLESNACIONAL$16);
            }
            target.setByteValue(optanteSimplesNacional);
        }
    }
    
    /**
     * Sets (as xml) the "OptanteSimplesNacional" element
     */
    public void xsetOptanteSimplesNacional(br.org.abrasf.nfse.TsSimNao optanteSimplesNacional)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(OPTANTESIMPLESNACIONAL$16, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsSimNao)get_store().add_element_user(OPTANTESIMPLESNACIONAL$16);
            }
            target.set(optanteSimplesNacional);
        }
    }
    
    /**
     * Gets the "IncentivoFiscal" element
     */
    public byte getIncentivoFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCENTIVOFISCAL$18, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "IncentivoFiscal" element
     */
    public br.org.abrasf.nfse.TsSimNao xgetIncentivoFiscal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(INCENTIVOFISCAL$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "IncentivoFiscal" element
     */
    public void setIncentivoFiscal(byte incentivoFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCENTIVOFISCAL$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INCENTIVOFISCAL$18);
            }
            target.setByteValue(incentivoFiscal);
        }
    }
    
    /**
     * Sets (as xml) the "IncentivoFiscal" element
     */
    public void xsetIncentivoFiscal(br.org.abrasf.nfse.TsSimNao incentivoFiscal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSimNao target = null;
            target = (br.org.abrasf.nfse.TsSimNao)get_store().find_element_user(INCENTIVOFISCAL$18, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsSimNao)get_store().add_element_user(INCENTIVOFISCAL$18);
            }
            target.set(incentivoFiscal);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$20);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$20) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$20);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$20);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$20);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$20);
        }
    }
}
