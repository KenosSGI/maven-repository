/*
 * XML Type:  tcDadosIntermediario
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcDadosIntermediario
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcDadosIntermediario(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcDadosIntermediarioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcDadosIntermediario
{
    private static final long serialVersionUID = 1L;
    
    public TcDadosIntermediarioImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAOINTERMEDIARIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoIntermediario");
    private static final javax.xml.namespace.QName RAZAOSOCIAL$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RazaoSocial");
    private static final javax.xml.namespace.QName CODIGOMUNICIPIO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoMunicipio");
    
    
    /**
     * Gets the "IdentificacaoIntermediario" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoIntermediario getIdentificacaoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoIntermediario target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoIntermediario)get_store().find_element_user(IDENTIFICACAOINTERMEDIARIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "IdentificacaoIntermediario" element
     */
    public void setIdentificacaoIntermediario(br.org.abrasf.nfse.TcIdentificacaoIntermediario identificacaoIntermediario)
    {
        generatedSetterHelperImpl(identificacaoIntermediario, IDENTIFICACAOINTERMEDIARIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoIntermediario" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoIntermediario addNewIdentificacaoIntermediario()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoIntermediario target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoIntermediario)get_store().add_element_user(IDENTIFICACAOINTERMEDIARIO$0);
            return target;
        }
    }
    
    /**
     * Gets the "RazaoSocial" element
     */
    public java.lang.String getRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "RazaoSocial" element
     */
    public br.org.abrasf.nfse.TsRazaoSocial xgetRazaoSocial()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "RazaoSocial" element
     */
    public void setRazaoSocial(java.lang.String razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RAZAOSOCIAL$2);
            }
            target.setStringValue(razaoSocial);
        }
    }
    
    /**
     * Sets (as xml) the "RazaoSocial" element
     */
    public void xsetRazaoSocial(br.org.abrasf.nfse.TsRazaoSocial razaoSocial)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsRazaoSocial target = null;
            target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().find_element_user(RAZAOSOCIAL$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsRazaoSocial)get_store().add_element_user(RAZAOSOCIAL$2);
            }
            target.set(razaoSocial);
        }
    }
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    public int getCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    public void setCodigoMunicipio(int codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOMUNICIPIO$4);
            }
            target.setIntValue(codigoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    public void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(CODIGOMUNICIPIO$4);
            }
            target.set(codigoMunicipio);
        }
    }
}
