/*
 * An XML document type.
 * Localname: EnviarLoteRpsSincronoEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one EnviarLoteRpsSincronoEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface EnviarLoteRpsSincronoEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EnviarLoteRpsSincronoEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("enviarloterpssincronoenvio2727doctype");
    
    /**
     * Gets the "EnviarLoteRpsSincronoEnvio" element
     */
    br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio getEnviarLoteRpsSincronoEnvio();
    
    /**
     * Sets the "EnviarLoteRpsSincronoEnvio" element
     */
    void setEnviarLoteRpsSincronoEnvio(br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio enviarLoteRpsSincronoEnvio);
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsSincronoEnvio" element
     */
    br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio addNewEnviarLoteRpsSincronoEnvio();
    
    /**
     * An XML EnviarLoteRpsSincronoEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface EnviarLoteRpsSincronoEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EnviarLoteRpsSincronoEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("enviarloterpssincronoenvio4e55elemtype");
        
        /**
         * Gets the "LoteRps" element
         */
        br.org.abrasf.nfse.TcLoteRps getLoteRps();
        
        /**
         * Sets the "LoteRps" element
         */
        void setLoteRps(br.org.abrasf.nfse.TcLoteRps loteRps);
        
        /**
         * Appends and returns a new empty "LoteRps" element
         */
        br.org.abrasf.nfse.TcLoteRps addNewLoteRps();
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * True if has "Signature" element
         */
        boolean isSetSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * Unsets the "Signature" element
         */
        void unsetSignature();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio newInstance() {
              return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument.EnviarLoteRpsSincronoEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.EnviarLoteRpsSincronoEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
