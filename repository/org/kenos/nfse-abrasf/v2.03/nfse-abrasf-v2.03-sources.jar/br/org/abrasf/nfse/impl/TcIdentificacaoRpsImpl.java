/*
 * XML Type:  tcIdentificacaoRps
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcIdentificacaoRps
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcIdentificacaoRps(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcIdentificacaoRpsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcIdentificacaoRps
{
    private static final long serialVersionUID = 1L;
    
    public TcIdentificacaoRpsImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMERO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Numero");
    private static final javax.xml.namespace.QName SERIE$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Serie");
    private static final javax.xml.namespace.QName TIPO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Tipo");
    
    
    /**
     * Gets the "Numero" element
     */
    public long getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public br.org.abrasf.nfse.TsNumeroRps xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroRps target = null;
            target = (br.org.abrasf.nfse.TsNumeroRps)get_store().find_element_user(NUMERO$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(long numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$0);
            }
            target.setLongValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(br.org.abrasf.nfse.TsNumeroRps numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroRps target = null;
            target = (br.org.abrasf.nfse.TsNumeroRps)get_store().find_element_user(NUMERO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroRps)get_store().add_element_user(NUMERO$0);
            }
            target.set(numero);
        }
    }
    
    /**
     * Gets the "Serie" element
     */
    public java.lang.String getSerie()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Serie" element
     */
    public br.org.abrasf.nfse.TsSerieRps xgetSerie()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSerieRps target = null;
            target = (br.org.abrasf.nfse.TsSerieRps)get_store().find_element_user(SERIE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Serie" element
     */
    public void setSerie(java.lang.String serie)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERIE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERIE$2);
            }
            target.setStringValue(serie);
        }
    }
    
    /**
     * Sets (as xml) the "Serie" element
     */
    public void xsetSerie(br.org.abrasf.nfse.TsSerieRps serie)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsSerieRps target = null;
            target = (br.org.abrasf.nfse.TsSerieRps)get_store().find_element_user(SERIE$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsSerieRps)get_store().add_element_user(SERIE$2);
            }
            target.set(serie);
        }
    }
    
    /**
     * Gets the "Tipo" element
     */
    public byte getTipo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPO$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "Tipo" element
     */
    public br.org.abrasf.nfse.TsTipoRps xgetTipo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsTipoRps target = null;
            target = (br.org.abrasf.nfse.TsTipoRps)get_store().find_element_user(TIPO$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "Tipo" element
     */
    public void setTipo(byte tipo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIPO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIPO$4);
            }
            target.setByteValue(tipo);
        }
    }
    
    /**
     * Sets (as xml) the "Tipo" element
     */
    public void xsetTipo(br.org.abrasf.nfse.TsTipoRps tipo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsTipoRps target = null;
            target = (br.org.abrasf.nfse.TsTipoRps)get_store().find_element_user(TIPO$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsTipoRps)get_store().add_element_user(TIPO$4);
            }
            target.set(tipo);
        }
    }
}
