/*
 * An XML document type.
 * Localname: GerarNfseEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.GerarNfseEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one GerarNfseEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class GerarNfseEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.GerarNfseEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public GerarNfseEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GERARNFSEENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "GerarNfseEnvio");
    
    
    /**
     * Gets the "GerarNfseEnvio" element
     */
    public br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio getGerarNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio target = null;
            target = (br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio)get_store().find_element_user(GERARNFSEENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "GerarNfseEnvio" element
     */
    public void setGerarNfseEnvio(br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio gerarNfseEnvio)
    {
        generatedSetterHelperImpl(gerarNfseEnvio, GERARNFSEENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "GerarNfseEnvio" element
     */
    public br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio addNewGerarNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio target = null;
            target = (br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio)get_store().add_element_user(GERARNFSEENVIO$0);
            return target;
        }
    }
    /**
     * An XML GerarNfseEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class GerarNfseEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.GerarNfseEnvioDocument.GerarNfseEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public GerarNfseEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RPS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Rps");
        
        
        /**
         * Gets the "Rps" element
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().find_element_user(RPS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Rps" element
         */
        public void setRps(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico rps)
        {
            generatedSetterHelperImpl(rps, RPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Rps" element
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().add_element_user(RPS$0);
                return target;
            }
        }
    }
}
