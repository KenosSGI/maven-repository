/*
 * XML Type:  tsInscricaoMunicipal
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsInscricaoMunicipal
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsInscricaoMunicipal(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsInscricaoMunicipal.
 */
public class TsInscricaoMunicipalImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsInscricaoMunicipal
{
    private static final long serialVersionUID = 1L;
    
    public TsInscricaoMunicipalImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsInscricaoMunicipalImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
