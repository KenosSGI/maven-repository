/*
 * XML Type:  tsSimNao
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsSimNao
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsSimNao(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsSimNao.
 */
public class TsSimNaoImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements br.org.abrasf.nfse.TsSimNao
{
    private static final long serialVersionUID = 1L;
    
    public TsSimNaoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsSimNaoImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
