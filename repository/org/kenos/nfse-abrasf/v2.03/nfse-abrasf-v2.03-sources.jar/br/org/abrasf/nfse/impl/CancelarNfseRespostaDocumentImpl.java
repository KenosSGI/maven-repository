/*
 * An XML document type.
 * Localname: CancelarNfseResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.CancelarNfseRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one CancelarNfseResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class CancelarNfseRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CancelarNfseRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public CancelarNfseRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CANCELARNFSERESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CancelarNfseResposta");
    
    
    /**
     * Gets the "CancelarNfseResposta" element
     */
    public br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta getCancelarNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta target = null;
            target = (br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta)get_store().find_element_user(CANCELARNFSERESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CancelarNfseResposta" element
     */
    public void setCancelarNfseResposta(br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta cancelarNfseResposta)
    {
        generatedSetterHelperImpl(cancelarNfseResposta, CANCELARNFSERESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CancelarNfseResposta" element
     */
    public br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta addNewCancelarNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta target = null;
            target = (br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta)get_store().add_element_user(CANCELARNFSERESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML CancelarNfseResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class CancelarNfseRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CancelarNfseRespostaDocument.CancelarNfseResposta
    {
        private static final long serialVersionUID = 1L;
        
        public CancelarNfseRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RETCANCELAMENTO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "RetCancelamento");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "RetCancelamento" element
         */
        public br.org.abrasf.nfse.TcRetCancelamento getRetCancelamento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcRetCancelamento target = null;
                target = (br.org.abrasf.nfse.TcRetCancelamento)get_store().find_element_user(RETCANCELAMENTO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "RetCancelamento" element
         */
        public boolean isSetRetCancelamento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RETCANCELAMENTO$0) != 0;
            }
        }
        
        /**
         * Sets the "RetCancelamento" element
         */
        public void setRetCancelamento(br.org.abrasf.nfse.TcRetCancelamento retCancelamento)
        {
            generatedSetterHelperImpl(retCancelamento, RETCANCELAMENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "RetCancelamento" element
         */
        public br.org.abrasf.nfse.TcRetCancelamento addNewRetCancelamento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcRetCancelamento target = null;
                target = (br.org.abrasf.nfse.TcRetCancelamento)get_store().add_element_user(RETCANCELAMENTO$0);
                return target;
            }
        }
        
        /**
         * Unsets the "RetCancelamento" element
         */
        public void unsetRetCancelamento()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RETCANCELAMENTO$0, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$2, 0);
            }
        }
    }
}
