/*
 * XML Type:  tcLoteRps
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcLoteRps
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcLoteRps(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcLoteRpsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcLoteRps
{
    private static final long serialVersionUID = 1L;
    
    public TcLoteRpsImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMEROLOTE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NumeroLote");
    private static final javax.xml.namespace.QName CPFCNPJ$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CpfCnpj");
    private static final javax.xml.namespace.QName INSCRICAOMUNICIPAL$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "InscricaoMunicipal");
    private static final javax.xml.namespace.QName QUANTIDADERPS$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "QuantidadeRps");
    private static final javax.xml.namespace.QName LISTARPS$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaRps");
    private static final javax.xml.namespace.QName ID$10 = 
        new javax.xml.namespace.QName("", "Id");
    private static final javax.xml.namespace.QName VERSAO$12 = 
        new javax.xml.namespace.QName("", "versao");
    
    
    /**
     * Gets the "NumeroLote" element
     */
    public long getNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "NumeroLote" element
     */
    public br.org.abrasf.nfse.TsNumeroLote xgetNumeroLote()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroLote target = null;
            target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "NumeroLote" element
     */
    public void setNumeroLote(long numeroLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMEROLOTE$0);
            }
            target.setLongValue(numeroLote);
        }
    }
    
    /**
     * Sets (as xml) the "NumeroLote" element
     */
    public void xsetNumeroLote(br.org.abrasf.nfse.TsNumeroLote numeroLote)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroLote target = null;
            target = (br.org.abrasf.nfse.TsNumeroLote)get_store().find_element_user(NUMEROLOTE$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroLote)get_store().add_element_user(NUMEROLOTE$0);
            }
            target.set(numeroLote);
        }
    }
    
    /**
     * Gets the "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj getCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().find_element_user(CPFCNPJ$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CpfCnpj" element
     */
    public void setCpfCnpj(br.org.abrasf.nfse.TcCpfCnpj cpfCnpj)
    {
        generatedSetterHelperImpl(cpfCnpj, CPFCNPJ$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj addNewCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().add_element_user(CPFCNPJ$2);
            return target;
        }
    }
    
    /**
     * Gets the "InscricaoMunicipal" element
     */
    public java.lang.String getInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoMunicipal" element
     */
    public br.org.abrasf.nfse.TsInscricaoMunicipal xgetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoMunicipal" element
     */
    public boolean isSetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOMUNICIPAL$4) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoMunicipal" element
     */
    public void setInscricaoMunicipal(java.lang.String inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOMUNICIPAL$4);
            }
            target.setStringValue(inscricaoMunicipal);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoMunicipal" element
     */
    public void xsetInscricaoMunicipal(br.org.abrasf.nfse.TsInscricaoMunicipal inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().add_element_user(INSCRICAOMUNICIPAL$4);
            }
            target.set(inscricaoMunicipal);
        }
    }
    
    /**
     * Unsets the "InscricaoMunicipal" element
     */
    public void unsetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOMUNICIPAL$4, 0);
        }
    }
    
    /**
     * Gets the "QuantidadeRps" element
     */
    public int getQuantidadeRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QUANTIDADERPS$6, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "QuantidadeRps" element
     */
    public br.org.abrasf.nfse.TsQuantidadeRps xgetQuantidadeRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsQuantidadeRps target = null;
            target = (br.org.abrasf.nfse.TsQuantidadeRps)get_store().find_element_user(QUANTIDADERPS$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "QuantidadeRps" element
     */
    public void setQuantidadeRps(int quantidadeRps)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(QUANTIDADERPS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(QUANTIDADERPS$6);
            }
            target.setIntValue(quantidadeRps);
        }
    }
    
    /**
     * Sets (as xml) the "QuantidadeRps" element
     */
    public void xsetQuantidadeRps(br.org.abrasf.nfse.TsQuantidadeRps quantidadeRps)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsQuantidadeRps target = null;
            target = (br.org.abrasf.nfse.TsQuantidadeRps)get_store().find_element_user(QUANTIDADERPS$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsQuantidadeRps)get_store().add_element_user(QUANTIDADERPS$6);
            }
            target.set(quantidadeRps);
        }
    }
    
    /**
     * Gets the "ListaRps" element
     */
    public br.org.abrasf.nfse.TcLoteRps.ListaRps getListaRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcLoteRps.ListaRps target = null;
            target = (br.org.abrasf.nfse.TcLoteRps.ListaRps)get_store().find_element_user(LISTARPS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ListaRps" element
     */
    public void setListaRps(br.org.abrasf.nfse.TcLoteRps.ListaRps listaRps)
    {
        generatedSetterHelperImpl(listaRps, LISTARPS$8, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaRps" element
     */
    public br.org.abrasf.nfse.TcLoteRps.ListaRps addNewListaRps()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcLoteRps.ListaRps target = null;
            target = (br.org.abrasf.nfse.TcLoteRps.ListaRps)get_store().add_element_user(LISTARPS$8);
            return target;
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$10);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$10);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$10) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$10);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$10);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$10);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$10);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$10);
        }
    }
    
    /**
     * Gets the "versao" attribute
     */
    public java.lang.String getVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$12);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    public br.org.abrasf.nfse.TsVersao xgetVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$12);
            return target;
        }
    }
    
    /**
     * Sets the "versao" attribute
     */
    public void setVersao(java.lang.String versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$12);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$12);
            }
            target.setStringValue(versao);
        }
    }
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    public void xsetVersao(br.org.abrasf.nfse.TsVersao versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$12);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsVersao)get_store().add_attribute_user(VERSAO$12);
            }
            target.set(versao);
        }
    }
    /**
     * An XML ListaRps(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ListaRpsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcLoteRps.ListaRps
    {
        private static final long serialVersionUID = 1L;
        
        public ListaRpsImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RPS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Rps");
        
        
        /**
         * Gets array of all "Rps" elements
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[] getRpsArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(RPS$0, targetList);
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[] result = new br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "Rps" element
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getRpsArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().find_element_user(RPS$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "Rps" element
         */
        public int sizeOfRpsArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RPS$0);
            }
        }
        
        /**
         * Sets array of all "Rps" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setRpsArray(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico[] rpsArray)
        {
            check_orphaned();
            arraySetterHelper(rpsArray, RPS$0);
        }
        
        /**
         * Sets ith "Rps" element
         */
        public void setRpsArray(int i, br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico rps)
        {
            generatedSetterHelperImpl(rps, RPS$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "Rps" element
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico insertNewRps(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().insert_element_user(RPS$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "Rps" element
         */
        public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().add_element_user(RPS$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "Rps" element
         */
        public void removeRps(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RPS$0, i);
            }
        }
    }
}
