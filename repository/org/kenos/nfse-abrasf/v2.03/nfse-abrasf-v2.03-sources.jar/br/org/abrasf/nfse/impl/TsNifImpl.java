/*
 * XML Type:  tsNif
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsNif
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsNif(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsNif.
 */
public class TsNifImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsNif
{
    private static final long serialVersionUID = 1L;
    
    public TsNifImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsNifImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
