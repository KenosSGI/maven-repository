/*
 * An XML document type.
 * Localname: ListaMensagemAlertaRetorno
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ListaMensagemAlertaRetorno(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ListaMensagemAlertaRetornoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument
{
    private static final long serialVersionUID = 1L;
    
    public ListaMensagemAlertaRetornoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTAMENSAGEMALERTARETORNO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemAlertaRetorno");
    
    
    /**
     * Gets the "ListaMensagemAlertaRetorno" element
     */
    public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
            target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().find_element_user(LISTAMENSAGEMALERTARETORNO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ListaMensagemAlertaRetorno" element
     */
    public void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno)
    {
        generatedSetterHelperImpl(listaMensagemAlertaRetorno, LISTAMENSAGEMALERTARETORNO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
     */
    public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
            target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().add_element_user(LISTAMENSAGEMALERTARETORNO$0);
            return target;
        }
    }
    /**
     * An XML ListaMensagemAlertaRetorno(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ListaMensagemAlertaRetornoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno
    {
        private static final long serialVersionUID = 1L;
        
        public ListaMensagemAlertaRetornoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENSAGEMRETORNO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "MensagemRetorno");
        
        
        /**
         * Gets array of all "MensagemRetorno" elements
         */
        public br.org.abrasf.nfse.TcMensagemRetorno[] getMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MENSAGEMRETORNO$0, targetList);
                br.org.abrasf.nfse.TcMensagemRetorno[] result = new br.org.abrasf.nfse.TcMensagemRetorno[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno getMensagemRetornoArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().find_element_user(MENSAGEMRETORNO$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "MensagemRetorno" element
         */
        public int sizeOfMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENSAGEMRETORNO$0);
            }
        }
        
        /**
         * Sets array of all "MensagemRetorno" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setMensagemRetornoArray(br.org.abrasf.nfse.TcMensagemRetorno[] mensagemRetornoArray)
        {
            check_orphaned();
            arraySetterHelper(mensagemRetornoArray, MENSAGEMRETORNO$0);
        }
        
        /**
         * Sets ith "MensagemRetorno" element
         */
        public void setMensagemRetornoArray(int i, br.org.abrasf.nfse.TcMensagemRetorno mensagemRetorno)
        {
            generatedSetterHelperImpl(mensagemRetorno, MENSAGEMRETORNO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno insertNewMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().insert_element_user(MENSAGEMRETORNO$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno addNewMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().add_element_user(MENSAGEMRETORNO$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "MensagemRetorno" element
         */
        public void removeMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENSAGEMRETORNO$0, i);
            }
        }
    }
}
