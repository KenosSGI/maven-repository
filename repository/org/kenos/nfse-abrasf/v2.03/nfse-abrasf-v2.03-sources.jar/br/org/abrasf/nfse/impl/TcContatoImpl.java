/*
 * XML Type:  tcContato
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcContato
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcContato(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcContatoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcContato
{
    private static final long serialVersionUID = 1L;
    
    public TcContatoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TELEFONE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Telefone");
    private static final javax.xml.namespace.QName EMAIL$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Email");
    
    
    /**
     * Gets the "Telefone" element
     */
    public java.lang.String getTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Telefone" element
     */
    public br.org.abrasf.nfse.TsTelefone xgetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsTelefone target = null;
            target = (br.org.abrasf.nfse.TsTelefone)get_store().find_element_user(TELEFONE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "Telefone" element
     */
    public boolean isSetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TELEFONE$0) != 0;
        }
    }
    
    /**
     * Sets the "Telefone" element
     */
    public void setTelefone(java.lang.String telefone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TELEFONE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TELEFONE$0);
            }
            target.setStringValue(telefone);
        }
    }
    
    /**
     * Sets (as xml) the "Telefone" element
     */
    public void xsetTelefone(br.org.abrasf.nfse.TsTelefone telefone)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsTelefone target = null;
            target = (br.org.abrasf.nfse.TsTelefone)get_store().find_element_user(TELEFONE$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsTelefone)get_store().add_element_user(TELEFONE$0);
            }
            target.set(telefone);
        }
    }
    
    /**
     * Unsets the "Telefone" element
     */
    public void unsetTelefone()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TELEFONE$0, 0);
        }
    }
    
    /**
     * Gets the "Email" element
     */
    public java.lang.String getEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Email" element
     */
    public br.org.abrasf.nfse.TsEmail xgetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsEmail target = null;
            target = (br.org.abrasf.nfse.TsEmail)get_store().find_element_user(EMAIL$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Email" element
     */
    public boolean isSetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EMAIL$2) != 0;
        }
    }
    
    /**
     * Sets the "Email" element
     */
    public void setEmail(java.lang.String email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EMAIL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EMAIL$2);
            }
            target.setStringValue(email);
        }
    }
    
    /**
     * Sets (as xml) the "Email" element
     */
    public void xsetEmail(br.org.abrasf.nfse.TsEmail email)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsEmail target = null;
            target = (br.org.abrasf.nfse.TsEmail)get_store().find_element_user(EMAIL$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsEmail)get_store().add_element_user(EMAIL$2);
            }
            target.set(email);
        }
    }
    
    /**
     * Unsets the "Email" element
     */
    public void unsetEmail()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EMAIL$2, 0);
        }
    }
}
