/*
 * An XML document type.
 * Localname: GerarNfseResposta
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.GerarNfseRespostaDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one GerarNfseResposta(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class GerarNfseRespostaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.GerarNfseRespostaDocument
{
    private static final long serialVersionUID = 1L;
    
    public GerarNfseRespostaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GERARNFSERESPOSTA$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "GerarNfseResposta");
    
    
    /**
     * Gets the "GerarNfseResposta" element
     */
    public br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta getGerarNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta target = null;
            target = (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta)get_store().find_element_user(GERARNFSERESPOSTA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "GerarNfseResposta" element
     */
    public void setGerarNfseResposta(br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta gerarNfseResposta)
    {
        generatedSetterHelperImpl(gerarNfseResposta, GERARNFSERESPOSTA$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "GerarNfseResposta" element
     */
    public br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta addNewGerarNfseResposta()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta target = null;
            target = (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta)get_store().add_element_user(GERARNFSERESPOSTA$0);
            return target;
        }
    }
    /**
     * An XML GerarNfseResposta(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class GerarNfseRespostaImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta
    {
        private static final long serialVersionUID = 1L;
        
        public GerarNfseRespostaImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName LISTANFSE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaNfse");
        private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$2 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
        
        
        /**
         * Gets the "ListaNfse" element
         */
        public br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse getListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse)get_store().find_element_user(LISTANFSE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaNfse" element
         */
        public boolean isSetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTANFSE$0) != 0;
            }
        }
        
        /**
         * Sets the "ListaNfse" element
         */
        public void setListaNfse(br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse listaNfse)
        {
            generatedSetterHelperImpl(listaNfse, LISTANFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaNfse" element
         */
        public br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse addNewListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse target = null;
                target = (br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse)get_store().add_element_user(LISTANFSE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaNfse" element
         */
        public void unsetListaNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTANFSE$0, 0);
            }
        }
        
        /**
         * Gets the "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "ListaMensagemRetorno" element
         */
        public boolean isSetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTAMENSAGEMRETORNO$2) != 0;
            }
        }
        
        /**
         * Sets the "ListaMensagemRetorno" element
         */
        public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
        {
            generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "ListaMensagemRetorno" element
         */
        public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$2);
                return target;
            }
        }
        
        /**
         * Unsets the "ListaMensagemRetorno" element
         */
        public void unsetListaMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTAMENSAGEMRETORNO$2, 0);
            }
        }
        /**
         * An XML ListaNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class ListaNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.GerarNfseRespostaDocument.GerarNfseResposta.ListaNfse
        {
            private static final long serialVersionUID = 1L;
            
            public ListaNfseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName COMPNFSE$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CompNfse");
            private static final javax.xml.namespace.QName LISTAMENSAGEMALERTARETORNO$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemAlertaRetorno");
            
            
            /**
             * Gets the "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse getCompNfse()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().find_element_user(COMPNFSE$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "CompNfse" element
             */
            public void setCompNfse(br.org.abrasf.nfse.TcCompNfse compNfse)
            {
                generatedSetterHelperImpl(compNfse, COMPNFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "CompNfse" element
             */
            public br.org.abrasf.nfse.TcCompNfse addNewCompNfse()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcCompNfse target = null;
                    target = (br.org.abrasf.nfse.TcCompNfse)get_store().add_element_user(COMPNFSE$0);
                    return target;
                }
            }
            
            /**
             * Gets the "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno getListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().find_element_user(LISTAMENSAGEMALERTARETORNO$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * True if has "ListaMensagemAlertaRetorno" element
             */
            public boolean isSetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(LISTAMENSAGEMALERTARETORNO$2) != 0;
                }
            }
            
            /**
             * Sets the "ListaMensagemAlertaRetorno" element
             */
            public void setListaMensagemAlertaRetorno(br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno listaMensagemAlertaRetorno)
            {
                generatedSetterHelperImpl(listaMensagemAlertaRetorno, LISTAMENSAGEMALERTARETORNO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "ListaMensagemAlertaRetorno" element
             */
            public br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno addNewListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno target = null;
                    target = (br.org.abrasf.nfse.ListaMensagemAlertaRetornoDocument.ListaMensagemAlertaRetorno)get_store().add_element_user(LISTAMENSAGEMALERTARETORNO$2);
                    return target;
                }
            }
            
            /**
             * Unsets the "ListaMensagemAlertaRetorno" element
             */
            public void unsetListaMensagemAlertaRetorno()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(LISTAMENSAGEMALERTARETORNO$2, 0);
                }
            }
        }
    }
}
