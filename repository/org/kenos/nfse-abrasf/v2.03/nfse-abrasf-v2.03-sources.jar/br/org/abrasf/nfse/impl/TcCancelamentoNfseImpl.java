/*
 * XML Type:  tcCancelamentoNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcCancelamentoNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcCancelamentoNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcCancelamentoNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcCancelamentoNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcCancelamentoNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CONFIRMACAO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Confirmacao");
    private static final javax.xml.namespace.QName SIGNATURE$2 = 
        new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
    private static final javax.xml.namespace.QName VERSAO$4 = 
        new javax.xml.namespace.QName("", "versao");
    
    
    /**
     * Gets the "Confirmacao" element
     */
    public br.org.abrasf.nfse.TcConfirmacaoCancelamento getConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcConfirmacaoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcConfirmacaoCancelamento)get_store().find_element_user(CONFIRMACAO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Confirmacao" element
     */
    public void setConfirmacao(br.org.abrasf.nfse.TcConfirmacaoCancelamento confirmacao)
    {
        generatedSetterHelperImpl(confirmacao, CONFIRMACAO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Confirmacao" element
     */
    public br.org.abrasf.nfse.TcConfirmacaoCancelamento addNewConfirmacao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcConfirmacaoCancelamento target = null;
            target = (br.org.abrasf.nfse.TcConfirmacaoCancelamento)get_store().add_element_user(CONFIRMACAO$0);
            return target;
        }
    }
    
    /**
     * Gets the "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "Signature" element
     */
    public boolean isSetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SIGNATURE$2) != 0;
        }
    }
    
    /**
     * Sets the "Signature" element
     */
    public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
    {
        generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Signature" element
     */
    public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.w3.x2000.x09.xmldsig.SignatureType target = null;
            target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "Signature" element
     */
    public void unsetSignature()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SIGNATURE$2, 0);
        }
    }
    
    /**
     * Gets the "versao" attribute
     */
    public java.lang.String getVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "versao" attribute
     */
    public br.org.abrasf.nfse.TsVersao xgetVersao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$4);
            return target;
        }
    }
    
    /**
     * Sets the "versao" attribute
     */
    public void setVersao(java.lang.String versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$4);
            }
            target.setStringValue(versao);
        }
    }
    
    /**
     * Sets (as xml) the "versao" attribute
     */
    public void xsetVersao(br.org.abrasf.nfse.TsVersao versao)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsVersao target = null;
            target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$4);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsVersao)get_store().add_attribute_user(VERSAO$4);
            }
            target.set(versao);
        }
    }
}
