/*
 * XML Type:  tcInfPedidoCancelamento
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfPedidoCancelamento
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcInfPedidoCancelamento(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcInfPedidoCancelamentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcInfPedidoCancelamento
{
    private static final long serialVersionUID = 1L;
    
    public TcInfPedidoCancelamentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName IDENTIFICACAONFSE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "IdentificacaoNfse");
    private static final javax.xml.namespace.QName CODIGOCANCELAMENTO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoCancelamento");
    private static final javax.xml.namespace.QName ID$4 = 
        new javax.xml.namespace.QName("", "Id");
    
    
    /**
     * Gets the "IdentificacaoNfse" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoNfse getIdentificacaoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoNfse target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoNfse)get_store().find_element_user(IDENTIFICACAONFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "IdentificacaoNfse" element
     */
    public void setIdentificacaoNfse(br.org.abrasf.nfse.TcIdentificacaoNfse identificacaoNfse)
    {
        generatedSetterHelperImpl(identificacaoNfse, IDENTIFICACAONFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "IdentificacaoNfse" element
     */
    public br.org.abrasf.nfse.TcIdentificacaoNfse addNewIdentificacaoNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcIdentificacaoNfse target = null;
            target = (br.org.abrasf.nfse.TcIdentificacaoNfse)get_store().add_element_user(IDENTIFICACAONFSE$0);
            return target;
        }
    }
    
    /**
     * Gets the "CodigoCancelamento" element
     */
    public byte getCodigoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCANCELAMENTO$2, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getByteValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoCancelamento" element
     */
    public br.org.abrasf.nfse.TsCodigoCancelamentoNfse xgetCodigoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TsCodigoCancelamentoNfse)get_store().find_element_user(CODIGOCANCELAMENTO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoCancelamento" element
     */
    public boolean isSetCodigoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOCANCELAMENTO$2) != 0;
        }
    }
    
    /**
     * Sets the "CodigoCancelamento" element
     */
    public void setCodigoCancelamento(byte codigoCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOCANCELAMENTO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOCANCELAMENTO$2);
            }
            target.setByteValue(codigoCancelamento);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoCancelamento" element
     */
    public void xsetCodigoCancelamento(br.org.abrasf.nfse.TsCodigoCancelamentoNfse codigoCancelamento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TsCodigoCancelamentoNfse)get_store().find_element_user(CODIGOCANCELAMENTO$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoCancelamentoNfse)get_store().add_element_user(CODIGOCANCELAMENTO$2);
            }
            target.set(codigoCancelamento);
        }
    }
    
    /**
     * Unsets the "CodigoCancelamento" element
     */
    public void unsetCodigoCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOCANCELAMENTO$2, 0);
        }
    }
    
    /**
     * Gets the "Id" attribute
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    public br.org.abrasf.nfse.TsIdTag xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
            return target;
        }
    }
    
    /**
     * True if has "Id" attribute
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(ID$4) != null;
        }
    }
    
    /**
     * Sets the "Id" attribute
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$4);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    public void xsetId(br.org.abrasf.nfse.TsIdTag id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsIdTag target = null;
            target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$4);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "Id" attribute
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(ID$4);
        }
    }
}
