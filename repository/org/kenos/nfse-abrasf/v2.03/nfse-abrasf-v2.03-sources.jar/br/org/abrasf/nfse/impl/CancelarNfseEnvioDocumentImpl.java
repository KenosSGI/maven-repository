/*
 * An XML document type.
 * Localname: CancelarNfseEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.CancelarNfseEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one CancelarNfseEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class CancelarNfseEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CancelarNfseEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public CancelarNfseEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CANCELARNFSEENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CancelarNfseEnvio");
    
    
    /**
     * Gets the "CancelarNfseEnvio" element
     */
    public br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio getCancelarNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio target = null;
            target = (br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio)get_store().find_element_user(CANCELARNFSEENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "CancelarNfseEnvio" element
     */
    public void setCancelarNfseEnvio(br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio cancelarNfseEnvio)
    {
        generatedSetterHelperImpl(cancelarNfseEnvio, CANCELARNFSEENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CancelarNfseEnvio" element
     */
    public br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio addNewCancelarNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio target = null;
            target = (br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio)get_store().add_element_user(CANCELARNFSEENVIO$0);
            return target;
        }
    }
    /**
     * An XML CancelarNfseEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class CancelarNfseEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CancelarNfseEnvioDocument.CancelarNfseEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public CancelarNfseEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PEDIDO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Pedido");
        
        
        /**
         * Gets the "Pedido" element
         */
        public br.org.abrasf.nfse.TcPedidoCancelamento getPedido()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcPedidoCancelamento target = null;
                target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().find_element_user(PEDIDO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "Pedido" element
         */
        public void setPedido(br.org.abrasf.nfse.TcPedidoCancelamento pedido)
        {
            generatedSetterHelperImpl(pedido, PEDIDO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Pedido" element
         */
        public br.org.abrasf.nfse.TcPedidoCancelamento addNewPedido()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcPedidoCancelamento target = null;
                target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().add_element_user(PEDIDO$0);
                return target;
            }
        }
    }
}
