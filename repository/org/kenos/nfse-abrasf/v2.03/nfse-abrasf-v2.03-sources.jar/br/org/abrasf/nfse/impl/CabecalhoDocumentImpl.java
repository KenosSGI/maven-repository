/*
 * An XML document type.
 * Localname: cabecalho
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.CabecalhoDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one cabecalho(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class CabecalhoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CabecalhoDocument
{
    private static final long serialVersionUID = 1L;
    
    public CabecalhoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CABECALHO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "cabecalho");
    
    
    /**
     * Gets the "cabecalho" element
     */
    public br.org.abrasf.nfse.CabecalhoDocument.Cabecalho getCabecalho()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CabecalhoDocument.Cabecalho target = null;
            target = (br.org.abrasf.nfse.CabecalhoDocument.Cabecalho)get_store().find_element_user(CABECALHO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cabecalho" element
     */
    public void setCabecalho(br.org.abrasf.nfse.CabecalhoDocument.Cabecalho cabecalho)
    {
        generatedSetterHelperImpl(cabecalho, CABECALHO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "cabecalho" element
     */
    public br.org.abrasf.nfse.CabecalhoDocument.Cabecalho addNewCabecalho()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.CabecalhoDocument.Cabecalho target = null;
            target = (br.org.abrasf.nfse.CabecalhoDocument.Cabecalho)get_store().add_element_user(CABECALHO$0);
            return target;
        }
    }
    /**
     * An XML cabecalho(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class CabecalhoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.CabecalhoDocument.Cabecalho
    {
        private static final long serialVersionUID = 1L;
        
        public CabecalhoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VERSAODADOS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "versaoDados");
        private static final javax.xml.namespace.QName VERSAO$2 = 
            new javax.xml.namespace.QName("", "versao");
        
        
        /**
         * Gets the "versaoDados" element
         */
        public java.lang.String getVersaoDados()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERSAODADOS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "versaoDados" element
         */
        public br.org.abrasf.nfse.TsVersao xgetVersaoDados()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsVersao target = null;
                target = (br.org.abrasf.nfse.TsVersao)get_store().find_element_user(VERSAODADOS$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "versaoDados" element
         */
        public void setVersaoDados(java.lang.String versaoDados)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VERSAODADOS$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VERSAODADOS$0);
                }
                target.setStringValue(versaoDados);
            }
        }
        
        /**
         * Sets (as xml) the "versaoDados" element
         */
        public void xsetVersaoDados(br.org.abrasf.nfse.TsVersao versaoDados)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsVersao target = null;
                target = (br.org.abrasf.nfse.TsVersao)get_store().find_element_user(VERSAODADOS$0, 0);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsVersao)get_store().add_element_user(VERSAODADOS$0);
                }
                target.set(versaoDados);
            }
        }
        
        /**
         * Gets the "versao" attribute
         */
        public java.lang.String getVersao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "versao" attribute
         */
        public br.org.abrasf.nfse.TsVersao xgetVersao()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsVersao target = null;
                target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$2);
                return target;
            }
        }
        
        /**
         * Sets the "versao" attribute
         */
        public void setVersao(java.lang.String versao)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(VERSAO$2);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(VERSAO$2);
                }
                target.setStringValue(versao);
            }
        }
        
        /**
         * Sets (as xml) the "versao" attribute
         */
        public void xsetVersao(br.org.abrasf.nfse.TsVersao versao)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TsVersao target = null;
                target = (br.org.abrasf.nfse.TsVersao)get_store().find_attribute_user(VERSAO$2);
                if (target == null)
                {
                    target = (br.org.abrasf.nfse.TsVersao)get_store().add_attribute_user(VERSAO$2);
                }
                target.set(versao);
            }
        }
    }
}
