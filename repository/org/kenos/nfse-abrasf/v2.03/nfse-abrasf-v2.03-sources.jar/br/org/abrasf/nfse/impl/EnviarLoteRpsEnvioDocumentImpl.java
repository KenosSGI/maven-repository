/*
 * An XML document type.
 * Localname: EnviarLoteRpsEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one EnviarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class EnviarLoteRpsEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public EnviarLoteRpsEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENVIARLOTERPSENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "EnviarLoteRpsEnvio");
    
    
    /**
     * Gets the "EnviarLoteRpsEnvio" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio getEnviarLoteRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio)get_store().find_element_user(ENVIARLOTERPSENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "EnviarLoteRpsEnvio" element
     */
    public void setEnviarLoteRpsEnvio(br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio enviarLoteRpsEnvio)
    {
        generatedSetterHelperImpl(enviarLoteRpsEnvio, ENVIARLOTERPSENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "EnviarLoteRpsEnvio" element
     */
    public br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio addNewEnviarLoteRpsEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio target = null;
            target = (br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio)get_store().add_element_user(ENVIARLOTERPSENVIO$0);
            return target;
        }
    }
    /**
     * An XML EnviarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class EnviarLoteRpsEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.EnviarLoteRpsEnvioDocument.EnviarLoteRpsEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public EnviarLoteRpsEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName LOTERPS$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "LoteRps");
        private static final javax.xml.namespace.QName SIGNATURE$2 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "LoteRps" element
         */
        public br.org.abrasf.nfse.TcLoteRps getLoteRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcLoteRps target = null;
                target = (br.org.abrasf.nfse.TcLoteRps)get_store().find_element_user(LOTERPS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "LoteRps" element
         */
        public void setLoteRps(br.org.abrasf.nfse.TcLoteRps loteRps)
        {
            generatedSetterHelperImpl(loteRps, LOTERPS$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "LoteRps" element
         */
        public br.org.abrasf.nfse.TcLoteRps addNewLoteRps()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcLoteRps target = null;
                target = (br.org.abrasf.nfse.TcLoteRps)get_store().add_element_user(LOTERPS$0);
                return target;
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Signature" element
         */
        public boolean isSetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SIGNATURE$2) != 0;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "Signature" element
         */
        public void unsetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SIGNATURE$2, 0);
            }
        }
    }
}
