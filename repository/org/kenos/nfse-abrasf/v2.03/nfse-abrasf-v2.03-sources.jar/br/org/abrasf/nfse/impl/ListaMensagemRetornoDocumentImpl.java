/*
 * An XML document type.
 * Localname: ListaMensagemRetorno
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ListaMensagemRetornoDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one ListaMensagemRetorno(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class ListaMensagemRetornoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemRetornoDocument
{
    private static final long serialVersionUID = 1L;
    
    public ListaMensagemRetornoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LISTAMENSAGEMRETORNO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "ListaMensagemRetorno");
    
    
    /**
     * Gets the "ListaMensagemRetorno" element
     */
    public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno getListaMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
            target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().find_element_user(LISTAMENSAGEMRETORNO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ListaMensagemRetorno" element
     */
    public void setListaMensagemRetorno(br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno listaMensagemRetorno)
    {
        generatedSetterHelperImpl(listaMensagemRetorno, LISTAMENSAGEMRETORNO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "ListaMensagemRetorno" element
     */
    public br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno addNewListaMensagemRetorno()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno target = null;
            target = (br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno)get_store().add_element_user(LISTAMENSAGEMRETORNO$0);
            return target;
        }
    }
    /**
     * An XML ListaMensagemRetorno(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class ListaMensagemRetornoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.ListaMensagemRetornoDocument.ListaMensagemRetorno
    {
        private static final long serialVersionUID = 1L;
        
        public ListaMensagemRetornoImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENSAGEMRETORNO$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "MensagemRetorno");
        
        
        /**
         * Gets array of all "MensagemRetorno" elements
         */
        public br.org.abrasf.nfse.TcMensagemRetorno[] getMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MENSAGEMRETORNO$0, targetList);
                br.org.abrasf.nfse.TcMensagemRetorno[] result = new br.org.abrasf.nfse.TcMensagemRetorno[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno getMensagemRetornoArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().find_element_user(MENSAGEMRETORNO$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "MensagemRetorno" element
         */
        public int sizeOfMensagemRetornoArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENSAGEMRETORNO$0);
            }
        }
        
        /**
         * Sets array of all "MensagemRetorno" element  WARNING: This method is not atomicaly synchronized.
         */
        public void setMensagemRetornoArray(br.org.abrasf.nfse.TcMensagemRetorno[] mensagemRetornoArray)
        {
            check_orphaned();
            arraySetterHelper(mensagemRetornoArray, MENSAGEMRETORNO$0);
        }
        
        /**
         * Sets ith "MensagemRetorno" element
         */
        public void setMensagemRetornoArray(int i, br.org.abrasf.nfse.TcMensagemRetorno mensagemRetorno)
        {
            generatedSetterHelperImpl(mensagemRetorno, MENSAGEMRETORNO$0, i, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_ARRAYITEM);
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno insertNewMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().insert_element_user(MENSAGEMRETORNO$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "MensagemRetorno" element
         */
        public br.org.abrasf.nfse.TcMensagemRetorno addNewMensagemRetorno()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.TcMensagemRetorno target = null;
                target = (br.org.abrasf.nfse.TcMensagemRetorno)get_store().add_element_user(MENSAGEMRETORNO$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "MensagemRetorno" element
         */
        public void removeMensagemRetorno(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENSAGEMRETORNO$0, i);
            }
        }
    }
}
