/*
 * XML Type:  tcEndereco
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcEndereco
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcEndereco(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcEnderecoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcEndereco
{
    private static final long serialVersionUID = 1L;
    
    public TcEnderecoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENDERECO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Endereco");
    private static final javax.xml.namespace.QName NUMERO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Numero");
    private static final javax.xml.namespace.QName COMPLEMENTO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Complemento");
    private static final javax.xml.namespace.QName BAIRRO$6 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Bairro");
    private static final javax.xml.namespace.QName CODIGOMUNICIPIO$8 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoMunicipio");
    private static final javax.xml.namespace.QName UF$10 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Uf");
    private static final javax.xml.namespace.QName CODIGOPAIS$12 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CodigoPais");
    private static final javax.xml.namespace.QName CEP$14 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Cep");
    
    
    /**
     * Gets the "Endereco" element
     */
    public java.lang.String getEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENDERECO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Endereco" element
     */
    public br.org.abrasf.nfse.TsEndereco xgetEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsEndereco target = null;
            target = (br.org.abrasf.nfse.TsEndereco)get_store().find_element_user(ENDERECO$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "Endereco" element
     */
    public boolean isSetEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENDERECO$0) != 0;
        }
    }
    
    /**
     * Sets the "Endereco" element
     */
    public void setEndereco(java.lang.String endereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENDERECO$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ENDERECO$0);
            }
            target.setStringValue(endereco);
        }
    }
    
    /**
     * Sets (as xml) the "Endereco" element
     */
    public void xsetEndereco(br.org.abrasf.nfse.TsEndereco endereco)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsEndereco target = null;
            target = (br.org.abrasf.nfse.TsEndereco)get_store().find_element_user(ENDERECO$0, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsEndereco)get_store().add_element_user(ENDERECO$0);
            }
            target.set(endereco);
        }
    }
    
    /**
     * Unsets the "Endereco" element
     */
    public void unsetEndereco()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENDERECO$0, 0);
        }
    }
    
    /**
     * Gets the "Numero" element
     */
    public java.lang.String getNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Numero" element
     */
    public br.org.abrasf.nfse.TsNumeroEndereco xgetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroEndereco target = null;
            target = (br.org.abrasf.nfse.TsNumeroEndereco)get_store().find_element_user(NUMERO$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "Numero" element
     */
    public boolean isSetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMERO$2) != 0;
        }
    }
    
    /**
     * Sets the "Numero" element
     */
    public void setNumero(java.lang.String numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMERO$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMERO$2);
            }
            target.setStringValue(numero);
        }
    }
    
    /**
     * Sets (as xml) the "Numero" element
     */
    public void xsetNumero(br.org.abrasf.nfse.TsNumeroEndereco numero)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsNumeroEndereco target = null;
            target = (br.org.abrasf.nfse.TsNumeroEndereco)get_store().find_element_user(NUMERO$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsNumeroEndereco)get_store().add_element_user(NUMERO$2);
            }
            target.set(numero);
        }
    }
    
    /**
     * Unsets the "Numero" element
     */
    public void unsetNumero()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMERO$2, 0);
        }
    }
    
    /**
     * Gets the "Complemento" element
     */
    public java.lang.String getComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Complemento" element
     */
    public br.org.abrasf.nfse.TsComplementoEndereco xgetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsComplementoEndereco target = null;
            target = (br.org.abrasf.nfse.TsComplementoEndereco)get_store().find_element_user(COMPLEMENTO$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "Complemento" element
     */
    public boolean isSetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMPLEMENTO$4) != 0;
        }
    }
    
    /**
     * Sets the "Complemento" element
     */
    public void setComplemento(java.lang.String complemento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMPLEMENTO$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMPLEMENTO$4);
            }
            target.setStringValue(complemento);
        }
    }
    
    /**
     * Sets (as xml) the "Complemento" element
     */
    public void xsetComplemento(br.org.abrasf.nfse.TsComplementoEndereco complemento)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsComplementoEndereco target = null;
            target = (br.org.abrasf.nfse.TsComplementoEndereco)get_store().find_element_user(COMPLEMENTO$4, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsComplementoEndereco)get_store().add_element_user(COMPLEMENTO$4);
            }
            target.set(complemento);
        }
    }
    
    /**
     * Unsets the "Complemento" element
     */
    public void unsetComplemento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMPLEMENTO$4, 0);
        }
    }
    
    /**
     * Gets the "Bairro" element
     */
    public java.lang.String getBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Bairro" element
     */
    public br.org.abrasf.nfse.TsBairro xgetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsBairro target = null;
            target = (br.org.abrasf.nfse.TsBairro)get_store().find_element_user(BAIRRO$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "Bairro" element
     */
    public boolean isSetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BAIRRO$6) != 0;
        }
    }
    
    /**
     * Sets the "Bairro" element
     */
    public void setBairro(java.lang.String bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BAIRRO$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BAIRRO$6);
            }
            target.setStringValue(bairro);
        }
    }
    
    /**
     * Sets (as xml) the "Bairro" element
     */
    public void xsetBairro(br.org.abrasf.nfse.TsBairro bairro)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsBairro target = null;
            target = (br.org.abrasf.nfse.TsBairro)get_store().find_element_user(BAIRRO$6, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsBairro)get_store().add_element_user(BAIRRO$6);
            }
            target.set(bairro);
        }
    }
    
    /**
     * Unsets the "Bairro" element
     */
    public void unsetBairro()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BAIRRO$6, 0);
        }
    }
    
    /**
     * Gets the "CodigoMunicipio" element
     */
    public int getCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$8, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoMunicipio" element
     */
    public br.org.abrasf.nfse.TsCodigoMunicipioIbge xgetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoMunicipio" element
     */
    public boolean isSetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOMUNICIPIO$8) != 0;
        }
    }
    
    /**
     * Sets the "CodigoMunicipio" element
     */
    public void setCodigoMunicipio(int codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOMUNICIPIO$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOMUNICIPIO$8);
            }
            target.setIntValue(codigoMunicipio);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoMunicipio" element
     */
    public void xsetCodigoMunicipio(br.org.abrasf.nfse.TsCodigoMunicipioIbge codigoMunicipio)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoMunicipioIbge target = null;
            target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().find_element_user(CODIGOMUNICIPIO$8, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoMunicipioIbge)get_store().add_element_user(CODIGOMUNICIPIO$8);
            }
            target.set(codigoMunicipio);
        }
    }
    
    /**
     * Unsets the "CodigoMunicipio" element
     */
    public void unsetCodigoMunicipio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOMUNICIPIO$8, 0);
        }
    }
    
    /**
     * Gets the "Uf" element
     */
    public br.org.abrasf.nfse.TsUf.Enum getUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                return null;
            }
            return (br.org.abrasf.nfse.TsUf.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "Uf" element
     */
    public br.org.abrasf.nfse.TsUf xgetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsUf target = null;
            target = (br.org.abrasf.nfse.TsUf)get_store().find_element_user(UF$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "Uf" element
     */
    public boolean isSetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UF$10) != 0;
        }
    }
    
    /**
     * Sets the "Uf" element
     */
    public void setUf(br.org.abrasf.nfse.TsUf.Enum uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UF$10);
            }
            target.setEnumValue(uf);
        }
    }
    
    /**
     * Sets (as xml) the "Uf" element
     */
    public void xsetUf(br.org.abrasf.nfse.TsUf uf)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsUf target = null;
            target = (br.org.abrasf.nfse.TsUf)get_store().find_element_user(UF$10, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsUf)get_store().add_element_user(UF$10);
            }
            target.set(uf);
        }
    }
    
    /**
     * Unsets the "Uf" element
     */
    public void unsetUf()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UF$10, 0);
        }
    }
    
    /**
     * Gets the "CodigoPais" element
     */
    public java.lang.String getCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPAIS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "CodigoPais" element
     */
    public br.org.abrasf.nfse.TsCodigoPaisBacen xgetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoPaisBacen target = null;
            target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().find_element_user(CODIGOPAIS$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "CodigoPais" element
     */
    public boolean isSetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CODIGOPAIS$12) != 0;
        }
    }
    
    /**
     * Sets the "CodigoPais" element
     */
    public void setCodigoPais(java.lang.String codigoPais)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CODIGOPAIS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CODIGOPAIS$12);
            }
            target.setStringValue(codigoPais);
        }
    }
    
    /**
     * Sets (as xml) the "CodigoPais" element
     */
    public void xsetCodigoPais(br.org.abrasf.nfse.TsCodigoPaisBacen codigoPais)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCodigoPaisBacen target = null;
            target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().find_element_user(CODIGOPAIS$12, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCodigoPaisBacen)get_store().add_element_user(CODIGOPAIS$12);
            }
            target.set(codigoPais);
        }
    }
    
    /**
     * Unsets the "CodigoPais" element
     */
    public void unsetCodigoPais()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CODIGOPAIS$12, 0);
        }
    }
    
    /**
     * Gets the "Cep" element
     */
    public java.lang.String getCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "Cep" element
     */
    public br.org.abrasf.nfse.TsCep xgetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCep target = null;
            target = (br.org.abrasf.nfse.TsCep)get_store().find_element_user(CEP$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "Cep" element
     */
    public boolean isSetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CEP$14) != 0;
        }
    }
    
    /**
     * Sets the "Cep" element
     */
    public void setCep(java.lang.String cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CEP$14);
            }
            target.setStringValue(cep);
        }
    }
    
    /**
     * Sets (as xml) the "Cep" element
     */
    public void xsetCep(br.org.abrasf.nfse.TsCep cep)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsCep target = null;
            target = (br.org.abrasf.nfse.TsCep)get_store().find_element_user(CEP$14, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsCep)get_store().add_element_user(CEP$14);
            }
            target.set(cep);
        }
    }
    
    /**
     * Unsets the "Cep" element
     */
    public void unsetCep()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CEP$14, 0);
        }
    }
}
