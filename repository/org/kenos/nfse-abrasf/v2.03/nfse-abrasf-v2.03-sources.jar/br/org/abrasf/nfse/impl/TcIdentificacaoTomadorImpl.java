/*
 * XML Type:  tcIdentificacaoTomador
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcIdentificacaoTomador
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcIdentificacaoTomador(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcIdentificacaoTomadorImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcIdentificacaoTomador
{
    private static final long serialVersionUID = 1L;
    
    public TcIdentificacaoTomadorImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CPFCNPJ$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "CpfCnpj");
    private static final javax.xml.namespace.QName INSCRICAOMUNICIPAL$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "InscricaoMunicipal");
    
    
    /**
     * Gets the "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj getCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().find_element_user(CPFCNPJ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "CpfCnpj" element
     */
    public boolean isSetCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CPFCNPJ$0) != 0;
        }
    }
    
    /**
     * Sets the "CpfCnpj" element
     */
    public void setCpfCnpj(br.org.abrasf.nfse.TcCpfCnpj cpfCnpj)
    {
        generatedSetterHelperImpl(cpfCnpj, CPFCNPJ$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "CpfCnpj" element
     */
    public br.org.abrasf.nfse.TcCpfCnpj addNewCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCpfCnpj target = null;
            target = (br.org.abrasf.nfse.TcCpfCnpj)get_store().add_element_user(CPFCNPJ$0);
            return target;
        }
    }
    
    /**
     * Unsets the "CpfCnpj" element
     */
    public void unsetCpfCnpj()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CPFCNPJ$0, 0);
        }
    }
    
    /**
     * Gets the "InscricaoMunicipal" element
     */
    public java.lang.String getInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "InscricaoMunicipal" element
     */
    public br.org.abrasf.nfse.TsInscricaoMunicipal xgetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "InscricaoMunicipal" element
     */
    public boolean isSetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSCRICAOMUNICIPAL$2) != 0;
        }
    }
    
    /**
     * Sets the "InscricaoMunicipal" element
     */
    public void setInscricaoMunicipal(java.lang.String inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSCRICAOMUNICIPAL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSCRICAOMUNICIPAL$2);
            }
            target.setStringValue(inscricaoMunicipal);
        }
    }
    
    /**
     * Sets (as xml) the "InscricaoMunicipal" element
     */
    public void xsetInscricaoMunicipal(br.org.abrasf.nfse.TsInscricaoMunicipal inscricaoMunicipal)
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TsInscricaoMunicipal target = null;
            target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().find_element_user(INSCRICAOMUNICIPAL$2, 0);
            if (target == null)
            {
                target = (br.org.abrasf.nfse.TsInscricaoMunicipal)get_store().add_element_user(INSCRICAOMUNICIPAL$2);
            }
            target.set(inscricaoMunicipal);
        }
    }
    
    /**
     * Unsets the "InscricaoMunicipal" element
     */
    public void unsetInscricaoMunicipal()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSCRICAOMUNICIPAL$2, 0);
        }
    }
}
