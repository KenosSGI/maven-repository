/*
 * XML Type:  tcInfNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcInfNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcInfNfse extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcInfNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("tcinfnfse52cbtype");
    
    /**
     * Gets the "Numero" element
     */
    long getNumero();
    
    /**
     * Gets (as xml) the "Numero" element
     */
    br.org.abrasf.nfse.TsNumeroNfse xgetNumero();
    
    /**
     * Sets the "Numero" element
     */
    void setNumero(long numero);
    
    /**
     * Sets (as xml) the "Numero" element
     */
    void xsetNumero(br.org.abrasf.nfse.TsNumeroNfse numero);
    
    /**
     * Gets the "CodigoVerificacao" element
     */
    java.lang.String getCodigoVerificacao();
    
    /**
     * Gets (as xml) the "CodigoVerificacao" element
     */
    br.org.abrasf.nfse.TsCodigoVerificacao xgetCodigoVerificacao();
    
    /**
     * Sets the "CodigoVerificacao" element
     */
    void setCodigoVerificacao(java.lang.String codigoVerificacao);
    
    /**
     * Sets (as xml) the "CodigoVerificacao" element
     */
    void xsetCodigoVerificacao(br.org.abrasf.nfse.TsCodigoVerificacao codigoVerificacao);
    
    /**
     * Gets the "DataEmissao" element
     */
    java.util.Calendar getDataEmissao();
    
    /**
     * Gets (as xml) the "DataEmissao" element
     */
    org.apache.xmlbeans.XmlDateTime xgetDataEmissao();
    
    /**
     * Sets the "DataEmissao" element
     */
    void setDataEmissao(java.util.Calendar dataEmissao);
    
    /**
     * Sets (as xml) the "DataEmissao" element
     */
    void xsetDataEmissao(org.apache.xmlbeans.XmlDateTime dataEmissao);
    
    /**
     * Gets the "NfseSubstituida" element
     */
    long getNfseSubstituida();
    
    /**
     * Gets (as xml) the "NfseSubstituida" element
     */
    br.org.abrasf.nfse.TsNumeroNfse xgetNfseSubstituida();
    
    /**
     * True if has "NfseSubstituida" element
     */
    boolean isSetNfseSubstituida();
    
    /**
     * Sets the "NfseSubstituida" element
     */
    void setNfseSubstituida(long nfseSubstituida);
    
    /**
     * Sets (as xml) the "NfseSubstituida" element
     */
    void xsetNfseSubstituida(br.org.abrasf.nfse.TsNumeroNfse nfseSubstituida);
    
    /**
     * Unsets the "NfseSubstituida" element
     */
    void unsetNfseSubstituida();
    
    /**
     * Gets the "OutrasInformacoes" element
     */
    java.lang.String getOutrasInformacoes();
    
    /**
     * Gets (as xml) the "OutrasInformacoes" element
     */
    br.org.abrasf.nfse.TsOutrasInformacoes xgetOutrasInformacoes();
    
    /**
     * True if has "OutrasInformacoes" element
     */
    boolean isSetOutrasInformacoes();
    
    /**
     * Sets the "OutrasInformacoes" element
     */
    void setOutrasInformacoes(java.lang.String outrasInformacoes);
    
    /**
     * Sets (as xml) the "OutrasInformacoes" element
     */
    void xsetOutrasInformacoes(br.org.abrasf.nfse.TsOutrasInformacoes outrasInformacoes);
    
    /**
     * Unsets the "OutrasInformacoes" element
     */
    void unsetOutrasInformacoes();
    
    /**
     * Gets the "ValoresNfse" element
     */
    br.org.abrasf.nfse.TcValoresNfse getValoresNfse();
    
    /**
     * Sets the "ValoresNfse" element
     */
    void setValoresNfse(br.org.abrasf.nfse.TcValoresNfse valoresNfse);
    
    /**
     * Appends and returns a new empty "ValoresNfse" element
     */
    br.org.abrasf.nfse.TcValoresNfse addNewValoresNfse();
    
    /**
     * Gets the "ValorCredito" element
     */
    java.math.BigDecimal getValorCredito();
    
    /**
     * Gets (as xml) the "ValorCredito" element
     */
    br.org.abrasf.nfse.TsValor xgetValorCredito();
    
    /**
     * True if has "ValorCredito" element
     */
    boolean isSetValorCredito();
    
    /**
     * Sets the "ValorCredito" element
     */
    void setValorCredito(java.math.BigDecimal valorCredito);
    
    /**
     * Sets (as xml) the "ValorCredito" element
     */
    void xsetValorCredito(br.org.abrasf.nfse.TsValor valorCredito);
    
    /**
     * Unsets the "ValorCredito" element
     */
    void unsetValorCredito();
    
    /**
     * Gets the "PrestadorServico" element
     */
    br.org.abrasf.nfse.TcDadosPrestador getPrestadorServico();
    
    /**
     * Sets the "PrestadorServico" element
     */
    void setPrestadorServico(br.org.abrasf.nfse.TcDadosPrestador prestadorServico);
    
    /**
     * Appends and returns a new empty "PrestadorServico" element
     */
    br.org.abrasf.nfse.TcDadosPrestador addNewPrestadorServico();
    
    /**
     * Gets the "OrgaoGerador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador getOrgaoGerador();
    
    /**
     * Sets the "OrgaoGerador" element
     */
    void setOrgaoGerador(br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador orgaoGerador);
    
    /**
     * Appends and returns a new empty "OrgaoGerador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoOrgaoGerador addNewOrgaoGerador();
    
    /**
     * Gets the "DeclaracaoPrestacaoServico" element
     */
    br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getDeclaracaoPrestacaoServico();
    
    /**
     * Sets the "DeclaracaoPrestacaoServico" element
     */
    void setDeclaracaoPrestacaoServico(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico declaracaoPrestacaoServico);
    
    /**
     * Appends and returns a new empty "DeclaracaoPrestacaoServico" element
     */
    br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewDeclaracaoPrestacaoServico();
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    br.org.abrasf.nfse.TsIdTag xgetId();
    
    /**
     * True if has "Id" attribute
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(br.org.abrasf.nfse.TsIdTag id);
    
    /**
     * Unsets the "Id" attribute
     */
    void unsetId();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcInfNfse newInstance() {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcInfNfse parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfNfse parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfNfse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfNfse parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
