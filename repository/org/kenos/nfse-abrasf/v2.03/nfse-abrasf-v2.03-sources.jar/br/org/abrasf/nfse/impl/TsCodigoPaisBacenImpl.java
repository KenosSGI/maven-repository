/*
 * XML Type:  tsCodigoPaisBacen
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsCodigoPaisBacen
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsCodigoPaisBacen(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsCodigoPaisBacen.
 */
public class TsCodigoPaisBacenImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsCodigoPaisBacen
{
    private static final long serialVersionUID = 1L;
    
    public TsCodigoPaisBacenImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsCodigoPaisBacenImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
