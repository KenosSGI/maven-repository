/*
 * XML Type:  tsCodigoMunicipioIbge
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsCodigoMunicipioIbge
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsCodigoMunicipioIbge(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsCodigoMunicipioIbge.
 */
public class TsCodigoMunicipioIbgeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements br.org.abrasf.nfse.TsCodigoMunicipioIbge
{
    private static final long serialVersionUID = 1L;
    
    public TsCodigoMunicipioIbgeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsCodigoMunicipioIbgeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
