/*
 * XML Type:  tcInfDeclaracaoPrestacaoServico
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * An XML tcInfDeclaracaoPrestacaoServico(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public interface TcInfDeclaracaoPrestacaoServico extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcInfDeclaracaoPrestacaoServico.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("tcinfdeclaracaoprestacaoservico01d7type");
    
    /**
     * Gets the "Rps" element
     */
    br.org.abrasf.nfse.TcInfRps getRps();
    
    /**
     * True if has "Rps" element
     */
    boolean isSetRps();
    
    /**
     * Sets the "Rps" element
     */
    void setRps(br.org.abrasf.nfse.TcInfRps rps);
    
    /**
     * Appends and returns a new empty "Rps" element
     */
    br.org.abrasf.nfse.TcInfRps addNewRps();
    
    /**
     * Unsets the "Rps" element
     */
    void unsetRps();
    
    /**
     * Gets the "Competencia" element
     */
    java.util.Calendar getCompetencia();
    
    /**
     * Gets (as xml) the "Competencia" element
     */
    org.apache.xmlbeans.XmlDate xgetCompetencia();
    
    /**
     * Sets the "Competencia" element
     */
    void setCompetencia(java.util.Calendar competencia);
    
    /**
     * Sets (as xml) the "Competencia" element
     */
    void xsetCompetencia(org.apache.xmlbeans.XmlDate competencia);
    
    /**
     * Gets the "Servico" element
     */
    br.org.abrasf.nfse.TcDadosServico getServico();
    
    /**
     * Sets the "Servico" element
     */
    void setServico(br.org.abrasf.nfse.TcDadosServico servico);
    
    /**
     * Appends and returns a new empty "Servico" element
     */
    br.org.abrasf.nfse.TcDadosServico addNewServico();
    
    /**
     * Gets the "Prestador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador();
    
    /**
     * Sets the "Prestador" element
     */
    void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador);
    
    /**
     * Appends and returns a new empty "Prestador" element
     */
    br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador();
    
    /**
     * Gets the "Tomador" element
     */
    br.org.abrasf.nfse.TcDadosTomador getTomador();
    
    /**
     * True if has "Tomador" element
     */
    boolean isSetTomador();
    
    /**
     * Sets the "Tomador" element
     */
    void setTomador(br.org.abrasf.nfse.TcDadosTomador tomador);
    
    /**
     * Appends and returns a new empty "Tomador" element
     */
    br.org.abrasf.nfse.TcDadosTomador addNewTomador();
    
    /**
     * Unsets the "Tomador" element
     */
    void unsetTomador();
    
    /**
     * Gets the "Intermediario" element
     */
    br.org.abrasf.nfse.TcDadosIntermediario getIntermediario();
    
    /**
     * True if has "Intermediario" element
     */
    boolean isSetIntermediario();
    
    /**
     * Sets the "Intermediario" element
     */
    void setIntermediario(br.org.abrasf.nfse.TcDadosIntermediario intermediario);
    
    /**
     * Appends and returns a new empty "Intermediario" element
     */
    br.org.abrasf.nfse.TcDadosIntermediario addNewIntermediario();
    
    /**
     * Unsets the "Intermediario" element
     */
    void unsetIntermediario();
    
    /**
     * Gets the "ConstrucaoCivil" element
     */
    br.org.abrasf.nfse.TcDadosConstrucaoCivil getConstrucaoCivil();
    
    /**
     * True if has "ConstrucaoCivil" element
     */
    boolean isSetConstrucaoCivil();
    
    /**
     * Sets the "ConstrucaoCivil" element
     */
    void setConstrucaoCivil(br.org.abrasf.nfse.TcDadosConstrucaoCivil construcaoCivil);
    
    /**
     * Appends and returns a new empty "ConstrucaoCivil" element
     */
    br.org.abrasf.nfse.TcDadosConstrucaoCivil addNewConstrucaoCivil();
    
    /**
     * Unsets the "ConstrucaoCivil" element
     */
    void unsetConstrucaoCivil();
    
    /**
     * Gets the "RegimeEspecialTributacao" element
     */
    byte getRegimeEspecialTributacao();
    
    /**
     * Gets (as xml) the "RegimeEspecialTributacao" element
     */
    br.org.abrasf.nfse.TsRegimeEspecialTributacao xgetRegimeEspecialTributacao();
    
    /**
     * True if has "RegimeEspecialTributacao" element
     */
    boolean isSetRegimeEspecialTributacao();
    
    /**
     * Sets the "RegimeEspecialTributacao" element
     */
    void setRegimeEspecialTributacao(byte regimeEspecialTributacao);
    
    /**
     * Sets (as xml) the "RegimeEspecialTributacao" element
     */
    void xsetRegimeEspecialTributacao(br.org.abrasf.nfse.TsRegimeEspecialTributacao regimeEspecialTributacao);
    
    /**
     * Unsets the "RegimeEspecialTributacao" element
     */
    void unsetRegimeEspecialTributacao();
    
    /**
     * Gets the "OptanteSimplesNacional" element
     */
    byte getOptanteSimplesNacional();
    
    /**
     * Gets (as xml) the "OptanteSimplesNacional" element
     */
    br.org.abrasf.nfse.TsSimNao xgetOptanteSimplesNacional();
    
    /**
     * Sets the "OptanteSimplesNacional" element
     */
    void setOptanteSimplesNacional(byte optanteSimplesNacional);
    
    /**
     * Sets (as xml) the "OptanteSimplesNacional" element
     */
    void xsetOptanteSimplesNacional(br.org.abrasf.nfse.TsSimNao optanteSimplesNacional);
    
    /**
     * Gets the "IncentivoFiscal" element
     */
    byte getIncentivoFiscal();
    
    /**
     * Gets (as xml) the "IncentivoFiscal" element
     */
    br.org.abrasf.nfse.TsSimNao xgetIncentivoFiscal();
    
    /**
     * Sets the "IncentivoFiscal" element
     */
    void setIncentivoFiscal(byte incentivoFiscal);
    
    /**
     * Sets (as xml) the "IncentivoFiscal" element
     */
    void xsetIncentivoFiscal(br.org.abrasf.nfse.TsSimNao incentivoFiscal);
    
    /**
     * Gets the "Id" attribute
     */
    java.lang.String getId();
    
    /**
     * Gets (as xml) the "Id" attribute
     */
    br.org.abrasf.nfse.TsIdTag xgetId();
    
    /**
     * True if has "Id" attribute
     */
    boolean isSetId();
    
    /**
     * Sets the "Id" attribute
     */
    void setId(java.lang.String id);
    
    /**
     * Sets (as xml) the "Id" attribute
     */
    void xsetId(br.org.abrasf.nfse.TsIdTag id);
    
    /**
     * Unsets the "Id" attribute
     */
    void unsetId();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico newInstance() {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.TcInfDeclaracaoPrestacaoServico) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
