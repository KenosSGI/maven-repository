/*
 * XML Type:  tcRetCancelamento
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcRetCancelamento
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcRetCancelamento(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcRetCancelamentoImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcRetCancelamento
{
    private static final long serialVersionUID = 1L;
    
    public TcRetCancelamentoImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NFSECANCELAMENTO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseCancelamento");
    
    
    /**
     * Gets the "NfseCancelamento" element
     */
    public br.org.abrasf.nfse.TcCancelamentoNfse getNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TcCancelamentoNfse)get_store().find_element_user(NFSECANCELAMENTO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "NfseCancelamento" element
     */
    public void setNfseCancelamento(br.org.abrasf.nfse.TcCancelamentoNfse nfseCancelamento)
    {
        generatedSetterHelperImpl(nfseCancelamento, NFSECANCELAMENTO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NfseCancelamento" element
     */
    public br.org.abrasf.nfse.TcCancelamentoNfse addNewNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TcCancelamentoNfse)get_store().add_element_user(NFSECANCELAMENTO$0);
            return target;
        }
    }
}
