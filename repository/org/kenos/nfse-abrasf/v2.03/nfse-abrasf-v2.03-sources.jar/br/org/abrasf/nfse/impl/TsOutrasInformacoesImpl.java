/*
 * XML Type:  tsOutrasInformacoes
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsOutrasInformacoes
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsOutrasInformacoes(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsOutrasInformacoes.
 */
public class TsOutrasInformacoesImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements br.org.abrasf.nfse.TsOutrasInformacoes
{
    private static final long serialVersionUID = 1L;
    
    public TsOutrasInformacoesImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsOutrasInformacoesImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
