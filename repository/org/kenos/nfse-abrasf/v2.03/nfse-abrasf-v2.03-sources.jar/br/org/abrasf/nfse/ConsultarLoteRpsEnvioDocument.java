/*
 * An XML document type.
 * Localname: ConsultarLoteRpsEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one ConsultarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface ConsultarLoteRpsEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarLoteRpsEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("consultarloterpsenvioc62edoctype");
    
    /**
     * Gets the "ConsultarLoteRpsEnvio" element
     */
    br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio getConsultarLoteRpsEnvio();
    
    /**
     * Sets the "ConsultarLoteRpsEnvio" element
     */
    void setConsultarLoteRpsEnvio(br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio consultarLoteRpsEnvio);
    
    /**
     * Appends and returns a new empty "ConsultarLoteRpsEnvio" element
     */
    br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio addNewConsultarLoteRpsEnvio();
    
    /**
     * An XML ConsultarLoteRpsEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface ConsultarLoteRpsEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConsultarLoteRpsEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s59BD2EBDCDFB9B15DB5AA6D9321B1694").resolveHandle("consultarloterpsenvio27a9elemtype");
        
        /**
         * Gets the "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador getPrestador();
        
        /**
         * Sets the "Prestador" element
         */
        void setPrestador(br.org.abrasf.nfse.TcIdentificacaoPrestador prestador);
        
        /**
         * Appends and returns a new empty "Prestador" element
         */
        br.org.abrasf.nfse.TcIdentificacaoPrestador addNewPrestador();
        
        /**
         * Gets the "Protocolo" element
         */
        java.lang.String getProtocolo();
        
        /**
         * Gets (as xml) the "Protocolo" element
         */
        br.org.abrasf.nfse.TsNumeroProtocolo xgetProtocolo();
        
        /**
         * Sets the "Protocolo" element
         */
        void setProtocolo(java.lang.String protocolo);
        
        /**
         * Sets (as xml) the "Protocolo" element
         */
        void xsetProtocolo(br.org.abrasf.nfse.TsNumeroProtocolo protocolo);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio newInstance() {
              return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument.ConsultarLoteRpsEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.ConsultarLoteRpsEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
