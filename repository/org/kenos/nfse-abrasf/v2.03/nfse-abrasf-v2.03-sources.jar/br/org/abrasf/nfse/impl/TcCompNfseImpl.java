/*
 * XML Type:  tcCompNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TcCompNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tcCompNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is a complex type.
 */
public class TcCompNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.TcCompNfse
{
    private static final long serialVersionUID = 1L;
    
    public TcCompNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NFSE$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Nfse");
    private static final javax.xml.namespace.QName NFSECANCELAMENTO$2 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseCancelamento");
    private static final javax.xml.namespace.QName NFSESUBSTITUICAO$4 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "NfseSubstituicao");
    
    
    /**
     * Gets the "Nfse" element
     */
    public br.org.abrasf.nfse.TcNfse getNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcNfse target = null;
            target = (br.org.abrasf.nfse.TcNfse)get_store().find_element_user(NFSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "Nfse" element
     */
    public void setNfse(br.org.abrasf.nfse.TcNfse nfse)
    {
        generatedSetterHelperImpl(nfse, NFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "Nfse" element
     */
    public br.org.abrasf.nfse.TcNfse addNewNfse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcNfse target = null;
            target = (br.org.abrasf.nfse.TcNfse)get_store().add_element_user(NFSE$0);
            return target;
        }
    }
    
    /**
     * Gets the "NfseCancelamento" element
     */
    public br.org.abrasf.nfse.TcCancelamentoNfse getNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TcCancelamentoNfse)get_store().find_element_user(NFSECANCELAMENTO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "NfseCancelamento" element
     */
    public boolean isSetNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NFSECANCELAMENTO$2) != 0;
        }
    }
    
    /**
     * Sets the "NfseCancelamento" element
     */
    public void setNfseCancelamento(br.org.abrasf.nfse.TcCancelamentoNfse nfseCancelamento)
    {
        generatedSetterHelperImpl(nfseCancelamento, NFSECANCELAMENTO$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NfseCancelamento" element
     */
    public br.org.abrasf.nfse.TcCancelamentoNfse addNewNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcCancelamentoNfse target = null;
            target = (br.org.abrasf.nfse.TcCancelamentoNfse)get_store().add_element_user(NFSECANCELAMENTO$2);
            return target;
        }
    }
    
    /**
     * Unsets the "NfseCancelamento" element
     */
    public void unsetNfseCancelamento()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NFSECANCELAMENTO$2, 0);
        }
    }
    
    /**
     * Gets the "NfseSubstituicao" element
     */
    public br.org.abrasf.nfse.TcSubstituicaoNfse getNfseSubstituicao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcSubstituicaoNfse target = null;
            target = (br.org.abrasf.nfse.TcSubstituicaoNfse)get_store().find_element_user(NFSESUBSTITUICAO$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "NfseSubstituicao" element
     */
    public boolean isSetNfseSubstituicao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NFSESUBSTITUICAO$4) != 0;
        }
    }
    
    /**
     * Sets the "NfseSubstituicao" element
     */
    public void setNfseSubstituicao(br.org.abrasf.nfse.TcSubstituicaoNfse nfseSubstituicao)
    {
        generatedSetterHelperImpl(nfseSubstituicao, NFSESUBSTITUICAO$4, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "NfseSubstituicao" element
     */
    public br.org.abrasf.nfse.TcSubstituicaoNfse addNewNfseSubstituicao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.TcSubstituicaoNfse target = null;
            target = (br.org.abrasf.nfse.TcSubstituicaoNfse)get_store().add_element_user(NFSESUBSTITUICAO$4);
            return target;
        }
    }
    
    /**
     * Unsets the "NfseSubstituicao" element
     */
    public void unsetNfseSubstituicao()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NFSESUBSTITUICAO$4, 0);
        }
    }
}
