/*
 * An XML document type.
 * Localname: SubstituirNfseEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.SubstituirNfseEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * A document containing one SubstituirNfseEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public class SubstituirNfseEnvioDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseEnvioDocument
{
    private static final long serialVersionUID = 1L;
    
    public SubstituirNfseEnvioDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSTITUIRNFSEENVIO$0 = 
        new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "SubstituirNfseEnvio");
    
    
    /**
     * Gets the "SubstituirNfseEnvio" element
     */
    public br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio getSubstituirNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio target = null;
            target = (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio)get_store().find_element_user(SUBSTITUIRNFSEENVIO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "SubstituirNfseEnvio" element
     */
    public void setSubstituirNfseEnvio(br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio substituirNfseEnvio)
    {
        generatedSetterHelperImpl(substituirNfseEnvio, SUBSTITUIRNFSEENVIO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
    }
    
    /**
     * Appends and returns a new empty "SubstituirNfseEnvio" element
     */
    public br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio addNewSubstituirNfseEnvio()
    {
        synchronized (monitor())
        {
            check_orphaned();
            br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio target = null;
            target = (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio)get_store().add_element_user(SUBSTITUIRNFSEENVIO$0);
            return target;
        }
    }
    /**
     * An XML SubstituirNfseEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public static class SubstituirNfseEnvioImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio
    {
        private static final long serialVersionUID = 1L;
        
        public SubstituirNfseEnvioImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SUBSTITUICAONFSE$0 = 
            new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "SubstituicaoNfse");
        private static final javax.xml.namespace.QName SIGNATURE$2 = 
            new javax.xml.namespace.QName("http://www.w3.org/2000/09/xmldsig#", "Signature");
        
        
        /**
         * Gets the "SubstituicaoNfse" element
         */
        public br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse getSubstituicaoNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse target = null;
                target = (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse)get_store().find_element_user(SUBSTITUICAONFSE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "SubstituicaoNfse" element
         */
        public void setSubstituicaoNfse(br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse substituicaoNfse)
        {
            generatedSetterHelperImpl(substituicaoNfse, SUBSTITUICAONFSE$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "SubstituicaoNfse" element
         */
        public br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse addNewSubstituicaoNfse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse target = null;
                target = (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse)get_store().add_element_user(SUBSTITUICAONFSE$0);
                return target;
            }
        }
        
        /**
         * Gets the "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType getSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().find_element_user(SIGNATURE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "Signature" element
         */
        public boolean isSetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SIGNATURE$2) != 0;
            }
        }
        
        /**
         * Sets the "Signature" element
         */
        public void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature)
        {
            generatedSetterHelperImpl(signature, SIGNATURE$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
        }
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        public org.w3.x2000.x09.xmldsig.SignatureType addNewSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.w3.x2000.x09.xmldsig.SignatureType target = null;
                target = (org.w3.x2000.x09.xmldsig.SignatureType)get_store().add_element_user(SIGNATURE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "Signature" element
         */
        public void unsetSignature()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SIGNATURE$2, 0);
            }
        }
        /**
         * An XML SubstituicaoNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public static class SubstituicaoNfseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse
        {
            private static final long serialVersionUID = 1L;
            
            public SubstituicaoNfseImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName PEDIDO$0 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Pedido");
            private static final javax.xml.namespace.QName RPS$2 = 
                new javax.xml.namespace.QName("http://www.abrasf.org.br/nfse.xsd", "Rps");
            private static final javax.xml.namespace.QName ID$4 = 
                new javax.xml.namespace.QName("", "Id");
            
            
            /**
             * Gets the "Pedido" element
             */
            public br.org.abrasf.nfse.TcPedidoCancelamento getPedido()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcPedidoCancelamento target = null;
                    target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().find_element_user(PEDIDO$0, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Pedido" element
             */
            public void setPedido(br.org.abrasf.nfse.TcPedidoCancelamento pedido)
            {
                generatedSetterHelperImpl(pedido, PEDIDO$0, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "Pedido" element
             */
            public br.org.abrasf.nfse.TcPedidoCancelamento addNewPedido()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcPedidoCancelamento target = null;
                    target = (br.org.abrasf.nfse.TcPedidoCancelamento)get_store().add_element_user(PEDIDO$0);
                    return target;
                }
            }
            
            /**
             * Gets the "Rps" element
             */
            public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getRps()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                    target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().find_element_user(RPS$2, 0);
                    if (target == null)
                    {
                      return null;
                    }
                    return target;
                }
            }
            
            /**
             * Sets the "Rps" element
             */
            public void setRps(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico rps)
            {
                generatedSetterHelperImpl(rps, RPS$2, 0, org.apache.xmlbeans.impl.values.XmlObjectBase.KIND_SETTERHELPER_SINGLETON);
            }
            
            /**
             * Appends and returns a new empty "Rps" element
             */
            public br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewRps()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico target = null;
                    target = (br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico)get_store().add_element_user(RPS$2);
                    return target;
                }
            }
            
            /**
             * Gets the "Id" attribute
             */
            public java.lang.String getId()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
                    if (target == null)
                    {
                      return null;
                    }
                    return target.getStringValue();
                }
            }
            
            /**
             * Gets (as xml) the "Id" attribute
             */
            public br.org.abrasf.nfse.TsIdTag xgetId()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsIdTag target = null;
                    target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
                    return target;
                }
            }
            
            /**
             * True if has "Id" attribute
             */
            public boolean isSetId()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().find_attribute_user(ID$4) != null;
                }
            }
            
            /**
             * Sets the "Id" attribute
             */
            public void setId(java.lang.String id)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.apache.xmlbeans.SimpleValue target = null;
                    target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(ID$4);
                    if (target == null)
                    {
                      target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(ID$4);
                    }
                    target.setStringValue(id);
                }
            }
            
            /**
             * Sets (as xml) the "Id" attribute
             */
            public void xsetId(br.org.abrasf.nfse.TsIdTag id)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    br.org.abrasf.nfse.TsIdTag target = null;
                    target = (br.org.abrasf.nfse.TsIdTag)get_store().find_attribute_user(ID$4);
                    if (target == null)
                    {
                      target = (br.org.abrasf.nfse.TsIdTag)get_store().add_attribute_user(ID$4);
                    }
                    target.set(id);
                }
            }
            
            /**
             * Unsets the "Id" attribute
             */
            public void unsetId()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_attribute(ID$4);
                }
            }
        }
    }
}
