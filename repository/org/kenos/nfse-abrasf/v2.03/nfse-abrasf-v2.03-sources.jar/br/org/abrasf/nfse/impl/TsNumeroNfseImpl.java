/*
 * XML Type:  tsNumeroNfse
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.TsNumeroNfse
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse.impl;
/**
 * An XML tsNumeroNfse(@http://www.abrasf.org.br/nfse.xsd).
 *
 * This is an atomic type that is a restriction of br.org.abrasf.nfse.TsNumeroNfse.
 */
public class TsNumeroNfseImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements br.org.abrasf.nfse.TsNumeroNfse
{
    private static final long serialVersionUID = 1L;
    
    public TsNumeroNfseImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TsNumeroNfseImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
