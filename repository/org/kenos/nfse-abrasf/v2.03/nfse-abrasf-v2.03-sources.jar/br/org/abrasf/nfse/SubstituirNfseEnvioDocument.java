/*
 * An XML document type.
 * Localname: SubstituirNfseEnvio
 * Namespace: http://www.abrasf.org.br/nfse.xsd
 * Java type: br.org.abrasf.nfse.SubstituirNfseEnvioDocument
 *
 * Automatically generated - do not modify.
 */
package br.org.abrasf.nfse;


/**
 * A document containing one SubstituirNfseEnvio(@http://www.abrasf.org.br/nfse.xsd) element.
 *
 * This is a complex type.
 */
public interface SubstituirNfseEnvioDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubstituirNfseEnvioDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("substituirnfseenvio3eb6doctype");
    
    /**
     * Gets the "SubstituirNfseEnvio" element
     */
    br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio getSubstituirNfseEnvio();
    
    /**
     * Sets the "SubstituirNfseEnvio" element
     */
    void setSubstituirNfseEnvio(br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio substituirNfseEnvio);
    
    /**
     * Appends and returns a new empty "SubstituirNfseEnvio" element
     */
    br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio addNewSubstituirNfseEnvio();
    
    /**
     * An XML SubstituirNfseEnvio(@http://www.abrasf.org.br/nfse.xsd).
     *
     * This is a complex type.
     */
    public interface SubstituirNfseEnvio extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubstituirNfseEnvio.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("substituirnfseenvio41b9elemtype");
        
        /**
         * Gets the "SubstituicaoNfse" element
         */
        br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse getSubstituicaoNfse();
        
        /**
         * Sets the "SubstituicaoNfse" element
         */
        void setSubstituicaoNfse(br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse substituicaoNfse);
        
        /**
         * Appends and returns a new empty "SubstituicaoNfse" element
         */
        br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse addNewSubstituicaoNfse();
        
        /**
         * Gets the "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType getSignature();
        
        /**
         * True if has "Signature" element
         */
        boolean isSetSignature();
        
        /**
         * Sets the "Signature" element
         */
        void setSignature(org.w3.x2000.x09.xmldsig.SignatureType signature);
        
        /**
         * Appends and returns a new empty "Signature" element
         */
        org.w3.x2000.x09.xmldsig.SignatureType addNewSignature();
        
        /**
         * Unsets the "Signature" element
         */
        void unsetSignature();
        
        /**
         * An XML SubstituicaoNfse(@http://www.abrasf.org.br/nfse.xsd).
         *
         * This is a complex type.
         */
        public interface SubstituicaoNfse extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubstituicaoNfse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s34EACA3C9C06E8D93CD56C11AC713C1F").resolveHandle("substituicaonfse1e90elemtype");
            
            /**
             * Gets the "Pedido" element
             */
            br.org.abrasf.nfse.TcPedidoCancelamento getPedido();
            
            /**
             * Sets the "Pedido" element
             */
            void setPedido(br.org.abrasf.nfse.TcPedidoCancelamento pedido);
            
            /**
             * Appends and returns a new empty "Pedido" element
             */
            br.org.abrasf.nfse.TcPedidoCancelamento addNewPedido();
            
            /**
             * Gets the "Rps" element
             */
            br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico getRps();
            
            /**
             * Sets the "Rps" element
             */
            void setRps(br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico rps);
            
            /**
             * Appends and returns a new empty "Rps" element
             */
            br.org.abrasf.nfse.TcDeclaracaoPrestacaoServico addNewRps();
            
            /**
             * Gets the "Id" attribute
             */
            java.lang.String getId();
            
            /**
             * Gets (as xml) the "Id" attribute
             */
            br.org.abrasf.nfse.TsIdTag xgetId();
            
            /**
             * True if has "Id" attribute
             */
            boolean isSetId();
            
            /**
             * Sets the "Id" attribute
             */
            void setId(java.lang.String id);
            
            /**
             * Sets (as xml) the "Id" attribute
             */
            void xsetId(br.org.abrasf.nfse.TsIdTag id);
            
            /**
             * Unsets the "Id" attribute
             */
            void unsetId();
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse newInstance() {
                  return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio.SubstituicaoNfse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio newInstance() {
              return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument.SubstituirNfseEnvio) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument newInstance() {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static br.org.abrasf.nfse.SubstituirNfseEnvioDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (br.org.abrasf.nfse.SubstituirNfseEnvioDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
